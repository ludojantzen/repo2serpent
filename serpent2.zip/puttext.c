/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : puttext.c                                      */
/*                                                                           */
/* Created:       2010/09/15 (JLe)                                           */
/* Last modified: 2012/05/20 (JLe)                                           */
/* Version:       2.1.6                                                       */
/*                                                                           */
/* Description: Stores text string in ASCII data block                       */
/*                                                                           */
/* Comments: - Adopted from Serpent 1.0.0                                    */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PutText:"

/*****************************************************************************/

long PutText(char *str)
{
  long ptr, memsize, n, nl;

  /* Avoid compiler warning */

  nl = -1;

  /* Check string */

  if (str == NULL)
    Die(FUNCTION_NAME, "Null pointer");
  else if (*str == EOF)
    Die(FUNCTION_NAME, "Empty string");
  else if ((nl = strlen(str)) < 1)
    Die(FUNCTION_NAME, "Empty string");

  /* Get pointer to free data */

  memsize = (long)RDB[DATA_ASCII_DATA_SIZE];
  ptr = memsize;

  /* Allocate memory for data */

  memsize = memsize + nl + 1;

  ASCII = (char *)Mem(MEM_REALLOC, ASCII, memsize*sizeof(char));

  /* Store data */

  for (n = 0; n < nl; n++)
    ASCII[ptr + n] = str[n];

  /* Terminate string */

  ASCII[ptr + n] = '\0';

  /* Update data block size */

  WDB[DATA_ASCII_DATA_SIZE] = (double)memsize;

  /* Calculate allocated memory in bytes */

  CalculateBytes();

  /* Return pointer */
  
  return ptr;
}

/*****************************************************************************/
