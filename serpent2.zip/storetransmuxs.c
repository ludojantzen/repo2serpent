/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : storetransmuxs.c                               */
/*                                                                           */
/* Created:       2011/06/08 (AIs)                                           */
/* Last modified: 2013/04/14 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Stores the one-group cross-sections and flux written by      */
/*              ClaculateTransmuXS to REACTION_PTR_TRANSMUXS to              */
/*              DEP_TRA_PS1/BOS/EOS and moves BOS to PS1 when needed         */
/*                                                                           */
/* Comments: This should maybe be part of CalculateTransmuXS                 */
/*           parempi että pidetään erillisenä aliohjelmana niin on selkeämpi */
/*           (JLe)                                                           */
/*                                                                           */
/* input: mat = pointer to material for which to store the values            */
/*        step = #step in this intervall                                     */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "StoreTransmuXS:"

/*****************************************************************************/

void StoreTransmuXS(long mat, long step, long type, long id)
{
  long dep, ptr, rea;
  double flx, xs;

#ifdef STAB_BURN

  /* NEW (AIs) */

  double old_ave_flux, new_ave_flux, old_ave_xs;
  double n;

  /* avoid compiler warnings */

  old_ave_flux=-INFTY; new_ave_flux=-INFTY; old_ave_xs=-INFTY; n=-INFTY;

#endif

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check burnup mode and burn flag */

  if (((long)RDB[DATA_BURNUP_CALCULATION_MODE] == NO) ||
      (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)))
    return;

  /* Get flux */

  if ((type != DEP_STEP_DEC_STEP) && (type != DEP_STEP_DEC_TOT))
    {
      ptr = (long)RDB[mat + MATERIAL_PTR_BURN_FLUX];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      flx = Mean(ptr, 0);
    }
  else
    flx = 0.0;

  /* Divide by volume (may be zero if reprocessing is applied) */

  if (RDB[mat + MATERIAL_VOLUME] > 0.0)
    flx = flx/RDB[mat + MATERIAL_VOLUME];
  else if (flx > 0.0)
    Die(FUNCTION_NAME, "Zero volume (%s)", GetText(mat + MATERIAL_PTR_NAME));

  /* Check value */

  CheckValue(FUNCTION_NAME, "flx", "", flx, 0.0, INFTY);

  /* store value */

  if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    {
      /* Predictor */

      if (step == 0)
        WDB[mat + MATERIAL_BURN_FLUX_PS1] = -INFTY; 
      else
        WDB[mat + MATERIAL_BURN_FLUX_PS1] = RDB[mat + MATERIAL_BURN_FLUX_BOS];
      
      WDB[mat + MATERIAL_BURN_FLUX_BOS] = flx;
      WDB[mat + MATERIAL_BURN_FLUX_EOS] = -INFTY; 
    }
  else
    {
      /* Corrector */

#ifdef STAB_BURN

      old_ave_flux = WDB[mat + MATERIAL_BURN_FLUX_EOS];

      n=WDB[DATA_BURN_CI_I]+1.0;

      if ((long)WDB[DATA_BURN_CI_I] == 0)
        WDB[mat + MATERIAL_BURN_FLUX_EOS] = flx;
      else
        WDB[mat + MATERIAL_BURN_FLUX_EOS] = 
          (n-1.0)/n*old_ave_flux + (1.0/n)*flx;

      new_ave_flux = WDB[mat + MATERIAL_BURN_FLUX_EOS];

#else

      WDB[mat + MATERIAL_BURN_FLUX_EOS] = flx;

#endif

    }

  /**************************************************************************/

  /***** Transmutation list *************************************************/

  /* Pointer to transmutation list */
  
  dep = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST];
  CheckPointer(FUNCTION_NAME, "(dep)", DATA_ARRAY, dep);

  /* Loop over list */

  while (dep > VALID_PTR)
    {
      /* Get the reaction and its XS */

      if ((type != DEP_STEP_DEC_STEP) && (type != DEP_STEP_DEC_TOT))
	{
	  rea = (long)RDB[dep + DEP_TRA_PTR_REA];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  xs = TestValuePair(rea + REACTION_PTR_TRANSMUXS, mat, id);
	}
      else
	xs = 0.0;

      if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
        {
          /* Predictor */

          if (step == 0)
            WDB[dep + DEP_TRA_PS1] = -INFTY; 
          else
            WDB[dep + DEP_TRA_PS1] = RDB[dep + DEP_TRA_BOS];

          WDB[dep + DEP_TRA_BOS] = xs;
          WDB[dep + DEP_TRA_EOS] = -INFTY; 
        }
      else
        {
          /* Corrector */

#ifdef STAB_BURN

          old_ave_xs =  WDB[dep + DEP_TRA_EOS];
	  
          if ((long)WDB[DATA_BURN_CI_I] == 0)
            WDB[dep + DEP_TRA_EOS] = xs;
          else
            WDB[dep + DEP_TRA_EOS] = 
              ((n-1.0)*old_ave_flux*old_ave_xs + flx*xs) / (new_ave_flux*n);
	  
#else
	  
          WDB[dep + DEP_TRA_EOS] = xs;
	  
#endif

        }

      /* Next reaction */

      dep = NextItem(dep);
    }

  /**************************************************************************/

  /***** Fission list *******************************************************/

  /* Pointer to fission list (pointteri voi olla null jos materiaali */
  /* on ei-fissiili) */

  dep = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST];
  
  /* Loop over list */

  while (dep > VALID_PTR)
    {
       /* Get the reaction and its XS */

      if ((type != DEP_STEP_DEC_STEP) && (type != DEP_STEP_DEC_TOT))
	{
	  rea = (long)RDB[dep + DEP_TRA_PTR_REA];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  xs = TestValuePair(rea + REACTION_PTR_TRANSMUXS, mat, id);
	}
      else
	xs = 0.0;

      if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
        {
          /* Predictor */

          if (step == 0)
            WDB[dep + DEP_TRA_PS1] = -INFTY;
          else
            WDB[dep + DEP_TRA_PS1] = RDB[dep + DEP_TRA_BOS];

          WDB[dep + DEP_TRA_BOS] = xs;
          WDB[dep + DEP_TRA_EOS] = -INFTY;
        }
      else
        {
          /* Corrector */

#ifdef STAB_BURN

          old_ave_xs =  WDB[dep + DEP_TRA_EOS];

          if ((long)WDB[DATA_BURN_CI_I] == 0)
            WDB[dep + DEP_TRA_EOS] = xs;
          else
            WDB[dep + DEP_TRA_EOS] = 
              ((n-1.0)*old_ave_flux*old_ave_xs + flx*xs) / (new_ave_flux*n);
	  
#else

          WDB[dep + DEP_TRA_EOS] = xs;

#endif
        }

      /* Next reaction */

      dep = NextItem(dep);
    }

  /**************************************************************************/
}

/*****************************************************************************/
