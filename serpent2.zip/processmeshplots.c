/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processmeshplots.c                             */
/*                                                                           */
/* Created:       2011/03/20 (JLe)                                           */
/* Last modified: 2013/03/18 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Processes mesh plots                                         */
/*                                                                           */
/* Comments: - Tässä varaillaan muistia vähän tarpeettomasti jos tyyppi on   */
/*             1-arvoinen jakauma.                                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessMeshPlots:"

/*****************************************************************************/

void ProcessMeshPlots()
{
  long mpl, nx, ny, ptr, n, det, ax, type, ndis, div, sz;
  double xmin, xmax, ymin, ymax, zmin, zmax, lims[6];
  char tmpstr[MAX_STR];

  /* Check if mesh plots are defined */

  if ((long)RDB[DATA_PTR_MPL0] < VALID_PTR)
    return;

  fprintf(out, "Processing mesh plots...\n");

  /* Loop over plots and calculate total size */

  sz = 0;

  mpl = (long)RDB[DATA_PTR_MPL0];
  while(mpl > VALID_PTR)
    {
      /* Get size */

      nx = (long)RDB[mpl + MPL_NX];
      ny = (long)RDB[mpl + MPL_NY];

      /* Get number of distributions and divider flag */

      ndis = (long)RDB[mpl + MPL_NDIST];
      div = (long)WDB[mpl + MPL_DIV];

      /* Add to size */

      if (div == NO)
	sz = sz + ndis*(nx*ny + 1);
      else
	sz = sz + 2*ndis*(nx*ny + 1);

      /* Next plot */

      mpl = NextItem(mpl);
    }

  /* Allocate memory for data */
  
  PreallocMem(sz + 1, RES2_ARRAY);

  /* Reset counter */

  n = 1;

  /* Loop over plots */

  mpl = (long)RDB[DATA_PTR_MPL0];
  while(mpl > VALID_PTR)
    {
      /* Get limits */

      if ((xmin = RDB[mpl + MPL_XMIN]) == -INFTY)
	xmin = RDB[DATA_GEOM_MINX];

      if ((xmax = RDB[mpl + MPL_XMAX]) == INFTY)
	xmax= RDB[DATA_GEOM_MAXX];

      if ((ymin = RDB[mpl + MPL_YMIN]) == -INFTY)
	ymin = RDB[DATA_GEOM_MINY];

      if ((ymax = RDB[mpl + MPL_YMAX]) == INFTY)
	ymax= RDB[DATA_GEOM_MAXY];

      if ((zmin = RDB[mpl + MPL_ZMIN]) == -INFTY)
	zmin = RDB[DATA_GEOM_MINZ];

      if ((zmax = RDB[mpl + MPL_ZMAX]) == INFTY)
	zmax= RDB[DATA_GEOM_MAXZ];

      /* Get type */
    
      type = (long)RDB[mpl + MPL_TYPE];

      /* Get number of distributions and divider flag */

      ndis = (long)RDB[mpl + MPL_NDIST];
      div = (long)WDB[mpl + MPL_DIV];

      /* Get axis and set dimensions */

      ax = (long)RDB[mpl + MPL_AX];

      /* Check is and set coordinates */

      if (ax == 1)
	{
	  /* distribution in yz-plane */
	      
	  WDB[mpl + MPL_XMIN] = ymin;
	  WDB[mpl + MPL_XMAX] = ymax;

	  WDB[mpl + MPL_YMIN] = zmin;
	  WDB[mpl + MPL_YMAX] = zmax;

	  WDB[mpl + MPL_ZMIN] = xmin;
	  WDB[mpl + MPL_ZMAX] = xmax;
	}
      else if (ax == 2)
	{
	  /* distribution in xz-plane */
	  
	  WDB[mpl + MPL_XMIN] = xmin;
	  WDB[mpl + MPL_XMAX] = xmax;

	  WDB[mpl + MPL_YMIN] = zmin;
	  WDB[mpl + MPL_YMAX] = zmax;

	  WDB[mpl + MPL_ZMIN] = ymin;
	  WDB[mpl + MPL_ZMAX] = ymax;
	}
      else
	{
	  /* distribution in xy-plane */
	  
	  WDB[mpl + MPL_XMIN] = xmin;
	  WDB[mpl + MPL_XMAX] = xmax;

	  WDB[mpl + MPL_YMIN] = ymin;
	  WDB[mpl + MPL_YMAX] = ymax;

	  WDB[mpl + MPL_ZMIN] = zmin;
	  WDB[mpl + MPL_ZMAX] = zmax;
	}

      /* Get size */

      nx = (long)RDB[mpl + MPL_NX];
      ny = (long)RDB[mpl + MPL_NY];

      /* Put mesh variables */

      lims[0] = RDB[mpl + MPL_XMIN];
      lims[1] = RDB[mpl + MPL_XMAX];
      lims[2] = RDB[mpl + MPL_YMIN];
      lims[3] = RDB[mpl + MPL_YMAX];
      lims[4] = RDB[mpl + MPL_ZMIN];
      lims[5] = RDB[mpl + MPL_ZMAX];
      
      /* Allocate memory */

      ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, nx, ny, 1,
		       lims);

      /* Put pointer */

      WDB[mpl + MPL_PTR_VAL1] = (double)ptr;

      /* Check divider flag */

      if (div == YES)
	{
	  /* Allocate memory */

	  ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, nx, ny, 1,
			   lims);

	  /* Put pointer */

	  WDB[mpl + MPL_PTR_DIV1] = (double)ptr;
	}

      /* Check double distribution */
      
      if (ndis == 2)
	{
	  /* Allocate memory */

	  ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, nx, ny, 1,
			   lims);

	  /* Put pointer */
	  
	  WDB[mpl + MPL_PTR_VAL2] = (double)ptr;

	  /* Check divider flag */

	  if (div == YES)
	    {
	      /* Allocate memory */
	      
	      ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, nx, ny, 
			       1, lims);
	      
	      /* Put pointer */
	      
	      WDB[mpl + MPL_PTR_DIV2] = (double)ptr;
	    }
	}

      /* Set file name */

      sprintf(tmpstr, "%s_mesh%ld", GetText(DATA_PTR_INPUT_FNAME), n++);
      WDB[mpl + MPL_PTR_FNAME] = (double)PutText(tmpstr);

      /* Link detector */

      if ((type == MPL_TYPE_DET) ||
	  (type == MPL_TYPE_DET_IMP))
	{
	  /* Find detector */
	  
	  det = RDB[DATA_PTR_DET0];
	  CheckPointer(FUNCTION_NAME, "(det)", DATA_ARRAY, det);

	  if ((det = SeekListStr(det, DET_PTR_NAME, 
				 GetText(mpl + MPL_PTR_DET))) < VALID_PTR)
	    Error(mpl, "Detector %s not defined", GetText(mpl + MPL_PTR_DET));
	  
	  /* Set pointer */

	  WDB[mpl + MPL_PTR_DET] = (double)det;
	}

      /* Switch history lists on if importance type */

      if (type == MPL_TYPE_DET_IMP)
	WDB[DATA_HIST_LIST_SIZE] = fabs(RDB[DATA_HIST_LIST_SIZE]);
    
      /* Next plot */

      mpl = NextItem(mpl);
    }

  fprintf(out, "OK.\n\n");
}

/*****************************************************************************/
