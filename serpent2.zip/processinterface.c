/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processinterface.c                             */
/*                                                                           */
/* Created:       2012/02/14 (JLe)                                           */
/* Last modified: 2013/04/03 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Processes multi-physics interfaces                           */
/*                                                                           */
/* Comments: - Stats are allocated in allocinterfacestat.c                   */
/*                                                                           */
/*           - Polttoaineinterfacen aksiaalijako lisätty 3.4.2013            */ 
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessInterface:"

/*****************************************************************************/

void ProcessInterface()
{
  long loc0, loc1, loc2, mat0, mat, ptr, found, msh, dim, nx, ny, nz, np, n;
  long uni, nst, reg, cell, axi;
  double x, y, z, rad, xmin, xmax, ymin, ymax, zmin, zmax, dmax, f;
  double lims[6];

  /* Loop over interfaces */

  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /***********************************************************************/

      /***** Link material ***************************************************/

      /* Check material pointer (not set in all types) */

      if ((long)RDB[loc0 + IFC_PTR_MAT] < VALID_PTR)
	{
	  /* Check type just to be sure */

	  if ((long)RDB[loc0 + IFC_TYPE] != IFC_TYPE_FUEP)
	    Die(FUNCTION_NAME, "material poiner not set");
	}
      else
	{
	  /* Reset found flag */

	  found = NO;
	  
	  /* Loop over materials and find match */
	  
	  mat0 = (long)RDB[DATA_PTR_M0];
	  while (mat0 > VALID_PTR)
	    {
	      /* Reset pointer */
	      
	      mat = -1;
	      
	      /* Compare name */
	      
	      if (CompareStr(mat0 + MATERIAL_PTR_NAME, loc0 + IFC_PTR_MAT))
		mat = mat0;
	      
	      /* Check if material was divided for burnup calculation */
	      
	      if ((ptr = (long)RDB[mat0 + MATERIAL_DIV_PTR_PARENT]) 
		  > VALID_PTR)
		if (CompareStr(ptr + MATERIAL_PTR_NAME, loc0 + IFC_PTR_MAT))
		  mat = mat0;
	      
	      /* Check material */
	      
	      if (mat > VALID_PTR)
		{
		  /* Link interface and put flag */
		  
		  WDB[mat + MATERIAL_PTR_IFC] = (double)loc0;
		  WDB[mat + MATERIAL_USE_IFC] = (double)YES;		  

		  /* Check mode */
		  
		  if (1 != 2)
		    {
		      /* Densities given, override material density */
		      
		      if (RDB[loc0 + IFC_MAX_DENSITY] != 0.0)
			WDB[mat + MATERIAL_ADENS] = 
			  RDB[loc0 + IFC_MAX_DENSITY];
		      else if ((long)RDB[loc0 + IFC_TYPE] != IFC_TYPE_FUNC)
			Error(loc0, "No non-zero densities in distribution"); 
		    }
		  else
		    {
		      /* Density factors given, override maximum density */
		      
		      if (RDB[loc0 + IFC_MAX_DENSITY] > 0.0)
			WDB[loc0 + IFC_MAX_DENSITY] = 1.0;
		      else if ((long)RDB[loc0 + IFC_TYPE] != IFC_TYPE_FUNC)
			Error(loc0, 
			      "No positive density factors in distribution");
		    }
		  
		  /* Check if temperature is given */
		  
		  if (RDB[loc0 + IFC_MAX_TEMP] > 0.0)
		    {
		      /* Put maximum temperature */
		      
		      if (RDB[loc0 + IFC_MAX_TEMP] > 
			  RDB[mat + MATERIAL_ETTM_TMAX])
			WDB[mat + MATERIAL_ETTM_TMAX] = 
			  RDB[loc0 + IFC_MAX_TEMP];

		      /* Put minimum temperature */
		      
		      if (RDB[loc0 + IFC_MIN_TEMP] < 
			  RDB[mat + MATERIAL_ETTM_TMIN])
			WDB[mat + MATERIAL_ETTM_TMIN] = 
			  RDB[loc0 + IFC_MIN_TEMP];
		      
		      /* Set on-the-fly Doppler-broadening mode */
		      
		      WDB[mat + MATERIAL_ETTM_MODE] = (double)YES;
		    }

		  /* Set found flag */
		  
		  found = YES;
		}
	      
	      /* Next material */
	      
	      mat0 = NextItem(mat0);
	    }
      
	  /* Check that material was found */
      
	  if (found == NO)
	    Error(loc0, "Material %s in distribution file not defined", 
		  GetText(loc0 + IFC_PTR_MAT));
      	}

      /***********************************************************************/

      /***** Processing for each interface type ******************************/
      
      /* Check interface type type */

      if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_PT_AVG)
	{
	  /*******************************************************************/

	  /***** Average of points *******************************************/

	  /* Get limits */

	  xmin = RDB[loc0 + IFC_MESH_XMIN];
	  xmax = RDB[loc0 + IFC_MESH_XMAX];
	  ymin = RDB[loc0 + IFC_MESH_YMIN];
	  ymax = RDB[loc0 + IFC_MESH_YMAX];
	  zmin = RDB[loc0 + IFC_MESH_ZMIN];
	  zmax = RDB[loc0 + IFC_MESH_ZMAX];

	  /* Get exclusion radius and dimension */

	  rad = RDB[loc0 + IFC_EXCL_RAD];
	  dim = (long)RDB[loc0 + IFC_DIM];

	  /* Calculate search mesh size */

	  if ((nx = (long)(xmax - xmin)/(2.0*rad)) < 1)
	    nx = 1;

	  if ((ny = (long)(ymax - ymin)/(2.0*rad)) < 1)
	    ny = 1;

	  if ((nz = (long)(zmax - zmin)/(2.0*rad)) < 1)
	    nz = 1;
	  
	  /* Adjust boundaries */
      
	  xmin = xmin - 1E-6;
	  xmax = xmax + 1E-6;
	  ymin = ymin - 1E-6;
	  ymax = ymax + 1E-6;
	  zmin = zmin - 1E-6;
	  zmax = zmax + 1E-6;
	  
	  /* 1D and 2D distributions */
      
	  if (dim == 1)
	    {
	      xmin = -INFTY;
	      xmax = INFTY;
	      nx = 1;
	      
	      ymin = -INFTY;
	      ymax = INFTY;
	      ny = 1;
	    }
	  else if (dim == 2)
	    {
	      zmin = -INFTY;
	      zmax = INFTY;
	      nz = 1;
	    }

	  /* Get maximum density */

	  if ((dmax = RDB[loc0 + IFC_MAX_DENSITY]) == 0.0)
	    Die(FUNCTION_NAME, "Zero maximum density");

	  /* Put mesh variables */

	  lims[0] = xmin;
	  lims[1] = xmax;
	  lims[2] = ymin;
	  lims[3] = ymax;
	  lims[4] = zmin;
	  lims[5] = zmax;
	  
	  /* Create mesh structure */
      
	  msh = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_PTR, 50, 50, 50, 
			   lims);
	  
	  /* Put pointer */
      
	  WDB[loc0 + IFC_PTR_SEARCH_MESH] = (double)msh;

	  /* Loop over points */
	  
	  loc1 = (long)RDB[loc0 + IFC_PTR_POINTS];
	  while (loc1 > VALID_PTR)
	    {
	      /* Get coordinates */
	      
	      x = RDB[loc1 + IFC_PT_X];
	      y = RDB[loc1 + IFC_PT_Y];
	      z = RDB[loc1 + IFC_PT_Z];
	      
	      /* Add point in search mesh */

	      AddSearchMesh(msh, loc1, x - rad, x + rad, y - rad, y + rad, 
			    z - rad, z + rad);	 
     
	      /* Convert densities to density factors */

	      if (RDB[loc1 + IFC_PT_DF]*dmax < 0.0)
		Error(loc0, "Inconsistent densities given in distribution");
	      else
		WDB[loc1 + IFC_PT_DF] = RDB[loc1 + IFC_PT_DF]/dmax;

	      /* Next point */

	      loc1 = NextItem(loc1);
	    }	  
	  
	  /********************************************************************/
	}
      else if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_MESH)
	{
	  /*******************************************************************/

	  /***** Cartesian mesh-based ****************************************/

	  /* Get maximum density */

	  if ((dmax = RDB[loc0 + IFC_MAX_DENSITY]) == 0.0)
	    Die(FUNCTION_NAME, "Zero maximum density");

	  /* Get pointer to mesh */

	  msh = (long)RDB[loc0 + IFC_PTR_SEARCH_MESH];
	  CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

	  /* Get size */

	  np = (long)(RDB[msh + MESH_N0]*RDB[msh + MESH_N1]*RDB[msh + MESH_N2]);
	  CheckValue(FUNCTION_NAME, "np", "", np, 1, 100000000);

	  /* Loop over cells */

	  for (n = 0; n < np; n++)
	    {
	      /* Get mesh pointer */
		      
	      ptr = (long)RDB[msh + MESH_PTR_PTR] + n;
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      /* Get pointer to contents */

	      loc1 = (long)RDB[ptr];
	      CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

	      /* Convert densities to density factors */

	      if (RDB[loc1 + IFC_MSH_DF]*dmax < 0.0)
		Error(loc0, "Inconsistent densities given in distribution");
	      else
		WDB[loc1 + IFC_MSH_DF] = RDB[loc1 + IFC_MSH_DF]/dmax;
	    }	  
	  
	  /********************************************************************/
	}
      else if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_CGNS)
	{
	  /********************************************************************/

	  /***** Unstructured CGNS-type mesh **********************************/

	  /* Get limits */

	  xmin = RDB[loc0 + IFC_MESH_XMIN];
	  xmax = RDB[loc0 + IFC_MESH_XMAX];
	  ymin = RDB[loc0 + IFC_MESH_YMIN];
	  ymax = RDB[loc0 + IFC_MESH_YMAX];
	  zmin = RDB[loc0 + IFC_MESH_ZMIN];
	  zmax = RDB[loc0 + IFC_MESH_ZMAX];

	  /* Check boundaries */

	  if ((xmin >= xmax) || (ymin >= ymax) || (zmin >= zmax))
	    Error(loc0, "Structure is not 3D");

	  /* Adjust boundaries */
      
	  xmin = xmin - 1E-6;
	  xmax = xmax + 1E-6;
	  ymin = ymin - 1E-6;
	  ymax = ymax + 1E-6;
	  zmin = zmin - 1E-6;
	  zmax = zmax + 1E-6;

	  xmin = -600;
	  xmax =  600;
	  ymin = -600;
	  ymax =  600;
	  zmin = -600;
	  zmax =  600;

	  /* Put mesh variables */

	  lims[0] = xmin;
	  lims[1] = xmax;
	  lims[2] = ymin;
	  lims[3] = ymax;
	  lims[4] = zmin;
	  lims[5] = zmax;
	  
	  /* Create mesh structure */
      
	  msh = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_PTR, 50, 50, 50, 
			   lims);
	  
	  /* Put pointer */
      
	  WDB[loc0 + IFC_PTR_SEARCH_MESH] = (double)msh;

	  /* Get maximum density */

	  if ((dmax = RDB[loc0 + IFC_MAX_DENSITY]) == 0.0)
	    Die(FUNCTION_NAME, "Zero maximum density");

	  /* Loop over CGNS cells */

	  loc1 = (long)RDB[loc0 + IFC_PTR_CGNS];
	  while (loc1 > VALID_PTR)
	    {
	      /* Get limits */

	      xmin = RDB[loc1 + IFC_CGNS_XMIN];
	      xmax = RDB[loc1 + IFC_CGNS_XMAX];
	      ymin = RDB[loc1 + IFC_CGNS_YMIN];
	      ymax = RDB[loc1 + IFC_CGNS_YMAX];
	      zmin = RDB[loc1 + IFC_CGNS_ZMIN];
	      zmax = RDB[loc1 + IFC_CGNS_ZMAX];

	      /* Add to search mesh */

	      AddSearchMesh(msh, loc1, xmin, xmax, ymin, ymax, zmin, zmax);

	      /* Convert densities to density factors */

	      if (RDB[loc1 + IFC_CGNS_DF]*dmax < 0.0)
		Error(loc0, "Inconsistent densities given in distribution");
	      else
		WDB[loc1 + IFC_CGNS_DF] = RDB[loc1 + IFC_CGNS_DF]/dmax;

	      /* Next */

	      loc1 = NextItem(loc1);
	    }

	  /*******************************************************************/
	}
      else if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_FUEP)
	{
	  /********************************************************************/

	  /***** Interface for fuel performance codes *************************/

	  /* Pointer to structure */

	  loc1 = (long)RDB[loc0 + IFC_PTR_FUEP];
	  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

	  /* Loop */

	  while (loc1 > VALID_PTR)
	    {
	      /* Find pin universe */
	      
	      uni = (long)RDB[DATA_PTR_U0];
	      while (uni > VALID_PTR)
		{
		  /* Compare */
		  
		  if (CompareStr(uni + UNIVERSE_PTR_NAME, 
				 loc1 + IFC_FUEP_PTR_UNI))
		    break;
		  
		  /* Next */
		  
		  uni = NextItem(uni);
		}
	      
	      /* Check pointer */
	      
	      if (uni < VALID_PTR)
		Error(loc0, "Universe %s does not exist", 
		      GetText(loc1 + IFC_FUEP_PTR_UNI));
	      
	      /* Check universe type (tää testaa vaan että on nesti, ei */
	      /* sitä onko pinnan tyyppinä sylinteri) */

	      if ((long)RDB[uni + UNIVERSE_TYPE] != UNIVERSE_TYPE_NEST)
		Error(loc0, "Universe %s is not pin type", 
		      GetText(uni + UNIVERSE_PTR_NAME));
	      
	      /* Check that universe is not associated with another ifc */

	      if ((long)RDB[uni + UNIVERSE_PTR_IFC_FUEP] > VALID_PTR)
		Error(loc0, "Multiple interfaces for universe %s",
		      GetText(uni + UNIVERSE_PTR_NAME));

	      /* Put pointers */
	      
	      WDB[loc1 + IFC_FUEP_PTR_UNI] = (double)uni;
	      WDB[uni + UNIVERSE_PTR_IFC_FUEP] = (double)loc1;

	      /* Get pointer to nest structure */
	      
	      nst = (long)RDB[uni + UNIVERSE_PTR_NEST];
	      CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

	      /* Pointer to axial zones */

	      if ((axi = (long)RDB[loc1 + IFC_FUEP_PTR_AX]) < VALID_PTR)
		Error(loc0, "Interface has no axial zones");	      
	      
	      /* Loop over axial zones */

	      while(axi > VALID_PTR)
		{
		  /* Pointer to radial zones */
		  
		  if ((loc2 = (long)RDB[axi + IFC_FUEP_AX_PTR_RAD]) < VALID_PTR)
		    Error(loc0, "Interface has no radial zones");

		  /* Check order (hot) */

		  rad = 0.0;
		  while (loc2 > VALID_PTR)
		    {
		      /* Compare radii */

		      if (RDB[loc2 + IFC_FUEP_RAD_HOT_R2] > rad)
			rad = RDB[loc2 + IFC_FUEP_RAD_HOT_R2];
		      else
			Error(loc0, "Radii must be in ascending order");

		      /* Next */

		      loc2 = NextItem(loc2);
		    }
		  
		  /* Check order (cold) */

		  rad = 0.0;
		  while (loc2 > VALID_PTR)
		    {
		      /* Compare radii */
		  
		      if (RDB[loc2 + IFC_FUEP_RAD_COLD_R2] > rad)
			rad = RDB[loc2 + IFC_FUEP_RAD_COLD_R2];
		      else
			Error(loc0, "Radii must be in ascending order");

		      /* Next */

		      loc2 = NextItem(loc2);
		    }
		
		  /* Link materials */

		  mat = -1;
		  loc2 = (long)RDB[axi + IFC_FUEP_AX_PTR_RAD];
		  while (loc2 > VALID_PTR)
		    {
		      /* Loop over nest regions */
		  
		      reg = (long)RDB[nst + NEST_PTR_REGIONS];
		      while (reg > VALID_PTR)
			{
			  /* Pointer to cell */

			  cell = (long)RDB[reg + NEST_REG_PTR_CELL];
			  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, 
				       cell);

			  /* Pointer to material */

			  if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > 
			      VALID_PTR)
			    {
			      /* Compare */
			      
			      if (CompareStr(mat + MATERIAL_PTR_NAME, 
					     loc2 + IFC_FUEP_RAD_PTR_MAT))
				break;
			    }
			  else
			    Error(loc0, 
				  "Void pin regions not allowed (miksei?)");
			  
			  /* Next region */

			  reg = NextItem(reg);
			}
		      
		      /* Check from region pointer that material was found */

		      if (reg < VALID_PTR)
			Error(loc0, "Material %s is not defined",
			      GetText(loc2 + IFC_FUEP_RAD_PTR_MAT));

		      /* Put region and materil pointer */

		      WDB[loc2 + IFC_FUEP_RAD_PTR_REG] = (double)reg;
		      WDB[loc2 + IFC_FUEP_RAD_PTR_MAT] = (double)mat;

		      /* Put flag */

		      WDB[mat + MATERIAL_USE_IFC] = (double)YES;

		      /* Check temperature */

		      if (RDB[loc2 + IFC_FUEP_RAD_TEMP] > 0.0)
			{
			  /* Adjust material temperatures */
		      
			  if (RDB[loc2 + IFC_FUEP_RAD_TEMP] > 
			      RDB[mat + MATERIAL_ETTM_TMAX])
			    WDB[mat + MATERIAL_ETTM_TMAX] = 
			      RDB[loc2 + IFC_FUEP_RAD_TEMP];
			  
			  if (RDB[loc2 + IFC_FUEP_RAD_TEMP] < 
			      RDB[mat + MATERIAL_ETTM_TMIN])
			    WDB[mat + MATERIAL_ETTM_TMIN] = 
			      RDB[loc2 + IFC_FUEP_RAD_TEMP];
			}

		      /* Set on-the-fly Doppler-broadening mode */
		  
		      WDB[mat + MATERIAL_ETTM_MODE] = (double)YES;
		  
		      /* Next radial zone */
		      
		      loc2 = NextItem(loc2);
		    }
		  
		  /* Next axial zone */

		  axi = NextItem(axi);
		}

	      /* Next pin */

	      loc1 = NextItem(loc1);
	    }

	  /********************************************************************/
	}
      else
	Die(FUNCTION_NAME, "Invalid interface type");

      /* Next interface */

      loc0 = NextItem(loc0);
    }

  /***************************************************************************/

  /***** Additional processing for fuep type *********************************/

  /* Loop over interfaces */

  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Loop over pins */

      loc1 = (long)RDB[loc0 + IFC_PTR_FUEP];
      while (loc1 > VALID_PTR)
	{
	  /* Loop over axial zones */

	  axi = (long)RDB[loc1 + IFC_FUEP_PTR_AX];
	  while(axi > VALID_PTR)
	    {
	      /* Loop over radial zones */
	      
	      loc2 = (long)RDB[axi + IFC_FUEP_AX_PTR_RAD];
	      while (loc2 > VALID_PTR)
		{
		  /* Calculate square radius */
		  
		  WDB[loc2 + IFC_FUEP_RAD_HOT_R2] = 
		    RDB[loc2 + IFC_FUEP_RAD_HOT_R2]*
		    RDB[loc2 + IFC_FUEP_RAD_HOT_R2]; 

		  WDB[loc2 + IFC_FUEP_RAD_COLD_R2] = 
		    RDB[loc2 + IFC_FUEP_RAD_COLD_R2]*
		    RDB[loc2 + IFC_FUEP_RAD_COLD_R2]; 
		  
		  /* Calculate density factor */

		  if((ptr = PrevItem(loc2)) > VALID_PTR)
		    {
		      f = (RDB[loc2 + IFC_FUEP_RAD_COLD_R2] - 
			   RDB[ptr + IFC_FUEP_RAD_COLD_R2])/
			(RDB[loc2 + IFC_FUEP_RAD_HOT_R2] - 
			 RDB[ptr + IFC_FUEP_RAD_HOT_R2]);
		    }
		  else
		    {
		      f = RDB[loc2 + IFC_FUEP_RAD_COLD_R2]/
			RDB[loc2 + IFC_FUEP_RAD_HOT_R2];
		    }

		  /* Check value */
		  
		  if (f > 1.0)
		    {
		      Warn(FUNCTION_NAME, 
			   "Density factor %1.2f larger than 1.0, setting 1.0", 
			   f);
		      f = 1.0;
		    }

		  /* Put value */

		  WDB[loc2 + IFC_FUEP_RAD_DF] = f;

		  /* Next radial zone */
	      
		  loc2 = NextItem(loc2);
		}

	      /* Next axial zone */

	      axi = NextItem(axi);
	    }
	      
	  /* Next pin */
	  
	  loc1 = NextItem(loc1);
	}

      /* Next interface */

      loc0 = NextItem(loc0);
    }
  
  /***************************************************************************/
}

/*****************************************************************************/
