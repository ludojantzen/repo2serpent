/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scoredf.c                                      */
/*                                                                           */
/* Created:       2013/03/05 (JLe)                                           */
/* Last modified: 2013/03/07 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Scores fluxes and currends used for calculating              */
/*              discontinuity factors                                        */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreDF:"

/*****************************************************************************/

void ScoreDF(double x0, double y0, double z0, double u, double v, double w, 
	     double lmax, double E, double wgt, long id)
{
  long adf, gcu, ntot, ng, surf, type, ptr, np, in0, in1, n1, n2, m1, m2;
  double d, l, x, y, z, mu, u0, v0, w0;
  
  /* Check that group constants are calculated */

  if ((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;

  /* Check if active cycle */

  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP])
    return;

  /* Check if discontinuity factors are calculated and get pointer */
  
  if ((adf = (long)RDB[DATA_PTR_ADF0]) < VALID_PTR)
    return;

  /* Get pointer to microgroup energy grid */
  
  ptr = (long)RDB[DATA_MICRO_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	
  
  /* Number of groups */

  ntot = (long)RDB[ptr + ENERGY_GRID_NE] - 1;
  
  /* Get group index */

  if ((ng = GridSearch(ptr, E)) < 0)
    return;
  else
    ng = ntot - ng - 1;

  /* Loop over discontinuity factors */

  while (adf > VALID_PTR)
    {
      /* Pointer to gcu universe */

      gcu = (long)RDB[adf + ADF_PTR_GCU];
      CheckPointer(FUNCTION_NAME, "(gcu)", DATA_ARRAY, gcu);

      /* Get surface pointer */
      
      surf = (long)RDB[adf + ADF_PTR_SURF];
      CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);
	      
      /* Get surface type */
	      
      type = (long)RDB[surf + SURFACE_TYPE];
	      
      /* Get number of parameters */
	      
      np = (long)RDB[surf + SURFACE_N_PARAMS];
	      
      /* Pointer to parameter list */
	      
      ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Monve to starting position */

      x = x0;
      y = y0;
      z = z0;

      /* Reset distance */
      
      l = 0.0;
      
      /* Get initial position */
      
      in0 = TestSurface(surf, x, y, z, NO, id);

      /* Loop over all surfaces in track */
      
      while (l < lmax)
	{      
	  /* Get distance */
		  
	  d = SurfaceDistance(surf, &RDB[ptr], type, np, x, y, z, u, v, w, id);

	  /* Extrapolate */
	  
	  d = d + EXTRAP_L;
	  
	  /* Check with maximum */
	  
	  if (l + d > lmax)
	    {
	      /* Score TLE of cell flux */

	      if (in0 == YES)
		{
		  ptr = (long)RDB[gcu + GCU_MICRO_ADF_CELL_FLUX];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddPrivateRes(ptr + ng, (lmax - l)*wgt, id);
		}
	     
	      /* Break loop */
	      
	      break;
	    }
	  else
	    {
	      /* Score TLE of cell flux */

	      if (in0 == YES)
		{
		  ptr = (long)RDB[gcu + GCU_MICRO_ADF_CELL_FLUX];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddPrivateRes(ptr + ng, d*wgt, id);
		}
	    }
	  
	  /* Update coordinates */
	  
	  x = x + d*u;
	  y = y + d*v;
	  z = z + d*w;
	  
	  /* Test position */
	  
	  in1 = TestSurface(surf, x, y, z, NO, id);

	  /* Check if surface was crossed */

	  if (in0 != in1)
	    {
	      /* Get surface, corner and normal */

	      DFPos(surf, x, y, z, &n1, &n2, &m1, &m2, &u0, &v0, &w0);

	      /* n2 and m2 contain the indexes of opposite surface   */
	      /* and corner, which is needed to account for periodic */
	      /* boundary condition. Check if something else. */

	      if ((long)RDB[adf + ADF_BC] == BC_REFLECTIVE)
		{
		  n2 = n1;
		  m2 = m1;
		}
	      else if ((long)RDB[adf + ADF_BC] == BC_BLACK)
		{
		  n2 = -1;
		  m2 = -1;
		}
	      else if ((long)RDB[adf + ADF_BC] != BC_PERIODIC)
		Die(FUNCTION_NAME, "Invalid boundary condition");

	      /* Calculate cosine */

	      if ((mu = fabs(u*u0 + v*v0 + w*w0)) < 0.1)
		mu = 0.05;

	      /* Check surface index */

	      if (n1 > -1)
		{
		  /* Score surface flux */

		  ptr = (long)RDB[gcu + GCU_MICRO_ADF_SURF_FLUX];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddPrivateRes(ptr + ng + n1*ntot, wgt/mu, id);

		  if (n2 > -1)
		    {
		      ptr = (long)RDB[gcu + GCU_MICRO_ADF_SURF_FLUX];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      AddPrivateRes(ptr + ng + n2*ntot, wgt/mu, id);
		    }

		  /* Score inward or outward current */
		  
		  if ((in0 == NO) && (in1 == YES))
		    {
		      ptr = (long)RDB[gcu + GCU_MICRO_ADF_IN_CURR];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      AddPrivateRes(ptr + ng + n1*ntot, wgt, id);

		      if (n2 > -1)
			{
			  ptr = (long)RDB[gcu + GCU_MICRO_ADF_OUT_CURR];
			  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			  AddPrivateRes(ptr + ng + n2*ntot, wgt, id);
			}
		    }
		  else if ((in0 == YES) && (in1 == NO))
		    {
		      ptr = (long)RDB[gcu + GCU_MICRO_ADF_OUT_CURR];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      AddPrivateRes(ptr + ng + n1*ntot, wgt, id);
		      
		      if (n2 > -1)
			{
			  ptr = (long)RDB[gcu + GCU_MICRO_ADF_IN_CURR];
			  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			  AddPrivateRes(ptr + ng + n2*ntot, wgt, id);
			}
		    }
		}
	      
	      /* Check Corner index */

	      if (m1 > -1)
		{
		  /* Score corner flux */

		  ptr = (long)RDB[gcu + GCU_MICRO_ADF_CORN_FLUX];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddPrivateRes(ptr + ng + m1*ntot, wgt/mu, id);

		  if (m2 > -1)
		    {
		      ptr = (long)RDB[gcu + GCU_MICRO_ADF_CORN_FLUX];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      AddPrivateRes(ptr + ng + m2*ntot, wgt/mu, id);
		    }
		}
	    }

	  /* Put previous position */
	  
	  in0 = in1;
	}

      /* Next adf */

      adf = NextItem(adf);
    }
}

/*****************************************************************************/
