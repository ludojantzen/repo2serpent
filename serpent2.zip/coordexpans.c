/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : coordexpans.c                                  */
/*                                                                           */
/* Created:       2013/04/04 (JLe)                                           */
/* Last modified: 2013/04/08 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Coordinate transformations for thermal expansion             */
/*                                                                           */
/* Comments: - Hot-to-cold -muunnosta tarvitaan laskettaessa tehojakaumaa    */
/*             ja materiaalikohtaisia reaktionopeuksia esim. palamalaskussa. */
/*             Kutsutaan nyt vielä pelkästään scoreinterfacepower.c:stä,     */
/*             ja noi muut jutut pitää vielä miettiä tarkemmin (esim. että   */
/*             tallennetaanko muunnetut koordinaatit suoraan rakenteisiin    */
/*             joista muut aliohjelmat ne lukee, tehdäänkö muunnos aina      */
/*             paikallisesti. Esim. fissioneutronit pitäisi tallentaa        */
/*             muuntamattomilla koordinaateilla, muuten lähdepiste siirtyy.  */
/*             Voi kyllä olla että koko homma menee kerralla oikein jos      */
/*             muunnoksen tekee suoraan whereami.c:stä.)                     */
/*                                                                           */
/*           - Cold-to-hot -muunnosta tarvitaan korjaamaan neutronin paikkaa */
/*             aikariippuvassa simulaatiossa kun geometria muuttuu askelten  */
/*             välissä (pitää vielä miettiä että kannattaako sitä korjata    */
/*             ollenkaan).                                                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CoordExpans:"

/*****************************************************************************/

void CoordExpans(long loc0, double *x, double *y, double *z, long mode)
{
  long loc1, loc2, ptr;
  double rc0, rc1, rh0, rh1, rh, rc, cost, sint;
  /* Find axial zone */

  loc1 = (long)RDB[loc0 + IFC_FUEP_PTR_AX];
  while (loc1 > VALID_PTR)
    {
      /* Check 2D */
      
      if ((long)RDB[DATA_GEOM_DIM] == 2)
	break;

      /* Compare coordinates */
      
      if ((*z >= RDB[loc1 + IFC_FUEP_AX_ZMIN]) &&
	  (*z < RDB[loc1 + IFC_FUEP_AX_ZMAX]))
	break;
      
      /* Next */
      
      loc1 = NextItem(loc1);
    }

  /* Check pointer */

  if (loc1 < VALID_PTR)
    return;

  /* Check mode */

  if (mode == 1)
    {
      /***********************************************************************/

      /***** Hot-to-cold *****************************************************/

      /* First find the radial zone where the point is */
      
      loc2 = (long)RDB[loc1 + IFC_FUEP_AX_PTR_RAD];
      while (loc2 > VALID_PTR)
	{
	  /* Compare square radii */

	  if ((*x*(*x)+*y*(*y)) < RDB[loc2 + IFC_FUEP_RAD_HOT_R2])
	    break;

	  /* Next */
	  
	  loc2 = NextItem(loc2);
	}

      /* If radial zone is not found, do not change coordinates */

      if (loc2 < VALID_PTR)
	return;

      /* Get the outer and inner radii of the zone */

      rc1 = sqrt(RDB[loc2 + IFC_FUEP_RAD_COLD_R2]);
      rh1 = sqrt(RDB[loc2 + IFC_FUEP_RAD_HOT_R2]);

      if ((ptr = PrevItem(loc2)) > VALID_PTR)
	{
	  rc0 = sqrt(RDB[ptr + IFC_FUEP_RAD_COLD_R2]);
	  rh0 = sqrt(RDB[ptr + IFC_FUEP_RAD_HOT_R2]);
	}
      else
	{
	  rc0 = 0.0;
	  rh0 = 0.0;
	}

      /* Calculate the hot radius of the point as well as directional */
      /* cosine and sine */

      rh = sqrt(*x*(*x) + *y*(*y));
      cost = *x/rh;
      sint = *y/rh;

      /* Calculate the cold radius via linear interpolation */

      rc = rc0 + (rc1-rc0)*(rh-rh0)/(rh1-rh0);

      /* Calculate new x and y values */

      *x = rc*cost;
      *y = rc*sint;

      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Cold-to-hot *****************************************************/

      /* First find the radial zone where the point is */
      
      loc2 = (long)RDB[loc1 + IFC_FUEP_AX_PTR_RAD];
      while (loc2 > VALID_PTR)
	{
	  /* Compare square radii */

	  if ((*x*(*x)+*y*(*y)) < RDB[loc2 + IFC_FUEP_RAD_COLD_R2])
	    break;

	  /* Next */
	  
	  loc2 = NextItem(loc2);
	}

      /* If radial zone is not found, do not change coordinates */

      if (loc2 < VALID_PTR)
	return;

      /* Get the outer and inner radii of the zone */

      rc1 = sqrt(RDB[loc2 + IFC_FUEP_RAD_COLD_R2]);
      rh1 = sqrt(RDB[loc2 + IFC_FUEP_RAD_HOT_R2]);

      if ((ptr = PrevItem(loc2)) > VALID_PTR)
	{
	  rc0 = sqrt(RDB[loc2 + IFC_FUEP_RAD_COLD_R2]);
	  rh0 = sqrt(RDB[loc2 + IFC_FUEP_RAD_HOT_R2]);
	}
      else
	{
	  rc0 = 0.0;
	  rh0 = 0.0;
	}

      /* Calculate the hot radius of the point as well as directional */
      /* cosine and sine */

      rc = sqrt(*x*(*x) + *y*(*y));
      cost = *x/rc;
      sint = *y/rc;

      /* Calculate the hot radius via linear interpolation */

      rh = rh0 + (rh1-rh0)*(rc-rc0)/(rc1-rc0);

      /* Calculate new x and y values */

      *x = rh*cost;
      *y = rh*sint;

      /************************************************************************/
    }
}

/*****************************************************************************/
