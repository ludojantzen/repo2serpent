/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : sabdatatester.c                                */
/*                                                                           */
/* Created:       2012/11/10 (JLe)                                           */
/* Last modified: 2012/11/10 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Arpoo S(a,b) -taulukot uuteen uskoon                         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SABDataTester:"

/*****************************************************************************/

void SABDataTester()
{
  long i0, i1, j, n, m, nbatch, nsamp, id, Eb, Ebi, Ebi1, Ebi2, mub, nuc, rea;
  long mt, nnuc, loc0, loc1, loc2, loc3, ptr, np;
  unsigned long seed;
  double *E, *mu, E0, E1, mu1, Emin, Emax, u0, v0, w0, u1, v1, w1, P, err, lim;
  double *Ei, *Ei1, *Ei2, frac, nonzero, f, El0, El1, tot;
  char fname[MAX_STR];
  FILE *fp;

  /* Check if used */

  if ((long)RDB[DATA_BF_SAB_NE] == 0)
    return;

  /***************************************************************************/

  /***** Memory allocation, etc. *********************************************/

  /* Set binning */

  Eb = (long)RDB[DATA_BF_SAB_NE];
  mub = (long)RDB[DATA_BF_SAB_NMU];
  Ebi1 = 0;
  Ebi2 = 0;

  /* Set number of batches and samples */

  nsamp = 100000;
  nbatch = 100000;
  lim = RDB[DATA_BF_SAB_LIM];
  frac = RDB[DATA_BF_SAB_FRAC];

  /* Loop over data to get minimum and maximum energy and number of nuclides */

  Emin = INFTY;
  Emax = -INFTY;
  nnuc = 0;
  Ei1 = NULL;
  Ei2 = NULL;

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Loop over reactions */

      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];	    
      while (rea > VALID_PTR)
	{
	  /* Get mt */
	  
	  mt = (long)RDB[rea + REACTION_MT];

	  /* Add counter */

	  if (mt == 1004)
	    nnuc++;

	  /* Check for S(a,b) reaction */

	  if ((mt == 1002) || (mt == 1004))
	    {
	      /* Compare energies */

	      if (RDB[rea + REACTION_EMIN] < Emin)
		Emin = RDB[rea + REACTION_EMIN];
	      if (RDB[rea + REACTION_EMAX] > Emax)
		Emax = RDB[rea + REACTION_EMAX];
	      if (RDB[rea + REACTION_SAB_MIN_EM_E] < Emin)
		Emin = RDB[rea + REACTION_SAB_MIN_EM_E];
	      if (RDB[rea + REACTION_SAB_MAX_EM_E] > Emax)
		Emax = RDB[rea + REACTION_SAB_MAX_EM_E];

	      /* Get pointer to distribution */

	      loc0 = (long)RDB[rea + REACTION_PTR_ERG];
	      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	      /* Get pointer to data */
	      
	      loc0 = (long)RDB[loc0 + ERG_PTR_DATA];
	      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	      /* Get pointer to incident energy grid */
	      
	      loc0 = (long)RDB[loc0 + 1];
	      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	      /* Get number of incident energy bins */

	      if (mt == 1002)
		np = (long)RDB[loc0 + ENERGY_GRID_NE];
	      else
		np = (long)RDB[loc0 + ENERGY_GRID_NE];

	      /* Pointer to energies */

	      loc0 = (long)RDB[loc0 + ENERGY_GRID_PTR_DATA];
	      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	      /* Check mode */

	      if (mt == 1002)
		{	      
		  /* Add points to grid */
		  
		  Ei1 = AddPts(Ei1, &Ebi1, &RDB[loc0], np);
		}
	      else
		{	      
		  /* Add points to grid */
		  
		  Ei2 = AddPts(Ei2, &Ebi2, &RDB[loc0], np);
		}
	    }

	  /* Next reaction */

	  rea = NextItem(rea);
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Adjust sizes */

  Ebi1 = Ebi1 - 1;
  Ebi2 = Ebi2 - 1;

  /* Check */

  if (Emax < Emin)
    Die(FUNCTION_NAME, "No S(a,b) data found");

  /* Pointer to random number seed */
  
  loc0 = (long)RDB[DATA_PTR_RNG_SEED];

  /* Allocate memory for stats */

  if (Ebi2 > 0)
    loc1 = NewStat("Inelastic mode", 3, Ebi2, Eb, mub);

  if (Ebi1 > 0)
    loc2 = NewStat("Elastic mode", 2, Ebi1, mub);

  /* Print */

  fprintf(out, "Creating %ld x %ld scattering matrices ", Eb, mub);
  fprintf(out, "between %1.5E and %1.5E MeV...\n\n", Emin, Emax);

  /* Create energy and cosine arrays */

  E = MakeArray(Emin, Emax, Eb + 1, 2);
  mu = MakeArray(-1.0, 1.0, mub + 1, 1);

  /* Open file for writing */

  sprintf(fname, "%s_sab.m", GetText(DATA_PTR_INPUT_FNAME));
  fp = fopen(fname, "w");

  /* Write parameters */

  fprintf(fp, "nnuc = %ld;\n", nnuc);
  fprintf(fp, "Eb = %ld;\n", Eb);
  fprintf(fp, "mub = %ld;\n", mub);
  fprintf(fp, "Emin = %1.5E;\n", Emin);
  fprintf(fp, "Emax = %1.5E;\n", Emax);

  /* Write incident energy array */

  if (Ebi1 > 0)
    {
      fprintf(fp, "\nEi1 = [\n");
      for (n = 0; n < Ebi1 + 1; n++)
	fprintf(fp, "%1.5E\n", Ei1[n]);
      fprintf(fp, "];\n");
    }

  if (Ebi2 > 0)
    {
      fprintf(fp, "\nEi2 = [\n");
      for (n = 0; n < Ebi2 + 1; n++)
	fprintf(fp, "%1.5E\n", Ei2[n]);
      fprintf(fp, "];\n");
    }

  /* Write energy array */

  fprintf(fp, "\nE = [\n");
  for (n = 0; n < Eb + 1; n++)
    fprintf(fp, "%1.5E\n", E[n]);
  fprintf(fp, "];\n");

  /* Write cosine array */

  fprintf(fp, "\nmu = [\n");
  for (n = 0; n < mub + 1; n++)
    fprintf(fp, "%1.5E\n", mu[n]);
  fprintf(fp, "];\n");

  fclose(fp);

  /***************************************************************************/

  /***** Sampling loop *******************************************************/

  /* Resed nuclide counter */

  nnuc = 0;

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Loop over reactions */

      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];	    
      while (rea > VALID_PTR)
	{
	  /* Get mt */
	  
	  mt = (long)RDB[rea + REACTION_MT];

	  /* Check for S(a,b) reaction */

	  if ((mt != 1002) && (mt != 1004))
	    {
	      /* Skip reaction */

	      rea = NextItem(rea);

	      /* Cycle loop */
	      
	      continue;
	    }

	  /* Get incident grid size and pointer to data */

	  if (mt == 1002)
	    {
	      Ebi = Ebi1;
	      Ei = Ei1;
	    }
	  else
	    {
	      Ebi = Ebi2;
	      Ei = Ei2;
	    }

	  /* Check */
	  
	  if ((Ei == NULL) || (Ebi < 1))
	    Die(FUNCTION_NAME, "Error in incident energies");
	  
	  /* Allocate memory for structure */

	  loc3 = ReallocMem(DATA_ARRAY, BRAVE_NEW_SAB_BLOCK_SIZE);

	  /* Put energy and cosine grid sizes */

	  WDB[loc3 + BRAVE_NEW_SAB_NEI] = (double)Ebi;
	  WDB[loc3 + BRAVE_NEW_SAB_NE] = (double)Eb;
	  WDB[loc3 + BRAVE_NEW_SAB_NMU] = (double)mub;

	  /* Put incident energy grid */

	  ptr = ReallocMem(DATA_ARRAY, Ebi + 1);
	  WDB[loc3 + BRAVE_NEW_SAB_PTR_EI] = (double)ptr;
	  for (n = 0; n < Ebi + 1; n++)
	    WDB[ptr++] = Ei[n];	    

	  /* Put energy grid */

	  ptr = ReallocMem(DATA_ARRAY, Eb + 1);
	  WDB[loc3 + BRAVE_NEW_SAB_PTR_EGRID] = (double)ptr;
	  for (n = 0; n < Eb + 1; n++)
	    WDB[ptr++] = E[n];	    

	  /* Put mu grid */

	  ptr = ReallocMem(DATA_ARRAY, mub + 1);
	  WDB[loc3 + BRAVE_NEW_SAB_PTR_MUGRID] = (double)ptr;
	  for (n = 0; n < mub + 1; n++)
	    WDB[ptr++] = mu[n];	    
	  
	  /* allocate memory for distribution */

	  if (mt == 1002)
	    ptr = ReallocMem(DATA_ARRAY, Ebi*mub);
	  else
	    ptr = ReallocMem(DATA_ARRAY, Ebi*Eb*mub);
	    
	  /* Put pointer */

	  WDB[loc3 + BRAVE_NEW_SAB_PTR_DATA] = (double)ptr;

	  /* Pointer to original nuclide data */

	  ptr = (long)RDB[rea + REACTION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Update nuclide count and print */

	  if (mt == 1004)
	    {
	      /* Update counter */

	      nnuc++;

	      /* Open file */

	      fp = fopen(fname, "a");

	      /* Print name */

	      fprintf(fp, "\nnuc(%2ld,[1:%2ld]) = '%s';\n",
		      nnuc, strlen(GetText(ptr + NUCLIDE_PTR_NAME)),
		      GetText(ptr + NUCLIDE_PTR_NAME));

	      /* Print temperature */

	      fprintf(fp, "temp(%2ld) = %1.5E;\n", nnuc,
		      RDB[ptr + NUCLIDE_TEMP]);

	      /* Close file */

	      fclose(fp);
	    }	  

	  /* Loop over incident energies */

	  for (i0 = 0; i0 < Ebi; i0++)
	    {	  
	      /* Set limits for incident energy */

	      El0 = Ei[i0];
	      El1 = Ei[i0 + 1];

	      /* Compare to channel boundaries */

	      if (El0 < RDB[rea + REACTION_EMIN])
		El0 = RDB[rea + REACTION_EMIN];
	      if (El1 > RDB[rea + REACTION_EMAX])
		El1 = RDB[rea + REACTION_EMAX];

	      /* Check boundaries */
	      
	      if (El0 < El1)
		{
		  /* Loop over batches */
	  
		  for (m = 0; m < nbatch; m++)
		    {
		      /* Reset error */
		      
		      err = -1.0;

		      /*******************************************************/

		      /***** Parallel loop ***********************************/
	      
#ifdef OPEN_MP
#pragma omp parallel private(n,id,seed,E0,E1,u0,v0,w0,u1,v1,w1,mu1,i1,j) 
#endif
		      {
			
#ifdef OPEN_MP
#pragma omp for schedule(dynamic)
#endif	  
			/* Loop over samples */
			
			for (n = 0; n < nsamp; n++)
			  {
			    /* Get Open MP thread id */
			    
			    id = OMP_THREAD_NUM;
			    
			    /* Init random number sequence */
			    
			    seed = ReInitRNG(m*nsamp + n);
			    
			    /* Put seed in private data */
			    
			    PutPrivateData(loc0, seed, id);
			    
			    /* Sample incident energy */
			    
			    E0 = RandF(id)*(El1 - El0) + El0;
			    E1 = E0;

			    /* Check */

			    CheckValue(FUNCTION_NAME, "E0", "", E0, 
				       RDB[rea + REACTION_EMIN],
				       RDB[rea + REACTION_EMAX]);
		    
			    /* Sample random incident direction */
			
			    IsotropicDirection(&u0, &v0, &w0, id);
			    u1 = u0;
			    v1 = v0;
			    w1 = w0;
			    
			    /* Sample scattering */
			    
			    SabScattering(rea, &E1, &u1, &v1, &w1, id);
			    
			    /* Adjust upper boundary */
			    
			    if (E1 == Emax)
			      E1 = 0.999999*Emax;
			    
			    /* Calculate cosine */
			    
			    mu1 = u1*u0 + v1*v0 + w1*w0;
			    
			    /* Check values */
			    
			    CheckValue(FUNCTION_NAME, "E1", "", E1, Emin,Emax);
			    CheckValue(FUNCTION_NAME, "mu1", "", mu1,-1.0,1.0);
			    
			    /* Indexes to emission bins */
			    
			    i1 = SearchArray(E, E1, Eb + 1); 	  
			    CheckValue(FUNCTION_NAME, "i1", "", i1, 0, Eb - 1);
			    
			    j = SearchArray(mu, mu1, mub + 1); 
			    CheckValue(FUNCTION_NAME, "j", "", j, 0, mub - 1);
			    
			    /* Score */
			    
			    if (mt == 1004)
			      AddBuf(1.0, 1.0, loc1, id, -1, i0, i1, j);
			    else if (mt == 1002)
			      AddBuf(1.0, 1.0, loc2, id, -1, i0, j);
			    else
			      Die(FUNCTION_NAME, "Invalid mt %ld", mt);
			    
			  }
		      }
		      
		      /***** End of parallel loop ****************************/

		      /*******************************************************/
	      
		      /* Reduce scoring buffer */
		  
		      ReduceBuffer();
		      
		      /* Collect inelastic */
		      
		      if (mt == 1004)
			for (i1 = 0; i1 < Eb; i1++)
			  for (j = 0; j < mub; j++)
			    {
			      P = BufVal(loc1, i0, i1, j)/((double)nsamp);
			      AddStat(P, loc1, i0, i1, j);
			    }
		      
		      /* Collect elastic */

		      if (mt == 1002)
			for (j = 0; j < mub; j++)
			  {
			    P = BufVal(loc2, i0, j)/((double)nsamp);
			    AddStat(P, loc2, i0, j);
			  }
		      
		      /* Clear buffer */
		      
		      ClearBuf();
		      
		      /* Check statistics */

		      if (m > 2)
			{
			  /* Reset error fraction */
			  
			  err = 0.0;
			  nonzero = 0.0;
			  
			  /* Inelastic */
			  
			  if (mt == 1004)
			    for (i1 = 0; i1 < Eb; i1++)
			      for (j = 0; j < mub; j++)
				{
				  /* Get relative error */
				  
				  f = RelErr(loc1, i0, i1, j);
				  
				  /* Compare */
				  
				  if (f > 0.0)
				    nonzero = nonzero + 1.0;
				  if ((f > 0.0) && (f < lim))
				    err = err + 1.0;
				}
		      
			  /* Elastic */
			  
			  if (mt == 1002)
			    for (j = 0; j < mub; j++)
			      {
				/* Get relative error */
				
				f = RelErr(loc2, i0, j);
				
				/* Compare */
				
				if (f > 0.0)
				  nonzero = nonzero + 1.0;
				if ((f > 0.0) && (f < lim))
				  err = err + 1.0;
			      }

			  /* Check if all are zero */
			  
			  if (nonzero == 0)
			    break;
			  
			  /* Divide by nonzero */
			
			  err = err/nonzero;

			  /* Pointer to original nuclide data */

			  ptr = (long)RDB[rea + REACTION_PTR_NUCLIDE];
			  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			  
			  /* Print */

			  fprintf(out, "%9s : nuc = %s : mt = %ld : ",
				  TimeStr((long)TimerVal(TIMER_RUNTIME)),
				  GetText(ptr + NUCLIDE_PTR_NAME), mt);
			  if ((Ebi > 9) && (Ebi < 100))
			    fprintf(out, "Eini = %2ld / %ld : ", i0 + 1, Ebi);
			  else if ((Ebi > 9) && (Ebi < 1000))
			    fprintf(out, "Eini = %3ld / %ld : ", i0 + 1, Ebi);
			  else if ((Ebi > 9) && (Ebi < 10000))
			    fprintf(out, "Eini = %4ld / %ld : ", i0 + 1, Ebi);
			  else
			    fprintf(out, "Eini = %ld / %ld : ", i0 + 1, Ebi);
			  
			  fprintf(out, "frac = %6.2f%% (%1.2f%% / %1.2f%%)\n", 
				  100.0*err, 100.0*frac, 100.0*lim);

			  /* Compare to limit */
			  
			  if (err > frac)
			    break;
			}
		    }
		
		  /***********************************************************/

		  /***** Output **********************************************/
		  
		  /* Reset total probability */

		  tot = 0.0;

		  /* Inelastic */

		  if (mt == 1004)
		    for (i1 = 0; i1 < Eb; i1++)
		      for (j = 0; j < mub; j++)
			tot = tot + Mean(loc1, i0, i1, j);

		  /* Elastic */

		  if (mt == 1002)
		    for (j = 0; j < mub; j++)
		      tot = tot + Mean(loc2, i0, j);
		  
		  /* Check */

		  if ((tot != 0.0) && (fabs(1.0 - tot) > 1E-5))
		    Die(FUNCTION_NAME, "Error in total probability");

		  /* Reset cumulative probability */

		  P = 0.0;

		  /* Inelastic */

		  if (mt == 1004)
		    {
		      /* Get pointer */
		      
		      ptr = (long)RDB[loc3 + BRAVE_NEW_SAB_PTR_DATA];
		      ptr = ptr + i0*Eb*mub;

		      /* Write data */
		      
		      for (i1 = 0; i1 < Eb; i1++)
			for (j = 0; j < mub; j++)
			  {
			    P = P + Mean(loc1, i0, i1, j)/tot;
			    WDB[ptr++] = P;
			  }
		    }

		  /* Elastic */

		  if (mt == 1002)
		    {
		      /* Get pointer */
		      
		      ptr = (long)RDB[loc3 + BRAVE_NEW_SAB_PTR_DATA];
		      ptr = ptr + i0*mub;

		      /* Write data */

		      for (j = 0; j < mub; j++)
			{
			  P = P + Mean(loc2, i0, j)/tot;
			  WDB[ptr++] = P;
			}
		    }

		  /***********************************************************/
		}
	    	    
	      /***************************************************************/

	      /***** Matlab output *******************************************/
     
	      /* Open file */
	      
	      fp = fopen(fname, "a");

	      /* Print inelastic */

	      if (mt == 1004)
		for (i1 = 0; i1 < Eb; i1++)
		  for (j = 0; j < mub; j++)
		    {
		      fprintf(fp, "inl(%2ld,%3ld,%3ld,%3ld, [1:2]) = ", nnuc,
				i0 + 1, i1 + 1, j + 1);
			fprintf(fp, "[%1.5E ", Mean(loc1, i0, i1, j));
			fprintf(fp, "%1.5E];\n", RelErr(loc1, i0, i1, j));
		      }

	      /* Print elastic */

	      if (mt == 1002)
		for (j = 0; j < mub; j++)
		  {
		    fprintf(fp, "ela(%2ld,%3ld,%3ld, [1:2]) = ", nnuc,
			    i0 + 1, j + 1);
		    fprintf(fp, "[%1.5E ", Mean(loc2, i0, j));
		    fprintf(fp, "%1.5E];\n", RelErr(loc2, i0, j));
		  }
	      
	      /* Close file */

	      fclose(fp);
	    	  
	      /***************************************************************/
	      	      
	      /* Clear statistics */

	      ClearStat(-1);
	    }
	  
	  /* Put reaction pointer (pitää tehdä tässä koska tuolla */
	  /* kutsutaan SabScattering():ia */

	  WDB[rea + REACTION_PTR_NEW_SAB] = (double)loc3;

	  /* Next reaction */

	  rea = NextItem(rea);
	}
      
      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Free memory */

  Mem(MEM_FREE, E);
  Mem(MEM_FREE, mu);

  if (Ei1 != NULL)
    Mem(MEM_FREE, Ei1);
  if (Ei2 != NULL)
    Mem(MEM_FREE, Ei2);
  
  /* Exit */

  fprintf(out, "\nOK.\n\n");

  /***************************************************************************/
}

/*****************************************************************************/


