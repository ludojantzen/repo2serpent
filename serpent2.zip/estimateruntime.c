/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : estimateruntime.c                              */
/*                                                                           */
/* Created:       2011/03/12 (JLe)                                           */
/* Last modified: 2013/03/14 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Estimates running time                                       */
/*                                                                           */
/* Comments: - Predictor-corrector -ym. askeleet pitää ottaa tohon mukaan    */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "EstimateRuntime:"

/*****************************************************************************/

void EstimateRuntime()
{
  long i, tot, skip, np, nc;
  double t0, t1, ct, tt;

  /* Get cycle index and number of skip cycles */

  i = (long)RDB[DATA_CYCLE_IDX] + 1;
  skip = (long)RDB[DATA_CRIT_SKIP];

  /* Check mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      /* Get number of batches */

      tot = (long)RDB[DATA_SRC_BATCHES];
  
      /* Init time */

      t0 = TimerVal(TIMER_RUNTIME) - TimerVal(TIMER_TRANSPORT);

      /* Time per cycle */

      t1 = TimerVal(TIMER_TRANSPORT)/((double)i);

      /* Estimate total time */

      ct = t0 + tot*t1;
    }
  else if (i > skip)
    {
      /* Get number of criticality cycles */

      tot = (long)RDB[DATA_CRIT_CYCLES];

      /* Init time */

      t0 = TimerVal(TIMER_RUNTIME) - TimerVal(TIMER_TRANSPORT_ACTIVE);

      /* Time per cycle */

      t1 = TimerVal(TIMER_TRANSPORT_ACTIVE)/((double)(i - skip));

      /* Estimate total time */
      
      ct = t0 + tot*t1;
    }
  else
    ct = 0.0;

  /* Put time */

  WDB[DATA_ESTIM_CYCLE_TIME] = ct;

  /* Number of predictor and corrector cycle left */

  np = (long)RDB[DATA_BURN_TOT_STEPS] - (long)RDB[DATA_BURN_PRED_STEP];  

  if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE)
    nc = 0;
  else
    {
      /* MODIFIED (AIs) */
      /* this only works if MAX iterations = MIN iterations */
      /* when convergence check is added this must change*/
      
      nc = (long)RDB[DATA_BURN_TOT_STEPS]*(long)RDB[DATA_BURN_CI_MAXI] 
        - (long)RDB[DATA_BURN_CORR_STEP];
    }

  /* Estimate total running time with burnup */

  if ((long)RDB[DATA_BURN_STEP] > 0.0)
    {
      /* Add estimated time to complete this step */

      tt = ct;

      /* Add estimated processing time */

      tt = tt + (np + nc)*TimerVal(TIMER_PROCESS);

      /* Add estimated burnup time */

      tt = tt + (np + nc)*TimerVal(TIMER_BURNUP);

      /* Add estimated transport time */

      tt = tt + np*RDB[DATA_PRED_TRANSPORT_TIME];
      tt = tt + nc*RDB[DATA_CORR_TRANSPORT_TIME];
    }
 else
   tt = 0.0;

  /* Put time */

  WDB[DATA_ESTIM_TOT_TIME] = tt;
}

/*****************************************************************************/
