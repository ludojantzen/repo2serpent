/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : movedt.c                                       */
/*                                                                           */
/* Created:       2012/10/05 (JLe)                                           */
/* Last modified: 2012/12/28 (JLe)                                           */
/* Version:       2.1.12                                                     */
/*                                                                           */
/* Description: Moves particle forward using delta-tracking                  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MoveDT:"

/*****************************************************************************/

long MoveDT(long part, double majorant, double minxs, long *cell, double *xs0, 
	    double *x, double *y, double *z, double *l0, double u, double v, 
	    double w, double E, long id)
{
  long ptr, type, mat;
  double totxs, l;

  /* Check particle pointer */

  CheckPointer(FUNCTION_NAME, "(part)", DATA_ARRAY, part);

  /* Get particle type */

  type = (long)RDB[part + PARTICLE_TYPE];  

  /* Add to DT fraction counter */
		
  ptr = (long)RDB[RES_DT_TRACK_FRAC];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(1.0, 1.0, ptr, id, 2 - type);
  
  /* Check cross section and sample path length */
  
  CheckValue(FUNCTION_NAME, "majorant", "", majorant, ZERO, INFTY);
  l = -log(RandF(id))/majorant;

  /* Move particle to collision site */
		  
  *x = *x + u*l;
  *y = *y + v*l;
  *z = *z + w*l;

  /* Set path length */
      
  *l0 = l;

  /* Find location */

  *cell = WhereAmI(*x, *y, *z, u, v, w, id);
  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, *cell);

  /* Stop track at outer boundary */
		  
  if (StopAtBoundary(cell, x, y, z, l0, u, v, w, id) == YES)
    {
      /* Set cross section */

      *xs0 = -1.0;

      /* Return surface crossing */
      
      return TRACK_END_SURF;
    }
  else
    {
      /* Get material pointer */

      mat = (long)RDB[*cell + CELL_PTR_MAT];
      mat = MatPtr(mat, id);

      /* Get total cross section */

      totxs = TotXS(mat, type, E, id);

      /* Compare to minimum value */

      if (totxs > minxs)
	{
	  /* Sample between real and virtual collision */
	  
	  if (RandF(id) < totxs/majorant)
	    {
	      /* Set cross section */

	      *xs0 = totxs;

	      /* Add to success counter */
		  
	      ptr = (long)RDB[RES_DT_TRACK_EFF];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY,ptr);
	      AddBuf(1.0, 1.0, ptr, id, 2 - type);

	      /* Return collision */

	      return TRACK_END_COLL;
	    }
	  else
	    {
	      /* Set cross section */

	      *xs0 = -1.0;

	      /* Add to failure counter */
		  
	      ptr = (long)RDB[RES_DT_TRACK_EFF];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY,ptr);
	      AddBuf(1.0, 1.0, ptr, id, 4 - type);

	      /* Return virtual */

	      return TRACK_END_VIRT;
	    }
	}
      else
	{
	  /* Sample scoring */
	      
	  if (RandF(id) < minxs/majorant)
	    {
	      /* Set cross section */

	      *xs0 = minxs;

	      /* Sample between real and virtual collision */
	      
	      if (RandF(id) < totxs/minxs)
		{
		  /* Add to success counter */
		  
		  ptr = (long)RDB[RES_DT_TRACK_EFF];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY,ptr);
		  AddBuf(1.0, 1.0, ptr, id, 2 - type);

		  /* Return collision */
		  
		  return TRACK_END_COLL;
		}
	      else
		{
		  /* Add to failure counter */
		  
		  ptr = (long)RDB[RES_DT_TRACK_EFF];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY,ptr);
		  AddBuf(1.0, 1.0, ptr, id, 4 - type);

		  /* Return virtual */

		  return TRACK_END_VIRT;
		}
	    }
	  else
	    {
	      /* Set cross section */
	      
	      *xs0 = -1.0;

	      /* Add to failure counter */
		  
	      ptr = (long)RDB[RES_DT_TRACK_EFF];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY,ptr);
	      AddBuf(1.0, 1.0, ptr, id, 4 - type);

	      /* Return virtual */

	      return TRACK_END_VIRT;
	    }
	}
    }
}

/*****************************************************************************/
