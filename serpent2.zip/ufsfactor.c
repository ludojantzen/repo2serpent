/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : ufsfactor.c                                    */
/*                                                                           */
/* Created:       2012/02/11 (JLe)                                           */
/* Last modified: 2012/10/25 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Returns multiplier for uniform fission source method         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "UFSFactor:"

/*****************************************************************************/

double UFSFactor(double x, double y, double z)
{
  long msh, ptr, idx, n0, n1, n2;
  double f, g;
  
  /* Check if method is in use */

  if ((long)RDB[DATA_UFS_MODE] == UFS_MODE_NONE)
    return 1.0;

  /* Check simulation mode */

  if ((long)RDB[DATA_SIMULATION_MODE] != SIMULATION_MODE_CRIT)
    return 1.0;

  /* Get pointer to mesh */

  msh = (long)RDB[DATA_UFS_PTR_SRC_MESH];
  CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

  /* Get mesh size */
  
  n0 = (long)RDB[msh + MESH_N0];
  n1 = (long)RDB[msh + MESH_N1];
  n2 = (long)RDB[msh + MESH_N2];
  
  /* Check values */
  
  CheckValue(FUNCTION_NAME, "n0", "", n0, 1, 10000);
  CheckValue(FUNCTION_NAME, "n1", "", n1, 1, 10000);
  CheckValue(FUNCTION_NAME, "n2", "", n2, 1, 10000);
      
  /* Check if all data is collected */

  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP])
    {
      /* Get exponent */

      g = RDB[DATA_UFS_ORDER];

      /* Check if biasing is used when collecting cycles */

      if (g < 0.0)
	g = -g;
      else
	return 1.0;
      
      /* Calculate factor from mesh data */
      
      f = MeshVal(msh, x, y, z)/MeshTot(msh)*n0*n1*n2;
      
      /* Adjust */
      
      if (f > 0.0)
	f = pow(1.0/f, g);
      else
	f = 1.0;

      /* Cutoff */
      
      if (f > RDB[DATA_UFS_MAX])
	f = RDB[DATA_UFS_MAX];
      else if (f < RDB[DATA_UFS_MIN])
	f = RDB[DATA_UFS_MIN];
    }
  else 
    {
      /* Get index */
      
      if ((idx = MeshIndex(msh, x, y, z)) > -1)
	{
	  /* Get pointer to direct data */
	  
	  ptr = (long)RDB[DATA_UFS_PTR_FACTORS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr + idx);
	  
	  /* Read value */
	  
	  f = RDB[ptr + idx];
	}
      else
	f = 1.0;
    }

  /* Check factor */

  CheckValue(FUNCTION_NAME, "f", "", f, RDB[DATA_UFS_MIN], RDB[DATA_UFS_MAX]);

  /* Return value */

  return f;
}

/*****************************************************************************/
