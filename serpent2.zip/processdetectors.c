/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processdetectors.c                             */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2012/12/19 (JLe)                                           */
/* Version:       2.1.12                                                     */
/*                                                                           */
/* Description: Processes source definitions                                 */
/*                                                                           */
/* Comments: - Detector cells and universes are processed in                 */
/*             creategeometry.c                                              */
/*           - TODO: se automaattinen volume-juttu                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessDetectors:"

/*****************************************************************************/

void ProcessDetectors()
{
  long det, ene, ptr, mat, uni, lat, cell, surf, tme, tot, n1, n2, msh1, msh2;
  long ebins, ubins, cbins, mbins, lbins, rbins, zbins, ybins, xbins, tbins;
  char str[MAX_STR];

  /***************************************************************************/

  /***** Structure for criticality source detector ***************************/

  /* Check if file name is given */

  if ((long)RDB[DATA_PTR_CRIT_SRC_DET]  > VALID_PTR)
    {
      /* Allocate memory for detector structure (not included in list) */

      det = ReallocMem(DATA_ARRAY, DET_BLOCK_SIZE);

      /* Put file name */

      WDB[det + DET_WRITE_PTR_FILE] = RDB[DATA_PTR_CRIT_SRC_DET];
      
      /* Allocate memory for buffer */
      
      ptr = ReallocMem(DATA_ARRAY, SRC_FILE_BUF_SIZE*SRC_BUF_BLOCK_SIZE);

      /* Put pointer and buffer size */
      
      WDB[det + DET_WRITE_PTR_BUF] = (double)ptr;
      WDB[det + DET_WRITE_BUF_SZ] = (double)SRC_FILE_BUF_SIZE;

      /* Reset index */

      WDB[det + DET_WRITE_BUF_IDX] = 0.0;

      /* Put fraction */

      WDB[det + DET_WRITE_PROB] = 1.0;

      /* Remove old file */
      
      remove(GetText(det + DET_WRITE_PTR_FILE));

      /* Put pointer */

      WDB[DATA_PTR_CRIT_SRC_DET] = (double)det;
    }

  /* Exit if detectors are not defined */

  if ((long)RDB[DATA_PTR_DET0] < VALID_PTR)
    return;

  /***************************************************************************/

  /***** Link pointers and allocate memory ***********************************/

  /* Loop over detectors */

  det = (long)RDB[DATA_PTR_DET0];  
  while (det > VALID_PTR)
    {
      /* Number of mesh bins */
  
      if ((msh1 = (long)RDB[det + DET_PTR_MESH]) > VALID_PTR)
	{
	  xbins = (long)RDB[msh1 + MESH_N0];
	  ybins = (long)RDB[msh1 + MESH_N1];
	  zbins = (long)RDB[msh1 + MESH_N2];
	}
      else
	{
	  xbins = 1;
	  ybins = 1;
	  zbins = 1;
	}
      
      /***********************************************************************/
      
      /***** Link energy grids to detectors **********************************/

      /* Check pointer */
      
      if ((long)RDB[det + DET_PTR_EGRID] > VALID_PTR)
	{
	  /* Find grid */
	  
	  ene = RDB[DATA_PTR_ENE0];
	  if ((ene = SeekListStr(ene, ENE_PTR_NAME, 
				 GetText(det + DET_PTR_EGRID))) < VALID_PTR)
	    Error(det, "Energy grid %s in detector %s is not defined", 
		  GetText(det + DET_PTR_EGRID), 
		  GetText(det + DET_PTR_NAME));
	  
	  /* Set pointer */
	  
	  WDB[det + DET_PTR_EGRID] = RDB[ene + ENE_PTR_GRID];
	  
	  /* Set number of bins */

	  ebins = (long)RDB[ene + ENE_NB];
	}
      else
	ebins = 1;

      /***********************************************************************/

      /***** Link time bins to detectors *************************************/

      /* Check pointer */
      
      if ((long)RDB[det + DET_PTR_TME] > VALID_PTR)
	{
	  /* Find bins */
	  
	  tme = RDB[DATA_PTR_TME0];
	  if ((tme = SeekListStr(tme, TME_PTR_NAME, 
				 GetText(det + DET_PTR_TME))) < VALID_PTR)
	    Error(det, "Time binning %s in detector %s is not defined", 
		  GetText(det + DET_PTR_TME), 
		  GetText(det + DET_PTR_NAME));
	  
	  /* Set pointer */
	  
	  WDB[det + DET_PTR_TME] = RDB[tme + TME_PTR_BINS];
	  
	  /* Set number of bins */

	  tbins = (long)RDB[tme + TME_NB];
	}
      else
	tbins = 1;

      /***********************************************************************/
      
      /***** Link materials to response functions ****************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_RBINS]) < VALID_PTR)
	{
	  /* Create response bin for flux */
	  
	  ptr = NewItem(det + DET_PTR_RBINS, DET_RBIN_BLOCK_SIZE);
	      
	  /* Put mt and material pointer */
	  
	  WDB[ptr + DET_RBIN_MT] = 0.0;
	  WDB[ptr + DET_RBIN_PTR_MAT] = NULLPTR;
	  
	  /* Set void mode */
	  
	  WDB[ptr + DET_RBIN_VOID_MODE] = (double)YES;
	  
	  /* Set counter */

	  rbins = 1;
	}
      else
	{
	  /* Reset counter */

	  rbins = 0;
	  
	  /* Loop over reaction bins */
 
	  while (ptr > VALID_PTR)
	    {
	      /* Check void */
	      
	      if (!strcmp(GetText(ptr + DET_RBIN_PTR_MAT), "void"))
		{
		  /* Set null pointer */
		  
		  WDB[ptr + DET_RBIN_PTR_MAT] = NULLPTR;

		  /* Set void mode */

		  WDB[ptr + DET_RBIN_VOID_MODE] = (double)YES;
		}
	      else
		{
		  /* Find material */
		  
		  mat = RDB[DATA_PTR_M0];
		  if ((mat = SeekListStr(mat,MATERIAL_PTR_NAME, 
					 GetText(ptr + DET_RBIN_PTR_MAT))) 
		      < VALID_PTR)
		    Error(det,
			  "Material %s in detector %s response is not defined", 
			  GetText(ptr + DET_RBIN_PTR_MAT), 
			  GetText(det + DET_PTR_NAME));
		  
		  /* Set pointer */
		  
		  WDB[ptr + DET_RBIN_PTR_MAT] = (double)mat;
		  
		  /* Reset void mode */

		  WDB[ptr + DET_RBIN_VOID_MODE] = (double)NO;

		  /* Set used-flags */
		  
		  SetOption(mat + MATERIAL_OPTIONS, OPT_USED);
		}

	      /* Update number of bins */
	      
	      rbins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}

      /***********************************************************************/

      /***** Link universes to detectors *************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_UBINS]) < VALID_PTR)
	ubins = 1;
      else
	{
	  /* Reset counter */

	  ubins = 0;

	  /* Loop over universe bins */

	  while (ptr > VALID_PTR)
	    {
	      /* Find universe */
	      
	      uni = RDB[DATA_PTR_U0];
	      if ((uni = SeekListStr(uni, UNIVERSE_PTR_NAME, 
				     GetText(ptr + DET_UBIN_PTR_UNI))) 
		  < VALID_PTR)
		Error(det,"Universe %s in detector %s is not defined", 
		      GetText(ptr + DET_UBIN_PTR_UNI), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_UBIN_PTR_UNI] = (double)uni;
	      
	      /* Update number of bins */
	      
	      ubins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/

      /***** Link lattices to detectors **************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_LBINS]) < VALID_PTR)
	lbins = 1;
      else
	{
	  /* Find lattice */
	      
	  lat = RDB[DATA_PTR_L0];
	  if ((lat = SeekListStr(lat, LAT_PTR_NAME, 
				 GetText(ptr + DET_LBIN_PTR_LAT))) 
	      < VALID_PTR)
	    Error(det,"Lattice %s in detector %s is not defined", 
		  GetText(ptr + DET_LBIN_PTR_LAT), 
		  GetText(det + DET_PTR_NAME));
	  
	  /* Set pointer */
	      
	  WDB[ptr + DET_LBIN_PTR_LAT] = (double)lat;
	  
	  /* Set number of bins */
	  
	  lbins = (long)RDB[lat + LAT_NTOT];
	}
      
      /***********************************************************************/

      /***** Link materials to detectors *************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_MBINS]) < VALID_PTR)
	mbins = 1;
      else
	{
	  /* Reset counter */

	  mbins = 0;

	  /* Loop over bins */
      
	  while (ptr > VALID_PTR)
	    {
	      /* Find material */
	      
	      mat = RDB[DATA_PTR_M0];
	      if ((mat = SeekListStr(mat, MATERIAL_PTR_NAME, 
				     GetText(ptr + DET_MBIN_PTR_MAT))) 
		  < VALID_PTR)
		Error(det,"Material %s in detector %s is not defined", 
		      GetText(ptr + DET_MBIN_PTR_MAT), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_MBIN_PTR_MAT] = (double)mat;
	      
	      /* Update number of bins */
	      
	      mbins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/

      /***** Link cells to detectors *****************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_CBINS]) < VALID_PTR)
	cbins = 1;
      else
	{
	  /* Reset counter */

	  cbins = 0;

	  /* Loop over cell bins */

	  while (ptr > VALID_PTR)
	    {
	      /* Find cell */
	      
	      cell = RDB[DATA_PTR_C0];
	      if ((cell = SeekListStr(cell, CELL_PTR_NAME, 
				      GetText(ptr + DET_CBIN_PTR_CELL))) 
		  < VALID_PTR)
		Error(det,"Cell %s in detector %s is not defined", 
		      GetText(ptr + DET_CBIN_PTR_CELL), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_CBIN_PTR_CELL] = (double)cell;

	      /* Pointer to universe */

	      uni = (long)RDB[cell + CELL_PTR_UNI];
	      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

	      /* Check universe type and set super-imposed flag */

	      if ((long)RDB[uni + UNIVERSE_TYPE] == UNIVERSE_TYPE_SUPER)
		WDB[ptr + DET_CBIN_SUPER_CELL] = (double)YES;
	      else
		WDB[ptr + DET_CBIN_SUPER_CELL] = (double)NO;
	      
	      /* Update number of bins */
	      
	      cbins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/

      /***** Link dividers and multipliers ***********************************/

      /* Check pointer */

      if ((long)RDB[det + DET_PTR_MUL] > VALID_PTR)
	{
	  /* Find detector */
	  
	  ptr = RDB[DATA_PTR_DET0];
	  if ((ptr = SeekListStr(ptr, DET_PTR_NAME,
				 GetText(det + DET_PTR_MUL)))
	      < VALID_PTR)
	    Error(det, "Multiplier / divider detector %s is not defined", 
		  GetText(det + DET_PTR_MUL));
	  
	  /* Set pointer */
	  
	  WDB[det + DET_PTR_MUL] = (double)ptr;
	}
      
      /***********************************************************************/

      /***** Link adjoints ***************************************************/

      /* Check pointer */

      if ((long)RDB[det + DET_PTR_ADJOINT] > VALID_PTR)
	{
	  /* Find detector */
	  
	  ptr = RDB[DATA_PTR_DET0];
	  if ((ptr = SeekListStr(ptr, DET_PTR_NAME,
				 GetText(det + DET_PTR_ADJOINT)))
	      < VALID_PTR)
	    Error(det,"Adjoint detector %s is not defined", 
		  GetText(det + DET_PTR_ADJOINT));
	  
	  /* Set pointer */
	  
	  WDB[det + DET_PTR_ADJOINT] = (double)ptr;

	  /* Switch history lists on */
	  
	  WDB[DATA_HIST_LIST_SIZE] = fabs(RDB[DATA_HIST_LIST_SIZE]);
	}
      
      /***********************************************************************/

      /***** Link surface current parameters *********************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_SBINS]) > VALID_PTR)
	{
	  /* Find surface */
	      
	  surf = RDB[DATA_PTR_S0];
	  if ((surf = SeekListStr(surf, SURFACE_PTR_NAME, 
				  GetText(ptr + DET_SBIN_PTR_SURF))) 
	      < VALID_PTR)
	    Error(det,"Surface %s in detector %s is not defined", 
		  GetText(ptr + DET_SBIN_PTR_SURF), 
		  GetText(det + DET_PTR_NAME));
	  
	  /* Set pointer */
	  
	  WDB[ptr + DET_SBIN_PTR_SURF] = (double)surf;

	  /* Check invalid options (Tää ei tarkista kaikkea) */

	  if ((long)RDB[det + DET_PTR_UBINS] > VALID_PTR)
	    Error(det, "Universe bins not allowed with current detector");
	  if ((long)RDB[det + DET_PTR_LBINS] > VALID_PTR)
	    Error(det, "Lattice bins not allowed with current detector");
	  if ((long)RDB[det + DET_PTR_MBINS] > VALID_PTR)
	    Error(det, "Material bins not allowed with current detector");
	  if ((long)RDB[det + DET_PTR_CBINS] > VALID_PTR)
	    Error(det, "Cell bins not allowed with current detector");
	}

      /***********************************************************************/
      
      /***** Detector source files *******************************************/

      /* Check if file name is given */

      if ((long)RDB[det + DET_WRITE_PTR_FILE] > VALID_PTR)
	{
	  /* Allocate memory for buffer */

	  ptr = ReallocMem(DATA_ARRAY, SRC_FILE_BUF_SIZE*SRC_BUF_BLOCK_SIZE);

	  /* Put pointer and buffer size */

	  WDB[det + DET_WRITE_PTR_BUF] = (double)ptr;
	  WDB[det + DET_WRITE_BUF_SZ] = (double)SRC_FILE_BUF_SIZE;

	  /* Reset index */

	  WDB[det + DET_WRITE_BUF_IDX] = 0.0;

	  /* Remove old file */

	  remove(GetText(det + DET_WRITE_PTR_FILE));
	}
      
      /***********************************************************************/

      /***** Allocate memory for statistics **********************************/
    
      /* Set final bin sizes */

      WDB[det + DET_N_EBINS] = (double)ebins;
      WDB[det + DET_N_UBINS] = (double)ubins;
      WDB[det + DET_N_CBINS] = (double)cbins;
      WDB[det + DET_N_MBINS] = (double)mbins;
      WDB[det + DET_N_LBINS] = (double)lbins;
      WDB[det + DET_N_RBINS] = (double)rbins;
      WDB[det + DET_N_TBINS] = (double)tbins;

      /* Calculate total size */

      tot = ebins*ubins*cbins*mbins*lbins*rbins*zbins*ybins*xbins*tbins;

      /* Check maximum size */

      if (tot > 100000)
	Error(det, "Total number of bins exceeds maximum");

      /* Check zero */

      if (tot < 1)
	Die(FUNCTION_NAME, "Error in bin sizes");

      /* Put total number fo bins */

      WDB[det + DET_N_TOT_BINS] = (double)tot;

      /* Put name */

      sprintf(str, "DET_%s", GetText(det + DET_PTR_NAME));

      /* Allocate memory for results for non-adjoint detectors */

      if ((long)RDB[det + DET_PTR_ADJOINT] < VALID_PTR)
	{
	  /* Allocate memory */
	  
	  ptr = NewStat(str, 1, tot);
	
	  /* Put pointer */
	  
	  WDB[det + DET_PTR_STAT] = (double)ptr;
	}

      /***********************************************************************/

      /***** Set particle type ***********************************************/

      /* Check if not set */

      if ((long)RDB[det + DET_PARTICLE] == 0)
	{
	  /* Check combined mode */

	  if (((long)RDB[DATA_NEUTRON_TRANSPORT_MODE] == YES) &&
	      ((long)RDB[DATA_PHOTON_TRANSPORT_MODE] == YES))
	    Error(det, "Particle type must be set in combined neutron / photon mode");
	  else if ((long)RDB[DATA_NEUTRON_TRANSPORT_MODE] == YES)
	    WDB[det + DET_PARTICLE] = (double)PARTICLE_TYPE_NEUTRON;
	  else if ((long)RDB[DATA_PHOTON_TRANSPORT_MODE] == YES)
	    WDB[det + DET_PARTICLE] = (double)PARTICLE_TYPE_GAMMA;
	  else
	    Die(FUNCTION_NAME, "What the hell am I doing here?");
	}

      /***********************************************************************/

      /* Next detector */

      det = NextItem(det);
    }
  
  /* Loop over detectors */

  det = (long)RDB[DATA_PTR_DET0];  
  while (det > VALID_PTR)
    {
      /* Check adjoint type */
      
      if ((ptr = (long)RDB[det + DET_PTR_ADJOINT]) > VALID_PTR)
	{
	  /* Get sizes */

	  n1 = (long)RDB[det + DET_N_TOT_BINS];
	  n2 = (long)RDB[ptr + DET_N_TOT_BINS];
  
	  /* Allocate memory */

	  ptr = NewStat(str, 2, n1, n2);

	  /* Put pointer */
	  
	  WDB[det + DET_PTR_STAT] = (double)ptr;
	}
      
      /* Next detector */

      det = NextItem(det);
    }

  /***************************************************************************/

  /***** Checks **************************************************************/

  /* Loop over detectors */

  det = (long)RDB[DATA_PTR_DET0];  
  while (det > VALID_PTR)
    {
      /***********************************************************************/

      /***** Check multiplier / divider detectors ****************************/

      if ((ptr = (long)RDB[det + DET_PTR_MUL]) > VALID_PTR)
	{
	  /* Check number of values */

	  if ((long)RDB[ptr + DET_N_TOT_BINS] > 1)
	    {
	      /* Check each bin */

	      if (RDB[det + DET_N_EBINS] != RDB[ptr + DET_N_EBINS])
		Error(det, "Mismatch in energy bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_UBINS] != RDB[ptr + DET_N_UBINS])
		Error(det, "Mismatch in universe bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_CBINS] != RDB[ptr + DET_N_CBINS])
		Error(det, "Mismatch in cell bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_MBINS] != RDB[ptr + DET_N_MBINS])
		Error(det, "Mismatch in material bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_LBINS] != RDB[ptr + DET_N_LBINS])
		Error(det, "Mismatch in lattice bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_RBINS] != RDB[ptr + DET_N_RBINS])
		Error(det, "Mismatch in reaction bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_TBINS] != RDB[ptr + DET_N_TBINS])
		Error(det, "Mismatch in time bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      
	      /* Mesh bins */

	      msh1 = (long)RDB[det + DET_PTR_MESH];
	      msh2 = (long)RDB[ptr + DET_PTR_MESH];

	      if (msh1*msh2 < 0)
		Error(det, "Mismatch in mesh bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      else if ((msh1 > VALID_PTR) && (msh2 > VALID_PTR))
		{
		  if (RDB[msh1 + MESH_N0] != RDB[msh2 + MESH_N0])
		    Error(det, "Mismatch in mesh bins of detector %s",
			  GetText(ptr + DET_PTR_NAME));
		  if (RDB[msh1 + MESH_N1] != RDB[msh2 + MESH_N1])
		    Error(det, "Mismatch in mesh bins of detector %s",
			  GetText(ptr + DET_PTR_NAME));
		  if (RDB[msh1 + MESH_N2] != RDB[msh2 + MESH_N2])
		    Error(det, "Mismatch in mesh bins of detector %s",
			  GetText(ptr + DET_PTR_NAME));
		}
	    }
	}
      
      /***********************************************************************/

      /* Next detector */

      det = NextItem(det);
    }

  /***************************************************************************/
}  

/*****************************************************************************/
