/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : findcgnscell.c                                 */
/*                                                                           */
/* Created:       2012/09/11 (JLe)                                           */
/* Last modified: 2012/09/16 (JLe)                                           */
/* Version:       2.1.9                                                      */
/*                                                                           */
/* Description: Finds CGNS mesh cell                                         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FindCGNSCell:"

/*****************************************************************************/

long FindCGNSCell(long loc0, double x, double y, double z, long id)
{
  long msh, lst, loc1, cell, ptr;
  
  /* Check pointer */
  
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Check mode */
  
  if (1 != 2)
    {
      /* "Fast mode", get pointer to search mesh */
      
      msh = (long)RDB[loc0 + IFC_PTR_SEARCH_MESH];
      CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);
	  
      /* Get pointer to search mesh */
      
      if ((lst = MeshPtr(msh, x, y, z)) > VALID_PTR)
	lst = (long)RDB[lst];
      
      /* Loop over content */
      
      while (lst > VALID_PTR)
	{
	  /* Pointer to cell */
	  
	  loc1 = (long)RDB[lst + SEARCH_MESH_CELL_CONTENT];
	  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);
	  
	  /* Pointer to cell */
	  
	  cell = (long)RDB[loc1 + IFC_CGNS_PTR_CELL];
	  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);
	  
	  /* Test cell */
	  
	  if (InCell(cell, x, y, z, YES, id) == YES)
	    {
	      /* Check plotter mode */

	      if ((long)RDB[DATA_PLOTTER_MODE] == NO)
		{
		  /* Pointer to counter */
		  
		  ptr = (long)RDB[lst + SEARCH_MESH_PTR_CELL_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
		  
		  /* Add counter */
		  
		  AddPrivateData(ptr, 1, id);
		}

	      /* Return pointer */

	      return loc1;
	    }

	  /* Next */
	  
	  lst = NextItem(lst);
	}
    }
  else
    {
      /* "Safe mode", loop over all cgns cells */
      
      loc1 = (long)RDB[loc0 + IFC_PTR_CGNS];
      while (loc1 > VALID_PTR)
	{
	  /* Get pointer to geometry cell */
	  
	  cell = (long)RDB[loc1 + IFC_CGNS_PTR_CELL];
	  CheckPointer(FUNCTION_NAME, "cell", DATA_ARRAY, cell);
	  
	  /* Test */
	  
	  if (InCell(cell, x, y, z, YES, id) == YES)
	    return loc1;
	  
	  /* Next cgns cell */

	  loc1 = NextItem(loc1);
	}
    }

  /* Not in any, return null */

  return NULLPTR;
}

/*****************************************************************************/
