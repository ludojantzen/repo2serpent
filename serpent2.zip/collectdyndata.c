/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : collectdyndata.c                               */
/*                                                                           */
/* Created:       2012/11/11 (JLe)                                           */
/* Last modified: 2012/11/11 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Collects interval data from dynamic simulation               */

/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CollectDynData:"

/*****************************************************************************/

void  CollectDynData()
{
  long ptr, tb, id;
  double wgt0, wgt1, dt;

  /* Check time dependence */

  if (RDB[DATA_TIME_CUT_TMAX] == INFTY)
    return;

  /* Get time bin index and interval length */
  
  tb = (long)RDB[DATA_DYN_TB];
  dt = RDB[DATA_TIME_CUT_TMAX] - RDB[DATA_TIME_CUT_TMIN];
    
  /* Get previous weight */

  wgt0 = RDB[DATA_DYN_WGT0];

  /* Reset new weight */

  wgt1 = 0.0;

  /* Loop over threads */
  
  for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
    {
      /* Get pointer to bank */

      ptr = (long)RDB[OMPPtr(DATA_PART_PTR_BANK, id)];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get pointer to first item after dummy */

      ptr = NextItem(ptr);

      /* Loop */
      
      while (ptr > VALID_PTR)
	{
	  /* Add to weight */

	  wgt1 = wgt1 + RDB[ptr + PARTICLE_WGT];
	  
	  /* Next */

	  ptr = NextItem(ptr);
	}
    }

  /* Score population and period */

  ptr = (long)RDB[RES_DYN_POP];
  AddStat(wgt1/RDB[DATA_SRC_POP], ptr, tb);

  ptr = (long)RDB[RES_DYN_PERIOD];
  AddStat(dt/log(wgt1/wgt0), ptr, tb);

  /* Put new weight */

  WDB[DATA_DYN_WGT0] = wgt1;
}

/*****************************************************************************/
