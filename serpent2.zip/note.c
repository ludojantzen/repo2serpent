/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : warn.c                                         */
/*                                                                           */
/* Created:       2010/09/14 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prints note or warning message for user                      */
/*                                                                           */
/* Comments: - Tähän yhdeksi argumentiksi pointteri laskuriin?               */
/*           - Noi messaget vois kerätä myös erilliseen fileen               */
/*           - Printataan stdouttiin?                                        */
/*                                                                           */
/*****************************************************************************/

#include "header.h"

#define FUNCTION_NAME "Note:"

/*****************************************************************************/

void Note(long dummy, ...)
{
  va_list argp;
  va_start (argp, dummy);

  fprintf(out, "\n ***** Warning:\n ");
  vfprintf(out, va_arg(argp, char *), argp);
  fprintf(out, "\n\n");
}

/*****************************************************************************/
