/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : whereami.c                                     */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2013/03/05 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Finds neutron location in universes                          */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "WhereAmI:"

/*****************************************************************************/

long WhereAmI(double x, double y, double z, double u, double v, double w, 
	      long id)
{
  long uni, lvl0, lvl, cell, mat, nst, reg, lat, ptr, pbd, pbl, type, ncol;
  long zone, idx;

  /* Get pointer to root universe */
  
  uni = (long)RDB[DATA_PTR_ROOT_UNIVERSE];
  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

  /* Pointer to first level */

  lvl0 = (long)RDB[DATA_PTR_LVL0];
  CheckPointer(FUNCTION_NAME, "(lvl0)", DATA_ARRAY, lvl0);

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);

  /* Reset zone index */

  zone = 0;

  /* Loop over levels */

  while (lvl0 > VALID_PTR)
    {
      /* Pointer to private data */

      lvl = (long)RDB[lvl0 + LVL_PTR_PRIVATE_DATA];
      CheckPointer(FUNCTION_NAME, "(lvl)", PRIVA_ARRAY, lvl);

      /* Check universe pointer */
  
      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

      /* Do coordinate transformation */
      
      if ((ptr = (long)RDB[uni + UNIVERSE_PTR_TRANS]) > VALID_PTR)
	CoordTrans(ptr, &x, &y, &z, &u, &v, &w, id);

      /* Universe symmetry */

      UniSym(uni, &x, &y, &z, &u, &v, &w);

      /* Reset pointers */

      PutPrivateData(lvl + LVL_PRIV_PTR_NEST_REG, NULLPTR, id);
      PutPrivateData(lvl + LVL_PRIV_PTR_LAT, NULLPTR, id);
      PutPrivateData(lvl + LVL_PRIV_PTR_CELL, NULLPTR, id);
      PutPrivateData(lvl + LVL_PRIV_PTR_PBED, NULLPTR, id);
      PutPrivateData(lvl + LVL_PRIV_PTR_PEBBLE, NULLPTR, id);
      PutPrivateData(lvl + LVL_PRIV_PTR_MAT, NULLPTR, id);

      /* Put coordinates and direction cosines */
      
      PutPrivateData(lvl + LVL_PRIV_X, x, id);
      PutPrivateData(lvl + LVL_PRIV_Y, y, id);
      PutPrivateData(lvl + LVL_PRIV_Z, z, id);
      PutPrivateData(lvl + LVL_PRIV_U, u, id);
      PutPrivateData(lvl + LVL_PRIV_V, v, id);
      PutPrivateData(lvl + LVL_PRIV_W, w, id);

      /* Put coordinates to universe structure */

      ptr = RDB[uni + UNIVERSE_PTR_PRIVA_X];
      PutPrivateData(ptr, x, id);

      ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Y];
      PutPrivateData(ptr, y, id);

      ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Z];
      PutPrivateData(ptr, z, id);

      /* Reset last flag */
      
      PutPrivateData(lvl + LVL_PRIV_LAST, NO, id);
      
      /* Put level type */

      type = (long)RDB[uni + UNIVERSE_TYPE];
      PutPrivateData(lvl + LVL_PRIV_TYPE, type, id);
      
      /* Put universe pointer */

      PutPrivateData(lvl + LVL_PRIV_PTR_UNIV, uni, id);

      /* Put collision flag */

      StoreValuePair(uni + UNIVERSE_COL_COUNT, ncol, 1.0, id);

      /* Put gcu pointer */

      if ((long)RDB[DATA_OPTI_GC_CALC] == YES)
      	if ((ptr = RDB[uni + UNIVERSE_PTR_GCU]) > VALID_PTR)
	  StoreValuePair(DATA_GCU_PTR_UNI, ncol, ptr, id);

      /* Put collision universe */

      ptr = (long)RDB[DATA_PTR_COLLISION_UNI];
      PutPrivateData(ptr, uni, id);      

      /* Avoid warning messages */
      
      cell = -1;
      
      /* Check universe type */
      
      switch (type)
	{
	case UNIVERSE_TYPE_NEST:
	  {
	    /***** Nest universe *********************************************/

	    /* Pointer to nest */
	    
	    nst = (long)RDB[uni + UNIVERSE_PTR_NEST];
	    CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

	    /* Find nest region */
	    
	    reg = FindNestRegion(uni, nst, x, y, z, id);
	    CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

	    /* Get region index and update zone */

	    idx = (long)RDB[reg + NEST_REG_IDX];
	    zone = zone + ((long)RDB[lvl0 + LVL_ZONE_IDX_MULT])*idx;

	    /* Put region pointer */
	    
	    PutPrivateData(lvl + LVL_PRIV_PTR_NEST_REG, reg, id);
	    
	    /* Get cell pointer */
	    
	    cell = (long)RDB[reg + NEST_REG_PTR_CELL];
	    CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

	    /* Put cell pointer */
	    
	    PutPrivateData(lvl + LVL_PRIV_PTR_CELL, cell, id);
	    
	    /* Put collision flag */
	    
	    StoreValuePair(cell + CELL_COL_COUNT, ncol, 1.0, id);

	    /* Put collision region */

	    StoreValuePair(nst + NEST_PTR_COL_REG, ncol, reg, id);

	    /* Check fill pointer */
	    
	    if ((ptr = RDB[reg + NEST_REG_PTR_FILL]) > VALID_PTR)
	      {
		/* Filled region, update universe pointer */
		
		uni = ptr;
	      }
	    else
	      {
		/* Put zone index */

		ptr = (long)RDB[DATA_PTR_ZONE_IDX];
		PutPrivateData(ptr, zone, id);
		PutPrivateData(lvl + LVL_PRIV_ZONE_IDX,zone, id);

		/* Get material pointer */
	    
		mat = (long)RDB[cell + CELL_PTR_MAT];
		mat = MatPtr(mat, id);
		
		/* Put private pointer */
		
		PutPrivateData(lvl + LVL_PRIV_PTR_MAT, mat, id);
	    
		/* Put last flag */
		
		PutPrivateData(lvl + LVL_PRIV_LAST, YES, id);
		
		/* Return cell pointer */
		
		return cell;
	      }
	    
	    /* Break case */
	    
	    break;
	    
	    /****************************************************************/
	  }      
	  
	case UNIVERSE_TYPE_CELL:
	  {
	    /***** Cell universe ********************************************/
	    
	    /* Find cell */

	    if ((cell = FindUniverseCell(uni, x, y, z, &idx, id)) < VALID_PTR)
	      {
		/* Geometry error, check plotter mode */

		if ((long)RDB[DATA_PLOTTER_MODE] == YES)
		  return cell;
		else
		  Error(0, 
			"Geometry error in universe %s at (%1.2E %1.2E %1.2E)", 
			GetText(uni + UNIVERSE_PTR_NAME), x, y, z);
	      }

	    /* Check pointer */

	    CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

	    /* Update zone */

	    zone = zone + ((long)RDB[lvl0 + LVL_ZONE_IDX_MULT])*idx;

	    /* Put cell pointer */
	    
	    PutPrivateData(lvl + LVL_PRIV_PTR_CELL, cell, id);

	    /* Put collision flag */

	    StoreValuePair(cell + CELL_COL_COUNT, ncol, 1.0, id);
	    
	    /* Check fill pointer and call recursively */
	    
	    if ((ptr = RDB[cell + CELL_PTR_FILL]) > VALID_PTR)
	      {
		/* Filled cell, update universe pointer */
		
		uni = ptr;
	      }
	    else
	      {
		/* Put zone index */

		ptr = (long)RDB[DATA_PTR_ZONE_IDX];
		PutPrivateData(ptr, zone, id);
		PutPrivateData(lvl + LVL_PRIV_ZONE_IDX,zone, id);

		/* Get material pointer */
	    
		mat = (long)RDB[cell + CELL_PTR_MAT];
		mat = MatPtr(mat, id);
		
		/* Put private pointer */
		
		PutPrivateData(lvl + LVL_PRIV_PTR_MAT, mat, id);
	    
		/* Put last flag */
		
		PutPrivateData(lvl + LVL_PRIV_LAST, YES, id);

		/* Return cell pointer */
		
		return cell;
	      }

	    /* Break case */

	    break;

	    /*****************************************************************/
	  }      

	case UNIVERSE_TYPE_LATTICE:
	  {
	    /***** Lattice universe ******************************************/

	    /* Pointer to lattice */

	    lat = (long)RDB[uni + UNIVERSE_PTR_LAT];
	    CheckPointer(FUNCTION_NAME, "(lat)", DATA_ARRAY, lat);
	    
	    /* Put lattice pointer */
	    
	    PutPrivateData(lvl + LVL_PRIV_PTR_LAT, lat, id);
	    
	    /* Find lattice universe */
	    
	    if ((ptr = FindLatticeRegion(lat, lvl, &x, &y, &z, &idx, id)) 
		< VALID_PTR)
	      {
		/* Check plotter mode */
		
		if ((long)RDB[DATA_PLOTTER_MODE] == YES)
		  return GEOM_ERROR_NO_CELL;
		else
		  Error(lat, 
			"Invalid lattice element hit at (%1.2E %1.2E %1.2E)", 
			x, y, z);
	      }

	    /* Update zone */

	    zone = zone + ((long)RDB[lvl0 + LVL_ZONE_IDX_MULT])*idx;

	    /* Update universe pointer */
		
	    uni = ptr;

	    /* Break case */
	    
	    break;
	    
	    /*****************************************************************/
	  }
	  
	case UNIVERSE_TYPE_PBED:
	  {
	    /***** Explicit stochastic geometry ******************************/

	    /* Pointer to geometry */
	    
	    pbd = (long)RDB[uni + UNIVERSE_PTR_PBED];
	    CheckPointer(FUNCTION_NAME, "(pbd)", DATA_ARRAY, pbd);
	    
	    /* Put lattice pointer */
	    
	    PutPrivateData(lvl + LVL_PRIV_PTR_PBED, pbd, id);
	    
	    /* Find universe */

	    ptr = FindPBRegion(uni, pbd, &x, &y, &z, &pbl, &idx, id);

	    /* Update zone */

	    zone = zone + ((long)RDB[lvl0 + LVL_CUM_MAX_REGIONS])*idx;

	    /* Put direct pointer to pebble */
	    
	    PutPrivateData(lvl + LVL_PRIV_PTR_PEBBLE, pbl, id);

	    /* Update universe pointer */
		
	    uni = ptr;

	    /* Break case */

	    break;
	    
	    /*****************************************************************/
	  }

	default:
	  {
	    /* Invalid type */
	    
	    Die(FUNCTION_NAME, "Invalid universe type");
	  }
	}

      /* Next level */

      lvl0 = NextItem(lvl0);
    }

  /* Error */

  Die(FUNCTION_NAME, "No material cell");

  /* Avoid warning message */

  return 0;
}

/*****************************************************************************/
