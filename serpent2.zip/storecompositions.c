/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : storecompositions.c                            */
/*                                                                           */
/* Created:       2012/07/14 (JLe)                                           */
/* Last modified: 2012/07/14 (JLe)                                           */
/* Version:       2.1.8                                                      */
/*                                                                           */
/* Description: Stores compositions of burnable materials in a binary file   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "StoreCompositions:"

/*****************************************************************************/

void StoreCompositions(long idx)
{
  long nuc, mat, nnuc, iso;
  char tmpstr[MAX_STR];
  double adens;
  FILE *fp;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* File name */

  sprintf(tmpstr, "%s.i%ld", GetText(DATA_PTR_INPUT_FNAME), idx);

  /* Open file for writing (vai append?) */

  fp = fopen(tmpstr, "w");
  
  /* Check pointer */

  if (fp == NULL)
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /* Loop over compositions */

  mat = (long)RDB[DATA_PTR_M0];
  while(mat > VALID_PTR)
    {
      /* Get number of nuclides */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      nnuc = ListSize(iso);

      /* Loop over composition */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Write pointer */
      
	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  fwrite(&nuc, sizeof(long), 1, fp);

	  /* Write atomic density */
      
	  adens = RDB[iso + COMPOSITION_ADENS];
	  fwrite(&adens, sizeof(double), 1, fp);
	  
	  /* Next nuclide in composition */

	  iso = NextItem(iso);
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /* Close file and exit */

  fclose(fp);  
}

/*****************************************************************************/
