/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : collectresults.c                               */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2013/04/23 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Collects results after cycle or batch                        */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CollectResults:"

/*****************************************************************************/

void CollectResults()
{
  long ptr, mat, i, n, m, ng, n0, n1, n2, nz, gcu, pbd, nuc, rea, loc0, loc1;
  long uni, tfb, nst, reg, tb, nr, k, pts, nc, np;
  double nubar, tot, nuxn, capt, scatt, fiss, leak, val, flx, tots, gent, keff;
  double norm, sum, fE, div, fmass, wgt0, wgt1, beta, invv;

  /***************************************************************************/

  /***** Get parallel data ***************************************************/

  /* Reduce scoring buffer */

  ReduceBuffer();

  /* Collect MPI parallel data */

  CollectBuf();

  /***************************************************************************/

  /***** Collision and reaction sampling *************************************/

  /* Loop over particle types */

  for (n = 0; n < 2; n++)
    {
      /* Get total number of sampled tracks (ST + DT) */

      ptr = (long)RDB[RES_ST_TRACK_FRAC];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      div = BufVal(ptr, n);

      ptr = (long)RDB[RES_DT_TRACK_FRAC];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      div = div + BufVal(ptr, n);

      /* Calculate fractions */

      if (div > 0.0)
	{
	  ptr = (long)RDB[RES_ST_TRACK_FRAC];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  val = BufVal(ptr, n);
	  AddStat(val/div, ptr, n);
	  
	  ptr = (long)RDB[RES_DT_TRACK_FRAC];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  val = BufVal(ptr, n);
	  AddStat(val/div, ptr, n);
	}

      /* Efficiency of delta-tracking */

      ptr = (long)RDB[RES_DT_TRACK_EFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      div = BufVal(ptr, n) + BufVal(ptr, n + 2);

      if (div > 0.0)
	{
	  val = BufVal(ptr, n);
	  AddStat(val/div, ptr, n);
	}

      /* Total collision efficiency */

      ptr = (long)RDB[RES_TOT_COL_EFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      div = BufVal(ptr, n) + BufVal(ptr, n + 2);
      
      if (div > 0.0)
	{
	  val = BufVal(ptr, n);
	  AddStat(val/div, ptr, n);
	}

      /* Reaction sampling efficiency */

      ptr = (long)RDB[RES_REA_SAMPLING_EFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      div = BufVal(ptr, n) + BufVal(ptr, n + 2);

      if (div > 0.0)
	{
	  val = BufVal(ptr, n);
	  AddStat(val/div, ptr, n);
	}
      
      /* Failure rate */

      ptr = (long)RDB[RES_REA_SAMPLING_FAIL];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, n);

      if (div > 0.0)
	AddStat(val/div, ptr, n);

      /* Efficiency of interface collision rejection */

      ptr = (long)RDB[RES_IFC_COL_EFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufMean(ptr, n);
      
      if (val > 0.0)
	AddStat(val, ptr, n);

      /* Average number of surface crossings per history (skip photons */
      /* for now */

      if ((div = RDB[DATA_CYCLE_BATCH_SIZE]) > 0.0)
	{
	  ptr = (long)RDB[RES_AVG_SURF_CROSS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  val = BufVal(ptr, 0);
	  AddStat(val/div, ptr, 0);
	}
      
      /* Minimum macroscopic XS */

      ptr = (long)RDB[RES_MIN_MACROXS];
      val = BufMean(ptr, n);
      AddStat(val, ptr, n);
    }

  /* ETTM sampling efficiency */

  ptr = (long)RDB[RES_ETTM_SAMPLING_EFF];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  if ((div = BufVal(ptr, 1)) > 0)
    {
      val = BufVal(ptr, 0);
      AddStat(val/div, ptr, 0);
    }

  /***************************************************************************/

  /***** Normalized total reaction rates for photons *************************/

  /* Check transport mode */

  if ((long)RDB[DATA_PHOTON_TRANSPORT_MODE] == YES)
    {
      /* Get normalization factor for photon source */

      norm = NormCoef(PARTICLE_TYPE_GAMMA);
      CheckValue(FUNCTION_NAME, "norm", "", norm, 0.0, INFTY);

      /* Store value */

      ptr = (long)RDB[RES_NORM_COEF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(norm, ptr, 1);

      /* Total leak rate */
      
      ptr = (long)RDB[RES_TOT_PHOTON_LEAKRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      leak = BufVal(ptr, 0);
      AddStat(norm*leak, ptr, 0);

      /* Total energy cut-off rate */
      
      ptr = (long)RDB[RES_TOT_PHOTON_CUTRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, 0);
      AddStat(norm*val, ptr, 0);
      
      /* Total loss rate */
      
      ptr = (long)RDB[RES_TOT_PHOTON_LOSSRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(norm*(leak + val), ptr, 0);
      
      /* Total reaction rate */
      
      ptr = (long)RDB[RES_TOT_PHOTON_RR];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, 0);
      AddStat(norm*val, ptr, 0);
      
      /* Total source rate */
      
      ptr = (long)RDB[RES_TOT_PHOTON_SRCRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, 0);
      AddStat(norm*val, ptr, 0);
      
      /* Total flux */
      
      ptr = (long)RDB[RES_TOT_PHOTON_FLUX];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, 0);
      AddStat(norm*val, ptr, 0);
      
      /* Total heating rate */
      
      ptr = (long)RDB[RES_TOT_PHOTON_HEATRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, 0);
      AddStat(norm*val, ptr, 0);

      /* Analog reaction rate estimates */

      if ((long)RDB[DATA_ANA_RR_PCALC] != ARR_MODE_NONE)
	{
	  /* Loop over nuclides */

	  nuc = (long)RDB[DATA_PTR_NUC0];
	  while (nuc > VALID_PTR)
	    {
	      /* Check type */
	      
	      if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON)
		{
		  /* Loop over reactions */
		  
		  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
		  while (rea > VALID_PTR)
		    {
		      /* Get pointer */
		      
		      if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > 
			  VALID_PTR)
			{
			  /* Add to statistics */
			  
			  val = BufVal(ptr, 0);
			  AddStat(val*norm, ptr, 0);
			}
		      
		      /* Next reaction */
		      
		      rea = NextItem(rea);
		    }
		}
	      
	      /* Next nuclide */
	      
	      nuc = NextItem(nuc);
	    }
	}

      /* Lifetime */
  
      ptr = (long)RDB[RES_ANA_PHOTON_LIFETIME];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufMean(ptr, 0);
      AddStat(val, ptr, 0);
    }

  /* Check neutron transport mode */

  if ((long)RDB[DATA_NEUTRON_TRANSPORT_MODE] == NO)
    return;

  /* Get normalization factor for neutron source */

  norm = NormCoef(PARTICLE_TYPE_NEUTRON);
  CheckValue(FUNCTION_NAME, "norm", "", norm, 0.0, INFTY);

  /* Store value */

  ptr = (long)RDB[RES_NORM_COEF];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddStat(norm, ptr, 0);

  /***************************************************************************/
  
  /***** Common integral parameters for neutrons *****************************/
  
  /* Analog fission nubar */
  
  ptr = (long)RDB[RES_ANA_NUBAR];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  nubar = BufMean(ptr, 0);
  
  /* Fission term */
  
  ptr = (long)RDB[RES_TOT_FISSRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  fiss = BufVal(ptr, 0);

  /* Total source weights */
  
  ptr = (long)RDB[RES_INI_SRC_WGT];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  wgt0 = BufVal(ptr, 0);
  
  ptr = (long)RDB[RES_NEW_SRC_WGT];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  wgt1 = BufVal(ptr, 0);
    
  /* Check initial weight */
  
  CheckValue(FUNCTION_NAME, "wgt0", "", wgt0, ZERO, INFTY);
  
  /* Check mode */
  
  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      /* Collision estimate of k-eff */
      
      ptr = (long)RDB[RES_COL_KEFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(1.0 - wgt0/(wgt0 + fiss*nubar), ptr, 0);
      
      /* Analog estimate of k-eff */
      
      ptr = (long)RDB[RES_ANA_KEFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(1.0 - wgt0/(wgt0 + wgt1), ptr, 0);

      /* Source multiplication */

      ptr = (long)RDB[RES_SRC_MULT];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat((wgt1 + wgt0)/wgt0, ptr, 0);
      
      /* Mean number of generations */

      ptr = (long)RDB[RES_MEAN_NGEN];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufMean(ptr, 0);
      AddStat(val, ptr, 0);

      /* Loop over generations */
      
      for (i = 0; i < MAX_EXT_K_GEN; i++)
	if (wgt0 > 0.0)
	  {
	    /* Get new source weight */
	    
	    ptr = (long)RDB[RES_NEW_SRC_WGT];
	    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    wgt1 = BufVal(ptr, i + 1);
	    
	    /* Score k-eff */
	    
	    ptr = (long)RDB[RES_EXT_K];
	    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    AddStat(wgt1/wgt0, ptr, i);
	    
	    /* Update weight */
	    
	    wgt0 = wgt1;
	  }
    }
  else
    {
      /* Analog estimate of k-eff */
      
      ptr = (long)RDB[RES_ANA_KEFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Total */

      val = BufMean(ptr, 0);
      AddStat(val, ptr, 0);

      /* Prompt */
      
      val = BufVal(ptr, 1)/RDB[DATA_CRIT_POP];
      AddStat(val, ptr, 1);

      /* Delayed */
      
      val = BufVal(ptr, 2)/RDB[DATA_CRIT_POP];
      AddStat(val, ptr, 2);

      /* Collision estimate of k-eff */
      
      ptr = (long)RDB[RES_COL_KEFF];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(fiss*nubar/wgt0, ptr, 0);
    }
  
  /* Total capture rate */
      
  ptr = (long)RDB[RES_TOT_CAPTRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  capt = BufVal(ptr, 0);
  
  /* Scattering production rate */
  
  ptr = (long)RDB[RES_TOT_INLPRODRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  nuxn = BufVal(ptr, 0);
    
  /* Leak term */
  
  ptr = (long)RDB[RES_TOT_NEUTRON_LEAKRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  leak = BufVal(ptr, 0);

  ptr = (long)RDB[RES_ALB_NEUTRON_LEAKRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  leak = leak + BufVal(ptr, 0);

  /* Implicit estimate of k-eff */
  
  ptr = (long)RDB[RES_IMP_KEFF];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  keff = nubar*fiss/(capt + fiss - nuxn + leak + ZERO);
  AddStat(keff, ptr, 0);
  
  /* Implicit estimate of k-inf */
  
  ptr = (long)RDB[RES_IMP_KINF];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddStat(nubar*fiss/(capt + fiss - nuxn + ZERO), ptr, 0);

  /* Albedo */

  ptr = (long)RDB[RES_GEOM_ALBEDO];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddStat(RDB[DATA_GEOM_ALBEDO], ptr, 0);

  /* Total flux */
  
  ptr = (long)RDB[RES_TOT_NEUTRON_FLUX];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  div = BufVal(ptr, 0);
  
  /* 1/v */
  
  ptr = (long)RDB[RES_TOT_RECIPVEL];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  invv = BufVal(ptr, 0);
  AddStat(invv/div, ptr, 0);

  /***************************************************************************/

  /***** Forward-weighted time constants *************************************/

  /* Implicit lifetime estimators */
  
  if ((fiss > 0.0) && (nubar > 0.0))
    {
      /* Neutron generation (reproduction time) */

      ptr = (long)RDB[RES_FWD_IMP_GEN_TIME];
      CheckPointer(FUNCTION_NAME, "(ptr1)", DATA_ARRAY, ptr);
      val = invv/fiss/nubar;
      AddStat(val, ptr, 0);

      /* Prompt neutron lifetime */

      ptr = (long)RDB[RES_FWD_IMP_LIFETIME];
      CheckPointer(FUNCTION_NAME, "(ptr2)", DATA_ARRAY, ptr);
      val = keff*val;
      AddStat(val, ptr, 0);
      
      /* Analog beta zero */

      ptr = (long)RDB[RES_FWD_ANA_BETA_ZERO];
      CheckPointer(FUNCTION_NAME, "(ptr4)", DATA_ARRAY, ptr);

      /* Loop over precursor groups */

      for (n = 0; n < (long)RDB[DATA_PRECURSOR_GROUPS] + 1; n++)
	{
	  val = BufVal(ptr, n);
	  AddStat(val/fiss/nubar, ptr, n);
	}

      /* Analog decay constant */

      ptr = (long)RDB[RES_FWD_ANA_LAMBDA];
      CheckPointer(FUNCTION_NAME, "(ptr4)", DATA_ARRAY, ptr);

      /* Loop over precursor groups */

      for (n = 0; n < (long)RDB[DATA_PRECURSOR_GROUPS] + 1; n++)
	{
	  val = BufMean(ptr, n);
	  AddStat(val, ptr, n);
	}
    }

  /***************************************************************************/

  /***** Adjoint-weighted time constants *************************************/

  /* Get total fission rate */

  ptr = (long)RDB[RES_TOT_FISSRATE];
  CheckPointer(FUNCTION_NAME, "(ptr5)", DATA_ARRAY, ptr);
  fiss = BufVal(ptr, 0);
  
  /* Get analog k-eff */
  
  keff = RDB[DATA_CYCLE_KEFF];

  /* Check */

  if (fiss > 0.0)
    {
      /* Meulekamp beta-eff and lambda */
      
      for (n = 0; n < (long)RDB[DATA_PRECURSOR_GROUPS] + 1; n++)
	{
	  /* Beta-eff */

	  ptr = (long)RDB[RES_ADJ_MEULEKAMP_BETA_EFF];
	  CheckPointer(FUNCTION_NAME, "(ptr6)", DATA_ARRAY, ptr);
	  val = BufVal(ptr, n);
	  AddStat(val/fiss, ptr, n);

	  /* Lambda */

	  if (val > 0.0)
	    {
	      ptr = (long)RDB[RES_ADJ_MEULEKAMP_LAMBDA];
	      CheckPointer(FUNCTION_NAME, "(ptr6)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n)/val;
	      AddStat(val, ptr, n);
	    }
	}
      
      /* IFP estimators */

      if ((np = (long)RDB[DATA_IFP_CHAIN_LENGTH]) > 0)
	{
	  /* Loop over chain */

	  for (m = 0; m < np; m++)
	    {
	      /* Avoid compiler warning */

	      gent = 0.0;
	      beta = 0.0;
	      
	      /* Loop over types (t/p/d) */
	      
	      for (n = 0; n < 3; n++)
		{
		  /* Lifetime */

		  ptr = (long)RDB[RES_ADJ_IFP_LIFETIME];
		  CheckPointer(FUNCTION_NAME, "(ptr8)", DATA_ARRAY, ptr);
		  val = BufMean(ptr, n, m);
		  AddStat(val, ptr, n, m);
		  
		  /* Generation time */
        
		  ptr = (long)RDB[RES_ADJ_IFP_GEN_TIME];
		  CheckPointer(FUNCTION_NAME, "(ptr7)", DATA_ARRAY, ptr);
		  AddStat(val/keff, ptr, n, m);

		  /* Remember prompt value */

		  if (n == 1)
		    gent = val/keff;
		}

	      /* Loop over precursor groups */
	  
	      for (n = 0; n < (long)RDB[DATA_PRECURSOR_GROUPS] + 1; n++)
		{
		  /* Beta-eff */

		  ptr = (long)RDB[RES_ADJ_IFP_BETA_EFF];
		  CheckPointer(FUNCTION_NAME, "(ptr9)", DATA_ARRAY, ptr);
		  val = BufVal(ptr, n, m);
		  AddStat(val/fiss, ptr, n, m);

		  /* Remember total value */

		  if (n == 0)
		    beta = val/fiss;

		  /* Lambda */

		  if (val > 0.0)
		    {
		      ptr = (long)RDB[RES_ADJ_IFP_LAMBDA];
		      CheckPointer(FUNCTION_NAME, "(ptr9)", DATA_ARRAY, ptr);
		      val = BufVal(ptr, n, m)/val;
		      AddStat(val, ptr, n, m);
		    }
		}

	      /* Rossi alpha */

	      if (gent > 0.0)
		{
		  ptr = (long)RDB[RES_ADJ_IFP_ROSSI_ALPHA];
		  CheckPointer(FUNCTION_NAME, "(ptr10)", DATA_ARRAY, ptr);
		  AddStat(-beta/gent, ptr, m);
		}
	    }
	}

      /* PERT estimators */

      if ((np = (long)RDB[DATA_IFP_CHAIN_LENGTH]) > 0)
	{
	  /* Avoid compiler warning */

	  gent = 0.0;
	  beta = 0.0;
	  
	  /* Loop over types (t/p/d) */
	  
	  for (n = 0; n < 3; n++)
	    {
	      /* Lifetime */
	      
	      ptr = (long)RDB[RES_ADJ_PERT_LIFETIME];
	      CheckPointer(FUNCTION_NAME, "(ptr11)", DATA_ARRAY, ptr);
	      val = BufMean(ptr, n);
	      AddStat(val, ptr, n);
	      
	      /* Generation time */	      

	      ptr = (long)RDB[RES_ADJ_PERT_GEN_TIME];
	      CheckPointer(FUNCTION_NAME, "(ptr12)", DATA_ARRAY, ptr);
	      AddStat(val/keff, ptr, n);

	      /* Remember prompt value (not calculated, use total) */
	      
	      if (n == 0)
		gent = val/keff;
	    }
	  
	  /* Beta-eff */
	  
	  ptr = (long)RDB[RES_ADJ_PERT_BETA_EFF];
	  CheckPointer(FUNCTION_NAME, "(ptr13)", DATA_ARRAY, ptr);
	  
	  /* Loop over precursor groups */
	  
	  for (n = 0; n < (long)RDB[DATA_PRECURSOR_GROUPS] + 1; n++)
	    {
	      val = BufMean(ptr, n);
	      AddStat(val, ptr, n);
	      
	      /* Remember total value */
	      
	      if (n == 0)
		beta = val;
	    }
	  
	  /* Rossi alpha */
	  
	  if (gent > 0.0)
	    {
	      ptr = (long)RDB[RES_ADJ_PERT_ROSSI_ALPHA];
	      CheckPointer(FUNCTION_NAME, "(ptr14)", DATA_ARRAY, ptr);
	      AddStat(-beta/gent, ptr, 0);
	    }
	}
    }

  /***************************************************************************/

  /***** Misc. time constants ************************************************/

  /* Loop over total, prompt and delayed values */

  for (n = 0; n < 3; n++)
    {
      /* Slowing-down time */
  
      ptr = (long)RDB[RES_ANA_SLOW_TIME];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufMean(ptr, n);
      AddStat(val, ptr, n);

      /* Thermal neutron lifetime */
  
      ptr = (long)RDB[RES_ANA_THERM_TIME];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufMean(ptr, n);
      AddStat(val, ptr, n);
    }

  /* Get source weight */
  
  ptr = (long)RDB[RES_INI_SRC_WGT];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  div = BufVal(ptr, 0);
 
  /* Get total delayed neutron fraction */
  
  ptr = (long)RDB[RES_ANA_NUBAR];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  beta = BufVal(ptr, 0);

  if (beta > 0.0)
    {
      ptr = (long)RDB[RES_FWD_ANA_BETA_ZERO];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      beta = BufVal(ptr, 0)/beta;
    }

  /* Total neutron thermalization fraction */
  
  ptr = (long)RDB[RES_ANA_THERM_TIME];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  val = BufWgt(ptr, 0);

  ptr = (long)RDB[RES_ANA_THERM_FRAC];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddStat(val/div, ptr, 0);

  /* Prompt neutron thermalization fraction */

  ptr = (long)RDB[RES_ANA_THERM_TIME];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  val = BufWgt(ptr, 1);

  ptr = (long)RDB[RES_ANA_THERM_FRAC];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddStat(val/((1.0 - beta)*div), ptr, 1);

  /* Delayed neutron thermalization fraction */

  if ((beta*div) > 0.0)
    {
      ptr = (long)RDB[RES_ANA_THERM_TIME];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufWgt(ptr, 2);
      
      ptr = (long)RDB[RES_ANA_THERM_FRAC];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(val/(beta*div), ptr, 2);
    }

  /* Analog estimate of delayed neutron emission time */
  
  ptr = (long)RDB[RES_ANA_DELAYED_EMTIME];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  val = BufMean(ptr, 0);
  AddStat(val, ptr, 0);

  /***************************************************************************/

  /***** Fission matrix ******************************************************/

  /* Get pointer to matrix data */

  if ((loc0 = (long)RDB[DATA_PTR_FMTX]) > VALID_PTR)
    {
      /* Get size */

      ng = (long)RDB[loc0 + FMTX_SIZE];

      /* Get pointer to source term */
      
      pts = (long)RDB[loc0 + FMTX_PTR_SRC];
      CheckPointer(FUNCTION_NAME, "(pts)", DATA_ARRAY, pts);

      /* Get pointer to matrix */
      
      ptr = (long)RDB[loc0 + FMTX_PTR_MTX];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Loop over groups and source regions */

      for (i = 0; i < 3; i++)
	{
#ifdef OPEN_MP
#pragma omp parallel private(n, m, div, val)
#endif
	  {
			
#ifdef OPEN_MP
#pragma omp for 
#endif	  
	    for (n = 0; n < ng; n++)
	      {
		/* Source term */
		
		div = BufVal(pts, i, n);
		
		/* Loop over target regions score */
		
		for (m = 0; m < ng; m++)
		  {
		    /* Get value */
		    
		    val = BufVal(ptr, i, m, n);
		    
		    /* Check divisor and score */
		    
		    if (div > 0.0)	      
		      AddStat(val/div, ptr, i, m, n);
		  }	  
	      }
	  }
	}
    }

  /* Check active cycle */

  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP])
    return;

  /***************************************************************************/
  
  /***** Normalized total reaction rates for neutrons ************************/

  /* Total cut-off rate (no binned values) */
  
  ptr = (long)RDB[RES_TOT_NEUTRON_CUTRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  leak = BufVal(ptr, 0);
  AddStat(norm*leak, ptr, 0);

  /* Total leak rate (no binned values) */
  
  ptr = (long)RDB[RES_TOT_NEUTRON_LEAKRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  leak = BufVal(ptr, 0);
  AddStat(norm*leak, ptr, 0);

  /* Albedo leak rate */
  
  ptr = (long)RDB[RES_ALB_NEUTRON_LEAKRATE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  val = BufVal(ptr, 0);
  AddStat(norm*val, ptr, 0);
  
  /* Add to leak term */

  leak = leak + val;

  /* Total reaction rate */
  
  ptr = (long)RDB[RES_TOT_NEUTRON_RR];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  val = BufVal(ptr, 0);
  AddStat(norm*val, ptr, 0);
  
  /* Loop over total, burnable and non-burnable rates */
  
  for (i = 0; i < 3; i++)
    {
      /* Analog fission energy */
      
      ptr = (long)RDB[RES_ANA_FISSE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      fE = BufMean(ptr, i);
      AddStat(fE, ptr, i); 
      
      /* Analog fission nubar */
      
      ptr = (long)RDB[RES_ANA_NUBAR];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      nubar = BufMean(ptr, i);
      AddStat(fE, ptr, i); 
      
      /* Total fission rate */
      
      ptr = (long)RDB[RES_TOT_FISSRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      fiss = BufVal(ptr, i);
      AddStat(norm*fiss, ptr, i);
      
      /* Implicit fission energy */

      if (fiss > 0.0)
	{      
	  ptr = (long)RDB[RES_IMP_FISSE];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  val = BufVal(ptr, i)/fiss;
	  AddStat(val, ptr, i); 

	  /* Replace analog value */

	  if (val > 0.0)
	    fE = val;
	}

      /* Total power */
      
      ptr = (long)RDB[RES_TOT_NEUTRON_POWER];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(norm*fiss*fE, ptr, i);
      
      /* Total power density */
      
      if (i == 0)
	fmass = RDB[DATA_INI_FMASS];
      else if (i == 1)
	fmass = RDB[DATA_INI_BURN_FMASS];
      else
	fmass = RDB[DATA_INI_FMASS] - RDB[DATA_INI_BURN_FMASS];
      
      if (fmass > 0.0)
	{
	  ptr = (long)RDB[RES_TOT_POWDENS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddStat(1E-6*norm*fiss*fE/fmass, ptr, i);
	}
      
      /* Total generation rate */
      
      ptr = (long)RDB[RES_TOT_GENRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(norm*fiss*nubar, ptr, i);
      
      /* Total capture rate */
      
      ptr = (long)RDB[RES_TOT_CAPTRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      capt = BufVal(ptr, i);
      AddStat(norm*capt, ptr, i);
      
      /* Total absorption rate */
      
      ptr = (long)RDB[RES_TOT_ABSRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(norm*(capt + fiss), ptr, i);
      
      /* Total loss rate */
      
      ptr = (long)RDB[RES_TOT_NEUTRON_LOSSRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddStat(norm*(leak + capt + fiss), ptr, i);
      
      /* Total flux */
      
      ptr = (long)RDB[RES_TOT_NEUTRON_FLUX];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, i);
      AddStat(norm*val, ptr, i);
      
      /* Total source rate */
      
      ptr = (long)RDB[RES_TOT_NEUTRON_SRCRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, i);
      AddStat(norm*val, ptr, i);
    }
  
  /***************************************************************************/
  
  /***** Analog reaction rate estimators for neutrons ************************/
  
  /* Conversion ratio */
  
  ptr = (long)RDB[RES_ANA_CONV_RATIO];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  val = BufVal(ptr, 1);
  div = BufVal(ptr, 2);
  
  if (div > 0.0)
    AddStat(val/div, ptr, 0);
  
  /* Fission fractions */
  
  ptr = (long)RDB[RES_ANA_FISS_FRAC];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  div = BufVal(ptr, 0);
  
  if (div > 0.0)
    {
      val = BufVal(ptr, 1);
      AddStat(val/div, ptr, 1);
      
      val = BufVal(ptr, 2);
      AddStat(val/div, ptr, 2);
      
      val = BufVal(ptr, 3);
      AddStat(val/div, ptr, 3);
      
      val = BufVal(ptr, 4);
      AddStat(val/div, ptr, 4);
      
      val = BufVal(ptr, 5);
      AddStat(val/div, ptr, 5);
    }
  
  /***************************************************************************/

  /***** Temperature feedback data *******************************************/

  /* Loop over feedbacks */
  
  tfb = (long)RDB[DATA_PTR_TFB0];
  while (tfb > VALID_PTR)
    {
      /* Pointer to nest */

      nst = (long)RDB[tfb + TFB_PTR_NST];
      CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

      /* Get number of regions */

      n0 = (long)RDB[tfb + TFB_N_REG];

      /* Get the number of nests */

      n = (long)RDB[nst + NEST_COUNT];

      /* Reset index */
      
      i = 0;
      
      /* Loop over regions */
      
      reg = (long)RDB[tfb + TFB_PTR_REG_LIST];
      while (reg > VALID_PTR)
	{
	  /* Loop over time bins */

	  for (tb = 0; tb < (long)RDB[DATA_DYN_NB]; tb++)
	    {
	      /* Volume-averaged temperature */

	      ptr = (long)RDB[tfb + TFB_PTR_MEAN_VTEMP];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, i, tb);
	      AddStat(val, ptr, i, tb);

	      /* Flux-averaged temperature */

	      ptr = (long)RDB[tfb + TFB_PTR_MEAN_FTEMP];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      if ((div = BufVal(ptr, i + n0, tb)) > 0.0)
		{
		  val = BufVal(ptr, i, tb);
		  AddStat(val/div, ptr, i, tb);
		}
	      
	      /* Maximum temperature */
	      
	      ptr = (long)RDB[tfb + TFB_PTR_MAX_TEMP];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufMean(ptr, i, tb);
	      AddStat(val, ptr, i, tb);
	      
	      /* Minimum temperature */
	      
	      ptr = (long)RDB[tfb + TFB_PTR_MIN_TEMP];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufMean(ptr, i, tb);
	      AddStat(val, ptr, i, tb);
	      
	      /* Density */
	      
	      ptr = (long)RDB[tfb + TFB_PTR_MEAN_MDENS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufMean(ptr, i, tb);
	      AddStat(val, ptr, i, tb);
	      
	      /* Heat conductivity */
	      
	      ptr = (long)RDB[tfb + TFB_PTR_MEAN_HC];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufMean(ptr, i, tb);
	      AddStat(val, ptr, i, tb);
	      
	      /* Radius */
	      
	      ptr = (long)RDB[tfb + TFB_PTR_MEAN_RAD];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      if (i == 0)
		{
		  val = BufMean(ptr, i, tb);
		  AddStat(val, ptr, i, tb);
		}
	      
	      val = BufMean(ptr, i + 1, tb);
	      AddStat(val, ptr, i + 1, tb);
	    }	
	  
	  /* Update index */
	  
	  i++;

	  /* Next */
	  
	  reg = NextItem(reg);
	}
      
      /* Next */
      
      tfb = NextItem(tfb);
    }    
  
  /***************************************************************************/

  /***** Few-group constants *************************************************/

  /* Loop over universes */
      
  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Number of energy groups */
      
      ng = (long)RDB[DATA_ERG_FG_NG];
      
      /* Reset total scattering rate */
      
      tots = 0.0;
      
      /* Loop over energy groups */
      
      for (n = 0; n < ng + 1; n++)
	{
	  /* Flux */
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_FLX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  flx = BufVal(ptr, n);
	  AddStat(norm*flx, ptr, n);
	  
	  /* Leak */
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_LEAK];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  val = BufVal(ptr, n);
	  AddStat(norm*val, ptr, n);
	  
	  /* Check value */
	  
	  if (flx > 0.0)
	    {
	      /* Total cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      tot = BufVal(ptr, n);
	      AddStat(tot/flx, ptr, n);

	      /* Fission cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_FISSXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      fiss = BufVal(ptr, n);
	      AddStat(fiss/flx, ptr, n);

	      /* Fission energy */

	      if (fiss > 0.0)
		{
		  ptr = (long)RDB[gcu + GCU_RES_FG_FISSE];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  val = BufVal(ptr, n);
		  AddStat(val/fiss/MEV, ptr, n);
		}

	      /* Capture cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_CAPTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Absorption cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_ABSXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Reduced absorption cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_RABSXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Elastic scattering cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_ELAXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Inelastic scattering cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_INLXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Total scattering cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Scattering production cross section */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATTPRODXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      /* Nubar */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_NUBAR];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      nubar = BufMean(ptr, n);
	      AddStat(nubar, ptr, n);
	      
	      /* NSF */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_NSF];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddStat(nubar*fiss/flx, ptr, n);
	      
	      /* 1/v */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_RECIPVEL];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      /* PN scattering cross sections */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT0];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      /* This is used as the scattering rate for other scattering */
	      /* parameters for compatibility with df (4.10.2012 / 2.1.9) */

	      scatt = val;

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT1];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      /* Use scatt1 for calculating mubar */

	      ptr = (long)RDB[gcu + GCU_RES_FG_P1_MUBAR];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      if (scatt > 0.0)
		AddStat(val/scatt, ptr, n);

	      /* Higher scattering orders... */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT2];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT3];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT4];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT5];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Poison production cross sections */

	      ptr = (long)RDB[gcu + GCU_RES_FG_I135_PROD_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_XE135_PROD_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_PM149_PROD_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SM149_PROD_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_I135_ABS_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_XE135_ABS_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_PM149_ABS_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SM149_ABS_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);
	    		
	      /* Fission spectra (no total values) */
	      
	      if (n < ng)
		{
		  /* Total chi */
		  
		  ptr = (long)RDB[gcu + GCU_RES_FG_CHI];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  sum = 0.0;
		  for (i = 0; i < ng; i++)
		    sum = sum + BufVal(ptr, i);
		  
		  if (sum > 0.0)
		    {
		      val = BufVal(ptr, n)/sum;
		      AddStat(val, ptr, n);
		    }
		  
		  /* Prompt chi */
		  
		  ptr = (long)RDB[gcu + GCU_RES_FG_CHIP];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  sum = 0.0;
		  for (i = 0; i < ng; i++)
		    sum = sum + BufVal(ptr, i);
		  
		  if (sum > 0.0)
		    {
		      val = BufVal(ptr, n)/sum;
		      AddStat(val, ptr, n);
		    }
		  
		  /* Delayed chi */
		  
		  ptr = (long)RDB[gcu + GCU_RES_FG_CHID];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  sum = 0.0;
		  for (m = 0; m < ng; m++)
		    sum = sum + BufVal(ptr, m);
		  
		  if (sum > 0.0)
		    {
		      val = BufVal(ptr, n)/sum;
		      AddStat(val, ptr, n);
		    }
		}
	      
	      /* Scattering matrix and group-transfer and -production */
	      /* probabilities */
	      
	      if (n > 0)
		{
		  /* Loop over target groups */
		  
		  for (m = 0; m < ng; m++)
		    {
		      /* Get scattering rate */
		      
		      ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSXS];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      val = BufVal(ptr, m, n - 1);
		      
		      if (flx > 0.0)
			AddStat(val/flx, ptr, m, n - 1);
		      
		      /* Add to total */

		      if ((long)RDB[DATA_GC_REMXS_MULT] == NO)
			tots = tots + val;
		      
		      /* Group-transfer probabilities */
		      
		      if (scatt > 0.0)
			{
			  ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSP];
			  CheckPointer(FUNCTION_NAME, "(ptr)",DATA_ARRAY,ptr);
			  AddStat(val/scatt, ptr, m, n - 1);
			}

		      /* Get scattering rate */
		      
		      ptr = (long)RDB[gcu + GCU_RES_FG_GPRODXS];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      val = BufVal(ptr, m, n - 1);
		      
		      if (flx > 0.0)
			AddStat(val/flx, ptr, m, n - 1);
		      
		      /* Add to total */
		      
		      if ((long)RDB[DATA_GC_REMXS_MULT] == YES)
			tots = tots + val;
		      
		      /* Group-transfer probabilities */
		      
		      if (scatt > 0.0)
			{
			  ptr = (long)RDB[gcu + GCU_RES_FG_GPRODP];
			  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			  AddStat(val/scatt, ptr, m, n - 1);
			}
		    }
		  
		  /* Group-wise removal cross section */
		  
		  if ((long)RDB[DATA_GC_REMXS_MULT] == NO)
		    {
		      ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSXS];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      val = tot - BufVal(ptr, n - 1, n - 1);
		    }
		  else
		    {
		      ptr = (long)RDB[gcu + GCU_RES_FG_GPRODXS];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      val = tot - BufVal(ptr, n - 1, n - 1);
		    }

		  ptr = (long)RDB[gcu + GCU_RES_FG_REMXS];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddStat(val/flx, ptr, n);
		}
	    }
	}
      
      /* Total removal rate */
      
      ptr = (long)RDB[gcu + GCU_RES_FG_TOTXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      val = BufVal(ptr, 0) - tots;
      
      /* Total flux */
      
      ptr = (long)RDB[gcu + GCU_RES_FG_FLX];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      flx = BufVal(ptr, 0);
      
      /* Total removal cross section */
      
      if (flx > 0.0)
	{
	  ptr = (long)RDB[gcu + GCU_RES_FG_REMXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddStat(val/flx, ptr, 0);
	}
      
      /* Next universe */
      
      gcu = NextItem(gcu);
    }

  /***************************************************************************/

  /***** MORA cross sections *************************************************/

  /* Loop over universes */
      
  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Pointer to MORA data */

      if ((loc0 = (long)RDB[gcu + GCU_PTR_MORA]) > VALID_PTR)
	{
	  /* Number of energy groups and cosine bins */
      
	  ng = (long)RDB[loc0 + MORA_N_EG];
	  nc = (long)RDB[loc0 + MORA_N_COS];
	  
	  /* Get total flux */

	  ptr = (long)RDB[loc0 + MORA_PTR_FLX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  flx = BufVal(ptr, ng);

	  /* Get total prompt and delayed chi */

	  ptr = (long)RDB[loc0 + MORA_PTR_CHIP];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  wgt0 = BufVal(ptr, ng);
	  
	  ptr = (long)RDB[loc0 + MORA_PTR_CHID];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  wgt1 = BufVal(ptr, ng);

	  /* Loop over energy groups */

	  for (n = 0; n < ng; n++)
	    {
	      ptr = (long)RDB[loc0 + MORA_PTR_FLX];    
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      div = BufVal(ptr, n);

	      if (flx > 0.0)
		AddStat(div/flx, ptr, n);
	      
	      ptr = (long)RDB[loc0 + MORA_PTR_TOT];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      tot = BufVal(ptr, n );

	      if (div > 0.0)
		AddStat(tot/div, ptr, n);

	      ptr = (long)RDB[loc0 + MORA_PTR_CAPT];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      capt = BufVal(ptr, n );

	      if (div > 0.0)
		AddStat(capt/div, ptr, n);

	      ptr = (long)RDB[loc0 + MORA_PTR_FISS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      fiss = BufVal(ptr, n );

	      if (div > 0.0)
		AddStat(fiss/div, ptr, n);

	      ptr = (long)RDB[loc0 + MORA_PTR_KAPPA];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n );

	      if (fiss > 0.0)
		AddStat(val/fiss, ptr, n);

	      ptr = (long)RDB[loc0 + MORA_PTR_PNU];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n );
	      
	      if (fiss > 0.0)
		AddStat(val/fiss, ptr, n);

	      ptr = (long)RDB[loc0 + MORA_PTR_DNU];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n );
	      
	      if (fiss > 0.0)
		AddStat(val/fiss, ptr, n);
	      
	      ptr = (long)RDB[loc0 + MORA_PTR_CHIP];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n );

	      if (wgt0 > 0.0)
		AddStat(val/wgt0, ptr, n);

	      ptr = (long)RDB[loc0 + MORA_PTR_CHID];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      val = BufVal(ptr, n );

	      if (wgt1 > 0.0)
		AddStat(val/wgt1, ptr, n);

	      scatt = tot - fiss - capt;

	      for (m = 0; m < ng; m++)
		for (i = 0; i < (long)RDB[loc0 + MORA_N_COS]; i++)
		  if (div > 0.0)
		    {
		      ptr = (long)RDB[loc0 + MORA_PTR_SCATTP];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		      val = BufVal(ptr, m, n, i);
		      AddStat(val/div, ptr, m, n, i);

		      ptr = (long)RDB[loc0 + MORA_PTR_SCATTW];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      
		      val = BufVal(ptr, m, n, i);
		      AddStat(val/div, ptr, m, n, i);
		    }
	    }
	}

      /* Next universe */
      
      gcu = NextItem(gcu);
    }
  
  /***************************************************************************/

  /***** Microscopic reaction rates  for neutrons (analog estimators) ********/

  /* Check mode */

  if ((long)RDB[DATA_ANA_RR_NCALC] != ARR_MODE_NONE)
    {
      /* Loop over nuclides */
      
      nuc = (long)RDB[DATA_PTR_NUC0];
      while (nuc > VALID_PTR)
	{
	  /* Check type */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_PHOTON)
	    {
	      /* Loop over reactions */
	      
	      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	      while (rea > VALID_PTR)
		{
		  /* Get pointer */
		  
		  if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > 
		      VALID_PTR)
		    {
		      /* Add to statistics */
		      
		      val = BufVal(ptr, 0);
		      AddStat(val*norm, ptr, 0);
		    }
		  
		  /* Next reaction */
		  
		  rea = NextItem(rea);
		}
	    }
	  
	  /* Next nuclide */
	  
	  nuc = NextItem(nuc);
	}
    }

  /***************************************************************************/
  
  /***** Transmutation cross sections for burnup calculation *****************/
  
  /* Check burnup mode */

  if ((long)RDB[DATA_BURNUP_CALCULATION_MODE] == YES)
    {
      /* Loop over materials */
  
      mat = (long)RDB[DATA_PTR_M0];
      while (mat > VALID_PTR)
	{
	  /* Check material burn-flag */
	  
	  if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	    {
	      /* Total flux for normalization */
	      
	      ptr = (long)RDB[mat + MATERIAL_PTR_BURN_FLUX];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      val = BufVal(ptr, 0);
	      AddStat(val*norm, ptr, 0);
	    }
	  
	  /* Next material */
	  
	  mat = NextItem(mat);
	}
    }
  
  /***************************************************************************/
  
  /***** Core power distributions ********************************************/
  
  /* Check if distribution is given */
  
  if (RDB[DATA_CORE_PDE_DEPTH] > 0.0)
    {
      /* Core level */
      
      if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES0]) > VALID_PTR)
	{
 
#ifdef OPEN_MP
#pragma omp parallel private(n0, val)
#endif
	  {
			
#ifdef OPEN_MP
#pragma omp for 
#endif	  
	    for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	      {
		val = BufVal(ptr, n0);
		AddStat(val*norm, ptr, n0);
	      }
	  }
	}

      /* Pin level */
      
      if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES1]) > VALID_PTR)
	{

#ifdef OPEN_MP
#pragma omp parallel private(n0, n1, val)
#endif
	  {
			
#ifdef OPEN_MP
#pragma omp for 
#endif	  

	    for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	      for (n1 = 0; n1 < (long)RDB[DATA_CORE_PDE_N1]; n1++)
		{
		  val = BufVal(ptr, n0, n1);
		  AddStat(val*norm, ptr, n0, n1);
		}
	  }
	}
      
      /* Region level */
      
      if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES2]) > VALID_PTR)
	{
	  if ((long)RDB[DATA_CORE_PDE_N1] > 0)
	    {
#ifdef OPEN_MP
#pragma omp parallel private(n0, n1, n2, val)
#endif
	      {
		
#ifdef OPEN_MP
#pragma omp for 
#endif	  
		for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
		  for (n1 = 0; n1 < (long)RDB[DATA_CORE_PDE_N1]; n1++)
		    for (n2 = 0; n2 < (long)RDB[DATA_CORE_PDE_N2]; n2++)
		      {
			val = BufVal(ptr, n0, n1, n2);
			AddStat(val*norm, ptr, n0, n1, n2);
		      }
	      }
	    }
	  else
	    {

#ifdef OPEN_MP
#pragma omp parallel private(n0, n2, val)
#endif
	      {
		
#ifdef OPEN_MP
#pragma omp for 
#endif	  
		for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
		  for (n2 = 0; n2 < (long)RDB[DATA_CORE_PDE_N2]; n2++)
		    {
		      val = BufVal(ptr, n0, 0, n2);
		      AddStat(val*norm, ptr, n0, 0, n2);
		    }
	      }
	    }
	}
    }
  
  /***************************************************************************/

  /***** Pebble-bed power distributions **************************************/

  /* Loop over pbed geometries */
  
  pbd = (long)RDB[DATA_PTR_PB0];
  while (pbd > VALID_PTR)
    {
      /* Get pointer to distribution */
      
      if ((ptr = (long)RDB[pbd + PBED_PTR_POW]) > VALID_PTR)
	{
#ifdef OPEN_MP
#pragma omp parallel private(i, val)
#endif
	  {

	    /* Loop over pebbles */
	    
#ifdef OPEN_MP
#pragma omp for 
#endif	  
	    for (i = 0; i < (long)RDB[pbd + PBED_N_PEBBLES]; i++)
	      {
		/* Get power and add to statistics */
		
		val = BufVal(ptr, i);
		AddStat(val*norm, ptr, i);
	      }
	  }
	}
          
      /* Next */
      
      pbd = NextItem(pbd);
    }

  /***************************************************************************/

  /***** Multi-physics interface *********************************************/
 
  /* Loop over interfaces */

  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Check flag */

      if ((long)RDB[loc0 + IFC_CALC_OUTPUT] == NO)
	{
	  /* Next interface */

	  loc0 = NextItem(loc0);

	  /* Cycle loop */

	  continue;
	}

      /* Check type */
      
      if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_FUEP)
	{
	  /* Loop over fuel performance code interfaces */
	  
	  loc1 = (long)RDB[loc0 + IFC_PTR_FUEP];
	  while (loc1 > VALID_PTR)
	    {
	      /* Pointer to universe */

	      uni = (long)RDB[loc1 + IFC_FUEP_PTR_UNI];
	      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

	      nst = (long)RDB[uni + UNIVERSE_PTR_NEST];
	      CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

	      Warn(FUNCTION_NAME, "mätsääkö toi nest count tohon oikeaan lukuun?");

	      /* Get pointer to statistics */
	      
	      ptr = (long)RDB[loc1 + IFC_FUEP_PTR_POWER];
	      CheckPointer(FUNCTION_NAME, "ptr", DATA_ARRAY, ptr);
	      
#ifdef OPEN_MP
#pragma omp parallel private(n, k, val)
#endif
	      {
		
		/* Loop over regions */
		
#ifdef OPEN_MP
#pragma omp for 
#endif	  	    
		for (n = 0; n < (long)RDB[loc1 + IFC_FUEP_OUT_NZ]; n++)
		  for (k = 0; k < (long)RDB[loc1 + IFC_FUEP_OUT_NR]; k++)
		    {
		      val = BufVal(ptr, n, k)/RDB[nst + NEST_COUNT];
		      AddStat(norm*val, ptr, n, k);
		    }
	      }
	      
	      /* Next */
	      
	      loc1 = NextItem(loc1);
	    }
	}
      else
	{
	  /* Get pointer to common statistics */
	  
	  ptr = (long)RDB[loc0 + IFC_PTR_STAT];
	  CheckPointer(FUNCTION_NAME, "ptr", DATA_ARRAY, ptr);
	  
	  /* Get number of axial bins */
	  
	  if ((nz = (long)RDB[loc0 + IFC_NZ]) > 0)
	    {
	      /* Get number of radial bins */
	      
	      nr = (long)RDB[loc0 + IFC_NR];
	      CheckValue(FUNCTION_NAME, "nr", "", nr, 1, 1000000);
	    }
	  else
	    nr = 0;
	  
#ifdef OPEN_MP
#pragma omp parallel private(m, n, k, val)
#endif
	  {
	    
	    /* Loop over regions */
	    
#ifdef OPEN_MP
#pragma omp for 
#endif	  	    
	    for (m = 0; m < (long)RDB[loc0 + IFC_STAT_NREG]; m++)
	      {
		/* Check Number of axial bins */
		
		if (nz > 0)
		  {
		    /* Three-dimensional array, loop over bins */
		    
		    for (n = 0; n < nz; n++)
		      for (k = 0; k < nr; k++)
			{
			  val = BufVal(ptr, m, n, k);
			  AddStat(norm*val, ptr, m, n, k);
			}
		  }
		else
		  {
		    /* Single bin */
		    
		    val = BufVal(ptr, m);
		    AddStat(norm*val, ptr, m);
		  }
	      }
	  }
	}
	  
      /* Next interface */
	  
      loc0 = NextItem(loc0);
    }
      
  /***************************************************************************/
}

/*****************************************************************************/
