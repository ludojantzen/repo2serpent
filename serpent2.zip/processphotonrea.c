/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processphotonrea.c                             */
/*                                                                           */
/* Created:       2011/04/14 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes photon reactions                                   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessPhotonRea:"

/*****************************************************************************/

void ProcessPhotonRea(long rea)
{
  long mt, nuc, ace, ptr, n, loc0;
  long NXS[16], JXS[32];   
  double *XSS;

  double wco[55] = {0.00, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.10, 0.12, 
		    0.15, 0.18, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 
		    0.60, 0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.30, 1.40, 1.50, 
		    1.60, 1.70, 1.80, 1.90, 2.00, 2.20, 2.40, 2.60, 2.80, 3.00, 
		    3.20, 3.40, 3.60, 3.80, 4.00, 4.20, 4.40, 4.60, 4.80, 5.00, 
		    5.20, 5.40, 5.60, 5.80, 6.00};

  double vic[21] = {0.000, 0.005, 0.010, 0.050, 0.100, 0.150, 0.200, 0.300, 
		    0.400, 0.500, 0.600, 0.700, 0.800, 0.900, 1.000, 1.500, 
		    2.000, 3.000, 4.000, 5.000, 8.000};

  /* Check reaction pointer */

  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

  /* Get reaction mt */
  
  mt = (long)RDB[rea + REACTION_MT];

  /* Pointer to nuclide data */

  nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

  /* Pointer to ACE data */

  ace = (long)RDB[nuc + NUCLIDE_PTR_ACE];

  /* Read data to NXS array */
	  
  ptr = (long)ACE[ace + ACE_PTR_NXS];
  
  for (n = 0; n < 16; n++)
    NXS[n] = (long)ACE[ptr++];

  /* Read data to JXS array */
  
  ptr = (long)ACE[ace + ACE_PTR_JXS];
  
  for (n = 0; n < 32; n++)
    JXS[n] = (long)ACE[ptr++];
  
  /* Get pointer to XSS array */
  
  XSS = &ACE[(long)ACE[ace + ACE_PTR_XSS]];

  /* Allocate memory for distribution block */

  loc0 = NewItem(rea + REACTION_PTR_PHOTON_DIST, PHOTON_DIST_BLOCK_SIZE);

  /* Check mt */

  if (mt == 504)
    {
      /***** Incoherent scattering functions *********************************/

      /* Store array size */

      WDB[loc0 + PHOTON_DIST_MINC] = 21.0;

      /* Store momentum transfers */

      ptr = ReallocMem(DATA_ARRAY, 21);
      WDB[loc0 + PHOTON_DIST_PTR_VIC] = (double)ptr;

      for (n = 0; n < 21; n++)
	WDB[ptr++] = vic[n];

      /* Store scattering functions */

      ptr = ReallocMem(DATA_ARRAY, 21);
      WDB[loc0 + PHOTON_DIST_PTR_INC_FF] = (double)ptr;

      for (n = 0; n < 21; n++)
	WDB[ptr++] = XSS[JXS[1] - 1 + n];
	
      /***********************************************************************/
    }
  else if (mt == 502)
    {
      /***** Coherent form functions *****************************************/

      /* Store array size */

      WDB[loc0 + PHOTON_DIST_MCOH] = 55.0;

      /* Store squares of momentum transfer */

      ptr = ReallocMem(DATA_ARRAY, 55);
      WDB[loc0 + PHOTON_DIST_PTR_WCO] = (double)ptr;

      for (n = 0; n < 55; n++)
	WDB[ptr++] = wco[n]*wco[n];

      /* Store integrated coherent form factors */

      ptr = ReallocMem(DATA_ARRAY, 55);
      WDB[loc0 + PHOTON_DIST_PTR_COH_FFINT] = (double)ptr;

      for (n = 0; n < 55; n++)
	WDB[ptr++] = XSS[JXS[2] - 1 + n];

      /* Store coherent form factors (these are not used?) */

      ptr = ReallocMem(DATA_ARRAY, 55);
      WDB[loc0 + PHOTON_DIST_PTR_COH_FF] = (double)ptr;

      for (n = 0; n < 55; n++)
	WDB[ptr++] = XSS[JXS[2] - 1 + 55 + n];

      /***********************************************************************/
    }
  else if (mt == 522)
    {
      /***** Photoelectric fluoresence data **********************************/

      /* Check if data exists */
      
      if (NXS[3] > 0)
	{
	  /* Store array size */
	  
	  WDB[loc0 + PHOTON_DIST_FLO_N] = (double)NXS[3];
	  
	  /* Store edge energies */
	  
	  ptr = ReallocMem(DATA_ARRAY, NXS[3]);
	  WDB[loc0 + PHOTON_DIST_PTR_FLO_E] = (double)ptr;
	  
	  for (n = 0; n < NXS[3]; n++)
	    WDB[ptr++] = XSS[JXS[3] - 1 + n];
	    
	  /* Store relative probabilities */
	  
	  ptr = ReallocMem(DATA_ARRAY, NXS[3]);
	  WDB[loc0 + PHOTON_DIST_PTR_FLO_PHI] = (double)ptr;
	  
	  for (n = 0; n < NXS[3]; n++)
	    WDB[ptr++] = XSS[JXS[3] - 1 + JXS[3] + n];
	  
	  /* Store yields */
	  
	  ptr = ReallocMem(DATA_ARRAY, NXS[3]);
	  WDB[loc0 + PHOTON_DIST_PTR_FLO_Y] = (double)ptr;
	  
	  for (n = 0; n < NXS[3]; n++)
	    WDB[ptr++] = XSS[JXS[3] - 1 + 2*JXS[3] + n];
	  
	  /* Store fluorescent energies */
	  
	  ptr = ReallocMem(DATA_ARRAY, NXS[3]);
	  WDB[loc0 + PHOTON_DIST_PTR_FLO_F] = (double)ptr;
	  
	  for (n = 0; n < NXS[3]; n++)
	    WDB[ptr++] = XSS[JXS[3] - 1 + 3*JXS[3] + n];
	}

      /***********************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Invalid reaction mode");
}

/*****************************************************************************/
