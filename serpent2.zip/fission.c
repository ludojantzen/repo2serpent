/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : fission.c                                      */
/*                                                                           */
/* Created:       2011/03/07 (JLe)                                           */
/* Last modified: 2013/04/23 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Handles fission                                              */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Fission:"

/*****************************************************************************/

void Fission(long mat, long rea, long part, double *E0, double t0, double x, 
	     double y, double z, double *u, double *v, double *w, double wgt1, 
	     double *wgt2, long id)
{
  long ptr, prg, prev, nmax, n, i, new, mode, ng, idx0, idx1;
  double tnu, dnu, beta, E, f, mu, u0, v0, w0, lambda, td;

  /* Check pointers */

  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
  CheckPointer(FUNCTION_NAME, "(part)", DATA_ARRAY, part);

  /* Check coordinates, energy and weight */

  CheckValue(FUNCTION_NAME, "x", "", x, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "y", "", y, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "z", "", z, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "E0", "", *E0, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "wgt1", "", wgt1, ZERO, INFTY);

  /* Avoid compiler warning */

  tnu = -1.0;

  /* Get total nubar */

  if ((ptr = (long)RDB[rea + REACTION_PTR_TNUBAR]) > VALID_PTR)
    tnu = Nubar(ptr, *E0, id);
  else
    Die(FUNCTION_NAME, "No prompt nubar data");

  /* Get delayed nubar */

  if ((ptr = (long)RDB[rea + REACTION_PTR_DNUBAR]) > VALID_PTR)
    dnu = Nubar(ptr, *E0, id);
  else
    dnu = 0.0;

  /* Check delayed neutron flag */

  if ((long)RDB[DATA_USE_DELNU] == NO)
    {
      /* Subtract delayed nubar from total */

      tnu = tnu - dnu;

      /* Set delayed nubar to zero */

      dnu = 0.0;
    }
  
  /* Calculate delayed neutron fraction */

  beta = dnu/tnu;
  CheckValue(FUNCTION_NAME, "beta", "", beta, 0.0, 3E-2);

  /* Original direction cosines */

  u0 = *u;
  v0 = *v;
  w0 = *w;

  /* Get simulation mode */
  
  mode = (long)RDB[DATA_SIMULATION_MODE];

  /* Get incident delayed neutron group and decay constant */

  ng = (long)RDB[part + PARTICLE_DN_GROUP];
  lambda = RDB[part + PARTICLE_DN_LAMBDA];

  /* Get fission matrix indexes */

  idx0 = (long)RDB[part + PARTICLE_FMTX_IDX];
  idx1 = FissMtxIndex(mat, id);

  /* Score incident neutron */
  
  ScoreFission(mat, rea, tnu, dnu, lambda, ng, *E0, 0.0, wgt1, 0.0, 
	       idx0, idx1, id);

  /* Check implicit fission mode */

  if ((long)RDB[DATA_OPT_IMPL_FISS] == YES)
    {
      /***********************************************************************/

      /***** Implicit fission ************************************************/

      Die(FUNCTION_NAME, "Implicit fission doesn't work");

      /* Check criticality source mode */

      if (mode == SIMULATION_MODE_CRIT)
	Die(FUNCTION_NAME, "Implicit fission in criticality source mode");

      /* Adjust weight */

      *wgt2 = tnu*wgt1;

      /* Reset mu */
      
      mu = 0.1;

      /* Reset precursor group and decay constant */

      ng = 0;
      lambda = -1.0;
      
      /* Sample between prompt and delayed neutron */
      
      if (RandF(id) > beta)
	{
	  /* Prompt neutron, sample energy */
	  
	  SampleENDFLaw(rea, -1, *E0, &E, &mu, id);
	}
      else
	{
	  /* Delayed neutron, sample precursor group */
	  
	  if ((ptr = SamplePrecursorGroup(rea, *E0, id)) > VALID_PTR)
	    {	  
	      /* Get precursor group */

	      ng = (long)RDB[ptr + PREC_IDX];
	      CheckValue(FUNCTION_NAME, "ng", "", ng, 1, 8);
	      
	      /* Get decay constant */

	      lambda = RDB[ptr + PREC_LAMBDA];
	      CheckValue(FUNCTION_NAME, "lambda", "", lambda, ZERO, INFTY);

	      /* Get pointer to energy distribution */
	      
	      ptr = (long)RDB[ptr + PREC_PTR_ERG];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      /* Sample energy */
	      
	      SampleENDFLaw(rea, ptr, *E0, &E, &mu, id);
	    }
	  else
	    {
	      /* Sampling failed, sample prompt neutron energy */
	      
	      SampleENDFLaw(rea, -1, *E0, &E, &mu, id);
	    }	
	}
      
      /* Adjust minimum and maximum energy */
      
      if (E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	E = 1.000001*RDB[DATA_NEUTRON_EMIN];
      else if (E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	E = 0.999999*RDB[DATA_NEUTRON_EMAX];
      
      /* Score emitted neutron */

      ScoreFission(mat, rea, 0.0, 0.0, lambda, ng, 0.0, E, wgt1, *wgt2, 
		   idx0, idx1, id);

      /* Check if mu is sampled from distribution or sample isotropic */
      
      if (mu == 0.1)
	IsotropicDirection(u, v, w, id);
      else
	{
	  /* Get incident direction cosines */
	  
	  *u = u0;
	  *v = v0;
	  *w = w0;
	  
	  /* Rotate */
	  
	  AziRot(mu, u, v, w, id);
	}
	  
      /* Put energy */

      *E0 = E;

      /* Update generation index */
      
      WDB[part + PARTICLE_GEN_IDX] = RDB[part + PARTICLE_GEN_IDX] + 1.0;
	  
      /* Get generation index */

      i = (long)RDB[part + PARTICLE_GEN_IDX];

      /* Score new source weight */
      
      ptr = (long)RDB[RES_NEW_SRC_WGT];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(*wgt2, 1.0, ptr, id, 0);
      
      if (i < MAX_EXT_K_GEN + 1)
	AddBuf(*wgt2, 1.0, ptr, id, i);
      
      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Analog fission **************************************************/

      /* Get UFS factor */

      f = UFSFactor(x, y, z);

      /* Sample number of emitted neutrons and set weight */

      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
	{
	  nmax = SampleNu(tnu*f, id);
	  *wgt2 = wgt1/f;
	}
      else
	{
	  nmax = SampleNu(wgt1*tnu*f, id);
	  *wgt2 = 1.0/f;
	}

      if (nmax > 1000)
	Die(FUNCTION_NAME, "WTF?");

      /* Loop over source neutrons */

      for (n = 0; n < nmax; n++)
	{
	  /* Reset mu */

	  mu = 0.1;

	  /* Reset precursor group and decay constant */

	  ng = 0;
	  lambda = -1.0;

	  /* Sample between prompt and delayed neutron */

	  if (RandF(id) > beta)
	    {
	      /* Prompt neutron, sample energy */
	  
	      SampleENDFLaw(rea, -1, *E0, &E, &mu, id);
	    }
	  else
	    {
	      /* Delayed neutron, sample precursor group */

	      if ((ptr = SamplePrecursorGroup(rea, *E0, id)) > VALID_PTR)
		{	  
		  /* Get precursor group */

		  ng = (long)RDB[ptr + PREC_IDX];
		  CheckValue(FUNCTION_NAME, "ng", "", ng, 1, 8);
		  
		  /* Get decay constant */
		  
		  lambda = RDB[ptr + PREC_LAMBDA];
		  CheckValue(FUNCTION_NAME, "lambda", "", lambda, ZERO, INFTY);

		  /* Get pointer to energy distribution */
		  
		  ptr = (long)RDB[ptr + PREC_PTR_ERG];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  /* Sample energy */
		  
		  SampleENDFLaw(rea, ptr, *E0, &E, &mu, id);
		}
	      else
		{
		  /* Sampling failed, sample prompt neutron energy */
		  
		  SampleENDFLaw(rea, -1, *E0, &E, &mu, id);
		}	
	    }

	  /* Adjust minimum and maximum energy */
	  
	  if (E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	    E = 1.000001*RDB[DATA_NEUTRON_EMIN];
	  else if (E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	    E = 0.999999*RDB[DATA_NEUTRON_EMAX];

	  /* Check if mu is sampled from distribution or sample isotropic */

	  if (mu == 0.1)
	    IsotropicDirection(u, v, w, id);
	  else
	    {
	      /* Get incident direction cosines */
	      
	      *u = u0;
	      *v = v0;
	      *w = w0;
	      
	      /* Rotate */
	      
	      AziRot(mu, u, v, w, id);
	    }

	  /* Sample delayed neutron emission time */

	  if (lambda > 0.0)
	    td = -log(RandF(id))/lambda;
	  else
	    td = 0.0;

	  /* Score emitted neutron */

	  ScoreFission(mat, rea, 0.0, 0.0, lambda, ng, 0.0, E, wgt1, *wgt2, 
		       idx0, idx1, id);

	  /* Duplicate incident neutron */
	  
	  new = DuplicateParticle(part, id);

	  /* Put variables */

	  WDB[new + PARTICLE_X] = x;
	  WDB[new + PARTICLE_Y] = y;
	  WDB[new + PARTICLE_Z] = z;

	  WDB[new + PARTICLE_U] = *u;
	  WDB[new + PARTICLE_V] = *v;
	  WDB[new + PARTICLE_W] = *w;
	  
	  WDB[new + PARTICLE_E] = E;
	  WDB[new + PARTICLE_WGT] = *wgt2;
	  WDB[new + PARTICLE_PTR_MAT] = (double)mat;
	  WDB[new + PARTICLE_DN_GROUP] = (double)ng;
	  WDB[new + PARTICLE_DN_LAMBDA] = lambda;

	  /* Put lifetimes and delayed neutron groups to progenies */

	  if ((prg = (long)RDB[new + PARTICLE_PTR_FISS_PROG]) > VALID_PTR)
	    {
	      /* Loop from last to first */

	      prg = LastItem(prg);
	      while (prg > VALID_PTR)
		{
		  /* Get pointer to previous */

		  if ((prev = PrevItem(prg)) > VALID_PTR)
		    {
		      /* Copy data from previous */

		      WDB[prg + FISS_PROG_DN_GROUP] = 
			WDB[prev + FISS_PROG_DN_GROUP];
		      WDB[prg + FISS_PROG_LIFETIME] = 
			WDB[prev + FISS_PROG_LIFETIME];
		      WDB[prg + FISS_PROG_LAMBDA] = 
			WDB[prev + FISS_PROG_LAMBDA];
		    }
		  else
		    {
		      /* Put new */

		      WDB[prg + FISS_PROG_DN_GROUP] = 
			WDB[part + PARTICLE_DN_GROUP];
		      WDB[prg + FISS_PROG_LIFETIME] = 
			t0 - RDB[part + PARTICLE_T0];
		      WDB[prg + FISS_PROG_LAMBDA] = 
			WDB[part + PARTICLE_DN_LAMBDA];
		    }

		  /* Previous progeny */

		  prg = prev;
		}
	    }	  

	  /* Put time */

	  if (mode == SIMULATION_MODE_CRIT)
	    {
	      WDB[new + PARTICLE_T0] = 0.0;
	      WDB[new + PARTICLE_T] = 0.0;
	    }
	  else
	    {
	      WDB[new + PARTICLE_T0] = t0 + td;
	      WDB[new + PARTICLE_T] = t0 + td;
	    }

	  /* Delayed neutron emission time */

	  WDB[new + PARTICLE_TD] = td;

	  /* Put fission matrix index */

	  WDB[new + PARTICLE_FMTX_IDX] = (double)idx1;

	  /* Reset thermalization time */

	  WDB[new + PARTICLE_TT] = 0.0;

	  /* Update generation index */

	  WDB[new + PARTICLE_GEN_IDX] = RDB[new + PARTICLE_GEN_IDX] + 1.0;
	  
	  /* Check mode and store particle */

	  if (mode == SIMULATION_MODE_CRIT)
	    {
	      /* Bank neutron */

	      ToBank(new, id);

	      /* Write source file */
	      
	      if ((RDB[DATA_CYCLE_IDX] > RDB[DATA_CRIT_SKIP]) &&
		  ((ptr = (long)RDB[DATA_PTR_CRIT_SRC_DET]) > VALID_PTR))
		WriteSourceFile(ptr, x, y, z, *u, *v, *w, E, 1.0, t0 + td, id);
	    }
	  else
	    {
	      /* Bank or que neutron */
	      
	      if (RDB[new + PARTICLE_T] < RDB[DATA_TIME_CUT_TMIN])
		Die(FUNCTION_NAME, "Error in time");
	      else if (RDB[new + PARTICLE_T] >= RDB[DATA_TIME_CUT_TMAX])
		ToBank(new, id);	 
	      else
		ToQue(new, id);
	    }

	  /* Get generation index */

	  i = (long)RDB[new + PARTICLE_GEN_IDX];

	  /* Score new source weight */
      
	  ptr = (long)RDB[RES_NEW_SRC_WGT];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(*wgt2, 1.0, ptr, id, 0);
	  
	  if (i < MAX_EXT_K_GEN + 1)
	    AddBuf(*wgt2, 1.0, ptr, id, i);
	}
 
      /***********************************************************************/
    }
}

/*****************************************************************************/
