/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : storecomposition.c                             */
/*                                                                           */
/* Created:       2012/08/24 (JLe)                                           */
/* Last modified: 2012/08/24 (JLe)                                           */
/* Version:       2.1.8                                                      */
/*                                                                           */
/* Description: Stores material composition in a binary work file            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "StoreComposition:"

/*****************************************************************************/

void StoreComposition(long mat, long idx)
{
  long nnuc, iso;
  char tmpstr[MAX_STR];
  double val;
  FILE *fp;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* File name */

  sprintf(tmpstr, "%s.wrk", GetText(DATA_PTR_INPUT_FNAME));

  /* Open file for writing (vai append?) */

  fp = fopen(tmpstr, "a");
  
  /* Check pointer */

  if (fp == NULL)
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /* Write material pointer and index */

  fwrite(&mat, sizeof(long), 1, fp);
  fwrite(&idx, sizeof(long), 1, fp);

  /* Get number of nuclides */

  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  nnuc = ListSize(iso);

  /* Write number of nuclides */

  fwrite(&nnuc, sizeof(long), 1, fp);

  /* Write atomic density, mass density and burnup */

  val = RDB[mat + MATERIAL_ADENS];
  fwrite(&val, sizeof(double), 1, fp);

  val = RDB[mat + MATERIAL_MDENS];
  fwrite(&val, sizeof(double), 1, fp);

  val = RDB[mat + MATERIAL_BURNUP];
  fwrite(&val, sizeof(double), 1, fp);

  /* Loop over composition */

  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > VALID_PTR)
    {
      /* Write atomic density */
      
      val = RDB[iso + COMPOSITION_ADENS];
      fwrite(&val, sizeof(double), 1, fp);
	  
      /* Next nuclide in composition */

      iso = NextItem(iso);
    }

  /* Close file and exit */

  fclose(fp);  
}

/*****************************************************************************/
