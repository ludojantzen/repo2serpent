/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scoregc.c                                      */
/*                                                                           */
/* Created:       2011/05/04 (JLe)                                           */
/* Last modified: 2013/04/13 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Scores reaction rates needed for group constant generation   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreGC:"

/*****************************************************************************/

void ScoreGC(double flx, long mat, double E, double spd, double wgt, double g,
	     long id)
{
  long rea, gcu, ptr, loc0, ng, ntot, ncol;
  double tot, capt, fiss, fissE, ela, sprod, val;
  
  /* Check that group constants are calculated */

  if ((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);

  /* Get universe pointer */

  if ((gcu = TestValuePair(DATA_GCU_PTR_UNI, ncol, id)) < VALID_PTR)
    return;

  /***************************************************************************/

  /***** Common values *******************************************************/

  if (mat > VALID_PTR)
    {  
      /* Total reaction rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_TOTXS]) > VALID_PTR)
	tot = MacroXS(rea, E, id)*flx*g;
      else
	tot = 0.0;

      /* Capture rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_ABSXS]) > VALID_PTR)
	capt = MacroXS(rea, E, id)*flx*g;
      else
	capt = 0.0;

      /* Fission rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSXS]) > VALID_PTR)
	fiss = MacroXS(rea, E, id)*flx*g;
      else
	fiss = 0.0;

      /* Fission energy production rate */

      if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSE]) > VALID_PTR)
	fissE = MacroXS(rea, E, id)*flx*g;
      else
	fissE = 0.0;

      /* Elastic rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_ELAXS]) > VALID_PTR)
	ela = MacroXS(rea, E, id)*flx*g;
      else
	ela = 0.0;

      /* Inelastic scattering production rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_INLPXS]) > VALID_PTR)
	sprod = MacroXS(rea, E, id)*flx*g;
      else
	sprod = 0.0;
    }
  else
    {
      /* Reset values */

      tot = 0.0;
      capt = 0.0;
      fiss = 0.0;
      fissE = 0.0;
      ela = 0.0;
      sprod = 0.0;
    }

  /***************************************************************************/

  /***** MORA data ***********************************************************/

  if ((loc0 = (long)RDB[gcu + GCU_PTR_MORA]) > VALID_PTR)
    {
      /* Get pointer to energy grid */
  
      ptr = (long)RDB[loc0 + MORA_PTR_EG];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Total number of groups */

      ntot = (long)RDB[loc0 + MORA_N_EG];

      /* Find group */
      
      if ((ng = GridSearch(ptr, E)) > -1)
	{
	  /* Flux */
  
	  ptr = (long)RDB[loc0 + MORA_PTR_FLX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(flx, wgt, ptr, id, ng);
	  AddBuf(flx, wgt, ptr, id, ntot);

	  /* Score total reaction rate */

	  ptr = (long)RDB[loc0 + MORA_PTR_TOT];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(tot, wgt, ptr, id, ng);

	  /* Score fission rate */

	  ptr = (long)RDB[loc0 + MORA_PTR_FISS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(fiss, wgt, ptr, id, ng);

	  /* Score capture rate */

	  ptr = (long)RDB[loc0 + MORA_PTR_CAPT];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(capt, wgt, ptr, id, ng);

	  /* Score fission energy production rate */
	  
	  ptr = (long)RDB[loc0 + MORA_PTR_KAPPA];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(fissE, wgt, ptr, id, ng);
	}
    }

  /***************************************************************************/

  /***** Infinite spectrum ***************************************************/

  /* Number of groups */

  ntot = (long)RDB[DATA_ERG_FG_NG];

  /* Get pointer to few-group structure */
  
  ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get few-group index */

  if ((ng = GridSearch(ptr, E)) < 0)
    return;
  else
    ng = ntot - ng;

  /* Check index */

  CheckValue(FUNCTION_NAME, "ng1", "", ng, 0, ntot);

  /* Flux */
  
  ptr = (long)RDB[gcu + GCU_RES_FG_FLX];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(flx, wgt, ptr, id, ng);
  AddBuf(flx, wgt, ptr, id, 0);
  
  /* 1/v */
  
  ptr = (long)RDB[gcu + GCU_RES_FG_RECIPVEL];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(flx/spd, wgt, ptr, id, ng);
  AddBuf(flx/spd, wgt, ptr, id, 0);
  
  /* Check material pointer (cannot exit here because flux is also scored */
  /* for B1 fundamental mode calculation). */

  if (mat > VALID_PTR)
    {  
      /* Score total reaction rate */

      ptr = (long)RDB[gcu + GCU_RES_FG_TOTXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(tot, wgt, ptr, id, ng);
      AddBuf(tot, wgt, ptr, id, 0);

      /* Score fission rate */

      ptr = (long)RDB[gcu + GCU_RES_FG_FISSXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(fiss, wgt, ptr, id, ng);
      AddBuf(fiss, wgt, ptr, id, 0);

      /* Score fission energy production rate */

      ptr = (long)RDB[gcu + GCU_RES_FG_FISSE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(fissE, wgt, ptr, id, ng);
      AddBuf(fissE, wgt, ptr, id, 0);

      /* Score capture rate */

      ptr = (long)RDB[gcu + GCU_RES_FG_CAPTXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(capt, wgt, ptr, id, ng);
      AddBuf(capt, wgt, ptr, id, 0);

      /* Score absorption rate */

      val = fiss + capt;

      ptr = (long)RDB[gcu + GCU_RES_FG_ABSXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(val, wgt, ptr, id, ng);
      AddBuf(val, wgt, ptr, id, 0);
      
      /* Score reduced absorption rate */

      val = fiss + capt - sprod;

      ptr = (long)RDB[gcu + GCU_RES_FG_RABSXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(val, wgt, ptr, id, ng);
      AddBuf(val, wgt, ptr, id, 0);

      /* Score elastic scattering rate */
      
      ptr = (long)RDB[gcu + GCU_RES_FG_ELAXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(ela, wgt, ptr, id, ng);
      AddBuf(ela, wgt, ptr, id, 0);

      /* Score inelastic scattering rate (avoid round-off to negative) */

      if ((val = tot - capt - fiss - ela) < 0.0)
	val = 0.0;

      ptr = (long)RDB[gcu + GCU_RES_FG_INLXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(val, wgt, ptr, id, ng);
      AddBuf(val, wgt, ptr, id, 0);

      /* Score (total) scattering rate */

      val = tot - capt - fiss;

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATTXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(val, wgt, ptr, id, ng);
      AddBuf(val, wgt, ptr, id, 0);

      /* Score scattering production rate */

      val = tot - capt - fiss + sprod;

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATTPRODXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(val, wgt, ptr, id, ng);
      AddBuf(val, wgt, ptr, id, 0);
    }

  /***************************************************************************/

  /***** Micro-group data ****************************************************/

  /* Get pointer to microgroup energy grid */
  
  ptr = (long)RDB[DATA_MICRO_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	
  
  /* Number of groups */

  ntot = (long)RDB[ptr + ENERGY_GRID_NE] - 1;
  
  /* Get group index */

  if ((ng = GridSearch(ptr, E)) < 0)
    return;
  else
    ng = ntot - ng - 1;

  /* Check index */

  CheckValue(FUNCTION_NAME, "ng2", "", ng, 0, ntot - 1);

  /* Put values */

  ptr = RDB[gcu + GCU_MICRO_FLX];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*flx, id);

  ptr = RDB[gcu + GCU_MICRO_TOT];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*tot, id);

  ptr = RDB[gcu + GCU_MICRO_ABS];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*(capt + fiss), id);

  ptr = RDB[gcu + GCU_MICRO_FISS];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*fiss, id);

  ptr = RDB[gcu + GCU_MICRO_FISSE];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*fissE, id);

  ptr = RDB[gcu + GCU_MICRO_INV_V];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*flx/spd, id);

  /* Flux in fissile materials */

  if (mat > VALID_PTR)
    if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_FISSILE_MAT)
      {
	ptr = RDB[gcu + GCU_MICRO_FISS_FLX];
	CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	AddPrivateRes(ptr + ng, wgt*flx, id);
      }
  
  /***************************************************************************/
}

/*****************************************************************************/
