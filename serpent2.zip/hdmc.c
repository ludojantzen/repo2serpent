/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : hdmc.c                                         */
/*                                                                           */
/* Created:       2013/03/08 (JLe)                                           */
/* Last modified: 2013/04/26 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Homogenized few-group diffusion based Monte Carlo simulation */
/*              for calculating homogeneous flux for discontinuity factors.  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "HDMC:"

/* Local function prototypes */

void HDMCScatt(double *, double *, double *, long *, double *, long, double *, 
	     double *, double, long);

double SampleP1Mu(double, long);

void HDMCSrc(double *, double *, double *, double *, double *, double *, long *,
	   double *, double *, long, long, long, const double *, long, long);

void HDMCFission(double, double, double, double, double, double *, long, long);


/*****************************************************************************/

void HDMC()
{
  long gcu, adf, ptr, ng, ns, n, m, surf, type, pop, nbatch, ncyc, nskip, g;
  long id, i, j, n1, n2, m1, m2, nn;
  double *tot, *abs, *fiss, *scatt, *nsf, *nubar, *mubar, *chi, *s0, *s1;
  double *sp0, *Iin, *Iout, *alb, *src;
  double x, y, z, u, v, w, wgt, sum, norm, d, l, f, flx; 
  double xmin, xmax, ymin, ymax, keff, u0, v0, w0, mu;
  const double *params;
  FILE *fp;
  char tmpstr[MAX_STR];
  static double dis[2][100][100];

  /* Check mode */

  if ((long)RDB[DATA_RUN_HDMC] == NO)
    return;

  fprintf(out, "Calculating discontinuity factors with Monte Carlo...\n");

  /* Print flux distribution in file for comparison */

  sprintf(tmpstr, "%s_df.m", GetText(DATA_PTR_INPUT_FNAME));
  fp = fopen(tmpstr, "w");

  /* Loop over universes. This is the universe list entered in the */
  /* "set gcu" card. */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Get pointer to ADF block. Pointer exists if universe is listed */
      /* in "set adf". */

      if ((adf = (long)RDB[gcu + GCU_PTR_ADF]) < VALID_PTR)
	{
	  /* No adf's in this universe, get pointer to next */

	  gcu = NextItem(gcu);

	  /* Cycle loop */

	  continue;
	}

      /* Pointer to boundary surface */

      surf = (long)RDB[adf + ADF_PTR_SURF];
      CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);

      /* Surface type */

      type = (long)RDB[surf + SURFACE_TYPE];

      /* Parameter vector */

      ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      params = &RDB[ptr];

      /* Number of vertices in boundary surface */

      ns = (long)RDB[adf + ADF_NSURF];
      CheckValue(FUNCTION_NAME, "ns", "", ns, 1, 8);
      
      /***********************************************************************/

      /***** Get multi-group data needed in simulation ***********************/
      
      /* Number of energy groups */

      ng = (long)RDB[DATA_ERG_FG_NG];
      CheckValue(FUNCTION_NAME, "ng", "", ng, 2, 1000);

      /* Allocate memory for arrays */

      tot = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      abs = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      fiss = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      scatt = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      nsf = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      nubar = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      chi = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      mubar = (double *)Mem(MEM_ALLOC, ng, sizeof(double));
      s0 = (double *)Mem(MEM_ALLOC, ng*ng, sizeof(double));
      s1 = (double *)Mem(MEM_ALLOC, ng*ng, sizeof(double));
      sp0 = (double *)Mem(MEM_ALLOC, ng*ng, sizeof(double));
      Iin = (double *)Mem(MEM_ALLOC, ns*ng, sizeof(double));
      Iout = (double *)Mem(MEM_ALLOC, ns*ng, sizeof(double));
      alb = (double *)Mem(MEM_ALLOC, ns*ng, sizeof(double));
      src = (double *)Mem(MEM_ALLOC, ns*ng, sizeof(double));

      /* Loop over energy groups and read data */

      for (n = 0; n < ng; n++)
	{
	  /* Fission cross section */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_FISS];
	  else
	    ptr = (long)RDB[gcu + GCU_B1_FISS];
	  
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  fiss[n] = Mean(ptr, n);

	  /* Absorption cross section */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_ABS];
	  else
	    ptr = (long)RDB[gcu + GCU_B1_ABS];

	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  abs[n] = Mean(ptr, n) - fiss[n];

	  /* Fission neutron production cross section */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_NSF];
	  else
	    ptr = (long)RDB[gcu + GCU_B1_NSF];

	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  nsf[n] = Mean(ptr, n);

	  /* Fission nubar */

	  if (fiss[n] > 0.0)
	    nubar[n] = nsf[n]/fiss[n];
	  else
	    nubar[n] = 0.0;

	  /* Fission spectrum */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_CHIT];
	  else
	    ptr = (long)RDB[gcu + GCU_B1_CHIT];

	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  chi[n] = Mean(ptr, n);

	  /* Scattering matrix */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_S0];
	  else
	    ptr = (long)RDB[gcu + GCU_B1_S0];
	  
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  for (m = 0; m < ng; m++)
	    s0[n*ng + m] = Mean(ptr, n, m);

	  /* Mu-scattering matrix */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_S1];
	  else
	    ptr = (long)RDB[gcu + GCU_B1_S1];

	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  for (m = 0; m < ng; m++)
	    s1[n*ng + m] = Mean(ptr, n, m);
	  
	  /* Scattering production matrix */

	  if ((long)RDB[DATA_B1_CALC] == NO)
	    ptr = (long)RDB[gcu + GCU_INF_SP0];
	  else  
	    ptr = (long)RDB[gcu + GCU_B1_SP0];
	    
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  for (m = 0; m < ng; m++)
	    sp0[n*ng + m] = Mean(ptr, n, m);

	  /* Calculate total scattering cross section */

	  scatt[n] = 0.0;
	  for (m = 0; m < ng; m++)
	    scatt[n] = scatt[n] + s0[n*ng + m];

	  /* Calculate total cross section */

	  tot[n] = abs[n] + fiss[n] + scatt[n];

	  /* Calculate mubar */

	  mubar[n] = 0.0;
	  for (m = 0; m < ng; m++)
	    mubar[n] = mubar[n] + s1[n*ng + m];

	  if (scatt[n] > 0.0)
	    mubar[n] = mubar[n]/scatt[n];
	  else
	    Die(FUNCTION_NAME, "Scattering cross section is zero");

	  /* Calculate scattering weight factor matrix */

	  for (m = 0; m < ng; m++)
	    {
	      if (s0[n*ng + m] > 0.0)
		sp0[n*ng + m] = sp0[n*ng + m]/s0[n*ng + m];
	      else
		Die(FUNCTION_NAME, "Scattering cross section is zero");
	    }

	  /* Convert scattering matrix to probability matrix */

	  for (m = 0; m < ng; m++)
	    s0[n*ng + m] = s0[n*ng + m]/scatt[n];

	  /* Inward current */

	  ptr = (long)RDB[gcu + GCU_RES_FG_DF_IN_CURR];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  for (m = 0; m < ns; m++)
	    Iin[m*ng + n] = Mean(ptr, m, n);
	  
	  /* Outward current */

	  ptr = (long)RDB[gcu + GCU_RES_FG_DF_OUT_CURR];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  for (m = 0; m < ns; m++)
	    Iout[m*ng + n] = Mean(ptr, m, n);

	  /* Calculate albedo */

	  for (m = 0; m < ns; m++)
	    {
	      if (Iout[m*ng + n] > 0.0)
		alb[m*ng + n] = Iin[m*ng + n]/Iout[m*ng + n];
	      else
		alb[m*ng + n] = 0.0;
	    }
	}
      
      /* Calculate source probability distribution */

      sum = 0.0;
      for (n = 0; n < ng; n++)
	for (m = 0; m < ns; m++)
	  sum = sum + Iin[m*ng + n];

      if (sum > 0.0)
	for (n = 0; n < ng; n++)
	  for (m = 0; m < ns; m++)
	    src[m*ng + n] = Iin[m*ng + n]/sum;
      
      /***********************************************************************/

      /***** Print some output ***********************************************/

      /* Cross sections used for transport calculation, average scattering */
      /* cosine, averager fission neutron yield, fission spectrum. */

      printf("\nGroup constants:\n");
      printf("\ng      tot      abs     fiss    scatt   nubar   chi mubar\n");

      for (n = 0; n < ng; n++)
	printf("%ld %1.2E %1.2E %1.2E %1.2E : %1.3f %1.3f %1.3f\n", n + 1,
	       tot[n], abs[n], fiss[n], scatt[n], nubar[n], chi[n], mubar[n]);

      /* Scattering probability matrix and weight matrix used for sampling */
      /* emitted neutron energy group and weight increase due to (n,xn)    */
      /* reactions. Array index for scattering : n --> m is (m*ng + n).    */

      printf("\nscattering matrixes:\n");
      printf("\n         prob.          wgt\n");

      for (n = 0; n < ng; n++)
	{
	  for (m = 0; m < ng; m++)
	    printf("%1.4f ", s0[m*ng + n]);
	  
	  printf("    ");

	  for (m = 0; m < ng; m++)
	    printf("%1.4f ", sp0[m*ng + n]);

	  printf("\n");
	}

      /* Currents and albedos. Array index format is (m*ng + n), where */
      /* m is the surface index and n is the energy group. */

      printf("\nCurrents and albedos:\n\n");
      
      printf("surf    ");
      for (m = 0; m < ng; m++)
	printf("Iin%ld    Iout%ld     Inet%ld  alb%ld     ", m + 1, m + 1, 
	       m + 1, m + 1);

      printf("\n");

      for (m = 0; m < ns; m++)
	{
	  printf("%ld   ", m + 1);

	  for (n = 0; n < ng; n++)
	    printf("%1.2E %1.2E %9.2E %1.3f ", Iin[m*ng + n], Iout[m*ng + n],
		   Iin[m*ng + n] - Iout[m*ng + n], alb[m*ng + n]);

	  printf("\n");
	}
	
      printf("\n");

      /************************************************************************/
      
      /***** Main simulation loop *********************************************/

      /* Calculate sum of fission nubar to determine mode */

      sum = 0;
      for (n = 0; n < ng; n++)
	sum = sum + nubar[n];

      /* Check */

      if (sum == 0.0)
	{
	  /********************************************************************/

	  /***** External source simulation ***********************************/

	  /* Set population size and number of batches */
	  
	  pop = 5000;
	  nbatch = 200;
	  
	  printf("\nExternal source simulation for %ld histories...\n\n",
		 pop*nbatch);

	  /* Calculate normalization factor */

	  sum = 0.0;
	  for (n = 0; n < ng*ns; n++)
	    sum = sum + Iin[n];

	  norm = sum/(pop*nbatch);

	  /* Avoid compiler warning */

	  x = 0.0;
	  y = 0.0;
	  z = 0.0;

	  u = 0.0;
	  v = 0.0;
	  w = 0.0;

	  g = 0;
	  wgt = 0.0;

	  /* Reset distribution */

	  for (n = 0; n < ng; n++)
	    for (m = 0; m < 100; m++)
	      dis[n][m][0] = 0.0;

	  /* Loop over batches */

	  for (m = 0; m < nbatch; m++)
	    {
	      printf("Batch: %ld/%ld\n", m + 1, nbatch);

	      /* Loop over source neutrons */

	      id = 0;	  
	      for (n = 0; n < pop; n++)
		{
		  /* Sample source point */

		  HDMCSrc(&x, &y, &z, &u, &v, &w, &g, &wgt, src, surf, ns, 
			  type, params, ng, id);

		  /* Transport loop */

		  while (1 != 2)
		    {
		      /* Sample path length */
		      
		      l = -log(RandF(id))/tot[g];
		      
		      /* Calculate distance to boundary */
		      
		      d = SurfaceDistance(surf, params, type, ns, x, y, z, 
					  u, v, w, id);
		      
		      /* Compare */
		      
		      if (l < d)
			{
			  /* Move neutron to collision point */
			  
			  x = x + l*u;
			  y = y + l*v;
			  z = z + l*w;
			  
			  /* Score collision estimator in a 20cm thick */
			  /* slab divided into 100 segments */

			  i = (long)(100.0*((x - params[0])/
					    (-20.0 - params[0])));
			  
			  if ((i > -1) && (i < 100))
			    dis[g][i][0] = dis[g][i][0] 
			      + norm*wgt/tot[g]/20.0*100.0;
						  
			  /* Sample reaction */
			  
			  f = RandF(id)*tot[g];
			  
			  if ((f = f - scatt[g]) < 0.0)
			    {
			      /* Scattering */
			      
			      HDMCScatt(&u, &v, &w, &g, &wgt, ng, &s0[g*ng], 
					&sp0[g*ng], mubar[g], id);
			    }
			  else if ((f = f - abs[g]) < 0.0)
			    {
			      /* Absorption */
			      
			      break;
			    }
			  else
			    Die(FUNCTION_NAME, "Reaction sampling failed");
			}
		      else
			{
			  /* NOTE: The following applies to the 1D */
			  /* test case only */

			  /* Move neutron to boundary surface */
			  
			  x = x + (d - EXTRAP_L)*u;
			  y = y + (d - EXTRAP_L)*v;
			  z = z + (d - EXTRAP_L)*w;

			  /* Check position and direction */

			  if (x > 0.0)
			    Die(FUNCTION_NAME, "Particle lost");
			  if (u < 0.0)
			    Die(FUNCTION_NAME, "Error in direction");

			  /* This is where albedo should be applied to */
			  /* neutron weight and the particle reflected */
			  /* back to geometry. Breaking the loop here  */
			  /* corresponds to escape from geometry. */

			  break;
			}
		    }
		}
	    }

	  printf("\nSimulation completed.\n\n");

	  /* Print scored distribution in file */

	  for (n = 0; n < ng; n++)
	    for (i = 0; i < 100; i++)
	      fprintf(fp, "flx(%ld,%ld) = %E;\n", n + 1, i + 1, dis[n][i][0]);

	  /********************************************************************/
	}
      else
	{
	  /********************************************************************/

	  /***** Criticality source simulation ********************************/

	  /* NOTE: This mode uses the same neutron data structures as    */
	  /*       continuous-energy simulation for storing the fission  */
	  /*       source for next cycle. Stack size is not adjusted,    */
	  /*       which means that an underflow may occur if population */
	  /*       size differs significantly from the CE simulation.    */
	  /*       This can be compensated by increasing the set buf     */
	  /*       parameter in input file. Another problem is that the  */
	  /*       routines are designed for an OpenMP parallelized      */
	  /*       simulation, and each thread is assigned with its own  */
	  /*       stack. Since this part of the program is not run in   */
	  /*       parallel yet, neutrons that are returned to stack are */
	  /*       distributed into inactive stacks, which may cause the */
	  /*       sigle active stack to underflow. The only solution is */
	  /*       to not use too many OpenMP threads in the first place */

	  /* Calculate normalization factor (total heterogeneous flux) */

	  ptr = (long)RDB[gcu + GCU_RES_FG_DF_HET_VOL_FLUX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  
	  norm = 0.0;
	  for (n = 0; n < ng; n++)
	    norm = norm + Mean(ptr, n);

	  /* Set run parameters */

	  pop = (long)RDB[DATA_HDMC_POP];
	  ncyc = (long)RDB[DATA_HDMC_CYCLES];
	  nskip = (long)RDB[DATA_HDMC_SKIP];

	  /* Reset distribution */

	  for (n = 0; n < ng; n++)
	    for (i = 0; i < 100; i++)
	      for (j = 0; j < 100; j++)
		dis[n][i][j] = 0.0;

	  /********************************************************************/

	  /***** Generate initial source **************************************/

	  /* Reset thread id */

	  id = 0;

	  /* NOTE: This assumes that the boundary is sqc */

	  xmin = params[0] - params[2];
	  xmax = params[0] + params[2];
	  ymin = params[1] - params[2];
	  ymax = params[1] + params[2];
	  
	  /* Loop over population */

	  for (n = 0; n < pop; n++)
	    {
	      /* Sample coordinates */
		  
	      x = RandF(0)*(xmax - xmin) + xmin;
	      y = RandF(0)*(ymax - ymin) + ymin;
	      z = 0.0;
	  
	      /* Sample direction cosines */
      
	      IsotropicDirection(&u, &v, &w, id);

	      /* Get particle from stack */

	      nn = FromStack(PARTICLE_TYPE_NEUTRON, id);
  
	      /* Put values */
	      
	      WDB[nn + PARTICLE_X] = x;
	      WDB[nn + PARTICLE_Y] = y;
	      WDB[nn + PARTICLE_Z] = z;
	      
	      WDB[nn + PARTICLE_U] = u;
	      WDB[nn + PARTICLE_V] = v;
	      WDB[nn + PARTICLE_W] = w;
	      
	      WDB[nn + PARTICLE_E] = 0.0;
	      WDB[nn + PARTICLE_WGT] = 1.0;
	      WDB[nn + PARTICLE_FMTX_IDX] = -1.0;

	      /* Put particle to bank */
      
	      ToBank(nn, id);
	    }
	  	  
	  /* Put population size */
	  
	  WDB[DATA_SIMUL_BATCH_SIZE] = (double)pop;
	  
	  /********************************************************************/
	  
	  /***** Transport cycle **********************************************/

	  /* Reset initial guess for k-eff */

	  WDB[DATA_CYCLE_KEFF] = 1.0;

	  /* Loop over cycles */
	  
	  for (n = 0; n < ncyc + nskip; n++)
	    {
	      /* Put cycle index */

	      WDB[DATA_CYCLE_IDX] = (double)n;
	      
	      /* Clear buffer */
	      
	      ClearBuf();

	      /* Normalize source */
	      
	      NormalizeCritSrc();

	      /* Get cycle-wise k-eff */
		  
	      keff = RDB[DATA_CYCLE_KEFF];

	      /* Check skip cycles */

	      if (n > nskip - 1)
		{
		  /* Put k-eff */

		  ptr = (long)RDB[gcu + GCU_HDMC_KEFF];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddStat(keff, ptr, 0);
		  
		  /* Print */

		  printf("Cycle : %ld/%ld -- k-eff : %1.5f +/- %1.5f\n", 
			 n - nskip + 1, ncyc, Mean(ptr, 0), StdDev(ptr, 0));
		}
	      else
		printf("Inactive cycle : %ld/%ld -- keff : %1.5f\n", n + 1,
		       nskip, keff);

	      /* Parallel loop */

#ifdef OPEN_MP
#pragma omp parallel private(id, nn, x, y, z, u, v, w, g, wgt, d, l, i, j, f, ptr, mu, u0, v0, w0, n1, n2, m1, m2) 
#endif
	      {
		/* Get Open MP thread id */
		
		id = OMP_THREAD_NUM;
	      
		/* Loop over source */
		
		while (FromSrc(id) > VALID_PTR)
		  {
		    /* Get particle from que */
		    
		    nn = FromQue(id);
		  
		    /* Get variables */
		    
		    x = RDB[nn + PARTICLE_X];
		    y = RDB[nn + PARTICLE_Y];
		    z = RDB[nn + PARTICLE_Z];
		    u = RDB[nn + PARTICLE_U];
		    v = RDB[nn + PARTICLE_V];
		    w = RDB[nn + PARTICLE_W];
		    g = (long)RDB[nn + PARTICLE_E];
		    wgt = RDB[nn + PARTICLE_WGT];
		    
		    CheckValue(FUNCTION_NAME, "starting cosines", "",
			       u*u + v*v + w*w - 1.0, -1E-4, 1E-4);
		    
		    /* Transport loop */
		    
		    while (1 != 2)
		      {
			/* Check position (assumes sqc) */
			
			if ((x < xmin - 2.0*EXTRAP_L) || 
			    (x > xmax + 2.0*EXTRAP_L) ||
			    (y < ymin - 2.0*EXTRAP_L) || 
			    (y > ymax + 2.0*EXTRAP_L))
			  Warn(FUNCTION_NAME, 
			       "Error in position %E %E %E : %E %E %E",
			       xmin, x, xmax, ymin, y, ymax);
			
			/* Sample path length */
			
			l = -log(RandF(id))/tot[g];
			
			/* Calculate distance to boundary */
			
			d = SurfaceDistance(surf, params, type, ns, x, y, z, 
					    u, v, w, id);
			
			/* Compare */
			
			if (l < d)
			  {
			    /* Move neutron to collision point */
			    
			    x = x + l*u;
			    y = y + l*v;
			    z = z + l*w;
			    
			    /* Score collision estimate of neutron flux */
			    
			    if (n > nskip - 1)
			      {	
				i = (long)(100.0*((x - xmin)/(xmax - xmin)));
				j = (long)(100.0*((y - ymin)/(ymax - ymin)));
				
				if ((i > -1) && (i < 100) && 
				    (j > -1) && (j < 100))
				  {
#ifdef OPEN_MP
#pragma omp atomic
#endif			    
				    dis[g][j][i] += wgt/tot[g];
				  }
			      }
			    
			    /* Score total flux */
			    
			    ptr = (long)RDB[gcu + GCU_RES_FG_DF_HOM_VOL_FLUX];
			    CheckPointer(FUNCTION_NAME, "(ptr)", 
					 DATA_ARRAY, ptr);
			    AddBuf(1.0/tot[g], wgt, ptr, 0, g);
			  
			    /* Sample reaction */
			    
			    f = RandF(id)*tot[g];
			    
			    if ((f = f - scatt[g]) < 0.0)
			      {
				/* Scattering */
				
				HDMCScatt(&u, &v, &w, &g, &wgt, ng, &s0[g*ng], 
					  &sp0[g*ng], mubar[g], id);
			      }
			    else if ((f = f - fiss[g]) < 0.0)
			      {
				/* Fission */
				
				HDMCFission(x, y, z, wgt, nubar[g], chi, 
					    ng, id);
			      
				/* Break loop */
				
				break;
			      }
			    else if ((f = f - abs[g]) < 0.0)
			      {
				/* Absorption, break loop */
				
				break;
			      }
			    else
			      Die(FUNCTION_NAME, "Sampling failed");
			  }
			else
			  {
			    /* Move neutron to boundary surface */
			    
			    x = x + (d + EXTRAP_L)*u;
			    y = y + (d + EXTRAP_L)*v;
			    z = z + (d + EXTRAP_L)*w;
			    
			    /* Boundary routine. This identifies the   */
			    /* surface (index n1) and sets the surface */
			    /* normal vector. */
			    
			    DFPos(surf, x, y, z, &n1, &n2, &m1, &m2, 
				  &u0, &v0, &w0);
			    
			    /* Calculate cosine between neutron direction */
			    /* and surface normal */
			    
			    if ((mu = fabs(u*u0 + v*v0 + w*w0)) < 0.1)
			      mu = 0.05;
			    
			    /* Check surface index */
			    
			    if (n1 > -1)
			      {
				/* Score surface flux for the incident */
				/* neutron */
			      
				ptr = 
				  (long)RDB[gcu + GCU_RES_FG_DF_HOM_SURF_FLUX];
				CheckPointer(FUNCTION_NAME, "(ptr)", 
					     DATA_ARRAY, ptr);
				AddBuf(1.0/mu, wgt, ptr, 0, -1, n1, g);
			      }
			  
			    /* Use albedo to adjust weight */
			    
			    wgt = wgt*alb[n1*ng + g];
			    
			    /* Score surface flux for the reflected neutron */
			    
			    if (n1 > -1)
			      {
				/* Score surface flux for the incident */
				/* neutron */
			      
				ptr = 
				  (long)RDB[gcu + GCU_RES_FG_DF_HOM_SURF_FLUX];
				CheckPointer(FUNCTION_NAME, "(ptr)", 
					     DATA_ARRAY, ptr);
				AddBuf(1.0/mu, wgt, ptr, 0, -1, n1, g);
			      }
			    
			    /* Move neutron back inside */
			    
			    x = x - 2.0*EXTRAP_L*u;
			    y = y - 2.0*EXTRAP_L*v;
			    z = z - 2.0*EXTRAP_L*w;
			    
			    /* White or reflective boundary */
			    
			    if (1 == 2)
			      {
				/* White boundary, sample cosine relative to */
				/* surface normal */
				
				mu = sqrt(RandF(id));
				
				/* Rotate normal vector */
				
				AziRot(mu, &u0, &v0, &w0, id);
				
				/* Set new direction */
				
				u = u0;
				v = v0;
				w = w0;
			      }
			    else
			      {
				/* Reflective boundary */
				
				mu = (u*u0 + v*v0 + w*w0);
				
				u = u - 2.0*u0*mu;
				v = v - 2.0*v0*mu;
				w = w - 2.0*w0*mu;
			      }
			  }
		      }
		    
		    /* History terminated, put particle back in stack */
		    
		    ToStack(nn, id);
		  }
	      }
	      
	      /* Reduce scoring buffer */
	      
	      ReduceBuffer();

	      /* Get total volume flux for normalization */

	      ptr = (long)RDB[gcu + GCU_RES_FG_DF_HOM_VOL_FLUX];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      flx = 0.0;
	      for (g = 0; g < ng; g++)
		flx = flx + BufVal(ptr, g);	      

	      /* Collect surface flux */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_DF_HOM_SURF_FLUX];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      for (g = 0; g < ng; g++)
		for (i = 0; i < ns; i++)
		  {
		    f = BufVal(ptr, i, g);
		    f = f*norm/flx*RDB[adf + ADF_SURF_AREA];
		    AddStat(f, ptr, i, g);
		  }

	      /* Collect volume flux */

	      ptr = (long)RDB[gcu + GCU_RES_FG_DF_HOM_VOL_FLUX];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      for (g = 0; g < ng; g++)
		{
		  f = BufVal(ptr, g);
		  f = f*norm/flx;
		  AddStat(f, ptr, g);
		}
	    }
	  
	  printf("\nSimulation completed.\n\n");
	  
	  /* Print scored distribution in file */

	  for (n = 0; n < ng; n++)
	    for (i = 0; i < 100; i++)
	      for (j = 0; j < 100; j++)
		fprintf(fp, "flx%ld(%ld,%ld) = %E;\n", n + 1, i + 1, j + 1,
			dis[n][i][j]);

	  /*******************************************************************/
	}
      
      /************************************************************************/
      
      /***** Cleanup and exit *************************************************/

      /* Free allocated memory */
      
      Mem(MEM_FREE, tot);
      Mem(MEM_FREE, abs);
      Mem(MEM_FREE, fiss);
      Mem(MEM_FREE, scatt);
      Mem(MEM_FREE, nsf);
      Mem(MEM_FREE, nubar);
      Mem(MEM_FREE, chi);
      Mem(MEM_FREE, mubar);
      Mem(MEM_FREE, s0);
      Mem(MEM_FREE, s1);
      Mem(MEM_FREE, sp0);
      Mem(MEM_FREE, Iin);
      Mem(MEM_FREE, Iout);
      Mem(MEM_FREE, alb);
      Mem(MEM_FREE, src);
      
      /* Close output file */

      fclose(fp);

      /************************************************************************/

      /* Next universe */

      gcu = NextItem(gcu);
      
      /************************************************************************/
    }
}

/*****************************************************************************/

/***** Scattering subroutine *************************************************/

void HDMCScatt(double *u, double *v, double *w, long *g0, double *wgt, 
	       long ng, double *s0, double *sp0, double mubar, long id)
{
  long g1;
  double f, mu;

  /* Sample emission energy group */

  f = RandF(id);

  for (g1 = 0; g1 < ng; g1++)
    if ((f = f - s0[g1]) < 0.0)
      break;

  /* Check */

  if (f > 0.0)
    Die(FUNCTION_NAME, "Failed to sample emission energy ");

  /* Adjust weight */

  *wgt = *wgt*sp0[g1];

  /* Sample scattering cosine */

  mu = SampleP1Mu(mubar, id);
  
  /* Rotate direction cosines */

  AziRot(mu, u, v, w, id);

  /* Set new energy group */
  
  *g0 = g1;
}

/*****************************************************************************/

/***** Scattering cosine sampling ********************************************/

double SampleP1Mu(double mubar, long id)
{
  double f, mu;

  /* Sample P1 scattering cosine (from KENO-V.a manual, page 31) */
  
  f = RandF(id) - 1.0;
  
  if (fabs(mubar) < 0.0001)
    mu = f;
  else if (fabs(mubar) < 0.3333)
    mu = (sqrt(1.0 + 6.0*f*mubar + 9.0*mubar*mubar) - 1.0)/(3.0*mubar);
  else
    mu = f*(1.0 - fabs(mubar)) + mubar;

  /* Check */

  CheckValue(FUNCTION_NAME, "mu", "", mu, -1.0, 1.0);

  /* Return value */

  return mu;
}

/*****************************************************************************/

/***** Source subroutine *****************************************************/

void HDMCSrc(double *x, double *y, double *z, double *u, double *v, double *w,
	     long *g, double *wgt, double *src, long surf, long ns, long type,
	     const double *params, long ng, long id)
{
  long m, n, i;
  double f, mu;

  /* Check surface pointer */

  CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);

  /* Sample surface and energy group */

  f = RandF(id);
  for (i = 0; i < ns*ng; i++)
    if ((f = f - src[i]) < 0.0)
      break;
  
  /* Check */

  if (f > 0.0)
    Die(FUNCTION_NAME, "Failed to sample source");

  /* Calculate energy group and surface index */
  
  m = (long)((double)i/((double)ng));
  n = i - m*ng;

  /* Check */
  
  CheckValue(FUNCTION_NAME, "n", "", n, 0, ng - 1);
  CheckValue(FUNCTION_NAME, "m", "", m, 0, ns - 1);

  /* Check surface type, sample coordinates and set surface normal */

  switch(type)
    {
    case SURF_PX:
      {
	*x = params[0] - EXTRAP_L;
	*y = 0.0;
	*z = 0.0;
	
	*u = -1.0;
	*v = 0.0;
	*w = 0.0;

	break;
      }
    case SURF_PY:
      {
	*x = 0.0;
	*y = params[0] - EXTRAP_L;
	*z = 0.0;

	*u = 0.0;
	*v = -1.0;
	*w = 0.0;

	break;
      }
    case SURF_PZ:
      {
	*x = 0.0;
	*y = 0.0;
	*z = params[0] - EXTRAP_L;
	
	*u = 0.0;
	*v = 0.0;
	*w = -1.0;

	break;
      }
    default:
      {
	Die(FUNCTION_NAME, "Surface type not yet supported");
      }
    }
     
  /* Set energy group */

  *g = n;
  
  /* Set weight */
  
  *wgt = 1.0;

  /* Sample direction cosine relative to surface normal (assume */
  /* white boundary) */

  mu = sqrt(RandF(id));

  /* Rotate cosines to get final direction */
      
  AziRot(mu, u, v, w, id);
}

/******************************************************************************/

/**** Fission subroutine ******************************************************/

void HDMCFission(double x, double y, double z, double wgt, double nubar, 
		 double *chi, long ng, long id)
{
  long nu, n, nn, g;
  double keff, u, v, w, f;

  /* Get cycle-keff */
  
  keff = RDB[DATA_CYCLE_KEFF];

  /* Adjust nubar */

  nubar = wgt*nubar/keff;

  /* Get integer part */

  nu = (long)nubar;

  /* Sample extra neutron */
  
  if (RandF(id) < nubar - (double)nu)
    nu++;

  /* Loop over source particles */

  for (n = 0; n < nu; n++)
    {
      /* Sample direction cosines */

      IsotropicDirection(&u, &v, &w, id);

      /* Sample energy group */

      f = RandF(id);

      for (g = 0; g < ng; g++)
	if ((f = f - chi[g]) < 0.0)
	  break;

      /* Check */

      if (f > 0.0)
	Die(FUNCTION_NAME, "Failed to sample emission energy ");
      
      /* Get particle from stack */

      nn = FromStack(PARTICLE_TYPE_NEUTRON, id);

      /* Put values */
      
      WDB[nn + PARTICLE_X] = x;
      WDB[nn + PARTICLE_Y] = y;
      WDB[nn + PARTICLE_Z] = z;
      
      WDB[nn + PARTICLE_U] = u;
      WDB[nn + PARTICLE_V] = v;
      WDB[nn + PARTICLE_W] = w;
      
      WDB[nn + PARTICLE_E] = (double)g;
      WDB[nn + PARTICLE_WGT] = 1.0;
      WDB[nn + PARTICLE_FMTX_IDX] = -1.0;

      /* Put particle to bank */
      
      ToBank(nn, id);
    }
}

/*****************************************************************************/


















