/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : stopatboundary.c                               */
/*                                                                           */
/* Created:       2012/08/11 (JLe)                                           */
/* Last modified: 2012/11/04 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Stops particle at outer boundary                             */
/*                                                                           */
/* Comments: - Needed to account for handling leakage and repeated boundary  */
/*             conditions in delta-tracking mode                             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "StopAtBoundary:"

/*****************************************************************************/

long StopAtBoundary (long *cell, double *x0, double *y0, double *z0, 
		     double *l0, double u, double v, double w, long id)
{
  double x, y, z, min, l;

  /* Check cell pointer */

  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, *cell);

  /* Check that point is outside */
  
  if ((long)RDB[*cell + CELL_TYPE] != CELL_TYPE_OUTSIDE)
    return NO;

  /* Invert direction */

  u = -u;
  v = -v;
  w = -w;

  /* Get coordinates */

  x = *x0;
  y = *y0;
  z = *z0;
  
  /* Reset distance */

  l = 0.0;

  /* Find cell (this is needed because the direction was inverted) */
  
  *cell = WhereAmI(x, y, z, u, v, w, id);
  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, *cell);

  /* Loop until inside */

  do
    {
      /* Get distance to nearest boundary */

      if ((min = NearestBoundary(id)) == INFTY)
	Error(0, "Geometry error, possibly overlap at (%1.3E, %1.3E, %1.3E)\n", 
	      x, y, z);
    
      /* Check distance */

      if (min > 1E+9)
	Die(FUNCTION_NAME, "This doesn't happen anymore");

      /* Move over boundary */

      x = x + (min + EXTRAP_L)*u;
      y = y + (min + EXTRAP_L)*v;
      z = z + (min + EXTRAP_L)*w;

      /* Update distance */

      l = l + min + EXTRAP_L;
    
      /* Find cell */

      *cell = WhereAmI(x, y, z, u, v, w, id);
      CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, *cell);
    }
  while ((long)RDB[*cell + CELL_TYPE] == CELL_TYPE_OUTSIDE);

  /* Invert direction */

  u = -u;
  v = -v;
  w = -w;

  /* Move back outside (particle must be moved beyond extrapolation */
  /* distance to get surface detectors right) */

  x = x + 3.0*EXTRAP_L*u;
  y = y + 3.0*EXTRAP_L*v;
  z = z + 3.0*EXTRAP_L*w;

  /* Update distance */

  l = l - 3.0*EXTRAP_L;
  *l0 = *l0 - l;

  /* Find cell */

  *cell = WhereAmI(x, y, z, u, v, w, id);
  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, *cell);
  
  /* Check outside flag */

  if ((long)RDB[*cell + CELL_TYPE] != CELL_TYPE_OUTSIDE)
    Error(0, "Geometry error, possibly overlap at (%1.3E, %1.3E, %1.3E)\n", 
	  x, y, z);

  /* Update coordinates */

  *x0 = x;
  *y0 = y;
  *z0 = z;

  /* Exit subroutine */
  
  return YES;
}

/*****************************************************************************/
