/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : matptr.c                                       */
/*                                                                           */
/* Created:       2012/05/10 (JLe)                                           */
/* Last modified: 2013/03/14 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Returns material pointer for depletion zones                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MatPtr:"

/*****************************************************************************/

long MatPtr(long mat, long id)
{
  long ptr, div, lst, idx, nax, nrad, nseg, reg, uni, i, j, k;
  double x, y, z, r, phi;

  /* Check null pointer */

  if (mat < VALID_PTR)
    return mat;

  /* Check divisor */

  if ((div = (long)RDB[mat + MATERIAL_PTR_DIV]) < VALID_PTR)
    return mat;

  /* Check type */

  if ((long)RDB[mat + MATERIAL_DIV_TYPE] == MAT_DIV_TYPE_NEW)
    Die(FUNCTION_NAME, "Error");

  /***************************************************************************/

  /***** Division into zones *************************************************/

  /* Pointer to material list */

  lst = (long)RDB[div + DIV_PTR_MAT_LIST];
  CheckPointer(FUNCTION_NAME, "(lst)", DATA_ARRAY, lst);

  /* Check division */

  if ((long)RDB[div + DIV_SEP] == YES)
    {
      /* Get zone index */

      ptr = (long)RDB[DATA_PTR_ZONE_IDX];
      idx = (long)GetPrivateData(ptr, id);

      /* Find region */

      if ((lst = SeekList(lst, DIV_MAT_LIST_ZONE_IDX, idx, SORT_MODE_ASCEND))
	  < VALID_PTR)
	Die(FUNCTION_NAME, "Horrible error");
      
      /* Check index */

      if (idx != (long)RDB[lst + DIV_MAT_LIST_ZONE_IDX])
	Die(FUNCTION_NAME, "WTF?");
    }

  /***************************************************************************/

  /***** Division into sub-regions *******************************************/

  /* Get universe pointer */

  uni = (long)RDB[lst + DIV_MAT_LIST_PTR_UNIV];
  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

  /* Get pointer to sub-regions */

  reg = (long)RDB[lst + DIV_MAT_LIST_PTR_REG];
  CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

  /* Get bin sizes */

  nax = (long)RDB[div + DIV_NAX];
  nrad = (long)RDB[div + DIV_NRAD];
  nseg = (long)RDB[div + DIV_NSEG];

  /* Check for single-valued */

  if (nax*nrad*nseg == 1)
    idx = 0;
  else
    {
      /* Get local coordinates */

      ptr = RDB[uni + UNIVERSE_PTR_PRIVA_X];
      x = GetPrivateData(ptr, id);
      
      ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Y];
      y = GetPrivateData(ptr, id);
      
      ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Z];
      z = GetPrivateData(ptr, id);		  

      /* Axial coordinate */

      if (nax == 1)
	i = 0;
      else
	{
	  /* Calculate normalized coordinate */
	  
	  z = (z - RDB[div + DIV_ZMIN])/
	    (RDB[div + DIV_ZMAX] - RDB[div + DIV_ZMIN]);

	  /* Check that point is inside region */

	  if ((z < 0.0) || (z >= 1.0))
	    Error(div, 
		  "Axial dimension doesn't cover region (geometry error?)");

	  /* Calculate index */

	  i = (long)(z*nax);	  
	}
	    
      /* Radial coordinate */

      if (nrad == 1)
	j = 0;
      else
	{
	  /* Calculate radius */

	  r = sqrt(x*x + y*y);

	  /* Calculate normalized coordinate */

	  r = (r - RDB[div + DIV_RMIN])/
	    (RDB[div + DIV_RMAX] - RDB[div + DIV_RMIN]);

	  /* Check that point is inside region */

	  if ((r < 0.0) || (r >= 1.0))
	    Error(div, "Radial dimension doesn't cover region");

	  /* Calculate index */

	  j = (long)(r*r*nrad);
	}

      /* Angular segment */

      if (nseg == 1)
	k = 0;
      else
	{
	  /* Calculate angle */

	  phi = PolarAngle(x, y);

	  /* Add tilt */

	  phi = phi + RDB[div + DIV_SEG0];

	  /* Normalize */

	  phi = phi/(2.0*PI);
	  phi = phi - (double)((long)phi);

	  /* Check phi */

	  CheckValue(FUNCTION_NAME, "phi", "", phi, 0.0, 1.0);

	  /* Calculate index */

	  k = (long)(phi*nseg);
	}
      
      /* Calculate index */
      
      idx = i + j*nax + k*nax*nrad;
      CheckValue(FUNCTION_NAME, "idx", "", idx, 0, nax*nrad*nseg - 1);
    }
  
  /* Get pointer */
  
  mat = (long)RDB[reg + idx];
  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /***************************************************************************/

  /* Return pointer */

  return mat;
}

/*****************************************************************************/
