/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : disperse.c                                     */
/*                                                                           */
/* Created:       2012/02/08 (JLe)                                           */
/* Last modified: 2012/12/28 (JLe)                                           */
/* Version:       2.1.12                                                     */
/*                                                                           */
/* Description: Generates random particle distributions inside simple        */
/*              volumes                                                      */
/*                                                                           */
/* Comments: - From Serpent 1.1.9                                            */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Disperse:"

/* NOTE: pallo ja kuutio on origokeskeisiä. */

/*****************************************************************************/

struct particle {
  long idx;
  double x;
  double y;
  double z;
  double rp;
  long u;
  long fixed;
  struct particle *next;
};

struct smsh {
  long sz;
  long *n;
};

/*****************************************************************************/

void Disperse()
{
  long type, N, Nprev, N0, Nmax, u, n, m, i, j, k, nx, ny, nz;
  long imin, imax, jmin, jmax, kmin, kmax, ni, ptr, id;
  unsigned long seed;
  double r, rmin, rpmax, xmin, xmax, ymin, ymax, zmin, zmax, rp, x, y, z;
  double dx, dy, dz, dr, V0, V1, V2, pf;
  char answer[256], fname[256];
  struct particle *p, *first, *p1; 
  struct smsh ***f;
  FILE *fp, *outp;

  /***************************************************************************/

  /***** Prompt input data ***************************************************/

  /* Check if input file is given */

  if ((long)RDB[DATA_PTR_INPUT_FNAME] > 0)
    {
      fp = fopen(GetText(DATA_PTR_INPUT_FNAME), "r");
      outp = fopen("/dev/null", "w");
    }
  else
    {
      fp = stdin;
      outp = stdout;
    }

  printf("\nRandom particle distribution file generator launched...\n");

  if (fp == NULL)
    {
      printf("\nUnable to open input file.\n\n");
      exit(-1);
    }
  else if (fp != stdin)
    printf("\nReading data from file...\n\n");
  
  /* Get volume type */
  
  fprintf(outp, "\nEnter volume type: 1 = sphere\n");
  fprintf(outp, "                   2 = cylinder\n");
  fprintf(outp, "                   3 = cube\n");
  fprintf(outp, "                   4 = annular cylinder\n\n");
    
  if (fscanf(fp, "%ld", &type) == EOF)
    Die(FUNCTION_NAME, "fscanf error");

  fprintf(outp, "\n");

  /* Get volume dimensions */

  p = NULL;

  if (type == 1)
    {
      fprintf(outp, "Enter sphere radius (cm): ");

      if (fscanf(fp, "%lf", &r) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      V0 = (4.0/3.0)*PI*r*r*r;
      
      xmin = -r;
      xmax =  r;
      ymin = -r;
      ymax =  r;
      zmin = -r;
      zmax =  r;
    }
  else if (type == 2)
    {
      fprintf(outp, "Enter cylinder radius (cm): ");

      if (fscanf(fp, "%lf", &r) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter cylinder bottom co-ordinate (cm): ");

      if (fscanf(fp, "%lf", &zmin) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter cylinder top co-ordinate (cm): ");

      if (fscanf(fp, "%lf", &zmax) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      V0 = PI*r*r*(zmax - zmin);

      xmin = -r;
      xmax =  r;
      ymin = -r;
      ymax =  r;
    }
  else if (type == 3)
    {
      fprintf(outp, "Enter cube half-width (cm): ");

      if (fscanf(fp, "%lf", &r) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      V0 = 8*r*r*r;

      xmin = -r;
      xmax =  r;
      ymin = -r;
      ymax =  r;
      zmin = -r;
      zmax =  r;
    }
  else if (type == 4)
    {
      fprintf(outp, "Enter cylinder radius (cm): ");

      if (fscanf(fp, "%lf", &r) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter cylinder bottom co-ordinate (cm): ");

      if (fscanf(fp, "%lf", &zmin) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter cylinder top co-ordinate (cm): ");

      if (fscanf(fp, "%lf", &zmax) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter central hole radius (cm): ");

      if (fscanf(fp, "%lf", &rmin) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      V0 = PI*(r*r - rmin*rmin)*(zmax - zmin);

      xmin = -r;
      xmax =  r;
      ymin = -r;
      ymax =  r;
    }
  else
    {
      printf("\nInvalid type %ld.\n", type);
      exit(-1);
    }

  /* Loop over particle types */

  Nmax = 0;
  N0 = 0;

  V1 = 0;
  V2 = 0;

  rpmax = -1.0;

  do
    {
      /* Get number of particles, radius and universe */

      fprintf(outp, 
	      "Enter number of particles (> 1) or packing fraction (< 1): ");

      if (fscanf(fp, "%lf", &pf) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter particle radius (cm): ");

      if (fscanf(fp, "%lf", &rp) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "Enter particle universe: ");

      if (fscanf(fp, "%ld", &u) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      /* Compare radius to maximum */

      if (rp > rpmax)
	rpmax = rp;

      /* Calculate number of particles from packing fraction */

      if (pf > 1.0)
	N = (long)pf; 
      else
	N = (long)round(V0*pf/((4.0/3.0)*PI*rp*rp*rp));
      
      /* Calculate volume */
      
      V1 = V1 + N*(4.0/3.0)*PI*rp*rp*rp;

      /* Check packing fraction */

      if (V1/V0 > 0.7)
	{
	  printf("\nTotal packing fraction %1.2f too high.\n\n", V1/V0);
	  exit(-1);
	}

      /* Allocate memory for data */

      Nmax = Nmax + N;     
      p = (struct particle *)realloc(p, Nmax*sizeof(struct particle));

      /* Check */

      if (p == NULL)
	{
	  printf("\nMemory allocation failed, too many particles.\n\n");
	  exit(-1);
	}

      /* Create particles */

      for (n = N0; n < Nmax; n++)
	{
	  p[n].rp = rp;
	  p[n].u = u;
	  p[n].fixed = NO;
	}

      N0 = Nmax;      

      /* Prompt more particles */

      fprintf(outp, "\nMore particles? (y/n): ");

      if (fscanf(fp, "%s", answer) == EOF)
	Die(FUNCTION_NAME, "fscanf error");

      fprintf(outp, "\n");
    }
  while (answer[0] == 'y');

  /* Get file name */

  fprintf(outp, "Enter file name: ");

  if (fscanf(fp, "%s", fname) == EOF)
    Die(FUNCTION_NAME, "fscanf error");

  /* Close input file */

  if (fp != stdin)
    fclose(fp);

  /***************************************************************************/

  /***** Prepare data for distribution ***************************************/

  /* Calculate mesh size */
      
  nx = (long)(xmax - xmin)/(2.0*rpmax);
  ny = (long)(ymax - ymin)/(2.0*rpmax);
  nz = (long)(zmax - zmin)/(2.0*rpmax);
  
  /* Check cut-offs */
  
  if (nx < 5)
    nx = 5;
  else if (nx > 500)
    nx = 500;
  
  if (ny < 5)
    ny = 5;
  else if (ny > 500)
    ny = 500;
  
  if (nz < 5)
    nz = 5;
  else if (nz > 500)
    nz = 500;

  /* Allocate data for search mesh */

  f = (struct smsh ***)malloc(nx * sizeof(struct smsh **));

  for(i = 0; i < nx; i++)
    {
      f[i] = (struct smsh **)malloc(ny * sizeof(struct smsh *));

      for(j = 0; j < ny; j++)
	f[i][j] = (struct smsh *)malloc(nz * sizeof(struct smsh));
    }

  /* Reset data */

  for (k = 0; k < nz; k++)
    for (j = 0; j < ny; j++)
      for (i = 0; i < nx; i++)
	{
	  f[i][j][k].sz = 0;
	  f[i][j][k].n = NULL;
	}

  /* Set pointers for linked list */

  first = &p[0];

  for (n = 0; n < Nmax - 1; n++)
    p[n].next = &p[n + 1];

  p[n].next = NULL;

  /* Set indexes */

  for (n = 0; n < Nmax; n++)
    p[n].idx = n;

  /***************************************************************************/

  /***** Generate distribution ***********************************************/

  /* Reset printing counter */

  Nprev = -1;

  /* Set id */

  id = 0;

  /* Init random number sequence */
      
  seed = ReInitRNG(1);
  
  /* Put seed in private data */
  
  ptr = (long)RDB[DATA_PTR_RNG_SEED];
  PutPrivateData(ptr, seed, id);
 
  /* Randomize */

  fprintf(outp, "\nRandomizing %ld particles...\n\n", Nmax);

  do
    { 
      /* Pointer to first unfixed particle */

      p1 = first;

      /* Randomize */

      if (type == 1)
	{
	  while (p1 != NULL)
	    {
	      rp = p1->rp;
	      
	      do
		{
		  x = (2*RandF(id) - 1)*(r - rp);
		  y = (2*RandF(id) - 1)*(r - rp);
		  z = (2*RandF(id) - 1)*(r - rp);
		}
	      while (x*x + y*y + z*z > (r - rp)*(r - rp));
	      
	      p1->x = x;
	      p1->y = y;
	      p1->z = z;
	      
	      p1 = p1->next;
	    }
	}
      else if (type == 2)
	{
	  while (p1 != NULL)
	    {
	      rp = p1->rp;
	      
	      do
		{
		  x = (2*RandF(id) - 1)*(r - rp);
		  y = (2*RandF(id) - 1)*(r - rp);
		  z = RandF(id)*(zmax - zmin) + zmin;
		}
	      while ((x*x + y*y  > (r - rp)*(r - rp)) ||
		     (z < zmin + rp) || (z > zmax - rp));
	      
	      p1->x = x;
	      p1->y = y;
	      p1->z = z;

	      p1 = p1->next;
	    }
	}
      else if (type == 4)
	{
	  while (p1 != NULL)
	    {
	      rp = p1->rp;
	      
	      do
		{
		  x = (2*RandF(id) - 1)*(r - rp);
		  y = (2*RandF(id) - 1)*(r - rp);
		  z = RandF(id)*(zmax - zmin) + zmin;
		}
	      while ((x*x + y*y  > (r - rp)*(r - rp)) ||
		     (x*x + y*y  < (rmin + rp)*(rmin + rp)) ||
		     (z < zmin + rp) || (z > zmax - rp));
	      
	      p1->x = x;
	      p1->y = y;
	      p1->z = z;

	      p1 = p1->next;
	    }
	}
      else 
	{
	  while (p1 != NULL)
	    {
	      rp = p1->rp;
	      
	      x = (2*RandF(id) - 1)*(r - rp);
	      y = (2*RandF(id) - 1)*(r - rp);
	      z = (2*RandF(id) - 1)*(r - rp);
	      
	      p1->x = x;
	      p1->y = y;
	      p1->z = z;

	      p1 = p1->next;
	    }
	}

      /* Pointer to first unfixed particle */

      p1 = first;  

      /* Loop over distribution */

      N = 0;

      while(p1 != NULL)
	{
	  /* Get mesh indexes */
	  
	  imin = (long)((double)nx*(p1->x - p1->rp - xmin)/(xmax - xmin));
	  imax = (long)((double)nx*(p1->x + p1->rp - xmin)/(xmax - xmin));
	  jmin = (long)((double)ny*(p1->y - p1->rp - ymin)/(ymax - ymin));
	  jmax = (long)((double)ny*(p1->y + p1->rp - ymin)/(ymax - ymin));
	  kmin = (long)((double)nz*(p1->z - p1->rp - zmin)/(zmax - zmin));
	  kmax = (long)((double)nz*(p1->z + p1->rp - zmin)/(zmax - zmin));
	  
	  /* Test boundaries */
	  
	  if (imin < 0)
	    imin = 0;
	  if (imax > nx - 1)
	    imax = nx - 1;
	  
	  if (jmin < 0)
	    jmin = 0;
	  if (jmax > ny - 1)
	    jmax = ny - 1;
	  
	  if (kmin < 0)
	    kmin = 0;
	  if (kmax > nz - 1)
	    kmax = nz - 1;
	  
	  /* Set fixed-flag */

	  p1->fixed = YES;
	  
	  /* Loop particles in mesh to check overlap */

	  for (i = imin; i <= imax; i++)
	    for (j = jmin; j <= jmax; j++)
	      for (k = kmin; k <= kmax; k++)
		for (ni = 0; ni < f[i][j][k].sz; ni++)
		  {
		    /* Get index */
		    
		    m = f[i][j][k].n[ni];
		    
		    /* Check that particle is fixed */

		    if (p[m].fixed == NO)
		      Die(FUNCTION_NAME, "Particle not fixed");

		    /* Test */
		    
		    dx = p1->x - p[m].x;
		    dy = p1->y - p[m].y;
		    dz = p1->z - p[m].z;
		    dr = p1->rp + p[m].rp;
		    
		    if (dx*dx + dy*dy + dz*dz < dr*dr)
		      {
			/* Overlap, reset flag */
			
			p1->fixed = NO;
			
			/* Break loop */
			
			i = imax + 1;
			j = jmax + 1;
			k = kmax + 1;
			
			break;
		      }
		  }
	  
	  /* Check if flag is set */
	  
	  if (p1->fixed == YES)
	    {
	      /* Add particle in mesh */
	      
	      for (i = imin; i <= imax; i++)
		for (j = jmin; j <= jmax; j++)
		  for (k = kmin; k <= kmax; k++)
		    {
		      /* Get number of existing */
		      
		      ni = f[i][j][k].sz;
		      
		      /* Allocate memory */
		      
		      f[i][j][k].n = (long *)realloc(f[i][j][k].n, 
						    (ni + 1)*sizeof(long));
		      
		      /* Add index to list */
		      
		      f[i][j][k].n[ni] = p1->idx;
		      
		      /* Add size */
		      
		      f[i][j][k].sz++;			
		    }
	      
	      /* Add volume */
	      
	      V2 = V2 + (4.0/3.0)*PI*p1->rp*p1->rp*p1->rp;
	    }
	  else
	    {
	      /* Add counter */
	      
	      N++;
	    }

	  /* Next particle */

	  p1 = p1->next;
	}

      /* Check if status has changed */

      if ((N > 0) && (N != Nprev))
	{
	  /* Regenerate list */

	  first = NULL;
	  p1 = NULL;
	  
	  for (n = 0; n < Nmax; n++)
	    if (p[n].fixed == NO)
	      {
		if (first == NULL)
		  first = &p[n];
		else
		  p1->next = &p[n];
		
		p1 = &p[n];
		p1->next = NULL;
	      }
	  
	  /* Print number of particles left */

	  printf("Overlapping particles: %6ld / %ld pf = %1.5f / %1.5f\n", 
		 N, Nmax, V2/V0, V1/V0);
	  Nprev = N;
	}
    }
  while (N > 0);

  /* Verify */

#ifdef DEBUG

  printf("\n");

  for (n = 0; n < Nmax; n++)
    {
      printf("Verifying distribution: %6ld / %ld \n", n + 1, Nmax);
	     
      for (m = n + 1; m < Nmax; m++)
	{
	  /* Check overlap */
	  
	  dx = p[n].x - p[m].x;
	  dy = p[n].y - p[m].y;
	  dz = p[n].z - p[m].z;
	  dr = p[n].rp + p[m].rp;
	  
	  if (dx*dx + dy*dy + dz*dz < dr*dr)
	    Die(FUNCTION_NAME, "Particles overlapping");
	}
    }

#endif 

  /* Finished. Write data to file */

  printf("\nWriting final distribution to file \"%s\"...\n\n", fname);
  
  /* Write file */
  
  fp = fopen(fname, "w");
      
  for (n = 0; n < Nmax; n++)
    fprintf(fp, "%12.5E %12.5E %12.5E %11.5E %ld\n", p[n].x, p[n].y, p[n].z, 
	    p[n].rp, p[n].u);
  
  fclose(fp);

  printf("%ld particles, packing fraction = %1.5f\n\n", Nmax, V1/V0);

  /* Free memory */

  free(p);

  for (i = 0; i < nx; i++)
    {
      for (j = 0; j < ny; j++)
	{
	  for (k = 0; k < nz; k++)
	    free(f[i][j][k].n);
	  
	  free(f[i][j]);
	}
      free(f[i]);
    }

  free(f);
}

/*****************************************************************************/
