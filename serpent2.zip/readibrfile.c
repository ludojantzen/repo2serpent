/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readibrfile.c                                  */
/*                                                                           */
/* Created:       2011/01/28 (JLe)                                           */
/* Last modified: 2011/12/15 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reads energy-dependent isomeric branching ratios             */
/*                                                                           */
/* Comments: - Serpent-specific file format: <ZAI> <MT> <NE>                 */
/*                                           <E1> <P1>                       */
/*                                           ...                             */
/*                                                                           */
/*           - P1 is branching to ground state, if NE = 0, a single value    */
/*             is read.                                                      */
/*                                                                           */
/*           - Muuta nimi ibr -> bra                                         */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReadIBRFile:"

/*****************************************************************************/

void ReadIBRFile()
{
  long loc0, ptr, erg, ZAI, MT, NE, n;
  double BR, *E, *P;
  FILE *fp;

  /* Check that file name is given */

  if ((long)RDB[DATA_PTR_IBR_FNAME] < 1)
    return;
  
  /* Open file for reading */
  
  fp = OpenDataFile(DATA_PTR_IBR_FNAME, "isomeric br data");
  fprintf(out, "Reading isomeric branching ratios...\n");

  /* Avoid compiler warning */

  E = NULL;
  P = NULL;

  /* Read data */
  
  while (fscanf(fp, "%ld", &ZAI) > 0)
    {	  
      /* Allocate memory for structure */

      loc0 = NewItem(DATA_PTR_IBR_LIST, IBR_LIST_BLOCK_SIZE);

      /* Check ZAI */

      if ((ZAI < 1001) || (ZAI > 1200000))
	Error(0, "Invalid ZAI %ld in isomeric branching data file", ZAI);

      /* MT */
	  
      if (fscanf(fp, "%ld", &MT) < 0)
	Error(0, "Invalid format in isomeric branching data file");

      /* Check MT */

      if ((MT < 16) || (MT > 199))
	Error(0, "Invalid MT %ld in isomeric branching data file", MT);

      /* NE */
	  
      if (fscanf(fp, "%ld", &NE) < 0)
	Error(0, "Invalid format in isomeric branching data file");

      /* Check type */
      
      if (NE == 0)
	{
	  /* Read single value */
	  
	  if (fscanf(fp, "%lf", &BR) < 0)
	    Error(0, "Invalid format in isomeric branching data file");

	  /* Check ratio */

	  if ((BR < 0.0) || (BR > 1.0))
	    Error(0, "Invalid BR %E in isomeric branching data file", BR);
	}
      else if (NE > 0)
	{
	  /* Allocate memory for values */
	  
	  E = (double *)Mem(MEM_ALLOC, NE, sizeof(double));
	  P = (double *)Mem(MEM_ALLOC, NE, sizeof(double));
		  
	  /* Reset fixed ratio */

	  BR = 1.0;

	  /* Read data */

	  for (n = 0; n < NE; n++)
	    {
	      /* Read energy */
	  
	      if (fscanf(fp, "%lf", &E[n]) < 0)
		Error(0, "Invalid format in isomeric branching data file");

	      /* Check energy */

	      if ((E[n] < 1E-12) || (E[n] > 1000.0))
		Error(0, "Invalid E %E in isomeric branching data file", E[n]);

	      /* Read probability */
	  
	      if (fscanf(fp, "%lf", &P[n]) < 0)
		Error(0, "Invalid format in isomeric branching data file");

	      /* Check probability */

	      if ((P[n] < 0.0) || (P[n] > 1.0))
		Error(0, "Invalid P %E in isomeric branching data file", P[n]);
	    }
	}
      else
	Error(0, "Invalid NE %ld in isomeric branching data file", NE);
      
      /* Put data */

      WDB[loc0 + IBR_LIST_ZAI] = (double)ZAI;
      WDB[loc0 + IBR_LIST_MT] = (double)MT;
      WDB[loc0 + IBR_LIST_NE] = (double)NE;
      WDB[loc0 + IBR_LIST_BR] = (double)BR;

      /* Check distribution */

      if (NE == 0)
	{
	  /* Reset pointers */

	  WDB[loc0 + IBR_LIST_PTR_EGRID] = NULLPTR;
	  WDB[loc0 + IBR_LIST_PTR_DATA] = NULLPTR;
	}
      else
	{
	  /* Make energy grid */

	  erg = MakeEnergyGrid(NE, 0, 0, -1, E, EG_INTERP_MODE_LIN);
	  WDB[loc0 + IBR_LIST_PTR_EGRID] = (double)erg;

	  /* Allocate memory for values */

	  ptr = ReallocMem(DATA_ARRAY, NE);
	  WDB[loc0 + IBR_LIST_PTR_DATA] = (double)ptr;

	  /* Copy data */

	  memcpy(&WDB[ptr], P, NE*sizeof(double));
	  
	  /* Free temporary arrays */

	  Mem(MEM_FREE, E);
	  Mem(MEM_FREE, P);
	}
    }

  fprintf(out, "OK.\n\n");
  
  /* Close file */
  
  fclose(fp);
}

/*****************************************************************************/
