/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processvr.c                                    */
/*                                                                           */
/* Created:       2011/05/15 (JLe)                                           */
/* Last modified: 2012/04/22 (JLe)                                           */
/* Version:       2.1.5                                                      */
/*                                                                           */
/* Description: Processes some variance reduction stuff                      */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessVR:"

/*****************************************************************************/

void ProcessVR()
{
  long msh, ptr, n0, n1, n2;

  /***************************************************************************/
  
  /****** Uniform fission source method **************************************/
  
  if ((long)RDB[DATA_UFS_MODE] != UFS_MODE_NONE)
    {
      /* Get pointer to mesh */

      msh = (long)RDB[DATA_UFS_PTR_SRC_MESH];
      CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

      /* Set boundaries if not already set */

      if (RDB[msh + MESH_MIN0] == -INFTY)
	WDB[msh + MESH_MIN0] = RDB[DATA_GEOM_MINX];

      if (RDB[msh + MESH_MAX0] == INFTY)
	WDB[msh + MESH_MAX0] = RDB[DATA_GEOM_MAXX];

      if (RDB[msh + MESH_MIN1] == -INFTY)
	WDB[msh + MESH_MIN1] = RDB[DATA_GEOM_MINY];

      if (RDB[msh + MESH_MAX1] == INFTY)
	WDB[msh + MESH_MAX1] = RDB[DATA_GEOM_MAXY];

      if (RDB[msh + MESH_MIN2] == -INFTY)
	WDB[msh + MESH_MIN2] = RDB[DATA_GEOM_MINZ];

      if (RDB[msh + MESH_MAX2] == INFTY)
	WDB[msh + MESH_MAX2] = RDB[DATA_GEOM_MAXZ];

      /* Get mesh size */

      n0 = (long)RDB[msh + MESH_N0];
      n1 = (long)RDB[msh + MESH_N1];
      n2 = (long)RDB[msh + MESH_N2];

      /* Check values */

      CheckValue(FUNCTION_NAME, "n0", "", n0, 1, 10000);
      CheckValue(FUNCTION_NAME, "n1", "", n1, 1, 10000);
      CheckValue(FUNCTION_NAME, "n2", "", n2, 1, 10000);

      /* Allocate memory for factors */
      
      ptr = ReallocMem(DATA_ARRAY, n0*n1*n2);
      WDB[DATA_UFS_PTR_FACTORS] = (double)ptr;
    }

  /***************************************************************************/
}

/*****************************************************************************/
