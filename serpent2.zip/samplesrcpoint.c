/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : samplesrcpoint.c                               */
/*                                                                           */
/* Created:       2011/03/02 (JLe)                                           */
/* Last modified: 2013/02/28 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Samples neutron source point                                 */
/*                                                                           */
/* Comments: - Toi cell-haku ei toimi ihan oikein sillä whereami palauttaa   */
/*             alimman cellin. Universumihakua ei oo edes tehty vielä.       */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SampleSrcPoint:"
#define MAX_SRC_RESAMPLE 1000000

/*****************************************************************************/

long SampleSrcPoint(long id, long np, long idx)
{
  long n, cell, mat, src, cell0, mat0, surf, lst, loc0, loc1, rea, ptr;
  long type, stp, part, npmin, npmax, idx0;
  unsigned long seed;
  double rnd, mu, x, y, z, u, v, w, E, wgt, xmin, xmax, ymin, ymax, zmin, zmax;
  double t, dummy;

  /***************************************************************************/

  /***** Divide source to MPI tasks ******************************************/

#ifdef MPI_MODE1

  /* Check number of tasks */
  
  if (mpitasks > 1)
    {
      /* Calculate number of particles per task */

      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
	npmax = (long)(RDB[DATA_CRIT_POP]/((double)mpitasks));
      else
	npmax = (long)(RDB[DATA_SRC_POP]/((double)mpitasks));

      /* Calculate minimum and maximum particle index for this task */

      npmin = mpiid*npmax;
      
      if (mpiid < mpitasks - 1)
	npmax = (mpiid + 1)*npmax;
      else if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
	npmax = (long)RDB[DATA_CRIT_POP];
      else
	npmax = (long)RDB[DATA_SRC_POP];

      /* Check with task number */
      
      if ((np < npmin) || (np > npmax - 1))
	return -1;
    }

#endif

  /***************************************************************************/
  
  /***** Source sampling starts here *****************************************/

  /* Reset material pointer */

  mat = -1;

  /* Init random number sequence */
  
  seed = ReInitRNG(idx);
  
  /* Put seed in private data */
  
  ptr = (long)RDB[DATA_PTR_RNG_SEED];
  PutPrivateData(ptr, seed, id);

  /* Reset time */

  t = 0.0;
  
  /* Check if souce definition exist */

  if ((src = (long)RDB[DATA_PTR_SRC0]) < VALID_PTR)
    {
      /***********************************************************************/

      /***** Default uniform fission source **********************************/

      /* Check mode */

      if ((long)RDB[DATA_SIMULATION_MODE] != SIMULATION_MODE_CRIT)
	Die(FUNCTION_NAME, "No source definition");
      
      /* Loop until neutron is in fissile material */

      for (n = 0; n < MAX_SRC_RESAMPLE; n++)
	{
	  /* Sample coordinates */
		  
	  x = RandF(id)*(RDB[DATA_GEOM_MAXX] - RDB[DATA_GEOM_MINX])
	    + RDB[DATA_GEOM_MINX];
	  y = RandF(id)*(RDB[DATA_GEOM_MAXY] - RDB[DATA_GEOM_MINY])
	    + RDB[DATA_GEOM_MINY];
		  
	  if ((long)RDB[DATA_GEOM_DIM] == 3)
	    z = RandF(id)*(RDB[DATA_GEOM_MAXZ] - RDB[DATA_GEOM_MINZ])
	      + RDB[DATA_GEOM_MINZ];
	  else
	    z = 0.0;
		
	  /* Find location */
	  
	  if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
	    {
	      /* Apply boundary conditions */

	      BoundaryConditions(&cell, &x, &y, &z, &u, &v, &w, -1.0, &dummy, 
				 id);

	      /* Check cell pointer */

	      CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);
		
	      /* Check if cell contains fissile material */

	      if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
		if (((long)RDB[mat + MATERIAL_OPTIONS] & OPT_FISSILE_MAT) ||
		    ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC))
		  {
		    /* Sample isotropic direction */
		    
		    IsotropicDirection(&u, &v, &w, id);

		    /* Energy from a maxwellian distribution */

		    E = MaxwellEnergy(1.2895, id);

		    /* Set weight to unity */

		    wgt = 1.0;

		    /* Break loop */

		    break;
		  }
	    }
	}
      
      /* Set type to neutron */

      type = PARTICLE_TYPE_NEUTRON;

      /* Check error */
      
      if (n == MAX_SRC_RESAMPLE)
	Error(0, "Unable to sample fission source - try explicit definition");
      
      /***********************************************************************/
    }
  else
    {
      /***** Source from user-defined distribution ***************************/

      /* Sample source definition */

      rnd = RandF(id);
      
      /* loop over sources */

      src = (long)RDB[DATA_PTR_SRC0];
      while (src > VALID_PTR)
	{
	  /* Compare to weight */
	  
	  if ((rnd = rnd - RDB[src + SRC_WGT]) < 0.0)
	    break;
	  
	  /* Next source definition */
	  
	  src = NextItem(src);
	}

      /* Check pointer */

      if (src < VALID_PTR)
	Die(FUNCTION_NAME, "Unable to sample source");
      
      /* NOTE: Tähän voisi lisätä sellasen moodin että noita arvotaan */
      /*       samalla todennäköisyydellä mutta eri painolla. */
      
      /* Set weight to unity */
      
      wgt = 1.0;

      /* Set type */

      type = (long)RDB[src + SRC_TYPE];

      /* Check */

      if ((type != PARTICLE_TYPE_NEUTRON) && (type != PARTICLE_TYPE_GAMMA))
	Die(FUNCTION_NAME, "Invalid particle type");
      
      /***********************************************************************/
      
      /***** Direction *******************************************************/
      
      /* Check if isotropic (this is set to INFTY in processsources.c) */
      
      if (RDB[src + SRC_U0] > 1.0)
	IsotropicDirection(&u, &v, &w, id);
      else
	{
	  /* Set values */
	  
	  u = RDB[src + SRC_U0];
	  v = RDB[src + SRC_V0];
	  w = RDB[src + SRC_W0];
	}
      
      /***********************************************************************/
      
      /***** Energy **********************************************************/

      /* Check source energy */
      
      if ((E = RDB[src + SRC_E]) > ZERO)
	{
	  /* Check particle type */

	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      /* Compare to upper boundary */
	      
	      if (E > RDB[DATA_NEUTRON_EMAX])
		Error(src, "Source energy above maximum (%1.2f MeV)", 
		      RDB[DATA_NEUTRON_EMAX]);
	      
	      /* Compare to lower boundary */
	      
	      if (E < RDB[DATA_NEUTRON_EMIN])
		Error(src, "Source energy below minimum (%1.2E MeV)", 
		      RDB[DATA_NEUTRON_EMIN]);
	    }
	  else
	    {
	      /* Compare to upper boundary */
	      
	      if (E > RDB[DATA_PHOTON_EMAX])
		Error(src, "Source energy above maximum (%1.2f MeV)", 
		      RDB[DATA_PHOTON_EMAX]);
	      
	      /* Compare to lower boundary */
	      
	      if (E < RDB[DATA_PHOTON_EMIN])
		Error(src, "Source energy below minimum (%1.2E MeV)", 
		      RDB[DATA_PHOTON_EMIN]);
	    }
	}
            
      /* Check type */
      
      if ((lst = (long)RDB[src + SRC_PTR_EBINS]) > VALID_PTR)
	{
	  /* Bin structure, sample bin */
	  
	  n = (long)(RandF(id)*(ListSize(lst) - 1.0)) + 1;
	  
	  /* Get bin pointers */
	  
	  loc0 = ListPtr(lst, n - 1);
	  loc1 = ListPtr(lst, n);
	  
	  /* Put weight */
	  
	  wgt = wgt*RDB[loc1 + SRC_EBIN_WGT];
	  
	  /* Sample energy between boundaries */
	  
	  E = RandF(id)*(RDB[loc1 + SRC_EBIN_EMAX] - RDB[loc0 + SRC_EBIN_EMAX])
	    + RDB[loc0 + SRC_EBIN_EMAX];
	}
      else if ((rea = (long)RDB[src + SRC_PTR_REA]) > VALID_PTR)
	{
	  /* Put incident energy */
	  
	  if ((E = RDB[src + SRC_E]) < ZERO)
	    E = 1.000001*RDB[rea + REACTION_EMIN];
	  
	  /* Init cosine (-1.0, 0.0 and 1.0 case dubious error) */
	  
	  mu = 0.5;
	  
	  /* Sample energy and direction */
	  
	  SampleENDFLaw(rea, -1, E, &E, &mu, id);
	  
	  /* Check if cosine is changed */
	  
	  if (mu != 0.5)
	    AziRot(mu, &u, &v, &w, id);
	}
      else if ((E = RDB[src + SRC_E]) < ZERO)
	E = 1.0;
      
      /***********************************************************************/

      /***** Photon from radioactive decay ***********************************/

      /* Reset material pointer */

      mat0 = -1;

      /* Check type */

      if (type == PARTICLE_TYPE_GAMMA)      
	{
	  /* Sample material, weight and energy */

	  mat0 = RadGammaSrc(src, &E, &wgt, id);

	  /* Sample isotropic direction */

	  if (mat0 > VALID_PTR)
	    IsotropicDirection(&u, &v, &w, id);
	}

      /***********************************************************************/
	  
      /***** Position ********************************************************/

      /* Override material and cell definition if material was given by */
      /* radioactive decay source */

      if (mat0 < VALID_PTR)
	{
	  /* Pointer to cell and material */
	  
	  cell0 = (long)RDB[src + SRC_PTR_CELL];
	  mat0 = (long)RDB[src + SRC_PTR_MAT];
	}
      else
	cell0 = -1;

      /* Re-sampling loop */
      
      for (n = 0; n < MAX_SRC_RESAMPLE; n++)
	{
	  /* Check type */

	  if ((long)RDB[src + SRC_PTR_USR] > VALID_PTR)
	    {
	      /* User-defined source routine */

	      UserSrc(src, &x, &y, &z, &u, &v, &w, &E, &wgt, &t, id);
	    }
 	  else if ((RDB[src + SRC_X0] > -INFTY) && 
		   (RDB[src + SRC_Y0] > -INFTY) &&
		   (RDB[src + SRC_Z0] > -INFTY))
	    {
	      /* Check material and cell pointers */

	      if (mat0 > VALID_PTR)
		Error(src, "Point source not allowed with material source");
	      else if (cell0 > VALID_PTR)
		Error(src, "Point source not allowed with cell source");

	      /* Point source, set coordinates */

	      x = RDB[src + SRC_X0];
	      y = RDB[src + SRC_Y0];
	      z = RDB[src + SRC_Z0];
	    }
	  else if ((surf = (long)RDB[src + SRC_PTR_SURF]) > VALID_PTR)
	    {
	      /* Sample point on surface */
	      
	      SurfaceSrc(src, surf, &x, &y, &z, &u, &v, &w, id);
	    }
	  else if ((long)RDB[src + SRC_READ_PTR_FILE] > VALID_PTR)
	    {
	      /* Read parameters from file (all variables are overriden) */

	      ReadSourceFile(src, &x, &y, &z, &u, &v, &w, &E, &wgt, &t);
	    }
	  else
	    {
	      /* Get boundaries */

	      if ((xmin = RDB[src + SRC_XMIN]) == -INFTY)
		xmin = RDB[DATA_GEOM_MINX];

	      if ((xmax = RDB[src + SRC_XMAX]) == INFTY)
		xmax = RDB[DATA_GEOM_MAXX];

	      if ((ymin = RDB[src + SRC_YMIN]) == -INFTY)
		ymin = RDB[DATA_GEOM_MINY];

	      if ((ymax = RDB[src + SRC_YMAX]) == INFTY)
		ymax = RDB[DATA_GEOM_MAXY];

	      if ((zmin = RDB[src + SRC_ZMIN]) == -INFTY)
		zmin = RDB[DATA_GEOM_MINZ];

	      if ((zmax = RDB[src + SRC_ZMAX]) == INFTY)
		zmax = RDB[DATA_GEOM_MAXZ];

	      /* Sample coordinates */
	      
	      x = RandF(id)*(xmax - xmin) + xmin;
	      y = RandF(id)*(ymax - ymin) + ymin;
	      
	      if ((long)RDB[DATA_GEOM_DIM] == 3)
		z = RandF(id)*(zmax - zmin) + zmin;
	      else
		z = 0.0;
	    }
	  
	  /* Check boundaries */

	  if ((x > RDB[src + SRC_XMAX]) || (x < RDB[src + SRC_XMIN]) ||
	      (y > RDB[src + SRC_YMAX]) || (y < RDB[src + SRC_YMIN]) ||
	      (z > RDB[src + SRC_ZMAX]) || (z < RDB[src + SRC_ZMIN]))
	    {
	      /* Not within boundaries */
	      
	      Die(FUNCTION_NAME, "Source point outside boundaries");
	    }

	  /* Check time cut-off */

	  if ((t >= RDB[DATA_TIME_CUT_TMIN]) && (t < RDB[DATA_TIME_CUT_TMAX]))
	    {
	      if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		{
		  /* Check cell */
		  
		  if ((cell0 > VALID_PTR) && (cell == cell0))
		    break;
		  
		  /* Get material pointer */
		  
		  mat = (long)RDB[cell + CELL_PTR_MAT];
		  
		  /* Check material */
		  
		  if ((mat0 > VALID_PTR) && (mat == mat0))
		    break;
		  
		  /* Check if only surface or point source is used */
		  
		  if ((cell0 < VALID_PTR) && (mat0 < VALID_PTR) &&
		      ((long)RDB[cell + CELL_TYPE] != CELL_TYPE_OUTSIDE))
		    break;
		  
		  /* Material may be renamed for burnup calculation */
		  
		  if (mat > VALID_PTR)
		    if ((mat = (long)RDB[mat + MATERIAL_DIV_PTR_PARENT]) > 
			VALID_PTR)
		      if ((mat0 > VALID_PTR) && (mat == mat0))
			break;
		}
	    }
	}
      
      /* Check failure */
      
      if (n == MAX_SRC_RESAMPLE)
	Error(0, "Source sampling failed because of low efficiency");

      /***********************************************************************/ 
    }

  /* Adjust minimum and maximum energy */

  if (type == PARTICLE_TYPE_NEUTRON)
    {
      if (E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	E = 1.000001*RDB[DATA_NEUTRON_EMIN];
      else if (E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	E = 0.999999*RDB[DATA_NEUTRON_EMAX];
    }
  else
    {
      if (E < 1.0000001*RDB[DATA_PHOTON_EMIN])
	E = 1.000001*RDB[DATA_PHOTON_EMIN];
      else if (E > 0.999999*RDB[DATA_PHOTON_EMAX])
	E = 0.999999*RDB[DATA_PHOTON_EMAX];
    }

  /* Check time (noi karsitaan jo tuolla ylempänä) */

  if (src > VALID_PTR)
    {
      /* Lower limit */

      if (t < RDB[DATA_TIME_CUT_TMIN])
	Error(src, "Source time %1.2E is below time cutoff %1.2E", t, 
	      RDB[DATA_TIME_CUT_TMIN]);

      /* Upper limit */

      if (t >= RDB[DATA_TIME_CUT_TMAX])
	Error(src, "Source time %1.2E is above time cutoff %1.2E", t, 
	      RDB[DATA_TIME_CUT_TMAX]);
    }

  /* Get particle from stack */

  part = FromStack(type, id);
  
  /* Put values */

  WDB[part + PARTICLE_X] = x;
  WDB[part + PARTICLE_Y] = y;
  WDB[part + PARTICLE_Z] = z;

  WDB[part + PARTICLE_U] = u;
  WDB[part + PARTICLE_V] = v;
  WDB[part + PARTICLE_W] = w;

  WDB[part + PARTICLE_E] = E;
  WDB[part + PARTICLE_WGT] = wgt;
  WDB[part + PARTICLE_T0] = t;
  WDB[part + PARTICLE_T] = t;
  WDB[part + PARTICLE_TD] = 0.0;
  WDB[part + PARTICLE_TT] = 0.0;

  WDB[part + PARTICLE_PTR_MAT] = (double)mat;
  WDB[part + PARTICLE_RNG_IDX] = (double)idx;
  WDB[part + PARTICLE_HISTORY_IDX] = (double)idx;

  /* Get fission matrix index */

  idx0 = FissMtxIndex(mat, id);

  /* Put fission matrix index */
  
  WDB[part + PARTICLE_FMTX_IDX] = (double)idx0;

  /* Check simulation mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      /* Score source rate for fission matrix */
      
      if (idx0 > -1)
	{
	  /* Pointer to matrix */
	  
	  ptr = (long)RDB[DATA_PTR_FMTX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  ptr = (long)RDB[ptr + FMTX_PTR_SRC];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  
	  /* Score total */
	  
	  AddBuf(wgt, 1.0, ptr, id, -1, 0, idx0);
	  
	  /* Score prompt (no delayed in source) */
	  
	  AddBuf(wgt, 1.0, ptr, id, -1, 1, idx0);
	}

      /* Check particle type */

      if (type == PARTICLE_TYPE_GAMMA)
	{
	  /* Score source rate */

	  stp = (long)RDB[RES_TOT_PHOTON_SRCRATE];  
	  CheckPointer(FUNCTION_NAME, "(stp)", DATA_ARRAY, stp);
	  AddBuf(1.0, wgt, stp, id, 0);
	}
      else
	{
	  /* Score source rate */

	  stp = (long)RDB[RES_TOT_NEUTRON_SRCRATE];
	  CheckPointer(FUNCTION_NAME, "(stp)", DATA_ARRAY, stp);
	  AddBuf(1.0, wgt, stp, id, 0);
	  
	  /* Score initial source weight */
	  
	  ptr = (long)RDB[RES_INI_SRC_WGT];
	  CheckPointer(FUNCTION_NAME, "(stp)", DATA_ARRAY, stp);
	  AddBuf(1.0, wgt, ptr, id, 0);
	  
	  /* Score source rate in fissile and non-fissile materials */
	  
	  if (mat > VALID_PTR)
	    {
	      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
		AddBuf(1.0, wgt, stp, id, 1);
	      else
		AddBuf(1.0, wgt, stp, id, 2);
	    }
	}
	
      /* Put MPI id */

      WDB[part + PARTICLE_MPI_ID] = (double)mpiid;

      /* Reset generation index */

      WDB[part + PARTICLE_GEN_IDX] = 0.0;

      /* Put particle in que */
      
      ToQue(part, id);
    }
  else if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
    {
      /* Add to simulated batch size (this is different from DATA_NBATCH in */
      /* MPI mode, and may be different for each parallel task) NOTE: tän   */
      /* voisi tehdä jotenkin fiksumminkin jos jossain vaiheessa katsotaan  */
      /* että miten noi historiat jaetaan eri taskeille. */

#ifdef OPEN_MP
#pragma omp atomic
#endif
      WDB[DATA_SIMUL_BATCH_SIZE]++;

      /* Put particle to bank */
      
      ToBank(part, id);
    }
  else
    Die(FUNCTION_NAME, "Invalid simulation mode");

  /* Return pointer */

  return part;
}

/*****************************************************************************/
