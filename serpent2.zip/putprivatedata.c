/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : putprivatedata.c                               */
/*                                                                           */
/* Created:       2011/11/11 (JLe)                                           */
/* Last modified: 2011/11/30 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Puts value in PRIVA data block                               */
/*                                                                           */
/* Comments: - Replaced by macro when not compiled in debug mode             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PutPrivateData:"

/*****************************************************************************/

#ifdef DEBUG 

void PutPrivateData(long ptr, double val, long id)
{
  long sz;

  /* Get size of data block */
  
  sz = (long)RDB[DATA_REAL_PRIVA_SIZE];
  
  /* Check pointer */

  if ((ptr < 0) || (ptr > sz - 1))
    Die(FUNCTION_NAME, "Pointer error");

  /* Check id */

  if ((id < 0) || (id > (long)RDB[DATA_OMP_MAX_THREADS] - 1))
    Die(FUNCTION_NAME, "Error in thread id");
    
  /* Put value */
  
  PRIVA[ptr + id*sz] = val;
}

#endif

/*****************************************************************************/
