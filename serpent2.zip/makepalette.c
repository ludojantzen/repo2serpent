/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : makepalette.c                                  */
/*                                                                           */
/* Created:       2011/03/27 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Creates palette for mesh plots                               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MakePalette:"

void MakePalette(long *r, long *g, long *b, long colors, long type)
{
  long n;
  double f1, f2, x0, x1;

  /* Check type */

  if (type == PALETTE_HOT)
    {
      /***********************************************************************/

      /***** Hot color palette ***********************************************/

      /* Loop over colors */

      for (n = 0; n < colors; n++)
	{
	  /* Linear factor */

	  f1 = ((double)n)/((double)colors - 1.0);
	  
	  /* Red */
	  
	  x0 = 0.00;
	  x1 = 1.00;
	  
	  if (f1 < x0)
	    f2 = 0.0;
	  else if (f1 > x1)
	    f2 = 1.0;
	  else
	    f2 = (f1 - x0)/(x1 - x0);
	  
	  /* Sin factor */

	  f2 = sin(0.5*PI*f2);

	  /* Color value */

	  r[n] = (long)(235.0*f2) + 20;
	  
	  /* Green */
	  
	  x0 = 0.33;
	  x1 = 1.00;
	  
	  if (f1 < x0)
	    f2 = 0.0;
	  else if (f1 > x1)
	    f2 = 1.0;
	  else
	    f2 = (f1 - x0)/(x1 - x0);
	  
	  /* Sin factor */

	  f2 = sin(0.5*PI*f2);
	  
	  /* Color value */

	  g[n] = (long)(255.0*f2);
	  
	  /* Blue */
	  
	  x0 = 0.66;
	  x1 = 1.00;
	  
	  if (f1 < x0)
	    f2 = 0.0;
	  else if (f1 > x1)
	    f2 = 1.0;
	  else
	    f2 = (f1 - x0)/(x1 - x0);
	  
	  /* Sin factor */

	  f2 = sin(0.5*PI*f2);
	  
	  /* Color value */

	  b[n] = (long)(255.0*f2);
	}

      /***********************************************************************/
    }
  else if (type == PALETTE_COLD)
    {
      /***********************************************************************/

      /***** Cold color palette **********************************************/

      /* Loop over colors */

      for (n = 0; n < colors; n++)
	{
	  /* Linear factor */

	  f1 = ((double)n)/((double)colors - 1.0);
	  
	  /* Red */
	  
	  x0 = 0.66;
	  x1 = 1.00;
	  
	  if (f1 < x0)
	    f2 = 0.0;
	  else if (f1 > x1)
	    f2 = 1.0;
	  else
	    f2 = (f1 - x0)/(x1 - x0);
	  
	  /* Sin factor */

	  f2 = sin(0.5*PI*f2);
	  
	  /* Color value */

	  r[n] = (long)(255.0*f2);

	  /* Green */
	  
	  x0 = 0.33;
	  x1 = 1.00;
	  
	  if (f1 < x0)
	    f2 = 0.0;
	  else if (f1 > x1)
	    f2 = 1.0;
	  else
	    f2 = (f1 - x0)/(x1 - x0);
	  
	  /* Sin factor */

	  f2 = sin(0.5*PI*f2);
	  
	  /* Color value */

	  g[n] = (long)(255.0*f2);

	  /* Blue */
	  
	  x0 = 0.00;
	  x1 = 1.00;
	  
	  if (f1 < x0)
	    f2 = 0.0;
	  else if (f1 > x1)
	    f2 = 1.0;
	  else
	    f2 = (f1 - x0)/(x1 - x0);
	  
	  /* Sin factor */

	  f2 = sin(0.5*PI*f2);

	  /* Color value */

 	  b[n] = (long)(235.0*f2) + 20;
	}

      /***********************************************************************/
    }
  else if (type == PALETTE_JET)
    {
      /***********************************************************************/

      /***** Cold color palette **********************************************/

      /* Loop over colors */

      for (n = 0; n < colors; n++)
	{
	  /* Linear factor */

	  f1 = ((double)n)/((double)colors - 1.0);

	  /* Red */

	  if (f1 <= 0.375)
	    f2 = 0.0;
	  else if (f1 <= 0.6250)
	    f2 = (f1 - 0.3750)/(0.6250 - 0.3750);
	  else if (f1 <= 0.8750)
	    f2 = 1.0;
	  else
	    f2 = 1.0 - (f1 - 0.8750)/(1.0 - 0.8750)*0.5;

	  f2 = (1.0 - cos(f2*PI))/2.0;
	  r[n] = (long)(255.0*f2);

	  /* Green */

	  if (f1 <= 0.1250)
	    f2 = 0.0;
	  else if (f1 <= 0.3750)
	    f2 = (f1 - 0.1250)/(0.3750 - 0.1250);
	  else if (f1 <= 0.6250)
	    f2 = 1.0;
	  else if (f1 <= 0.8750)
	    f2 = 1.0 - (f1 - 0.6250)/(0.8750 - 0.6250);
	  else 
	    f2 = 0.0;

	  f2 = (1.0 - cos(f2*PI))/2.0;
	  g[n] = (long)(255.0*f2);

	  /* Blue */

	  if (f1 <= 0.1250)
	    f2 = 0.5*f1/0.1250 + 0.5;
	  else if (f1 <= 0.3750)
	    f2 = 1.0;
	  else if (f1 <= 0.6250)
	    f2 = 1.0 - (f1 - 0.3750)/(0.6250 - 0.3750);
	  else 
	    f2 = 0.0;

	  f2 = (1.0 - cos(f2*PI))/2.0;
	  b[n] = (long)(255.0*f2);




#ifdef mmm

	  /* Linear factor */

	  f1 = ((double)n)/((double)colors - 1.0);

	  /* Red */

	  if (f1 <= 0.375)
	    f2 = 0.0;
	  else if (f1 <= 0.6250)
	    f2 = (f1 - 0.3750)/(0.6250 - 0.3750);
	  else if (f1 <= 0.8750)
	    f2 = 1.0;
	  else
	    f2 = 1.0 - (f1 - 0.8750)/(1.0 - 0.8750)*0.5;

	  r[n] = (long)(255.0*f2);

	  /* Green */

	  if (f1 <= 0.1250)
	    f2 = 0.0;
	  else if (f1 <= 0.3750)
	    f2 = (f1 - 0.1250)/(0.3750 - 0.1250);
	  else if (f1 <= 0.6250)
	    f2 = 1.0;
	  else if (f1 <= 0.8750)
	    f2 = 1.0 - (f1 - 0.6250)/(0.8750 - 0.6250);
	  else 
	    f2 = 0.0;

	  g[n] = (long)(255.0*f2);

	  /* Blue */

	  if (f1 <= 0.1250)
	    f2 = 0.5*f1/0.1250 + 0.5;
	  else if (f1 <= 0.3750)
	    f2 = 1.0;
	  else if (f1 <= 0.6250)
	    f2 = 1.0 - (f1 - 0.3750)/(0.6250 - 0.3750);
	  else 
	    f2 = 0.0;

	  b[n] = (long)(255.0*f2);

#endif

	}

      /***********************************************************************/
    }
 else if (type == PALETTE_BW)
    {
      /***********************************************************************/

      /***** Cold color palette **********************************************/

      /* Loop over colors */

      for (n = 0; n < colors; n++)
	{
	  /* Linear factor */

	  f1 = ((double)n)/((double)colors - 1.0);
	  
	  /* Put values */
	  
	  r[n] = (long)(255.0*f1);
	  g[n] = (long)(255.0*f1);
	  b[n] = (long)(255.0*f1);
	}

      /***********************************************************************/
    }
  else if (type == PALETTE_HOTCOLD)
    {
      /***********************************************************************/

      /***** Combined hot / cold palette *************************************/

      /* Number of colors */

      colors = (long)((double)colors/2.0);
      
      /* Make cold palette */
      
      MakePalette(r, g, b, colors, PALETTE_COLD);

      /* Make hot palette */
    
      MakePalette(&r[colors], &g[colors], &b[colors], colors, PALETTE_HOT);
      
      /***********************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Invalid palette type");
}

/*****************************************************************************/
