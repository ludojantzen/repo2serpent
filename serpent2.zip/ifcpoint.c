/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : ifcpoint.c                                     */
/*                                                                           */
/* Created:       2013/03/17 (JLe)                                           */
/* Last modified: 2013/04/08 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Retrieves material density factor and temperature at a point */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "IFCPoint:"

/*****************************************************************************/

void IFCPoint(long mat, double *f0, double *T0, long id)
{
  long loc0, loc1, msh, type, dim, ptr, lst, np, uni;
  double f, T, wgt, r, r2, d2, d, ex, w, x, y, z, t, dx, dy, dz;

  /* Check material pointer */

  if (mat < VALID_PTR)
    return;

  /* Check pointer to material-wise interface */

  if ((loc0 = (long)RDB[mat + MATERIAL_PTR_IFC]) > VALID_PTR)
    {
      /* Get pointer to root universe */
      
      uni = (long)RDB[DATA_PTR_ROOT_UNIVERSE];
      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

      /* Get interface type */
  
      type = (long)RDB[loc0 + IFC_TYPE];
    }
  else
    {
      /* Get collision universe */
      
      ptr = (long)RDB[DATA_PTR_COLLISION_UNI];
      uni = GetPrivateData(ptr, id);
      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

      /* Check pointer to universe-wise interface */

      if ((loc0 = (long)RDB[uni + UNIVERSE_PTR_IFC_FUEP]) < VALID_PTR)
	return;

      /* Put type */

      type = IFC_TYPE_FUEP;
    }

  /* Get coordinates */
		  
  ptr = RDB[uni + UNIVERSE_PTR_PRIVA_X];
  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
  x = GetPrivateData(ptr, id);
  
  ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Y];
  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
  y = GetPrivateData(ptr, id);

  ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Z];
  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
  z = GetPrivateData(ptr, id);

  /* Get time (TODO) */
  /*
  ptr = RDB[DATA_PTR_PRIVA_TIME];
  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
  t = GetPrivateData(ptr, id);
  */

  t = 0.0;

  /* Reset density factor and temperature */

  f = -1.0;
  T = -1.0;

  /* Check type */
  
  if (type == IFC_TYPE_PT_AVG)
    {
      /***********************************************************************/
      
      /***** Average of point-wise values ************************************/

      /* Get pointer to search mesh */
  
      msh = (long)RDB[loc0 + IFC_PTR_SEARCH_MESH];
      CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

      /* Get dimensions */
  
      dim = (long)RDB[loc0 + IFC_DIM];
          
      /* Reset mean density factor, temperature and weight */
	  
      f = 0.0;
      T = 0.0;
      wgt = 0.0;
      
      /* Get exclusion radius and square of radius */
      
      r = RDB[loc0 + IFC_EXCL_RAD];
      r2 = r*r;
      
      /* Get exponent */
      
      ex = RDB[loc0 + IFC_EXP];
      
      /* Get pointer to search mesh */
      
      if ((lst = MeshPtr(msh, x, y, z)) > VALID_PTR)
	lst = (long)RDB[lst];
      
      /* Loop over content */
      
      while (lst > VALID_PTR)
	{
	  /* Pointer to point */
	  
	  loc1 = (long)RDB[lst + SEARCH_MESH_CELL_CONTENT];
	  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);
	  
	  /* Get parameters */
	  
	  dx = x - RDB[loc1 + IFC_PT_X];
	  dy = y - RDB[loc1 + IFC_PT_Y];
	  dz = z - RDB[loc1 + IFC_PT_Z];
	  
	  /* Avoid compiler warning */
	  
	  d2 = -1.0;
	  
	  /* Calculate square distance */
	  
	  if (dim == 3)
	    d2 = dx*dx + dy*dy + dz*dz;
	  else if (dim == 2)
	    d2 = dx*dx + dy*dy;
	  else if (dim == 1)
	    d2 = dz*dz;
	  else
	    Die(FUNCTION_NAME, "Invalid dimension");

	  /* Compare to exclusion radius */
	  
	  if (d2 < r2)
	    {
	      /* Calculate distance */
	      
	      d = sqrt(d2);
	      
	      /* Calculate weight factor */

	      w = pow(d, ex);
	      CheckValue(FUNCTION_NAME, "w", "", w, 0.0, INFTY);
	      
	      /* Invert */

	      if (w < 1E-3)
		w = 1E+3;
	      else
		w = 1.0/w;

	      /* Add to values */

	      f = f + RDB[loc1 + IFC_PT_DF]*w;
	      T = T + RDB[loc1 + IFC_PT_TMP]*w;
	      wgt = wgt + w;
	    }
	  
	  /* Next */
	  
	  lst = NextItem(lst);
	}

      /* Calculate mean */
      
      if (wgt != 0.0)
	{
	  f = f/wgt;
	  T = T/wgt;
	}

      /***********************************************************************/
    }
  else if (type == IFC_TYPE_MESH)
    {
      /***********************************************************************/
      
      /***** Mesh distribution ***********************************************/

      /* Get pointer to mesh */
  
      msh = (long)RDB[loc0 + IFC_PTR_SEARCH_MESH];
      CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);
            
      /* Get pointer to mesh cell */
      
      if ((ptr = MeshPtr(msh, x, y, z)) > VALID_PTR)
	{
	  /* Get pointer to data */

	  loc1 = (long)RDB[ptr];
	  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);
	  
	  /* Get values */
	  
	  f = RDB[loc1 + IFC_MSH_DF];
	  T = RDB[loc1 + IFC_MSH_TMP];
	}

      /***********************************************************************/
    }
  else if (type == IFC_TYPE_FUNC)
    {
      /***********************************************************************/
      
      /***** User-defined functional dependence ******************************/

      /* Get number of parameters */

      np = (long)RDB[loc0 + IFC_FUNC_NP];

      /* Get pointer to parameters */

      ptr = (long)RDB[loc0 + IFC_FUNC_PTR_PARAM];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get density factor and temperature */

      UserIFC(mat, &f, &T, x, y, z, t, np, &RDB[ptr]);

      /***********************************************************************/
    }
  else if (type == IFC_TYPE_CGNS)
    {
      /***********************************************************************/
      
      /***** CGNS mesh *******************************************************/

      /* Find region */

      if ((loc1 = FindCGNSCell(loc0, x, y, z, id)) > VALID_PTR)
	{
	  /* Get density factor and temperature */
		  
	  f = RDB[loc1 + IFC_CGNS_DF];
	  T = RDB[loc1 + IFC_CGNS_TMP];
	}
      
      /***********************************************************************/
    }
  else if (type == IFC_TYPE_FUEP)
    {
      /***********************************************************************/
      
      /***** Interface to fuel performance codes *****************************/

      /* Loop over axial zones */

      loc1 = (long)RDB[loc0 + IFC_FUEP_PTR_AX];
      while (loc1 > VALID_PTR)
	{
	  /* Check 2D */

	  if((long)RDB[DATA_GEOM_DIM] == 2)
	    break;

	  /* Compare coordinates */

	  if ((z >= RDB[loc1 + IFC_FUEP_AX_ZMIN]) &&
	      (z < RDB[loc1 + IFC_FUEP_AX_ZMAX]))
	    break;

	  /* Next */

	  loc1 = NextItem(loc1);
	}

      /* Check pointer */

      if (loc1 < VALID_PTR)
	return;

      /* Calculate square radius */

      r2 = x*x + y*y;

      /* Loop over radial zones */
      
      loc1 = (long)RDB[loc1 + IFC_FUEP_AX_PTR_RAD];
      while (loc1 > VALID_PTR)
	{
	  /* Compare radii */

	  if (r2 < RDB[loc1 + IFC_FUEP_RAD_HOT_R2])
	    break;

	  /* Next region */

	  loc1 = NextItem(loc1);
	}

      /* Check pointer */

      if (loc1 < VALID_PTR)
	return;

      /* Set density factor and temperature */

      f = RDB[loc1 + IFC_FUEP_RAD_DF];
      T = RDB[loc1 + IFC_FUEP_RAD_TEMP];

      /***********************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Invalid interface type");

  /* Put density factor */

  *f0 = f;

  /* Check temperature */

  if (T < ZERO)
    {
      /* Use ETTM minimum */

      T = RDB[mat + MATERIAL_ETTM_TMIN];
      CheckValue(FUNCTION_NAME, "mat", "", T, ZERO, 1E+12);      
    }

  /* Put temperature */

  *T0 = T;
}

/*****************************************************************************/
