/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : tmpmajorants.c                                 */
/*                                                                           */
/* Created:       2013/02/06 (JLe)                                           */
/* Last modified: 2013/02/07 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Calculates / updates majorant cross sections needed for      */
/*              DBRC and ETTM.                                               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "TmpMajorants:"

/*****************************************************************************/

void TmpMajorants()
{
  long nuc, rea, ptr, i0, ne, n, i, min0, max0;
  const double *E0, *xs0;
  double *xs1, *min, *max, T0, T1, awr, ar, f, maj, maj0;

  fprintf(out, "\nAdjusting majorant temperatures:\n\n");

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Get reaction pointer and temperatures */

      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DBRC)
	{
	  rea = (long)RDB[nuc + NUCLIDE_PTR_ELAXS];
	  T0 = RDB[nuc + NUCLIDE_XS_TEMP];
	  T1 = RDB[nuc + NUCLIDE_DBRC_MAX_TEMP];

	  /* Check ETTM flag */

	  if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_ETTM)
	    Die(FUNCTION_NAME, "Both DBRC and ETTM flags set");
	}
      else if (((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_ETTM) &&
	       ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_DECAY))
	{
	  rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
	  T0 = RDB[nuc + NUCLIDE_ETTM_MIN_TEMP];
	  T1 = RDB[nuc + NUCLIDE_ETTM_MAX_TEMP];

	  /* Check DBRC flag */

	  if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DBRC)
	    Die(FUNCTION_NAME, "Both DBRC and ETTM flags set");
	}
      else
	T1 = RDB[nuc + NUCLIDE_MAJORANT_TEMP];
      
      /* Check if majorant is already at correct temperature */
      
      if (T1 == RDB[nuc + NUCLIDE_MAJORANT_TEMP]) 
	{
	  /* Pointer to next */
	  
	  nuc = NextItem(nuc);
	  
	  /* Cycle loop */
	  
	  continue;
	}

      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DBRC)
	fprintf(out, "Nuclide %10s DBRC majorant to %1.0fK...\n", 
		GetText(nuc + NUCLIDE_PTR_NAME), T1);
      else
	fprintf(out, "Nuclide %10s ETTM majorant to %1.0fK...\n", 
		GetText(nuc + NUCLIDE_PTR_NAME), T1);

      /* Check lower temperature */

      if (T0 != RDB[nuc + NUCLIDE_XS_TEMP])
	Die(FUNCTION_NAME, "Incorrect XS temperature");

      /***********************************************************************/

      /***** Get cross sections and energy grid in arrays ********************/

      /* Check pointer */

      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

      /* Get first energy point and number of points */

      i0 = (long)RDB[rea + REACTION_XS_I0];
      ne = (long)RDB[rea + REACTION_XS_NE];

      /* Get cross section array */

      ptr = (long)RDB[rea + REACTION_PTR_XS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      xs0 = &RDB[ptr];

      /* Get pointer to energy grid */

      ptr = (long)RDB[rea + REACTION_PTR_EGRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get energy array */

      ptr = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      E0 = &RDB[ptr + i0];

      /* Get majorant reaction */

      ptr = (long)RDB[rea + REACTION_PTR_TMP_MAJORANT];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Pointer to cross section array */

      ptr = (long)RDB[ptr + REACTION_PTR_XS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      xs1 = &WDB[ptr];

      /* Get work arrays for limits */

      min = WorkArray(DATA_PTR_WORK_GRID1, PRIVA_ARRAY, ne, 0);
      max = WorkArray(DATA_PTR_WORK_GRID2, PRIVA_ARRAY, ne, 0);

      /***********************************************************************/

      /***** Equal temperatures **********************************************/

      if (T0 == T1)
	{
	  /* Copy data */

	  memcpy(xs1, xs0, ne*sizeof(double));

	  /* Update majorant temperature */

	  WDB[nuc + NUCLIDE_MAJORANT_TEMP] = T1;

	  /* Pointer to next nuclide */
	  
	  nuc = NextItem(nuc);
	  
	  /* Cycle loop */
	  
	  continue;
	}

      /***********************************************************************/
      
      /***** Generate limits *************************************************/

      /* Get atomic weight ratio */
      
      awr = RDB[nuc + NUCLIDE_AWR];

      /* Check mode */

      if (1 != 2)
	{
	  /*******************************************************************/

	  /***** Dagan's DBRC limits *****************************************/

	  /* AWR/kT */

	  ar = awr/(T1 - T0)/KELVIN;	  

	  /* Loop over energy grid */

	  for (n = 0; n < ne; n++)
	    {
	      /* Calculate factor */
     
	      f = 4.0/sqrt(ar*E0[n]);

	      /* Calculate minimum energy */

	      if (E0[n] < 16.0/ar)
		min[n] = E0[0];
	      else
		min[n] = E0[n]*(1.0 - f)*(1.0 - f);
	      
	      /* Calculate maximum energy */

	      max[n] = E0[n]*(1.0 + f)*(1.0 + f);

	      /* Check grid boundaries */

	      if (min[n] < E0[0])
		min[n] = E0[0];
	      if (max[n] > E0[ne - 1])
		max[n] = E0[ne - 1];

	      /* Check */

	      CheckValue(FUNCTION_NAME, "E", "", E0[n], min[n], max[n]);
	    }

	  /*******************************************************************/
	}
      else
	{
	  /*******************************************************************/

	  /***** New limits **************************************************/

	  /*******************************************************************/
	}

      /***********************************************************************/

      /***** Calculate indexes from limits ***********************************/

      /* Calculate indexes for lower limit */

      n = 0;
      for (i = 0; i < ne; i++)
	{
	  while(E0[n] < min[i])
	    n++;
	  
	  /* Check minimum, maximum and interval */

	  if (n == 0)
	    min[i] = 0.0;
	  else if (n > ne - 1)
	    Die(FUNCTION_NAME, "Error");
	  else
	    {
	      /* Check interval */

	      CheckValue(FUNCTION_NAME, "min", "", min[i], E0[n - 1], E0[n]);

	      /* Put index */
	      
	      if (n - 1 > i - 2)
		min[i] = (double)(i - 1);
	      else
		min[i] = (double)(n - 1);
	    }
	}

      /* Calculate indexes for upper */

      n = 0;
      for (i = 0; i < ne; i++)
	{
	  while(E0[n] < max[i])
	    n++;
	  
	  /* Check minimum, maximum and interval */

	  if (n == 0)
	    Die(FUNCTION_NAME, "Error");
	  else if (n > ne - 1)
	    Die(FUNCTION_NAME, "Error");
	  else
	    {
	      /* Check interval */
	      
	      CheckValue(FUNCTION_NAME, "min", "", max[i], E0[n - 1], E0[n]);

	      /* Put index */

	      if (n < i + 1)
		max[i] = (double)(i + 1);
	      else
		max[i] = (double)n;
	    }
	}

      /***********************************************************************/

      /***** Determine continuous-energy majorants ***************************/

      /* OpenMP parallel block */
  
#ifdef OPEN_MP
#pragma omp parallel private(n, maj, i, min0, max0, maj0)
#endif
      {
	/* Reset previous */

	min0 = -1;
	max0 = -1;
	maj0 = -1.0;

	/* Loop over energy grid */

#ifdef OPEN_MP
#pragma omp for 
#endif	  
	for (n = 0; n < ne; n++)
	  {
	    /* Reset value */

	    maj = 0.0;

	    /* Check if interval has changed */

	    if (((long)min[n] != min0) || ((long)max[n] != max0))
	      {
		/* Loop over interval */
	    	    
		maj0 = -1.0;
		for (i = (long)min[n]; i < (long)max[n]; i++)
		  if (xs0[i] > maj0)
		    maj0 = xs0[i];

		/* Compare to majorant */

		if (maj0 > maj)
		  maj = maj0;

		/* Set new limits */

		min0 = (long)min[n];
		max0 = (long)max[n];

		/* Check */

		if (max0 - min0 < 2)
		  Die(FUNCTION_NAME, "Error");
	      }
	    else if (maj0 > maj)
	      maj = maj0;

	    /* Make potential correction */
	    
	    maj = maj*PotCorr(nuc, E0[n], T1*KELVIN);
	    
	    /* Check value */
	    
	    CheckValue(FUNCTION_NAME, "maj", "", maj, xs0[n], INFTY);
	    
	    /* Put value */
	    
	    xs1[n] = maj;
	  }
      }

      /* Update majorant temperature */

      WDB[nuc + NUCLIDE_MAJORANT_TEMP] = T1;

      /***********************************************************************/

      /* Next nuclide */

      nuc = NextItem(nuc);
    }
}

/*****************************************************************************/
