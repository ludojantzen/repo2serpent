/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : clearmicrogroupxs.c                            */
/*                                                                           */
/* Created:       2013/03/04 (JLe)                                           */
/* Last modified: 2013/04/16 (JLe)                                           */
/* Version:       2.1.14                                                     */
/*                                                                           */
/* Description: Resets micro-group cross sections needed for B1 and P1       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ClearMicroGroupXS:"

/*****************************************************************************/

void ClearMicroGroupXS()
{
  long ptr, nmg, gcu, adf, n, m;

  /* Check active cycle */
  
  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP])
    return;

  /* Check if group constants are generated */

  if((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;
  
  /* Check micro-group mode */
  
  if (((long)RDB[DATA_SIMULATION_COMPLETED] == NO) && 
      ((long)RDB[DATA_MICRO_CALC_MODE] == MICRO_CALC_MODE_END))
    return;
  else if (((long)RDB[DATA_SIMULATION_COMPLETED] == YES) && 
	   ((long)RDB[DATA_MICRO_CALC_MODE] == MICRO_CALC_MODE_CYCLE))
    return;

  /* Get pointer to micro-group structure */
  
  ptr = (long)RDB[DATA_MICRO_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(ptr1)", DATA_ARRAY, ptr);

  /* Number of micro- and macro-groups */

  nmg = (long)RDB[ptr + ENERGY_GRID_NE] - 1;

  /* Loop over universes */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Get micro-group reaction rates */

      ptr = (long)RDB[gcu + GCU_MICRO_FLX];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_FISS_FLX];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_TOT];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_FISS];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_ABS];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_NSF];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_CHIT];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_CHIP];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_CHID];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));
    
      /* Scattering matrixes */

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT0];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP0];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT1];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP1];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT2];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP2];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT3];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP3];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT4];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP4];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT5];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP5];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT6];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP6];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATT7];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      ptr = (long)RDB[gcu + GCU_MICRO_SCATTP7];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      /* Check poison calculation */

      if ((long)RDB[DATA_OPTI_POISON_CALC] == YES)
	{
	  ptr = (long)RDB[gcu + GCU_MICRO_I135_YIELD];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_XE135_YIELD];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_PM149_YIELD];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_SM149_YIELD];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_I135_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_XE135_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_PM149_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_SM149_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));

	  ptr = (long)RDB[gcu + GCU_MICRO_I135_MACRO_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_XE135_MACRO_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_PM149_MACRO_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_SM149_MACRO_ABS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*sizeof(double));
	}

      /* Discontinuity factors  */

      if ((adf = (long)RDB[gcu + GCU_PTR_ADF]) > VALID_PTR)
	{
	  /* Get number of vertices and corners */

	  n = (long)RDB[adf + ADF_NSURF];
	  m = (long)RDB[adf + ADF_NCORN];

	  ptr = (long)RDB[gcu + GCU_MICRO_ADF_SURF_FLUX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*n*sizeof(double));

	  ptr = (long)RDB[gcu + GCU_MICRO_ADF_CORN_FLUX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*m*sizeof(double));
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_ADF_CELL_FLUX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*n*sizeof(double));

	  ptr = (long)RDB[gcu + GCU_MICRO_ADF_IN_CURR];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*n*sizeof(double));

	  ptr = (long)RDB[gcu + GCU_MICRO_ADF_OUT_CURR];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  memset(&RES2[ptr], 0.0, nmg*n*sizeof(double));
	}

      /* Next universe */
      
      gcu = NextItem(gcu);
    }
}

/*****************************************************************************/
