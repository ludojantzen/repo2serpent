/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : nearestboundary.c                              */
/*                                                                           */
/* Created:       2010/10/10 (JLe)                                           */
/* Last modified: 2013/04/05 (VVa)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Finds distance to the nearest boundary surface               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NearestBoundary:"

/*****************************************************************************/

double NearestBoundary(long id)
{
  long lvl0, lvl, reg, cell, pbd, pbl, surf, type, n, np, ptr, loc0, ltype;
  long uni, prev;
  double min, d, x, y, z, u, v, w, r2, params[MAX_SURFACE_PARAMS];

  /* Reset minimum distance */

  min = INFTY;

  /* Pointer to first level */

  lvl0 = (long)RDB[DATA_PTR_LVL0];
  CheckPointer(FUNCTION_NAME, "(lvl0)", DATA_ARRAY, lvl0);

  /* Loop over levels */

  while (lvl0 > VALID_PTR)
    {
      /* Pointer to private data */

      lvl = (long)RDB[lvl0 + LVL_PTR_PRIVATE_DATA];
      CheckPointer(FUNCTION_NAME, "(lvl)", PRIVA_ARRAY, lvl);
      
      /* Get coordinates */

      x = GetPrivateData(lvl + LVL_PRIV_X, id);
      y = GetPrivateData(lvl + LVL_PRIV_Y, id);
      z = GetPrivateData(lvl + LVL_PRIV_Z, id);

      /* Get direction cosines */

      u = GetPrivateData(lvl + LVL_PRIV_U, id);
      v = GetPrivateData(lvl + LVL_PRIV_V, id);
      w = GetPrivateData(lvl + LVL_PRIV_W, id);

      /* Get level type */

      ltype = (long)GetPrivateData(lvl + LVL_PRIV_TYPE, id);
      
      /* Check type */

      switch (ltype)
	{
	case UNIVERSE_TYPE_NEST:
	  {
	    /*****************************************************************/

	    /***** Nest ******************************************************/

	    /* Pointer to universe */

	    uni = (long)GetPrivateData(lvl + LVL_PRIV_PTR_UNIV, id);
	    CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

	    /* Check for fuel performance interface */
	    
	    if ((ptr = (long)RDB[uni + UNIVERSE_PTR_IFC_FUEP]) > VALID_PTR)
	      {
		/* Loop over axial zones */

		loc0 = (long)RDB[ptr + IFC_FUEP_PTR_AX];
		while (loc0 > VALID_PTR)
		  {
		    /* Check 2D */

		    if ((long)RDB[DATA_GEOM_DIM] == 2)
		      break;

		    /* Compare coordinates */
		    
		    if ((z >= RDB[loc0 + IFC_FUEP_AX_ZMIN]) &&
			(z < RDB[loc0 + IFC_FUEP_AX_ZMAX]))
		      {
			/* Distance to lower boundary */
			
			params[0] = RDB[loc0 + IFC_FUEP_AX_ZMIN];
			d = SurfaceDistance(-1, params, SURF_PZ, 1, x, y, z, 
					    u, v, w, id);

			/* Compare to minimum */

			if (d < min)
			  min = d;

			/* Distance to upper boundary */
			
			params[0] = RDB[loc0 + IFC_FUEP_AX_ZMAX];
			d = SurfaceDistance(-1, params, SURF_PZ, 1, x, y, z, 
					    u, v, w, id);

			/* Compare to minimum */

			if (d < min)
			  min = d;
			
			/* Break loop */

			break;
		      }
		    
		    /* Next */

		    loc0 = NextItem(loc0);
		  }
	      
		/* Check pointer */

		if (loc0 > VALID_PTR)
		  {
		    /* Calculate square radius */

		    r2 = x*x + y*y;
		    
		    /* Loop over radial zones */
		    
		    ptr = (long)RDB[loc0 + IFC_FUEP_AX_PTR_RAD];
		    while (ptr > VALID_PTR)
		      {
			/* Compare radii */
			
			if (r2 < RDB[ptr + IFC_FUEP_RAD_HOT_R2])
			  {
			    /* Distance to outer radius */
			
			    params[0] = 0.0;
			    params[1] = 0.0;
			    params[2] = sqrt(RDB[ptr + IFC_FUEP_RAD_HOT_R2]);
			    d = SurfaceDistance(-1, params, SURF_CYL, 3, 
						x, y, z, u, v, w, id);

			    /* Compare to minimum */

			    if (d < min)
			      min = d;

			    /* Previous zone */

			    if ((prev = PrevItem(ptr)) > VALID_PTR)
			      {
				/* Distance to inner radius */
				
				params[0] = 0.0;
				params[1] = 0.0;
				params[2] = 
				  sqrt(RDB[prev + IFC_FUEP_RAD_HOT_R2]);
				d = SurfaceDistance(-1, params, SURF_CYL, 3, 
						    x, y, z, u, v, w, id);
				
				/* Compare to minimum */
				
				if (d < min)
				  min = d;
			      }
			  }

			/* Next region */

			ptr = NextItem(ptr);
		      }

		    /* Compare to outermost surface */

		    if (ptr < VALID_PTR)
		      {
			/* Get pointer */

			ptr = (long)RDB[loc0 + IFC_FUEP_AX_PTR_RAD];
			ptr = LastItem(ptr);
			
			/* Distance to outer radius */
			
			params[0] = 0.0;
			params[1] = 0.0;
			params[2] = sqrt(RDB[ptr + IFC_FUEP_RAD_HOT_R2]);
			d = SurfaceDistance(-1, params, SURF_CYL, 3, 
					    x, y, z, u, v, w, id);
			
			/* Compare to minimum */
			
			if (d < min)
			  min = d;
		      }
		  }
	      }
	    else
	      {
		/* Pointer to nest region */

		reg = (long)GetPrivateData(lvl + LVL_PRIV_PTR_NEST_REG, id);
		CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);
		
		/* First surface */
		
		if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_IN]) > VALID_PTR)
		  {
		    /* Get type */
		    
		    type = (long)RDB[surf + SURFACE_TYPE];
		    
		    /* Get number of parameters */
		    
		    np = (long)RDB[surf + SURFACE_N_PARAMS];
		    
		    /* Pointer to parameter list */
		    
		    ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
		    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		    
		    /* Get distance */
		
		    d = SurfaceDistance(-1, &RDB[ptr], type, np, x, y, z, 
					u, v, w, id);
		    
		    /* Compare to minimum */
		    
		    if (d < min)
		      min = d;	      
		  }
		
		/* Second surface */
		
		if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_OUT]) > VALID_PTR)
		  {
		    /* Get type */
		    
		    type = (long)RDB[surf + SURFACE_TYPE];
		    
		    /* Get number of parameters */
		    
		    np = (long)RDB[surf + SURFACE_N_PARAMS];
		    
		    /* Pointer to parameter list */
		    
		    ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
		    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		    
		    /* Get distance */
		    
		    d = SurfaceDistance(-1, &RDB[ptr], type, np, x, y, z, 
					u, v, w, id);
		    
		    /* Compare to minimum */
		    
		    if (d < min)
		      min = d;	      
		  }
	      }
	    
	    /* Break case */

	    break;
	    
	    /*****************************************************************/
	  }      

	case UNIVERSE_TYPE_LATTICE:
	  {
	    /*****************************************************************/

	    /***** Lattice ***************************************************/

	    /* Check pointer to lattice */

	    if ((long)GetPrivateData(lvl + LVL_PRIV_PTR_LAT, id) < VALID_PTR)
	      Die(FUNCTION_NAME, "No lattice pointer");

	    /* Get surface type */
	    
	    type = (long)GetPrivateData(lvl + LVL_PRIV_LAT_SURF_TYPE, id);

	    /* Get number of surface parameters */
	    
	    np = (long)GetPrivateData(lvl + LVL_PRIV_LAT_SURF_NP, id);
	    
	    /* Get parameters (noiden kerrointen pit�� olla per�kk�in) */

	    for (n = 0; n < np; n++)
	      params[n] = GetPrivateData(lvl + LVL_PRIV_LAT_SURF_C0 + n, id);

	    /* Get distance */

	    d = SurfaceDistance(-1, params, type, np, x, y, z, u, v, w, id);

	    /* Compare to minimum */

	    if (d < min)
	      min = d;	      

	    /* Check if type is vertical stack */

	    if (type == SURF_PZ)
	      {
		/* Put parameter for second surface */

		params[0] = GetPrivateData(lvl + LVL_PRIV_LAT_SURF_C1, id);
		
		/* Get distance */

		d = SurfaceDistance(-1, params, type, np, x, y, z, u, v, w, id);
		
		/* Compare to minimum */
		
		if (d < min)
		  min = d;	      
	      }

	    /* Break case */

	    break;

	    /*****************************************************************/
	  }
	  
	case UNIVERSE_TYPE_CELL:
	  {
	    /*****************************************************************/

	    /***** Cell ******************************************************/
	
	    /* Pointer to cell */
	
	    cell = (long)GetPrivateData(lvl + LVL_PRIV_PTR_CELL, id);
	    CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

	    /* Pointer to surface list */

	    loc0 = (long)RDB[cell + CELL_PTR_SURF_LIST];
	    CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	    /* Loop over list */

	    while ((surf = (long)RDB[loc0++]) > VALID_PTR)
	      {
		/* Get type */

		type = (long)RDB[surf + SURFACE_TYPE];
		
		/* Check infinite */

		if (type != SURF_INF)
		  {
		    /* Get number of parameters */
		
		    np = (long)RDB[surf + SURFACE_N_PARAMS];
		    
		    /* Pointer to parameter list */
		    
		    ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
		    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		    
		    /* Get distance */
		    
		    d = SurfaceDistance(surf, &RDB[ptr], type, np, x, y, z, 
					u, v, w, id);
		    
		    /* Compare to minimum */
		    
		    if (d < min)
		      min = d;
		  }	      
	      }

	    /* Break case */
	    
	    break;
	    
	    /*****************************************************************/
	  }      

	case UNIVERSE_TYPE_PBED:
	  {
	    /*****************************************************************/

	    /***** Explicit stochastic geometry ******************************/

	    /* Check direct pointer to pebble */

	    if ((pbl = (long)GetPrivateData(lvl + LVL_PRIV_PTR_PEBBLE, id)) > 
		VALID_PTR)
	      {
		/* Put surface parameters */

		params[0] = RDB[pbl + PEBBLE_X0];
		params[1] = RDB[pbl + PEBBLE_Y0];
		params[2] = RDB[pbl + PEBBLE_Z0];
		params[3] = RDB[pbl + PEBBLE_RAD];

		if ((x - params[0])*(x - params[0]) + 
		    (y - params[1])*(y - params[1]) + 
		    (z - params[2])*(z - params[2]) > params[3]*params[3])
		  Die(FUNCTION_NAME, "not inside");

		/* Get distance */

		d = SurfaceDistance(-1, params, SURF_SPH, 4, x, y, z, 
				    u, v, w, id);
		CheckValue(FUNCTION_NAME, "d", "", d, 0.0, 2.0*params[3]);
	      }
	    else
	      {
		/* Pointer to PB geometry */
	
		pbd = (long)GetPrivateData(lvl + LVL_PRIV_PTR_PBED, id);
		CheckPointer(FUNCTION_NAME, "(pbd)", DATA_ARRAY, pbd);
		
		/* Get minimum distance */
		
		d = NearestPBSurf(pbd, x, y, z, u, v, w, id);
	      }

	    /* Compare to minimum */
	    
	    if (d < min)
	      min = d;
	    
	    /* Break case */
	    
	    break;

	    /*****************************************************************/
	  }

	default:
	  {
	    /* Invalid type */
	    
	    Die(FUNCTION_NAME, "Invalid universe type");
	  }
	}
      
      /* Break loop if level is last */
      
      if ((long)GetPrivateData(lvl + LVL_PRIV_LAST, id) == YES)
      	break;

      /* Next level */

      lvl0 = NextItem(lvl0);
    }

  /* Return shortest distance */

  return min;
}

/*****************************************************************************/
