/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : allocinterfacestat.c                           */
/*                                                                           */
/* Created:       2012/09/11 (JLe)                                           */
/* Last modified: 2013/04/03 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Sets up stats and associated structures for multi-physics    */
/*              interfaces.                                                  */
/*                                                                           */
/* Comments: - Separeted from processinterface.c, because routine needs      */
/*             material fissile flags to be set.                             */
/*                                                                           */
/*           - Polttoaineinterfacen aksiaalijako lisätty 3.4.2013            */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "AllocInterfaceStat:"

/*****************************************************************************/

void AllocInterfaceStat()
{
  long loc0, loc1, ptr, nz, nr, n;
  double zmin, zmax, z, rmin, rmax, r2;

  /* Loop over interfaces */

  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Check output flag */
      
      if ((long)RDB[loc0 + IFC_CALC_OUTPUT] == YES)
	{
	  /* Check type */

	  if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_FUEP)
	    {
	      /***************************************************************/

	      /***** Interface for fuel performance codes ********************/

	      /* Loop over pins */

	      loc1 = (long)RDB[loc0 + IFC_PTR_FUEP];
	      while (loc1 > VALID_PTR)
		{
		  /* Get number of radial and axial zones */

                  if ((nr = (long)RDB[loc1 + IFC_FUEP_OUT_NR]) < 1)
                    Die(FUNCTION_NAME, "Error in number of radial zones");
                  if ((nz = (long)RDB[loc1 + IFC_FUEP_OUT_NZ]) < 1)
                    Die(FUNCTION_NAME, "Error in number of radial zones");

		  /* Allocate memory for stats */

		  ptr = NewStat("INTERFACE_POWER", 2, nz, nr);
                  WDB[loc1 + IFC_FUEP_PTR_POWER] = (double)ptr;      
		  
		  /* Put axial limits if not given */

		  if ((long)RDB[loc1 + IFC_FUEP_OUT_PTR_Z] < VALID_PTR)
		    {
		      /* Allocate memory for axial zones */

		      ptr = ReallocMem(DATA_ARRAY, nz + 1);
		      WDB[loc1 + IFC_FUEP_OUT_PTR_Z] = (double)ptr;

		      /* Get limits */

		      zmin = RDB[loc1 + IFC_FUEP_OUT_ZMIN];
		      zmax = RDB[loc1 + IFC_FUEP_OUT_ZMAX];
		      
		      /* Swap boundaries if necessary */

		      if (zmin > zmax)
			{
			  z = zmin;
			  zmin = zmax;
			  zmax = z;
			}

		      /* Put values */

		      for (n = 0; n < nz + 1; n++)
			{
			  z = ((double)n)/((double)(nz))*(zmax - zmin) + zmin;
			  WDB[ptr++] = z;
			}		      
		    }

		  /* Put radial limits if not given */

		  if ((long)RDB[loc1 + IFC_FUEP_OUT_PTR_R2] < VALID_PTR)
		    {
		      /* Allocate memory for radial zones */

		      ptr = ReallocMem(DATA_ARRAY, nr + 1);
		      WDB[loc1 + IFC_FUEP_OUT_PTR_R2] = (double)ptr;

		      /* Get limits */

		      rmin = RDB[loc1 + IFC_FUEP_OUT_RMIN];
		      rmax = RDB[loc1 + IFC_FUEP_OUT_RMAX];
		      
		      /* Swap boundaries if necessary */

		      if (rmin > rmax)
			{
			  r2 = rmin;
			  rmin = rmax;
			  rmax = r2;
			}

		      /* Put values */

		      for (n = 0; n < nr + 1; n++)
			{
			  r2 = sqrt(((double)(n))/((double)nr))*
			    (rmax - rmin) + rmin;
			  WDB[ptr++] = r2*r2;
			}
		    }

		  /* Next pin */

		  loc1 = NextItem(loc1);
		}

	      /***************************************************************/
	    }
	  else if ((long)RDB[loc0 + IFC_TYPE] != IFC_TYPE_CGNS)
	    {
	      /***************************************************************/

	      /***** Non-CGNS interfaces *************************************/
	      
	      /* Find interface regions for this interface */

	      FindInterfaceRegions(loc0, -1, -1, 0, 0.0, 0.0, 0.0, 0);

	      /* Sort output list by position */
	      
	      if ((loc1 = (long)RDB[loc0 + IFC_PTR_OUT]) > VALID_PTR)
		{
		  SortList(loc1, IFC_OUT_Y0, SORT_MODE_ASCEND);
		  SortList(loc1, IFC_OUT_X0, SORT_MODE_ASCEND);
		}

	      /* Reset number of regions */

	      n = 0;

	      /* Check pointer to score list */

	      if ((loc1 = (long)RDB[loc0 + IFC_PTR_SCORE]) > VALID_PTR)
		{
		  /* Sort list by region index */

		  SortList(loc1, IFC_SCORE_REG_IDX, SORT_MODE_ASCEND);

		  /* Close */
		  
		  CloseList(loc1);

		  /* Loop over regions and set stat indexes */
		  
		  n = 0;
		  while (loc1 > VALID_PTR)
		    {
		      /* Put index */

		      WDB[loc1 + IFC_SCORE_STAT_IDX] = (double)(n++);

		      /* Next */

		      loc1 = NextItem(loc1);
		    }
		}

	      /* Put total number of score regions */

	      WDB[loc0 + IFC_STAT_NREG] = (double)n;

	      /* Allocate memory for results */

	      if (n > 0)
		{
		  /* Get number of axial zones (aikaisemmassa versiossa tän */
		  /* sallittiin olla nolla?) */

		  if ((nz = (long)RDB[loc0 + IFC_NZ]) < 1)
		    Die(FUNCTION_NAME, "Error in number of axial zones");
		  
		  /* Get number of radial zones */
		  
		  if ((nr = (long)RDB[loc0 + IFC_NR]) < 1)
		    Die(FUNCTION_NAME, "Error in number of radial zones");
		  
		  /* USe three-dimensional array */
		  
		  ptr = NewStat("INTERFACE_POWER", 3, n, nz, nr);
		  WDB[loc0 + IFC_PTR_STAT] = (double)ptr;      
		}
	      else
		{
		  /* No regions, reset output flag */
		  
		  WDB[loc0 + IFC_CALC_OUTPUT] = (double)NO;
		}
	      
	      /***************************************************************/
	    }
	  else if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_CGNS)
	    {
	      /***************************************************************/

	      /***** CGNS interface ******************************************/
	      
	      /* Loop over CGNS cells */
	      
	      n = 0;
	      loc1 = (long)RDB[loc0 + IFC_PTR_CGNS];
	      while (loc1 > VALID_PTR)
		{
		  /* Put index */

		  if ((long)RDB[loc1 + IFC_CGNS_STAT_IDX] > 0)
		    WDB[loc1 + IFC_CGNS_STAT_IDX] = (double)(n++);
		  else
		    WDB[loc1 + IFC_CGNS_STAT_IDX] = -1.0;

		  /* Next */
		  
		  loc1 = NextItem(loc1);
		}
	      
	      /* Put total number of score regions */
	      
	      WDB[loc0 + IFC_STAT_NREG] = (double)n;

	      /* Allocate memory for results */
		  
	      if (n > 0)
		{
		  /* Use one-dimensional array */

		  ptr = NewStat("INTERFACE_POWER", 1, n);
		  WDB[loc0 + IFC_PTR_STAT] = (double)ptr;      
		}
	      else
		{
		  /* No regions, reset output flag */
		  
		  WDB[loc0 + IFC_CALC_OUTPUT] = (double)NO;
		}

	      /***************************************************************/
	    }
	  else
	    Die(FUNCTION_NAME, "Invalid interface type");
	}

      /* Next interface */

      loc0 = NextItem(loc0);
    }
}

/*****************************************************************************/
