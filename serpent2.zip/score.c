/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : score.c                                        */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2013/04/23 (JLe)                                           */
/* Version:       2.1.14                                                     */
/*                                                                           */
/* Description: Scores general parameters needed for every calculation       */
/*                                                                           */
/* Comments: - Tästä on kommentoitu 2 returnia pois Dufekin stabiilia        */
/*             palamarutiinia varten (AIs:n koodia)                          */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Score:"

/*****************************************************************************/

void Score(long mat, long part, double flx, double x, double y, double z,
	   double u, double v, double w, double E, double wgt, double t,
	   double spd, double g, long id)
{
  long rea, ptr, prg, i, dng, n;
  double val, fiss, tot, fissE, lambda;

  /* Check input parameters */

  CheckPointer(FUNCTION_NAME, "(part)", DATA_ARRAY, part);
  CheckValue(FUNCTION_NAME, "x", "", x, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "y", "", y, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "z", "", z, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "cos", "", u*u+v*v+w*w - 1.0, -1E-5, 1E-5);
  CheckValue(FUNCTION_NAME, "flx", "", flx, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "E", "", E, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "wgt", "", wgt, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "t", "", t, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "spd", "", spd, ZERO, INFTY);
  
  /***************************************************************************/
  
  /***** Photon transport ****************************************************/

  /* Get particle type */

  if ((long)RDB[part + PARTICLE_TYPE] == PARTICLE_TYPE_GAMMA)
    {
      /* Flux */

      ptr = (long)RDB[RES_TOT_PHOTON_FLUX];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(flx, wgt, ptr, id, 0);

      /* Check material pointer */

      if (mat > VALID_PTR)
	{
	  /* Total reaction rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS]) > VALID_PTR)
	    if ((val = PhotonMacroXS(rea, E, id)*flx*g) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_PHOTON_RR];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		AddBuf(val, wgt, ptr, id, 0);
	      }

	  /* Photon heating reaction rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_HEATPHOTXS]) > VALID_PTR)
	    if ((val = PhotonMacroXS(rea, E, id)*flx*g) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_PHOTON_HEATRATE];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		AddBuf(val, wgt, ptr, id, 0);
	      }
	  
	  /* Score collision detector */
	  
	  ColDet(part, mat, flx, x, y, z, u, v, w, E, t, wgt, g, id);
	  
	  /* Score mesh */
	  
	  ScoreMesh(part, mat, flx, x, y, z, E, t, wgt, g, id);
	}

      /* Exit subroutine */

      return;
    }
  
  /***************************************************************************/

  /***** Score integral reaction rates ***************************************/

  /* Reset total and fission rate */

  tot = 0.0;
  fiss = 0.0;
  
  /* Flux */

  ptr = (long)RDB[RES_TOT_NEUTRON_FLUX];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(flx, wgt, ptr, id, 0);
  
  /* Check material pointer */

  if (mat > VALID_PTR)
    {
      /* Additional bins for burnable and non-burnable materials */
      
      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	i = 1;
      else
	i = 2;
      
      /* Flux in burnable and non-burnable materials */
      
      AddBuf(flx, wgt, ptr, id, i);
      
      /* Check implicit mode */
      
      if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == YES)
	{
	  /* Total reaction rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_TOTXS]) > VALID_PTR)
	    if ((tot = MacroXS(rea, E, id)*flx*g) >= 0.0)
	      {
		ptr = (long)RDB[RES_TOT_NEUTRON_RR];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		AddBuf(tot, wgt, ptr, id, 0);
	      }
	  
	  /* Capture rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_ABSXS]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx*g) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_CAPTRATE];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		AddBuf(val, wgt, ptr, id, 0);
		AddBuf(val, wgt, ptr, id, i);
	      }

	  /*  Fission energy */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSE]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx*g) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_IMP_FISSE];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		AddBuf(val, wgt, ptr, id, 0);
		AddBuf(val, wgt, ptr, id, i);
	      }
	  
	  /* Fission rates */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSXS]) > VALID_PTR)
	    if ((fiss = MacroXS(rea, E, id)*flx*g) > 0.0)
	      {
		/* Total */
		
		ptr = (long)RDB[RES_TOT_FISSRATE];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		AddBuf(fiss, wgt, ptr, id, 0);
		AddBuf(fiss, wgt, ptr, id, i);

		/* Delayed neutrons */

		if ((dng = (long)RDB[part + PARTICLE_DN_GROUP]) > 0)
		  {
		    /* Score fission rate */

		    ptr = (long)RDB[RES_ADJ_MEULEKAMP_BETA_EFF];
		    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		    AddBuf(fiss, wgt, ptr, id, 0);
		    AddBuf(fiss, wgt, ptr, id, dng);

		    /* Get decay constant */

		    lambda = RDB[part + PARTICLE_DN_LAMBDA];

		    /* Score lambda */
		    
		    ptr = (long)RDB[RES_ADJ_MEULEKAMP_LAMBDA];
		    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		    AddBuf(fiss*lambda, wgt, ptr, id, 0);
		    AddBuf(fiss*lambda, wgt, ptr, id, dng);
		  }

		/* Beta-eff using IFP */

		if ((prg = (long)RDB[part + PARTICLE_PTR_FISS_PROG]) > 0.0)
		  {
		    /* Loop over progenies */

		    for (n = 0; n < (long)RDB[DATA_IFP_CHAIN_LENGTH]; n++)
		      {
			/* Check pointer */
			
			CheckPointer(FUNCTION_NAME, "(prg)", DATA_ARRAY, prg);

			/* Get delayed neutron group */

			if ((dng = (long)RDB[prg + FISS_PROG_DN_GROUP]) > 0)
			  {
			    /* Score beta-eff */
			    
			    ptr = (long)RDB[RES_ADJ_IFP_BETA_EFF];
			    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, 
					 ptr);
			    
			    AddBuf(fiss, wgt, ptr, id, -1, 0, n);
			    AddBuf(fiss, wgt, ptr, id, -1, dng, n);

			    /* Get decay constant */

			    lambda = RDB[prg + FISS_PROG_LAMBDA];

			    /* Score lambda */
			    
			    ptr = (long)RDB[RES_ADJ_IFP_LAMBDA];
			    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, 
					 ptr);
			    
			    AddBuf(fiss*lambda, wgt, ptr, id, -1, 0, n);
			    AddBuf(fiss*lambda, wgt, ptr, id, -1, dng, n);
			  }
			
			/* Pointer to next */
			
			prg = NextItem(prg);
		      }
		  }
	      }
	  
	  /* Elastic scattering rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_ELAXS]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx*g) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_ELARATE];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		AddBuf(val, wgt, ptr, id, 0);
	      }
	  
	  /* Inelastic scattering production rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_INLPXS]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx*g) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_INLPRODRATE];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		AddBuf(val, wgt, ptr, id, 0);
	      }
	}
    }
  
  /* 1/v */

  ptr = (long)RDB[RES_TOT_RECIPVEL];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(flx/spd, wgt, ptr, id, 0);

  /***************************************************************************/

  /***** Score other stuff ***************************************************/
  /*
  if (tot < ZERO)
    return;
  */

  /* Reaction rates for uniform fission source method */

  ScoreUFS(flx, mat, wgt, x, y, z, E, g, id);

  /* Poisons */

  ScorePoison(flx, mat, E, wgt, g, id);

  /* Check if active cycle */

  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP])
    return;

  /* Score transmutation cross sections */

  ScoreTransmuXS(flx, mat, E, wgt, id);

  /* Check for corrector step and B1 mode. Removed for dev (AIs) */

#ifndef STAB_BURN

  if (((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) &&
      ((long)RDB[DATA_B1_BURNUP_CORR] == NO))
    return;

#endif

  /* Score group constant data (must be called before the check for */
  /* corrector calculation to get cross sections for B1). */

  ScoreGC(flx, mat, E, spd, wgt, g, id);

  /* Check for corrector step. Removed for dev. (AIs) */
 
#ifndef STAB_BURN

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP)
    return;

#endif

  /* Score collision detector */
  
  ColDet(part, mat, flx, x, y, z, u, v, w, E, t, wgt, g, id);
  
  /* Score adjoint (tää pitää siirtää collisioniin) */
  /*
    ScoreAdjoint(part, mat, rea, flx, x, y, z, u, v, w, E, t, wgt, id);
  */
  
  /* Check material pointer */
  
  if (mat > VALID_PTR)
    {
      /* Score mesh */
      
      ScoreMesh(part, mat, flx, x, y, z, E, t, wgt, g, id);
      
      /* Score temperature distribution */
      
      ScoreTemp(mat, flx, id, wgt);
      
      /* Get fission energy */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSE]) > VALID_PTR)
	if ((fissE = MacroXS(rea, E, id)*flx*g) > 0.0)
	  {
	    /* Score full-core power distribution */
	    
	    ScoreCPD(fissE, wgt, z, id);
	    
	    /* Score PB power distribution */
	    
	    ScorePB(fissE, wgt, id);
	    
	    /* Score power for multi-physics interface */
	    
	    ScoreInterfacePower(fissE, wgt, x, y, z, id);
	  }
    }

  /***************************************************************************/
}

/*****************************************************************************/
