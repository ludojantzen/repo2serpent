/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : leak.c                                         */
/*                                                                           */
/* Created:       2011/03/12 (JLe)                                           */
/* Last modified: 2012/10/25 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Handles leakage                                              */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Leak:"

/*****************************************************************************/

void Leak(long part, double x, double y, double z, double u, double v, 
	  double w, double E, double wgt, long id)
{
  long gcu, ptr, ntot, ng, ncol, type;

  /* Put particle back in stack */

  ToStack(part, id);

  /* Get particle type */

  type = (long)RDB[part + PARTICLE_TYPE];

  /* Score total leak rate */

  if (type == PARTICLE_TYPE_NEUTRON)
    ptr = (long)RDB[RES_TOT_NEUTRON_LEAKRATE];
  else
    ptr = (long)RDB[RES_TOT_PHOTON_LEAKRATE];

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(1.0, wgt, ptr, id, 0);

  /* Check active cycle and corrector step */

  if ((RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP]) ||
      (type == PARTICLE_TYPE_GAMMA) ||
      ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP))
    return;  

  /* Check for group constant calculation */

  if ((long)RDB[DATA_OPTI_GC_CALC] == YES)
    {
      /* Number of groups */

      ntot = (long)RDB[DATA_ERG_FG_NG];

      /* Get collision number */

      ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
      ncol = (long)GetPrivateData(ptr, id);
      
      /* Get pointer to GCU structure */
      
      gcu = TestValuePair(DATA_GCU_PTR_UNI, ncol, id);

      /* Get pointer to few-group structure */
  
      ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      
      /* Get few-group and universe indexes */

      if ((gcu > VALID_PTR) && ((ng = GridSearch(ptr, E)) > -1))
	{
	  /* Score few-group leakage */

	  ptr = (long)RDB[gcu + GCU_RES_FG_LEAK];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(1.0, wgt, ptr, id, 0);
	  AddBuf(1.0, wgt, ptr, id, ntot - ng);
	}
    }
}

/*****************************************************************************/
