/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processgc.c                                    */
/*                                                                           */
/* Created:       2011/06/10 (JLe)                                           */
/* Last modified: 2013/04/26 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Process data needed for group constant generation            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessGC:"

/*****************************************************************************/

void ProcessGC()
{
  long gcu, ptr, adf, loc0, loc1, uni, surf, nfg, nmg, n, m;
  double *E;

  /* Check option */

  if((long)RDB[DATA_OPTI_GC_CALC] == NO)
    {
      /* Reset pointers */

      WDB[DATA_MICRO_PTR_EGRID] = NULLPTR;
      WDB[DATA_ERG_FG_PTR_GRID] = NULLPTR;

      /* Exit subroutine */
 
      return;
    }

  /***************************************************************************/

  /***** Few-group structure *************************************************/

  /* Check pre-defined group structure */

  if ((ptr = (long)RDB[DATA_ERG_FG_PTR_PREDEF]) > VALID_PTR)
    {
      /* Number of energy groups */

      nfg = (long)RDB[ptr + ENE_NB];

      /* Pointer to data */

      ptr = (long)RDB[ptr + ENE_PTR_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr1)", DATA_ARRAY, ptr);

      ptr = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
      CheckPointer(FUNCTION_NAME, "(ptr2)", DATA_ARRAY, ptr);
      
      /* Put pointer and number of groups */

      WDB[DATA_ERG_FG_PTR_GRID] = (double)ptr;
      WDB[DATA_ERG_FG_NG] = (double)nfg;
    }
  
  /* Get number of groups */

  nfg = (long)RDB[DATA_ERG_FG_NG] + 1;
      
  /* Allcate memory for temporary array */
  
  E = (double *)Mem(MEM_ALLOC, nfg, sizeof(double));
  
  /* Check pointer to array */
  
  if ((ptr = (long)RDB[DATA_ERG_FG_PTR_GRID]) < VALID_PTR)
    Error(0, "Missing few-group structure for group constant generation");
  else
    {
      /* Read data in array */
	  
      for (n = 0; n < nfg; n++)
	E[n] = RDB[ptr++];
    }
  
  /* Check values */
  
  for (n = 1; n < nfg; n++)
    if (E[n] <= E[n - 1])
      Error(0, "Values in few-group structure must be in ascending order");

  /* Make energy grid */
      
  ptr = MakeEnergyGrid(nfg, 0, 0, -1, E, EG_INTERP_MODE_LIN);
      
  /* Put pointer */
  
  WDB[DATA_ERG_FG_PTR_GRID] = (double)ptr;
  
  /* Free temporary array */
  
  Mem(MEM_FREE, E);

  /***************************************************************************/

  /***** Process micro-group structure ***************************************/
  
  /* Find energy grid */
      
  if ((ptr = RDB[DATA_PTR_ENE0]) < VALID_PTR)
    Error(0, "No energy group structures defined for micro-group calculation");
  else if ((ptr = SeekListStr(ptr, ENE_PTR_NAME,
			      GetText(DATA_MICRO_PTR_EGRID))) < VALID_PTR)
    Error(0, "Energy grid %s used for micro-group calculation is not defined", 
	  GetText(DATA_MICRO_PTR_EGRID));
   
  /* Pointer to grid structure */

  ptr = (long)RDB[ptr + ENE_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ptr3)", DATA_ARRAY, ptr);

  /* Put pointer */

  WDB[DATA_MICRO_PTR_EGRID] = (double)ptr;

  /* Number of points */

  nmg = (long)RDB[ptr + ENERGY_GRID_NE] - 1;

  /* Get pointer to values */

  loc0 = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Pointer to few-group structure */

  ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ptr4)", DATA_ARRAY, ptr);

  /* Get pointer to values */

  loc1 = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

  /* Make sure that all points match */

  for (n = 1; n < nfg - 1; n++)
    {
      /* Find interval in micro-group structure */
      
      if ((m = SearchArray(&RDB[loc0], RDB[loc1 + n], nmg + 1)) > -1)
	{
	  /* Pick closest match */
	  
	  if ((RDB[loc1 + n] - RDB[loc0 + m]) > 
	      (RDB[loc0 + m + 1] - RDB[loc1 + n]))
	    m = m + 1;
	  
	  /* Put value */
	  
	  WDB[loc0 + m] = RDB[loc1 + n];
	}
    }

  /* Check that micro-group grid is still in ascending order */

  for (n = 1; n < nfg; n++)
    if (RDB[loc1 + n] <= RDB[loc1 + n - 1])
      Error(0, "Mismatch between micro and macro-group structure");

  /* Allocate memory for indexes */

  ptr = ReallocMem(DATA_ARRAY, nmg);
  WDB[DATA_MICRO_PTR_IDX_MAP] = (double)ptr;

  /* Map indexes */

  m = 0;
  for (n = 1; n < nfg - 1; n++)
    {
      /* Loop over micro-group structure */
      
      while (m < nmg)
	{
	  /* Check boundary */

	  if (RDB[loc0 + m] == RDB[loc1 + n])
	    break;

	  /* Put index */

	  WDB[ptr + nmg - m - 1] = (double)(nfg - 1 - n);

	  /* Next */

	  m++;
	}

      /* Check match */

      if (m == nmg)
	Error(0, 
	      "Few-group boundary %1.5E not found in micro-group energy grid",
	      RDB[loc1 + n]);
    }

  /* Put remaining */

  while (m < nmg)
    WDB[ptr + nmg - m++ - 1] = (double)(nfg -1 - n);

  /***************************************************************************/

  /***** Add ADF universes to GCU list ***************************************/

  /* Loop over ADF's */

  adf = (long)RDB[DATA_PTR_ADF0];
  while (adf > VALID_PTR)
    {
      /* Loop over universes */
      
      gcu = (long)RDB[DATA_PTR_GCU0];
      while (gcu > VALID_PTR)
	{
	  /* Compare */

	  if (CompareStr(gcu + GCU_PTR_UNIV, adf + ADF_PTR_GCU))
	    break;

	  /* Next */

	  gcu = NextItem(gcu);
	}
      
      /* Check pointer */

      if (gcu < VALID_PTR)
	{
	  /* Not defined, add to list */
	  
	  gcu = NewItem(DATA_PTR_GCU0, GCU_BLOCK_SIZE);
	  WDB[gcu + GCU_PTR_UNIV] = RDB[adf + ADF_PTR_GCU];
	}
      
      /* Next ADF */

      adf = NextItem(adf);
    }

  /***************************************************************************/

  /***** Universes ***********************************************************/

  /* Pointer is zero if list is not given */

  if((long)RDB[DATA_PTR_GCU0] == 0)
    {
      /* Allocate memory */

      gcu = NewItem(DATA_PTR_GCU0, GCU_BLOCK_SIZE);

      /* Pointer to root universe */

      ptr = (long)RDB[DATA_PTR_ROOT_UNIVERSE];
      CheckPointer(FUNCTION_NAME, "(ptr5)", DATA_ARRAY, ptr);

      /* Set name */

      WDB[gcu + GCU_PTR_UNIV] = RDB[ptr + UNIVERSE_PTR_NAME];
    }

  /* Loop over gcu structures */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Find universe */

      uni = RDB[DATA_PTR_U0];
      if ((uni = SeekListStr(uni, UNIVERSE_PTR_NAME, 
			     GetText(gcu + GCU_PTR_UNIV))) < VALID_PTR)
	Error(0, "Universe %s in group constant generation does not exist", 
	      GetText(gcu + GCU_PTR_UNIV));
      
      /* Put pointers */
      
      WDB[gcu + GCU_PTR_UNIV] = (double)uni;
      WDB[uni + UNIVERSE_PTR_GCU] = (double)(gcu);

      /***********************************************************************/

      /***** Few-group constants in infinite spectrum ************************/

      /* Allocate memory for results */

      ptr = NewStat("FLUX", 1, nfg); 
      WDB[gcu + GCU_RES_FG_FLX] = (double)ptr;
      
      ptr = NewStat("TOTXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_TOTXS] = (double)ptr;
      
      ptr = NewStat("FISSXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_FISSXS] = (double)ptr;
      
      ptr = NewStat("CAPTXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_CAPTXS] = (double)ptr;
      
      ptr = NewStat("ABSXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_ABSXS] = (double)ptr;

      ptr = NewStat("RABSXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_RABSXS] = (double)ptr;
      
      ptr = NewStat("ELAXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_ELAXS] = (double)ptr;
      
      ptr = NewStat("INELAXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_INLXS] = (double)ptr;
      
      ptr = NewStat("SCATTXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATTXS] = (double)ptr;

      ptr = NewStat("SCATTPRODXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATTPRODXS] = (double)ptr;
      
      ptr = NewStat("REMXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_REMXS] = (double)ptr;
      
      ptr = NewStat("NUBAR", 1, nfg); 
      WDB[gcu + GCU_RES_FG_NUBAR] = (double)ptr;
      
      ptr = NewStat("NSF", 1, nfg); 
      WDB[gcu + GCU_RES_FG_NSF] = (double)ptr;
      
      ptr = NewStat("RECIPVEL", 1, nfg); 
      WDB[gcu + GCU_RES_FG_RECIPVEL] = (double)ptr;
      
      ptr = NewStat("FISSE", 1, nfg); 
      WDB[gcu + GCU_RES_FG_FISSE] = (double)ptr;

      ptr = NewStat("LEAK", 1, nfg); 
      WDB[gcu + GCU_RES_FG_LEAK] = (double)ptr;

      ptr = NewStat("SCATT0", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATT0] = (double)ptr;

      ptr = NewStat("SCATT1", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATT1] = (double)ptr;

      ptr = NewStat("SCATT2", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATT2] = (double)ptr;

      ptr = NewStat("SCATT3", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATT3] = (double)ptr;

      ptr = NewStat("SCATT4", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATT4] = (double)ptr;

      ptr = NewStat("SCATT5", 1, nfg); 
      WDB[gcu + GCU_RES_FG_SCATT5] = (double)ptr;

      /* Fission spectra does not include total */

      ptr = NewStat("CHI", 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_CHI] = (double)ptr;

      ptr = NewStat("CHIP", 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_CHIP] = (double)ptr;

      ptr = NewStat("CHID", 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_CHID] = (double)ptr;

      /* Scattering matrix has extra dimension */

      ptr = NewStat("GTRANSFP", 2, nfg - 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_GTRANSP] = (double)ptr;

      ptr = NewStat("GTRANSFXS", 2, nfg - 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_GTRANSXS] = (double)ptr;

      ptr = NewStat("GPRODP", 2, nfg - 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_GPRODP] = (double)ptr;

      ptr = NewStat("GPRODXS", 2, nfg - 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_GPRODXS] = (double)ptr;

      /* Poison cross sections */

      ptr = NewStat("I135_PROD_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_I135_PROD_XS] = (double)ptr;  
      
      ptr = NewStat("XE135_PROD_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_XE135_PROD_XS] = (double)ptr;  
      
      ptr = NewStat("PM149_PROD_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_PM149_PROD_XS] = (double)ptr;  
      
      ptr = NewStat("SM149_PROD_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_SM149_PROD_XS] = (double)ptr;  
      
      ptr = NewStat("I135_ABS_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_I135_ABS_XS] = (double)ptr;  
      
      ptr = NewStat("XE135_ABS_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_XE135_ABS_XS] = (double)ptr;  
      
      ptr = NewStat("PM149_ABS_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_PM149_ABS_XS] = (double)ptr;  
      
      ptr = NewStat("SM149_ABS_XS", 1, nfg);
      WDB[gcu + GCU_RES_FG_SM149_ABS_XS] = (double)ptr;  
    
      /* P1 micro-group calculation */
      
      ptr = NewStat("P1_FLUX", 1, nfg); 
      WDB[gcu + GCU_RES_FG_P1_FLUX] = (double)ptr;

      ptr = NewStat("P1_TRANSPXS", 1, nfg); 
      WDB[gcu + GCU_RES_FG_P1_TRANSPXS] = (double)ptr;

      ptr = NewStat("P1_DIFFCOEF", 1, nfg); 
      WDB[gcu + GCU_RES_FG_P1_DIFFCOEF] = (double)ptr;

      ptr = NewStat("P1_MUBAR", 1, nfg); 
      WDB[gcu + GCU_RES_FG_P1_MUBAR] = (double)ptr;

      /* Allocate memory for micro-group data */

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_FLX] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_FISS_FLX] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_TOT] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_ABS] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_FISS] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_CHIT] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_CHIP] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_CHID] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_NSF] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_FISSE] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_INV_V] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT0] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP0] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT1] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP1] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT2] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP2] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT3] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP3] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT4] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP4] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT5] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP5] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT6] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP6] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATT7] = (double)ptr;

      ptr = AllocPrivateData(nmg*nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_SCATTP7] = (double)ptr;

      /* Check poison calculation */

      if ((long)RDB[DATA_OPTI_POISON_CALC] == YES)
	{
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_I135_YIELD] = (double)ptr;

	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_XE135_YIELD] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_PM149_YIELD] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_SM149_YIELD] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_I135_ABS] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_XE135_ABS] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_PM149_ABS] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_SM149_ABS] = (double)ptr;

	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_I135_MACRO_ABS] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_XE135_MACRO_ABS] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_PM149_MACRO_ABS] = (double)ptr;
	  
	  ptr = AllocPrivateData(nmg, RES2_ARRAY);
	  WDB[gcu + GCU_MICRO_SM149_MACRO_ABS] = (double)ptr;
	}

      /* B1 flux spectrum and diffusion coefficient */

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_B1_FLX] = (double)ptr;

      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_B1_DIFFCOEF] = (double)ptr;

      /* Homogeneous diffusion Monte Carlo k-eff */

      ptr = NewStat("HDMC_KEFF", 1, 1);
      WDB[gcu + GCU_HDMC_KEFF] = (double)ptr;

      /* Uudet vakiot */

      ptr = NewStat("INF_FLX", 1, nfg);
      WDB[gcu + GCU_INF_FLX] = (double)ptr;

      ptr = NewStat("INF_FISS_FLX", 1, nfg);
      WDB[gcu + GCU_INF_FISS_FLX] = (double)ptr;

      ptr = NewStat("INF_KINF", 1, nfg);
      WDB[gcu + GCU_INF_KINF] = (double)ptr;

      ptr = NewStat("INF_REP_TIME", 1, nfg);
      WDB[gcu + GCU_INF_REP_TIME] = (double)ptr;

      ptr = NewStat("INF_PROMPT_LIFE", 1, nfg);
      WDB[gcu + GCU_INF_PROMPT_LIFE] = (double)ptr;

      ptr = NewStat("INF_TOT", 1, nfg);
      WDB[gcu + GCU_INF_TOT] = (double)ptr;

      ptr = NewStat("INF_CAPT", 1, nfg);
      WDB[gcu + GCU_INF_CAPT] = (double)ptr;

      ptr = NewStat("INF_FISS", 1, nfg);
      WDB[gcu + GCU_INF_FISS] = (double)ptr;

      ptr = NewStat("INF_NSF", 1, nfg);
      WDB[gcu + GCU_INF_NSF] = (double)ptr;

      ptr = NewStat("INF_KAPPA", 1, nfg);
      WDB[gcu + GCU_INF_KAPPA] = (double)ptr;

      ptr = NewStat("INF_INVV", 1, nfg);
      WDB[gcu + GCU_INF_INVV] = (double)ptr;

      ptr = NewStat("INF_NUBAR", 1, nfg);
      WDB[gcu + GCU_INF_NUBAR] = (double)ptr;

      ptr = NewStat("INF_ABS", 1, nfg);
      WDB[gcu + GCU_INF_ABS] = (double)ptr;

      ptr = NewStat("INF_REMXS", 1, nfg);
      WDB[gcu + GCU_INF_REMXS] = (double)ptr;

      ptr = NewStat("INF_RABSXS", 1, nfg);
      WDB[gcu + GCU_INF_RABSXS] = (double)ptr;

      ptr = NewStat("INF_CHIT", 1, nfg + 1);
      WDB[gcu + GCU_INF_CHIT] = (double)ptr;

      ptr = NewStat("INF_CHIP", 1, nfg + 1);
      WDB[gcu + GCU_INF_CHIP] = (double)ptr;

      ptr = NewStat("INF_CHID", 1, nfg + 1);
      WDB[gcu + GCU_INF_CHID] = (double)ptr;

      ptr = NewStat("INF_I135_YIELD", 1, nfg);
      WDB[gcu + GCU_INF_I135_YIELD] = (double)ptr;

      ptr = NewStat("INF_XE135_YIELD", 1, nfg);
      WDB[gcu + GCU_INF_XE135_YIELD] = (double)ptr;

      ptr = NewStat("INF_PM149_YIELD", 1, nfg);
      WDB[gcu + GCU_INF_PM149_YIELD] = (double)ptr;

      ptr = NewStat("INF_SM149_YIELD", 1, nfg);
      WDB[gcu + GCU_INF_SM149_YIELD] = (double)ptr;

      ptr = NewStat("INF_I135_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_I135_ABS] = (double)ptr;

      ptr = NewStat("INF_XE135_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_XE135_ABS] = (double)ptr;

      ptr = NewStat("INF_PM149_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_PM149_ABS] = (double)ptr;

      ptr = NewStat("INF_SM149_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_SM149_ABS] = (double)ptr;

      ptr = NewStat("INF_I135_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_I135_MACRO_ABS] = (double)ptr;

      ptr = NewStat("INF_XE135_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_XE135_MACRO_ABS] = (double)ptr;

      ptr = NewStat("INF_PM149_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_PM149_MACRO_ABS] = (double)ptr;

      ptr = NewStat("INF_SM149_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_INF_SM149_MACRO_ABS] = (double)ptr;

      ptr = NewStat("INF_S0", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S0] = (double)ptr;

      ptr = NewStat("INF_S1", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S1] = (double)ptr;

      ptr = NewStat("INF_S2", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S2] = (double)ptr;

      ptr = NewStat("INF_S3", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S3] = (double)ptr;

      ptr = NewStat("INF_S4", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S4] = (double)ptr;

      ptr = NewStat("INF_S5", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S5] = (double)ptr;

      ptr = NewStat("INF_S6", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S6] = (double)ptr;

      ptr = NewStat("INF_S7", 2, nfg, nfg);
      WDB[gcu + GCU_INF_S7] = (double)ptr;

      ptr = NewStat("INF_SP0", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP0] = (double)ptr;

      ptr = NewStat("INF_SP1", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP1] = (double)ptr;

      ptr = NewStat("INF_SP2", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP2] = (double)ptr;

      ptr = NewStat("INF_SP3", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP3] = (double)ptr;

      ptr = NewStat("INF_SP4", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP4] = (double)ptr;

      ptr = NewStat("INF_SP5", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP5] = (double)ptr;

      ptr = NewStat("INF_SP6", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP6] = (double)ptr;

      ptr = NewStat("INF_SP7", 2, nfg, nfg);
      WDB[gcu + GCU_INF_SP7] = (double)ptr;

      ptr = NewStat("INF_SCATT0", 1, nfg);
      WDB[gcu + GCU_INF_SCATT0] = (double)ptr;

      ptr = NewStat("INF_SCATT1", 1, nfg);
      WDB[gcu + GCU_INF_SCATT1] = (double)ptr;

      ptr = NewStat("INF_SCATT2", 1, nfg);
      WDB[gcu + GCU_INF_SCATT2] = (double)ptr;

      ptr = NewStat("INF_SCATT3", 1, nfg);
      WDB[gcu + GCU_INF_SCATT3] = (double)ptr;

      ptr = NewStat("INF_SCATT4", 1, nfg);
      WDB[gcu + GCU_INF_SCATT4] = (double)ptr;

      ptr = NewStat("INF_SCATT5", 1, nfg);
      WDB[gcu + GCU_INF_SCATT5] = (double)ptr;

      ptr = NewStat("INF_SCATT6", 1, nfg);
      WDB[gcu + GCU_INF_SCATT6] = (double)ptr;

      ptr = NewStat("INF_SCATT7", 1, nfg);
      WDB[gcu + GCU_INF_SCATT7] = (double)ptr;

      ptr = NewStat("INF_SCATTP0", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP0] = (double)ptr;

      ptr = NewStat("INF_SCATTP1", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP1] = (double)ptr;

      ptr = NewStat("INF_SCATTP2", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP2] = (double)ptr;

      ptr = NewStat("INF_SCATTP3", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP3] = (double)ptr;

      ptr = NewStat("INF_SCATTP4", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP4] = (double)ptr;

      ptr = NewStat("INF_SCATTP5", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP5] = (double)ptr;

      ptr = NewStat("INF_SCATTP6", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP6] = (double)ptr;

      ptr = NewStat("INF_SCATTP7", 1, nfg);
      WDB[gcu + GCU_INF_SCATTP7] = (double)ptr;

      ptr = NewStat("INF_TRANSPXS", 1, nfg);
      WDB[gcu + GCU_INF_TRANSPXS] = (double)ptr;

      ptr = NewStat("INF_DIFFCOEF", 1, nfg);
      WDB[gcu + GCU_INF_DIFFCOEF] = (double)ptr;

      /* Uudet B1 vakiot */

      ptr = NewStat("B1_KINF", 1, 1);
      WDB[gcu + GCU_B1_KINF] = (double)ptr;

      ptr = NewStat("B1_KEFF", 1, 1);
      WDB[gcu + GCU_B1_KEFF] = (double)ptr;

      ptr = NewStat("B1_REP_TIME", 1, nfg);
      WDB[gcu + GCU_B1_REP_TIME] = (double)ptr;

      ptr = NewStat("B1_PROMPT_LIFE", 1, nfg);
      WDB[gcu + GCU_B1_PROMPT_LIFE] = (double)ptr;

      ptr = NewStat("B1_B2", 1, 1);
      WDB[gcu + GCU_B1_B2] = (double)ptr;

      ptr = NewStat("B1_ERR", 1, 1);
      WDB[gcu + GCU_B1_ERR] = (double)ptr;

      ptr = NewStat("B1_FLX", 1, nfg);
      WDB[gcu + GCU_B1_FLX] = (double)ptr;

      ptr = NewStat("B1_FISS_FLX", 1, nfg);
      WDB[gcu + GCU_B1_FISS_FLX] = (double)ptr;

      ptr = NewStat("B1_TOT", 1, nfg);
      WDB[gcu + GCU_B1_TOT] = (double)ptr;

      ptr = NewStat("B1_CAPT", 1, nfg);
      WDB[gcu + GCU_B1_CAPT] = (double)ptr;

      ptr = NewStat("B1_FISS", 1, nfg);
      WDB[gcu + GCU_B1_FISS] = (double)ptr;

      ptr = NewStat("B1_NSF", 1, nfg);
      WDB[gcu + GCU_B1_NSF] = (double)ptr;

      ptr = NewStat("B1_KAPPA", 1, nfg);
      WDB[gcu + GCU_B1_KAPPA] = (double)ptr;

      ptr = NewStat("B1_INVV", 1, nfg);
      WDB[gcu + GCU_B1_INVV] = (double)ptr;

      ptr = NewStat("B1_NUBAR", 1, nfg);
      WDB[gcu + GCU_B1_NUBAR] = (double)ptr;

      ptr = NewStat("B1_ABS", 1, nfg);
      WDB[gcu + GCU_B1_ABS] = (double)ptr;

      ptr = NewStat("B1_REMXS", 1, nfg);
      WDB[gcu + GCU_B1_REMXS] = (double)ptr;

      ptr = NewStat("B1_RABSXS", 1, nfg);
      WDB[gcu + GCU_B1_RABSXS] = (double)ptr;

      ptr = NewStat("B1_CHIT", 1, nfg + 1);
      WDB[gcu + GCU_B1_CHIT] = (double)ptr;

      ptr = NewStat("B1_CHIP", 1, nfg + 1);
      WDB[gcu + GCU_B1_CHIP] = (double)ptr;

      ptr = NewStat("B1_CHID", 1, nfg + 1);
      WDB[gcu + GCU_B1_CHID] = (double)ptr;

      ptr = NewStat("B1_I135_YIELD", 1, nfg);
      WDB[gcu + GCU_B1_I135_YIELD] = (double)ptr;

      ptr = NewStat("B1_XE135_YIELD", 1, nfg);
      WDB[gcu + GCU_B1_XE135_YIELD] = (double)ptr;

      ptr = NewStat("B1_PM149_YIELD", 1, nfg);
      WDB[gcu + GCU_B1_PM149_YIELD] = (double)ptr;

      ptr = NewStat("B1_SM149_YIELD", 1, nfg);
      WDB[gcu + GCU_B1_SM149_YIELD] = (double)ptr;

      ptr = NewStat("B1_I135_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_I135_ABS] = (double)ptr;

      ptr = NewStat("B1_XE135_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_XE135_ABS] = (double)ptr;

      ptr = NewStat("B1_PM149_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_PM149_ABS] = (double)ptr;

      ptr = NewStat("B1_SM149_MICRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_SM149_ABS] = (double)ptr;

      ptr = NewStat("B1_I135_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_I135_MACRO_ABS] = (double)ptr;

      ptr = NewStat("B1_XE135_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_XE135_MACRO_ABS] = (double)ptr;

      ptr = NewStat("B1_PM149_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_PM149_MACRO_ABS] = (double)ptr;

      ptr = NewStat("B1_SM149_MACRO_ABS", 1, nfg);
      WDB[gcu + GCU_B1_SM149_MACRO_ABS] = (double)ptr;

      ptr = NewStat("B1_S0", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S0] = (double)ptr;

      ptr = NewStat("B1_S1", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S1] = (double)ptr;

      ptr = NewStat("B1_S2", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S2] = (double)ptr;

      ptr = NewStat("B1_S3", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S3] = (double)ptr;

      ptr = NewStat("B1_S4", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S4] = (double)ptr;

      ptr = NewStat("B1_S5", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S5] = (double)ptr;

      ptr = NewStat("B1_S6", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S6] = (double)ptr;

      ptr = NewStat("B1_S7", 2, nfg, nfg);
      WDB[gcu + GCU_B1_S7] = (double)ptr;

      ptr = NewStat("B1_SP0", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP0] = (double)ptr;

      ptr = NewStat("B1_SP1", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP1] = (double)ptr;

      ptr = NewStat("B1_SP2", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP2] = (double)ptr;

      ptr = NewStat("B1_SP3", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP3] = (double)ptr;

      ptr = NewStat("B1_SP4", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP4] = (double)ptr;

      ptr = NewStat("B1_SP5", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP5] = (double)ptr;

      ptr = NewStat("B1_SP6", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP6] = (double)ptr;

      ptr = NewStat("B1_SP7", 2, nfg, nfg);
      WDB[gcu + GCU_B1_SP7] = (double)ptr;

      ptr = NewStat("B1_SCATT0", 1, nfg);
      WDB[gcu + GCU_B1_SCATT0] = (double)ptr;

      ptr = NewStat("B1_SCATT1", 1, nfg);
      WDB[gcu + GCU_B1_SCATT1] = (double)ptr;

      ptr = NewStat("B1_SCATT2", 1, nfg);
      WDB[gcu + GCU_B1_SCATT2] = (double)ptr;

      ptr = NewStat("B1_SCATT3", 1, nfg);
      WDB[gcu + GCU_B1_SCATT3] = (double)ptr;

      ptr = NewStat("B1_SCATT4", 1, nfg);
      WDB[gcu + GCU_B1_SCATT4] = (double)ptr;

      ptr = NewStat("B1_SCATT5", 1, nfg);
      WDB[gcu + GCU_B1_SCATT5] = (double)ptr;

      ptr = NewStat("B1_SCATT6", 1, nfg);
      WDB[gcu + GCU_B1_SCATT6] = (double)ptr;

      ptr = NewStat("B1_SCATT7", 1, nfg);
      WDB[gcu + GCU_B1_SCATT7] = (double)ptr;

      ptr = NewStat("B1_SCATTP0", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP0] = (double)ptr;

      ptr = NewStat("B1_SCATTP1", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP1] = (double)ptr;

      ptr = NewStat("B1_SCATTP2", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP2] = (double)ptr;

      ptr = NewStat("B1_SCATTP3", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP3] = (double)ptr;

      ptr = NewStat("B1_SCATTP4", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP4] = (double)ptr;

      ptr = NewStat("B1_SCATTP5", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP5] = (double)ptr;

      ptr = NewStat("B1_SCATTP6", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP6] = (double)ptr;

      ptr = NewStat("B1_SCATTP7", 1, nfg);
      WDB[gcu + GCU_B1_SCATTP7] = (double)ptr;

      ptr = NewStat("B1_TRANSPXS", 1, nfg);
      WDB[gcu + GCU_B1_TRANSPXS] = (double)ptr;

      ptr = NewStat("B1_DIFFCOEF", 1, nfg);
      WDB[gcu + GCU_B1_DIFFCOEF] = (double)ptr;
      
      /***********************************************************************/
      
      /***** Few-group constants in critical spectrum ************************/

      /* Check option */

      if ((long)RDB[DATA_B1_CALC] == YES)
	{
	  /* Allocate memory for results */

	  ptr = NewStat("B1_KINF", 1, 1);
	  WDB[gcu + GCU_FUM_FG_B1_KINF] = (double)ptr;
	  
	  ptr = NewStat("B1_BUCKLING", 1, 1);
	  WDB[gcu + GCU_FUM_FG_B1_BUCKLING] = (double)ptr;
	  
	  ptr = NewStat("B1_DIFFCOEF", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_DIFFCOEF] = (double)ptr;
	  
	  ptr = NewStat("B1_ABSXS", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_ABSXS] = (double)ptr;
	  
	  ptr = NewStat("B1_RABSXS", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_RABSXS] = (double)ptr;
	  
	  ptr = NewStat("B1_NSF", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_NSF] = (double)ptr;
	  
	  ptr = NewStat("B1_FISSXS", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_FISSXS] = (double)ptr;
	  
	  ptr = NewStat("B1_FISSXS", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_FISSXS] = (double)ptr;
	  
	  ptr = NewStat("B1_SCATTXS", 2, nfg, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_SCATTXS] = (double)ptr;
	  
	  ptr = NewStat("B1_SCATTPRODXS", 2, nfg, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_SCATTPRODXS] = (double)ptr;
	  
	  ptr = NewStat("B1_TOTXS", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_TOTXS] = (double)ptr;
	  
	  ptr = NewStat("B1_FLUX", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_FLUX] = (double)ptr;
	  
	  ptr = NewStat("B1_CHI", 1, nfg - 1);
	  WDB[gcu + GCU_FUM_FG_B1_CHI] = (double)ptr;
	  
	  ptr = NewStat("B1_REMXS", 1, nfg);
	  WDB[gcu + GCU_FUM_FG_B1_REMXS] = (double)ptr;
	  
	  ptr = NewStat("B1_I135_PROD_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_I135_PROD_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_Xe135_PROD_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_XE135_PROD_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_PM149_PROD_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_PM149_PROD_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_SM149_PROD_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_SM149_PROD_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_I135_ABS_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_I135_ABS_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_XE135_ABS_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_XE135_ABS_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_PM149_ABS_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_PM149_ABS_XS] = (double)ptr;
	  
	  ptr = NewStat("B1_SM149_ABS_XS", 1, nfg); 
	  WDB[gcu + GCU_FUM_FG_SM149_ABS_XS] = (double)ptr;
	  
	  /* Allocate memory for spectrum-correction factors */

	  ptr = ReallocMem(DATA_ARRAY, nmg);
	  WDB[gcu + GCU_FUM_PTR_SPEC_CORR] = (double)ptr;
	}
      
      /***********************************************************************/

      /* Next */

      gcu = NextItem(gcu);
    }

  /* Allocate memory for universe pointer */

  AllocValuePair(DATA_GCU_PTR_UNI);

  /***************************************************************************/

  /***** Process discontinuity factos ****************************************/

  /* Loop over ADF's */

  adf = (long)RDB[DATA_PTR_ADF0];
  while (adf > VALID_PTR)
    {
      /***********************************************************************/

      /***** Link universes and surfaces *************************************/

      /* Loop over universes */
      
      gcu = (long)RDB[DATA_PTR_GCU0];
      while (gcu > VALID_PTR)
	{
	  /* Get pointer */

	  uni = (long)RDB[gcu + GCU_PTR_UNIV];
	  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

	  /* Compare */

	  if (CompareStr(uni + UNIVERSE_PTR_NAME, adf + ADF_PTR_GCU))
	    break;

	  /* Next */

	  gcu = NextItem(gcu);
	}
      
      /* Check pointer */

      if (gcu > VALID_PTR)
	{
	  /* Link ADF to universe */

	  if ((long)RDB[gcu + GCU_PTR_ADF] > VALID_PTR)
	    Error(0, "Universe %s is associated with multiple df's",
		  GetText(adf + ADF_PTR_GCU));
	  else
	    WDB[gcu + GCU_PTR_ADF] = (double)adf;	  

	  /* Link universe to ADF */
	  
	  WDB[adf + ADF_PTR_GCU] = (double)gcu;
	}
      else
	Error(0, "Universe %s needed for df calculation does not exist",
	      GetText(adf + ADF_PTR_GCU));

      /* Find surface */

      surf = (long)RDB[DATA_PTR_S0];
      if ((surf = SeekListStr(surf, SURFACE_PTR_NAME, 
			      GetText(adf + ADF_PTR_SURF))) < VALID_PTR)
	Error(0, "Surface %s needed for df calculation does not exist",
	      GetText(adf + ADF_PTR_SURF));

      /* Put pointer */

      WDB[adf + ADF_PTR_SURF] = (double)surf;

      /* Check if boundary condition is set */

      if ((long)RDB[adf + ADF_BC] < BC_BLACK)
	{
	  /* Compare surface pointer and set global boundary condition */

	  if (surf == (long)RDB[DATA_PTR_BC_SURF])
	    WDB[adf + ADF_BC] = RDB[DATA_GEOM_BC0];
	  else
	    WDB[adf + ADF_BC] = (double)BC_BLACK;
	}

      /* BC0 is not set with partial boundaries */

      if ((long)RDB[adf + ADF_BC] < BC_BLACK)
	Error(0, "ADF boundary condition must be defined");

      /* Get pointer to surface parameters */

      ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
      CheckPointer(FUNCTION_NAME, "(ptr6)", DATA_ARRAY, ptr);

      /* Get number of faces and corners */

      switch ((long)RDB[surf + SURFACE_TYPE])
	{
	case SURF_PX:
	case SURF_PY:
	case SURF_PZ:
	case SURF_PLANE:
	  {
	    /* Planes */

	    n = 1;
	    m = 0;

	    /* Set volume and surface areas */

	    WDB[adf + ADF_VOL] = 1.0;
	    WDB[adf + ADF_SURF_AREA] = 1.0;
	    WDB[adf + ADF_CORN_AREA] = 1.0;

	    break;
	  }
	case SURF_SQC:
	  {
	    /* Square cylinder */
	    
	    n = 4;
	    m = 4;

	    /* Set volume and surface areas */

	    WDB[adf + ADF_VOL] = 4.0*RDB[ptr + 2]*RDB[ptr + 2];
	    WDB[adf + ADF_SURF_AREA] = 2.0*RDB[ptr + 2];
	    WDB[adf + ADF_CORN_AREA] = 2.0*ADF_CORN_WIDTH*RDB[ptr + 2];

	    break;
	  }
	case SURF_HEXXC:
	case SURF_HEXYC:
	  {
	    /* Hexagonal cylinders */
	    
	    n = 6;
	    m = 6;

	    break;
	  }
	case SURF_CUBE:
	case SURF_CUBOID:
	  {
	    /* Cube and cuboid */
	    
	    n = 6;
	    m = 4;

	    break;
	  }
	case SURF_HEXXPRISM:
	case SURF_HEXYPRISM:
	  {
	    /* Hexagonal prisms */
	    
	    n = 8;
	    m = 6;

	    break;
	  }
	default:
	  {
	    Error(0, "Surface %s is wrong type for df calculation",
		  GetText(surf + SURFACE_PTR_NAME));
	  }
	}

      /* Store values */

      WDB[adf + ADF_NSURF] = (double)n;
      WDB[adf + ADF_NCORN] = (double)m;
		    
      /* Allocate memory for micro-group fluxes and currents */

      ptr = AllocPrivateData(nmg*n, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_ADF_SURF_FLUX] = (double)ptr;

      ptr = AllocPrivateData(nmg*m, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_ADF_CORN_FLUX] = (double)ptr;
    
      ptr = AllocPrivateData(nmg, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_ADF_CELL_FLUX] = (double)ptr;

      ptr = AllocPrivateData(nmg*n, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_ADF_IN_CURR] = (double)ptr;

      ptr = AllocPrivateData(nmg*n, RES2_ARRAY);
      WDB[gcu + GCU_MICRO_ADF_OUT_CURR] = (double)ptr;

      /* Allocate memory for macro-group constants */

      ptr = NewStat("DF_HET_SURF_FLUX", 2, n, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_HET_SURF_FLUX] = (double)ptr;

      ptr = NewStat("DF_HOM_SURF_FLUX", 2, n, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_HOM_SURF_FLUX] = (double)ptr;

      ptr = NewStat("DF_SURF_DF", 2, n, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_SURF_DF] = (double)ptr;

      if (m > 0)
	{
	  ptr = NewStat("DF_HET_CORN_FLUX", 2, m, nfg - 1); 
	  WDB[gcu + GCU_RES_FG_DF_HET_CORN_FLUX] = (double)ptr;

	  ptr = NewStat("DF_HOM_CORN_FLUX", 2, m, nfg - 1); 
	  WDB[gcu + GCU_RES_FG_DF_HOM_CORN_FLUX] = (double)ptr;

	  ptr = NewStat("DF_CORN_DF", 2, m, nfg - 1); 
	  WDB[gcu + GCU_RES_FG_DF_CORN_DF] = (double)ptr;
	}

      ptr = NewStat("DF_HET_VOL_FLUX", 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_HET_VOL_FLUX] = (double)ptr;

      ptr = NewStat("DF_HOM_VOL_FLUX", 1, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_HOM_VOL_FLUX] = (double)ptr;

      ptr = NewStat("DF_IN_CURR", 2, n, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_IN_CURR] = (double)ptr;

      ptr = NewStat("DF_OUT_CURR", 2, n, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_OUT_CURR] = (double)ptr;

      ptr = NewStat("DF_NET_CURR", 2, n, nfg - 1); 
      WDB[gcu + GCU_RES_FG_DF_NET_CURR] = (double)ptr;

      /***********************************************************************/

      /* Next */

      adf = NextItem(adf);
    }

  /***************************************************************************/

  /***** MORA stuff **********************************************************/

  loc0 = (long)RDB[DATA_PTR_MORA0];
  while (loc0 > VALID_PTR)
    {
      /* Avoid compiler warning */

      uni = -1;

      /* Loop over gcu list */

      gcu = (long)RDB[DATA_PTR_GCU0];
      while (gcu > VALID_PTR)
	{
	  /* Pointer to universe */

	  uni = (long)RDB[gcu + GCU_PTR_UNIV];
	  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

	  /* Compare names */

	  if (CompareStr(uni + UNIVERSE_PTR_NAME, loc0 + MORA_PTR_UNIV))
	    break;

	  /* Next */

	  gcu = NextItem(gcu);
	}

      /* Check */

      if (gcu < VALID_PTR)
	Error(0, "Universe %s is not included in gc calculation", 
	      GetText(loc0 + MORA_PTR_UNIV));

      /* Put pointers */

      WDB[loc0 + MORA_PTR_UNIV] = (double)uni;
      WDB[gcu + GCU_PTR_MORA] = (double)loc0;

      /* Find energy group structure */

      loc1 = (long)RDB[DATA_PTR_ENE0];
      while (loc1 > VALID_PTR)
	{
	  /* Compare names */

	  if (CompareStr(loc1 + ENE_PTR_NAME, loc0 + MORA_PTR_EG))
	    break;
	  
	  /* Next */

	  loc1 = NextItem(loc1);
	}

      /* Check */

      if (loc1 < VALID_PTR)
	Error(0, "Energy group structure %s is not defined", 
	      GetText(loc0 + MORA_PTR_EG));

      /* Put pointer */

      WDB[loc0 + MORA_PTR_EG] = (double)RDB[loc1 + ENE_PTR_GRID];      

      /* Get number of energy groups and cosine bins */

      n = (long)RDB[loc1 + ENE_NB];
      m = (long)RDB[loc0 + MORA_N_COS];

      /* Put number of energy groups */

      WDB[loc0 + MORA_N_EG] = (double)n;

      /* Allocate memory for stats */

      ptr = NewStat("TOT", 1, n); 
      WDB[loc0 + MORA_PTR_TOT] = (double)ptr;

      ptr = NewStat("CAPT", 1, n); 
      WDB[loc0 + MORA_PTR_CAPT] = (double)ptr;

      ptr = NewStat("FISS", 1, n); 
      WDB[loc0 + MORA_PTR_FISS] = (double)ptr;

      ptr = NewStat("PNU", 1, n); 
      WDB[loc0 + MORA_PTR_PNU] = (double)ptr;

      ptr = NewStat("DNU", 1, n); 
      WDB[loc0 + MORA_PTR_DNU] = (double)ptr;

      ptr = NewStat("KAPPA", 1, n); 
      WDB[loc0 + MORA_PTR_KAPPA] = (double)ptr;

      ptr = NewStat("CHIP", 1, n + 1); 
      WDB[loc0 + MORA_PTR_CHIP] = (double)ptr;

      ptr = NewStat("CHID", 1, n + 1); 
      WDB[loc0 + MORA_PTR_CHID] = (double)ptr;

      ptr = NewStat("FLX", 1, n + 1); 
      WDB[loc0 + MORA_PTR_FLX] = (double)ptr;

      ptr = NewStat("SCATTP", 3, n, n, m); 
      WDB[loc0 + MORA_PTR_SCATTP] = (double)ptr;

      ptr = NewStat("SCATTW", 3, n, n, m); 
      WDB[loc0 + MORA_PTR_SCATTW] = (double)ptr;

      /* Next */

      loc0 = NextItem(loc0);
    }
  
  /***************************************************************************/
}

/*****************************************************************************/
