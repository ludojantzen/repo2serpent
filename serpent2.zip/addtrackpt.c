/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : addtrackpt.c                                   */
/*                                                                           */
/* Created:       2012/04/09 (JLe)                                           */
/* Last modified: 2012/10/14 (JLe)                                           */
/* Version:       2.1.9                                                      */
/*                                                                           */
/* Description: Stores collision points for plotter                          */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "AddTrackPt:"

/*****************************************************************************/

void AddTrackPt(double x, double y, double z, long part, long trk)
{
  long ptr, idx;

  /* Check index */

  if ((idx = (long)RDB[part + PARTICLE_HISTORY_IDX]) 
      > (long)RDB[DATA_TRACK_PLOTTER_HIS])
    return;

  /* Put OpenMP barrier */

#ifdef OPEN_MP
#pragma omp critical
#endif
  {
    /* Get pointer to next */

    ptr = (long)RDB[DATA_TRACK_PLOT_PTR_NEXT];
    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

    /* Put data */

    WDB[ptr + TRACK_PLOT_X] = x;
    WDB[ptr + TRACK_PLOT_Y] = y;
    WDB[ptr + TRACK_PLOT_Z] = z;
    WDB[ptr + TRACK_PLOT_IDX] = (double)idx;
    WDB[ptr + TRACK_PLOT_TRK] = (double)trk;

    /* Pointer to next */

    if ((ptr = NextItem(ptr)) < VALID_PTR)
      Die(FUNCTION_NAME, "Out of tracks");
    
    /* Put type */

    WDB[ptr + TRACK_PLOT_TRK] = (double)TRACK_PLOT_LAST;

    /* Put pointer */
    
    WDB[DATA_TRACK_PLOT_PTR_NEXT] = (double)ptr;
  }
}

/*****************************************************************************/
