/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : putcompositions.c                              */
/*                                                                           */
/* Created:       2012/05/11 (JLe)                                           */
/* Last modified: 2012/12/05 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Generates independent material compositions for materials    */
/*              divided into Serpent 1 -type regions and depletion zones.    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PutCompositions:"

/*****************************************************************************/

void PutCompositions()
{
  long mat, mat0, loc0, loc1, mem;

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check if material was produced by division */

      if ((mat0 = (long)RDB[mat + MATERIAL_DIV_PTR_PARENT]) < VALID_PTR)
	{
	  /* No, get pointer to next */

	  mat = NextItem(mat);

	  /* Cycle loop */

	  continue;
	}

      /* Calculate bytes */

      CalculateBytes();

      /* Get memory size */
      
      mem = RDB[DATA_TOTAL_BYTES];

      /* Check pointer to composition */

      if ((long)RDB[mat + MATERIAL_PTR_COMP] > VALID_PTR)
	Die(FUNCTION_NAME, "Divided material already has composition");

      /* Get pointer to original composition */

      loc0 = (long)RDB[mat0 + MATERIAL_PTR_COMP];
      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

      /* Loop over composition and copy */

      while (loc0 > VALID_PTR)
	{
	  /* Create new item */

	  loc1 = NewItem(mat + MATERIAL_PTR_COMP, COMPOSITION_BLOCK_SIZE);
	  
	  /* Copy data */
	  
	  memcpy(&WDB[loc1 + LIST_DATA_SIZE], &RDB[loc0 + LIST_DATA_SIZE], 
		 (COMPOSITION_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));
	  
	  /* Next */
	  
	  loc0 = NextItem(loc0);
	}

      /* Put additional options */

      SetOption(mat + MATERIAL_OPTIONS, (long)RDB[mat0 + MATERIAL_OPTIONS]);
      SetOption(mat + MATERIAL_OPTIONS, OPT_PHYSICAL_MAT);

      /* Copy physical parameters */

      WDB[mat + MATERIAL_ADENS] = RDB[mat0 + MATERIAL_ADENS];
      WDB[mat + MATERIAL_MDENS] = RDB[mat0 + MATERIAL_MDENS];
      WDB[mat + MATERIAL_INI_FISS_MDENS] = RDB[mat0 + MATERIAL_INI_FISS_MDENS];

      /* Copy poison flags */

      WDB[mat + MATERIAL_XENON_EQUIL_CALC] = 
	RDB[mat0 + MATERIAL_XENON_EQUIL_CALC];
      WDB[mat + MATERIAL_SAMARIUM_EQUIL_CALC] = 
	RDB[mat0 + MATERIAL_SAMARIUM_EQUIL_CALC];

      /* Calculate bytes */

      CalculateBytes();

      /* Update memory size */
      
      WDB[mat + MATERIAL_MEM_SIZE] = RDB[mat + MATERIAL_MEM_SIZE] + 
	RDB[DATA_TOTAL_BYTES] - mem;

      /* Next material */

      mat = NextItem(mat);
    }

  /* Find I-135, Xe-135, Pm-149 and Sm-149 for iteration */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check burn flag */

      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	{
	  /* Next material */

	  mat = NextItem(mat);

	  /* Cycle loop */

	  continue;
	}

      /* Loop over composition and find Xe-135 */

      loc0 = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (loc0 > VALID_PTR)
	{
	  /* Pointer to nuclide */

	  loc1 = (long)RDB[loc0 + COMPOSITION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

	  /* Check ZAI */

	  if ((long)RDB[loc1 + NUCLIDE_ZAI] == 531350)
	    WDB[mat + MATERIAL_PTR_I135_ISO] = (double)loc0;
	  else if ((long)RDB[loc1 + NUCLIDE_ZAI] == 541350)
	    WDB[mat + MATERIAL_PTR_XE135_ISO] = (double)loc0;
	  else if ((long)RDB[loc1 + NUCLIDE_ZAI] == 611490)
	    WDB[mat + MATERIAL_PTR_PM149_ISO] = (double)loc0;
	  else if ((long)RDB[loc1 + NUCLIDE_ZAI] == 621490)
	    WDB[mat + MATERIAL_PTR_SM149_ISO] = (double)loc0;

	  /* Next */

	  loc0 = NextItem(loc0);
	}

      /* Check pointers */

      if ((long)RDB[mat + MATERIAL_XENON_EQUIL_CALC] == YES)
	{
	  if ((long)RDB[mat + MATERIAL_PTR_I135_ISO] < VALID_PTR)
	    Die(FUNCTION_NAME, "I-135 not found");
	  if ((long)RDB[mat + MATERIAL_PTR_XE135_ISO] < VALID_PTR)
	    Die(FUNCTION_NAME, "Xe-135 not found");
	}

      if ((long)RDB[mat + MATERIAL_SAMARIUM_EQUIL_CALC] == YES)
	{
	  if ((long)RDB[mat + MATERIAL_PTR_PM149_ISO] < VALID_PTR)
	    Die(FUNCTION_NAME, "Pm-149 not found");
	  if ((long)RDB[mat + MATERIAL_PTR_SM149_ISO] < VALID_PTR)
	    Die(FUNCTION_NAME, "Sm-149 not found");
	}
  
      /* Next material */

      mat = NextItem(mat);
    }
}

/*****************************************************************************/
