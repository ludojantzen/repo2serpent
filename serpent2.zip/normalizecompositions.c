/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : normalizecompositions.c                        */
/*                                                                           */
/* Created:       2011/11/07 (JLe)                                           */
/* Last modified: 2012/09/07 (JLe)                                           */
/* Version:       2.1.8                                                      */
/*                                                                           */
/* Description: Normalizes material compositions before transport cycle      */
/*                                                                           */
/* Comments: - MPI-palamamoodissa tätä kutsutaan turhaan osalle              */
/*             materiaaleista.                                               */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NormalizeCompositions:"

/*****************************************************************************/

void NormalizeCompositions()
{
  long mat, nuc, iso;
  double f;

  /* Reset nuclide minimum and maximum fractions */
  
  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Reset values */

      WDB[nuc + NUCLIDE_MIN_AFRAC] = INFTY;
      WDB[nuc + NUCLIDE_MAX_AFRAC] = -INFTY;
      
      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Normalize material compositions */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Calculate fractions (tätä ei pidä eikä saa kutsua?) */
      /*
      IsotopeFractions(mat);
      */
      /* Next material */

      mat = NextItem(mat);
    }

  /* Find minimum and maximum fractions */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Loop over composition */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Pointer to nuclide data */

	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	  /* Calculate atomic fraction */

	  f = RDB[iso + COMPOSITION_ADENS]/RDB[mat + MATERIAL_ADENS];
	  CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);

	  /* Compare to minimum */
	  
	  if (f < RDB[nuc + NUCLIDE_MIN_AFRAC])
	    WDB[nuc + NUCLIDE_MIN_AFRAC] = f;

	  /* Compare to minimum */
	  
	  if (f > RDB[nuc + NUCLIDE_MAX_AFRAC])
	    WDB[nuc + NUCLIDE_MAX_AFRAC] = f;

	  /* Next nuclide */

	  iso = NextItem(iso);
	}


      /* Next material */

      mat = NextItem(mat);
    }
}


/*****************************************************************************/
