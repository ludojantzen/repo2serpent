/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : sampletarget.c                                 */
/*                                                                           */
/* Created:       2013/02/08 (JLe)                                           */
/* Last modified: 2013/02/08 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Samples target nuclide after collision                       */
/*                                                                           */
/* Comments: - Nuclide list must be sorted according to sample counter.      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SampleTarget:"

/*****************************************************************************/

long SampleTarget(long mat, long type, double E, double wgt, long id)
{
  long lst0, lst1, rea, rls1, rls2, ptr, i, n, N, nuc, ng, ptp;
  double totxs, adens, xs, absxs, f, Er, Emin, Emax, T;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check energy */

  CheckValue(FUNCTION_NAME, "E", "", E, ZERO, INFTY);

  /***************************************************************************/

  /***** Sample target nuclide ***********************************************/

  /* Check mode */

  if ((long)RDB[DATA_OPTI_MG_MODE] == YES)
    {
      /***********************************************************************/
  
      /***** Multi-group mode ************************************************/

      /* Pointer to energy groups */

      ptr = (long)RDB[DATA_COARSE_MG_PTR_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Find group index */

      if ((ng = GridSearch(ptr, E)) < 0)
	return -1;

      /* Check particle type */
	  
      if (type == PARTICLE_TYPE_NEUTRON)
	{
	  /* Get (macroscopic) total neutron cross section */
	  
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  totxs = MGXS(ptr, E, ng, id);
	      
	  /* Check implicit capture mode */
	      
	  if (RDB[DATA_OPT_IMPL_CAPT] == YES)
	    Die(FUNCTION_NAME, "Implicit capture not working in this mode");
	}
      else
	{
	  /* Get total gamma cross section */
	  
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  totxs = MGXS(ptr, E, ng, id);
	}
	  
      /* Sample fraction of total cross section */
	  
      totxs = RandF(id)*totxs;
	  
      /* Value may be zero if energy is outside the boundaries */
      
      if (totxs == 0.0)
	return -1;
      
      /* Pointer to material total */

      if (type == PARTICLE_TYPE_NEUTRON)
	{
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	}
      else
	{
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	}
      
      /* Get pointer to partial list */
	  
      lst1 = (long)RDB[ptr + REACTION_PTR_PARTIAL_LIST];
      CheckPointer(FUNCTION_NAME, "(lst1)", DATA_ARRAY, lst1);

      /* Avoid compiler warning */
	  
      xs = -1.0;
      rea = -1;
      rls1 = -1;

      /* Reset reaction pointer (rewind list) */

      rea = -1;

      /* Loop over reactions */
      
      while ((rls1 = NextReaction(lst1, &rea, &adens, &Emin, &Emax, id)) 
	     > VALID_PTR)
	{
	  /* Get microscopic cross section */
	  
	  xs = MGXS(rea, E, ng, id);
	  
	  /* Adjust total and check */
	  
	  if ((totxs = totxs - adens*xs) < 0.0)
	    break;
	}
    
      /* Check pointers */
	  
      if (rea < VALID_PTR)
	{
	  /* Print warning */
	  
	  Warn(FUNCTION_NAME, "Failed to sample target nuclide");

	  /* Return null */

	  return -1;
	}

      /* Pointer to nuclide */
      
      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

      /* Microscopic total cross section used for sampling nuclide */

      totxs = totxs;
      CheckValue(FUNCTION_NAME, "totxs", "", totxs, ZERO, INFTY);
      
      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Continuous-energy mode ******************************************/

      /* Check particle type */
	  
      if (type == PARTICLE_TYPE_NEUTRON)
	{
	  /* Check ETTM mode and get pointer to reaction channel */

	  if (ETTM == DOPPLER_MODE_MG_ETTM)
	    Die(FUNCTION_NAME, "Invalid ETTM mode");
	  else if (ETTM > DOPPLER_MODE_MG_ETTM)
	    {
	      /* Use continous-energy majorant */
	  
	      rea = (long)RDB[mat + MATERIAL_PTR_TMP_MAJORANTXS];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	    }
	  else
	    {
	      /* Use total neutron cross section */
	      
	      rea = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	    }

	  /* Get total cross section */

	  totxs = MacroXS(rea, E, id);

	  /* Check implicit capture mode and get absorption xs*/
	      
	  if (RDB[DATA_OPT_IMPL_CAPT] == YES)
	    {
	      /* Check ETTM */

	      if (ETTM > DOPPLER_MODE_PREPROCESS)
		Die(FUNCTION_NAME, "ETTM not allowed with implicit capture");

	      /* Get total abbsorption cross section */

	      ptr = (long)RDB[mat + MATERIAL_PTR_ABSXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      absxs = MacroXS(ptr, E, id);
	    }
	  else
	    {
	      /* Set absorption xs to zero */
	      
	      absxs = 0.0;
	    }
	}
      else
	{
	  /* Get total gamma cross section */
	      
	  rea = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  totxs = PhotonMacroXS(rea, E, id);
	  
	  /* Set absorption xs to zero */
	  
	  absxs = 0.0;
	}

      /* Calculate total cross section reduced by absorption */
      
      totxs = totxs - absxs;
      
      /* Check values */
      
      CheckValue(FUNCTION_NAME, "absxs", "", absxs, 0.0, INFTY);
      CheckValue(FUNCTION_NAME, "totxs", "", totxs, 0.0, INFTY);
	  
      /* Value may be zero if energy is outside the boundaries */
	  
      if (totxs == 0.0)
	return -1;
	  
      /* Sample fraction of total cross section */

      totxs = RandF(id)*totxs;
      
      /* Avoid compiler warning */
      
      nuc = -1;
      xs = -1.0;
      
      /* Get pointer to partial list */
      
      lst1 = (long)RDB[rea + REACTION_PTR_PARTIAL_LIST];
      CheckPointer(FUNCTION_NAME, "(lst1)", DATA_ARRAY, lst1);
      
      /* Reset reaction pointer (rewind list) */
      
      rea = -1;

      /* Loop over reactions */
	  
      while ((rls1 = NextReaction(lst1, &rea, &adens, &Emin, &Emax, id))
	     > VALID_PTR)
	{
	  /* Check reaction pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  
	  /* Pointer to nuclide */
	  
	  nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	  
	  /* Check particle type */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      /* Get total neutron cross section */
	      
	      xs = MicroXS(rea, E, id);
	      
	      /* Check implicit capture mode and get absorption xs*/
	      
	      if (RDB[DATA_OPT_IMPL_CAPT] == YES)
		{
		  ptr = (long)RDB[nuc + NUCLIDE_PTR_SUM_ABSXS];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  absxs = MicroXS(ptr, E, id);
		}
	      else
		{
		  /* Set absorption xs to zero */
		  
		  absxs = 0.0;
		}
	    }
	  else
	    {
	      /* Get total gamma cross section */
	      
	      xs = PhotonMicroXS(rea, E, id);
	      
	      /* Set absorption xs to zero */
	      
	      absxs = 0.0;
	    }	      
	  
	  /* Calculate total cross section reduced by absorption */
	  
	  xs = xs - absxs;
	  
	  /* Adjust total and check */
		  
	  if ((totxs = totxs - adens*xs) < 0.0)
	    break;
	}
      
      /* Check reaction pointer */
	  
      if (rea < VALID_PTR)
	{
	  /* Print warning */
	  
	  Warn(FUNCTION_NAME, "Failed to sample target nuclide");

	  /* Return null */

	  return -1;
	}

      /* Pointer to nuclide */
      
      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

      /* Microscopic total cross section used for sampling nuclide */

      totxs = xs;
      CheckValue(FUNCTION_NAME, "totxs", "", totxs, ZERO, INFTY);

      /***********************************************************************/
    }

  /***************************************************************************/

  /***** Handle rejections ***************************************************/

  /* Check nuclide, reaction and list pointers */

  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
  CheckPointer(FUNCTION_NAME, "(rls1)", DATA_ARRAY, rls1);

  /* Check total cross section */

  CheckValue(FUNCTION_NAME, "totxs", "", totxs, ZERO, INFTY);

  /* Check mode */

  if (ETTM > DOPPLER_MODE_PREPROCESS)
    {
      /* Temperature rejection, get material temperature */

      T = GetTemp(mat, id);

      /* Get total cross section */
	  
      rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      xs = DopMicroXS(mat, rea, E, &Er, T, id);
	  
      /* Calculate rejection factor */
	  
      f = xs*PotCorr(nuc, E, T*KELVIN)/totxs;

      /* Put energy and cross section for reaction sampling */

      E = Er;
      totxs = xs;
    }
  else if ((long)RDB[DATA_OPTI_MG_MODE] == YES)
    {
      /* Normal multi-group rejection, get total cross section */

      ptr = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      xs = MicroXS(ptr, E, id);

      /* Calculate rejection factor */

      f = xs/totxs;
      CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);

      /* Put cross section for reaction sampling */

      totxs = xs;
    }
  else 
    f = 1.0;

  /* Rejection sampling */
  
  if (RandF(id) < f)
    {
      /* Add to nuclide counter */
      
      if (rls1 > VALID_PTR)
	{	
	  ptr = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
	  CheckPointer(FUNCTION_NAME, "(ptr)",PRIVA_ARRAY, ptr);
	  AddPrivateData(ptr, 1.0, id);
	}		
      else
	Die(FUNCTION_NAME, "why is this null?");
    }
  else
    {
      /* Sample rejected */
      
      return -1;
    }        

  /***************************************************************************/

  /***** Sample reaction *****************************************************/

  /* Check nuclide pointer */

  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

  /* Check total cross section */

  CheckValue(FUNCTION_NAME, "totxs", "", totxs, ZERO, INFTY);

  /* Sample fraction of microscopic total cross section */
	  
  totxs = RandF(id)*totxs;
	  
  /* Pointer to partial reaction list */
	  
  lst0 = (long)RDB[nuc + NUCLIDE_PTR_SAMPLE_REA_LIST];
  CheckPointer(FUNCTION_NAME, "(lst0)", DATA_ARRAY, lst0);
  
  /* Loop over partials */
  
  i = 0;
  while ((rls1 = ListPtr(lst0, i++)) > VALID_PTR)
    {
      /* Pointer to reaction data */
	      
      rea = (long)RDB[rls1 + RLS_DATA_PTR_REA];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Get cross section */
      
      if (type == PARTICLE_TYPE_NEUTRON)
	xs = MicroXS(rea, E, id);
      else
	xs = PhotonMicroXS(rea, E, id);
      
      /* Adjust total and check */
      
      if ((totxs = totxs - xs) < 0.0)
	{
	  /* Add to counter */
	  
	  ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
	  CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
	  AddPrivateData(ptp, 1.0, id);
	  
	  /* Score analog reaction rate estimator */
	  
	  if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > VALID_PTR)
	    AddBuf(1.0, wgt, ptr, id, 0);
		  
	  /* Return reaction pointer */
		  
	  return rea;
	}
    }

  /* Check remaining total xs */

  if (totxs > 1E-12)  
    Die(FUNCTION_NAME, "Reaction sampling failed");
  else
    Warn(FUNCTION_NAME, "Reaction sampling failed");

  /* Reject sample */

  return -1;

  /***************************************************************************/





























      /* Check implicit capture mode */
      
      if ((RDB[DATA_OPT_IMPL_CAPT] == YES) && (type == PARTICLE_TYPE_NEUTRON))
	Die(FUNCTION_NAME, "Implicit capture not yet working");
      
      /* Pointer to total xs */
	  
      rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Check on-the-fly mode and temperature */
      
      if (((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_MG_ETTM) && (T > 0.0))
	{
	  /* Get total cross section at temperature-adjusted energy */
	  
	  totxs = DopMicroXS(mat, rea, E, &Er, T, id);
	  
	  /* Rejection probability with low-energy correction */
	  
	  f = totxs*PotCorr(nuc, E, T*KELVIN)/xs;
	}
      else
	{
	  /* Get total cross section */
	  
	  totxs = MicroXS(rea, E, id);
	  
	  /* Rejection probability */
	  
	  f = totxs/xs;
	  
	  /* Check */
	  
	  if (f > 1.0)
	    Die(FUNCTION_NAME, "f = %10f (%s E = %E)\n", f,
		GetText(nuc + NUCLIDE_PTR_NAME), E);
	  
	  /* Set relative energy */
	  
	  Er = E;
	}
      
      /* Rejection sampling */
      
      if (RandF(id) < f)
	{
	  /* Add to nuclide counter */
	  
	  if (rls1 > VALID_PTR)
	    {	
	      ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
	      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
	      AddPrivateData(ptp, 1.0, id);
	    }		
	}
      else
	{
	  /* Sample rejected */
	  
	  return -1;
	}
      
      /* Sample fraction of microscopic total cross section */
      
      totxs = totxs*RandF(id); 
      
      /* Pointer to partial reaction list */
      
      lst0 = (long)RDB[nuc + NUCLIDE_PTR_SAMPLE_REA_LIST];
      CheckPointer(FUNCTION_NAME, "(lst0)", DATA_ARRAY, lst0);
      
      /* Loop over partials */
      
      i = 0;
      while ((rls2 = ListPtr(lst0, i++)) > VALID_PTR)
	{
	  /* Pointer to reaction data */
	  
	  rea = (long)RDB[rls2 + RLS_DATA_PTR_REA];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  
	  /* Get cross section */
	  
	  xs = MicroXS(rea, Er, id);
	  
	  /* Adjust total and check */
	  
	  if ((totxs = totxs - xs) < 0.0)
	    {
	      /* Add to counter */
	      
	      ptp = (long)RDB[rls2 + RLS_DATA_PTR_COUNT];
	      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
	      AddPrivateData(ptp, 1.0, id);
	      
	      /* Score analog reaction rate estimator */
	      
	      if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > VALID_PTR)
		AddBuf(1.0, wgt, ptr, id, 0);
	      
	      /* Return reaction pointer */
	      
	      return rea;
	    }
	}
    }

  /***************************************************************************/

  /***** Continuous-energy ETTM for neutrons *********************************/

  else if (((long)RDB[mat + MATERIAL_CE_ETTM] == YES) && 
	   (type == PARTICLE_TYPE_NEUTRON))
    {
      /* Maximum number of resamples */

      N = 10;
      
      /* Resampling loop */
      
      for (n = 0; n < N; n++)
	{
	  /*******************************************************************/

	  /***** Sample target nuclide ***************************************/

	  /* Get continous-energy majorant */
	  
	  ptr = (long)RDB[mat + MATERIAL_PTR_TMP_MAJORANTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  
	  totxs = MacroXS(ptr, E, id);
	  CheckValue(FUNCTION_NAME, "totxs", "", totxs, 0.0, INFTY);

	  /* Check implicit capture mode */
	  
	  if (RDB[DATA_OPT_IMPL_CAPT] == YES)
	    Die(FUNCTION_NAME, "nje rabotayet");
	  
	  /* Value may be zero if energy is outside the boundaries */
	  
	  if (totxs == 0.0)
	    return -1;
	  
	  /* Sample fraction of total cross section */
	  
	  totxs = RandF(id)*totxs;
	  
	  /* Avoid compiler warning */
	  
	  nuc = -1;
	  xs = -1.0;
	  
	  /* Pointer to reaction list */
	  
	  ptr = (long)RDB[mat + MATERIAL_PTR_TMP_MAJORANTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Get pointer to partial list */
	  
	  lst1 = (long)RDB[ptr + REACTION_PTR_PARTIAL_LIST];
	  CheckPointer(FUNCTION_NAME, "(lst1)", DATA_ARRAY, lst1);

	  /* Reset reaction pointer (rewind list) */
	  
	  rea = -1;
	  
	  /* Loop over reactions */
	  
	  while ((rls1 = NextReaction(lst1, &rea, &adens, &Emin, &Emax, id))
		 > VALID_PTR)
	    {
	      /* Check reaction pointer */
	      
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	      
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	      
	      /* Get total neutron cross section */
	      
	      xs = MicroXS(rea, E, id);
	      
	      /* Adjust total and check */
	      
	      if ((totxs = totxs - adens*xs) < 0.0)
		{
		  /* Add to counter */
		  
		  if (rls1 > VALID_PTR)
		    {
		      ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
		      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		      AddPrivateData(ptp, 1.0, id);
		    }
		  
		  /* Break loop */
		  
		  break;
		}
	    }

	  /* Check pointers */
	  
	  if ((ptr < VALID_PTR) || (rea < VALID_PTR))
	    break;
	  
	  /*******************************************************************/

	  /***** ETTM rejection sampling *************************************/

	  /* Check nuclide and reaction list pointers */

	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	  CheckPointer(FUNCTION_NAME, "(rls1)", DATA_ARRAY, rls1);

	  /* Pointer to nuclide total cross section */
	  
	  rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	  /* Get total cross section at temperature-adjusted energy */
	  
	  totxs = DopMicroXS(mat, rea, E, &Er, T, id);
	  
	  /* Rejection probability with low-energy correction */
	  
	  f = totxs*PotCorr(nuc, E, T*KELVIN)/xs;

	  /* Rejection sampling */
      
	  if (RandF(id) < f)
	    {
	      /* Add to nuclide counter */
	      
	      if (rls1 > VALID_PTR)
		{	
		  ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		  AddPrivateData(ptp, 1.0, id);
		}		
	    }
	  else
	    {
	      /* Sample rejected */
	      
	      return -1;
	    }      

	  /*******************************************************************/

	  /***** Sample reaction *********************************************/

	  /* Sample fraction of microscopic total cross section */
	  
	  totxs = RandF(id)*totxs;
	  
	  /* Check nuclide pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	  /* Pointer to partial reaction list */
	  
	  lst0 = (long)RDB[nuc + NUCLIDE_PTR_SAMPLE_REA_LIST];
	  CheckPointer(FUNCTION_NAME, "(lst0)", DATA_ARRAY, lst0);
	  
	  /* Loop over partials */
	  
	  i = 0;
	  while ((rls1 = ListPtr(lst0, i++)) > VALID_PTR)
	    {
	      /* Pointer to reaction data */
	      
	      rea = (long)RDB[rls1 + RLS_DATA_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	      
	      /* Get cross section */
	      
	      xs = MicroXS(rea, Er, id);
	      	      
	      /* Adjust total and check */
	      
	      if ((totxs = totxs - xs) < 0.0)
		{
		  /* Add to counter */
		  
		  ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		  AddPrivateData(ptp, 1.0, id);
		  
		  /* Score analog reaction rate estimator */
		  
		  if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > 
		      VALID_PTR)
		    AddBuf(1.0, wgt, ptr, id, 0);
		  
		  /* Return reaction pointer */
		  
		  return rea;
		}
	    }
	  
	  /*******************************************************************/
    
	  /***** Something wrong *********************************************/
      
	  /* Sampling failed, break re-sampling loop if residual is large */
	  /* NOTE: Jollain nuklideilla (60144.03c @ JEFF-3.1.1 & JEF-2.2) */
	  /* reaktiot summautuu ures-alueella joskus nollaan vaikka total */
	  /* on ~1E-16. Voi olla että ongelma on numeerinen. */
	  
	  if (totxs > 1E-12)
	    break;
	  
	  /* Print warning */
	  
	  Warn(FUNCTION_NAME, "Reaction sampling failed (%s, E = %E)",
	       GetText(mat + MATERIAL_PTR_NAME), E);
	  
	  /* Check reaction lists */
	  
	  CheckReaListSum(mat, E, NO, id);
	  
	  /* Adjust energy and retry */
	  
	  E = (1.0 + (1.0 - RandF(id))*1E-6)*E;
	  
	  /* Check boundaries */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      if (E < RDB[DATA_NEUTRON_EMIN])
		E = (1.0 + RandF(id)*1E-6)*RDB[DATA_NEUTRON_EMIN];
	      else if (E > RDB[DATA_NEUTRON_EMAX])
		E = (1.0 - RandF(id)*1E-6)*RDB[DATA_NEUTRON_EMIN];
	    }
	  else
	    {
	      if (E < RDB[DATA_PHOTON_EMIN])
		E = (1.0 + RandF(id)*1E-6)*RDB[DATA_PHOTON_EMIN];
	      else if (E > RDB[DATA_PHOTON_EMAX])
		E = (1.0 - RandF(id)*1E-6)*RDB[DATA_PHOTON_EMIN];
	    }
	  
	  /*******************************************************************/
	}
      
      /* Maximum number of retries */
  
      fprintf(err, "\nReaction sampling failed after %ld / %ld attempts.\n", 
	      n, N);
      fprintf(err, "Remaining totxs: %E\n", totxs);
      
      /* Print reaction list data and terminate calculation */
      
      if (type == PARTICLE_TYPE_NEUTRON)
	CheckReaListSum(mat, E, YES, id);
      
      /***********************************************************************/
    }

  /***************************************************************************/

  /***** Continuous-energy mode **********************************************/

  else
    {
      /* Set maximum number of resamples */

      N = 10;
      
      /* Resampling loop */
      
      for (n = 0; n < N; n++)
	{
	  /*******************************************************************/

	  /***** Get pointers and total xs ***********************************/

	  /* Check particle type */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      /* Get total neutron cross section */
	      
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      totxs = MacroXS(ptr, E, id);

	      /* Check implicit capture mode and get absorption xs*/
	      
	      if (RDB[DATA_OPT_IMPL_CAPT] == YES)
		{
		  ptr = (long)RDB[mat + MATERIAL_PTR_ABSXS];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  absxs = MacroXS(ptr, E, id);
		}
	      else
		{
		  /* Set absorption xs to zero */
		  
		  absxs = 0.0;
		}
	    }
	  else
	    {
	      /* Get total gamma cross section */
	      
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      totxs = PhotonMacroXS(ptr, E, id);
	      
	      /* Set absorption xs to zero */

	      absxs = 0.0;
	    }

	  /* Calculate total cross section reduced by absorption */
	  
	  totxs = totxs - absxs;

	  /* Check values */

	  CheckValue(FUNCTION_NAME, "absxs", "", absxs, 0.0, INFTY);
	  CheckValue(FUNCTION_NAME, "totxs", "", totxs, 0.0, INFTY);
	  
	  /* Value may be zero if energy is outside the boundaries */
	  
	  if (totxs == 0.0)
	    return -1;
	  
	  /* Sample fraction of total cross section */

	  totxs = RandF(id)*totxs;
	  
	  /*******************************************************************/

	  /***** Sample target nuclide ***************************************/
	  
	  /* Avoid compiler warning */

	  nuc = -1;
	  xs = -1.0;

	  /* Pointer to material total */

	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    }
	  else
	    {
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    }

	  /* Get pointer to partial list */
	  
	  lst1 = (long)RDB[ptr + REACTION_PTR_PARTIAL_LIST];
	  CheckPointer(FUNCTION_NAME, "(lst1)", DATA_ARRAY, lst1);

	  /* Reset reaction pointer (rewind list) */

	  rea = -1;

	  /* Loop over reactions */
	  
	  while ((rls1 = NextReaction(lst1, &rea, &adens, &Emin, &Emax, id))
		 > VALID_PTR)
	    {
	      /* Check reaction pointer */

	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	      /* Pointer to nuclide */

	      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	      /* Check particle type */
	  
	      if (type == PARTICLE_TYPE_NEUTRON)
		{
		  /* Get total neutron cross section */
		  
		  xs = MicroXS(rea, E, id);
		      
		  /* Check implicit capture mode and get absorption xs*/
		  
		  if (RDB[DATA_OPT_IMPL_CAPT] == YES)
		    {
		      ptr = (long)RDB[nuc + NUCLIDE_PTR_SUM_ABSXS];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      absxs = MicroXS(ptr, E, id);
		    }
		  else
		    {
		      /* Set absorption xs to zero */
			  
		      absxs = 0.0;
		    }
		}
	      else
		{
		  /* Get total gamma cross section */
		      
		  xs = PhotonMicroXS(rea, E, id);
		  
		  /* Set absorption xs to zero */
		  
		  absxs = 0.0;
		}	      

	      /* Calculate total cross section reduced by absorption */
	  
	      xs = xs - absxs;

	      /* Adjust total and check */
		  
	      if ((totxs = totxs - adens*xs) < 0.0)
		{
		  /* Add to counter */
		  
		  if (rls1 > VALID_PTR)
		    {
		      ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
		      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		      AddPrivateData(ptp, 1.0, id);
		    }
		  
		  /* Break loop */
		  
		  break;
		}
	    }

	  /* Check pointers */
	  
	  if ((ptr < VALID_PTR) || (rea < VALID_PTR))
	    break;
	  
	  /*******************************************************************/

	  /***** Sample reaction *********************************************/
	  
	  /* Sample fraction of microscopic total cross section */
	  
	  totxs = RandF(id)*xs;
	  
	  /* Check nuclide pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	  /* Pointer to partial reaction list */
	  
	  lst0 = (long)RDB[nuc + NUCLIDE_PTR_SAMPLE_REA_LIST];
	  CheckPointer(FUNCTION_NAME, "(lst0)", DATA_ARRAY, lst0);
	  
	  /* Loop over partials */
	  
	  i = 0;
	  while ((rls1 = ListPtr(lst0, i++)) > VALID_PTR)
	    {
	      /* Pointer to reaction data */
	      
	      rea = (long)RDB[rls1 + RLS_DATA_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	      
	      /* Get cross section */
	      
	      if (type == PARTICLE_TYPE_NEUTRON)
		xs = MicroXS(rea, E, id);
	      else
		xs = PhotonMicroXS(rea, E, id);
	      
	      /* Adjust total and check */
	      
	      if ((totxs = totxs - xs) < 0.0)
		{
		  /* Add to counter */
		  
		  ptp = (long)RDB[rls1 + RLS_DATA_PTR_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		  AddPrivateData(ptp, 1.0, id);
		  
		  /* Score analog reaction rate estimator */
		  
		  if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > 
		      VALID_PTR)
		    AddBuf(1.0, wgt, ptr, id, 0);
		  
		  /* Return reaction pointer */
		  
		  return rea;
		}
	    }
	  
	  /*******************************************************************/
    
	  /***** Something wrong *********************************************/
      
	  /* Sampling failed, break re-sampling loop if residual is large */
	  /* NOTE: Jollain nuklideilla (60144.03c @ JEFF-3.1.1 & JEF-2.2) */
	  /* reaktiot summautuu ures-alueella joskus nollaan vaikka total */
	  /* on ~1E-16. Voi olla että ongelma on numeerinen. */
	  
	  if (totxs > 1E-12)
	    break;
	  
	  /* Print warning */
	  
	  Warn(FUNCTION_NAME, "Reaction sampling failed (%s, E = %E)",
	       GetText(mat + MATERIAL_PTR_NAME), E);
	  
	  /* Check reaction lists */
	  
	  CheckReaListSum(mat, E, NO, id);
	  
	  /* Adjust energy and retry */
	  
	  E = (1.0 + (1.0 - RandF(id))*1E-6)*E;
	  
	  /* Check boundaries */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      if (E < RDB[DATA_NEUTRON_EMIN])
		E = (1.0 + RandF(id)*1E-6)*RDB[DATA_NEUTRON_EMIN];
	      else if (E > RDB[DATA_NEUTRON_EMAX])
		E = (1.0 - RandF(id)*1E-6)*RDB[DATA_NEUTRON_EMIN];
	    }
	  else
	    {
	      if (E < RDB[DATA_PHOTON_EMIN])
		E = (1.0 + RandF(id)*1E-6)*RDB[DATA_PHOTON_EMIN];
	      else if (E > RDB[DATA_PHOTON_EMAX])
		E = (1.0 - RandF(id)*1E-6)*RDB[DATA_PHOTON_EMIN];
	    }
	  
	  /*******************************************************************/
	}
      
      /* Maximum number of retries */
  
      fprintf(err, "\nReaction sampling failed after %ld / %ld attempts.\n", 
	      n, N);
      fprintf(err, "Remaining totxs: %E\n", totxs);
      
      /* Print reaction list data and terminate calculation */
      
      if (type == PARTICLE_TYPE_NEUTRON)
	CheckReaListSum(mat, E, YES, id);
      
      /***********************************************************************/
    }
      
  /* No reaction sampled (virtual collision) */
  
  return -1;
}

/*****************************************************************************/
