/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : flushsrc.c                                     */
/*                                                                           */
/* Created:       2012/10/10 (JLe)                                           */
/* Last modified: 2012/10/10 (JLe)                                           */
/* Version:       2.1.9                                                      */
/*                                                                           */
/* Description: Removes all particles from source                            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FlushSrc:"

/*****************************************************************************/

void FlushSrc()
{
  long ptr, part;

  /* Get pointer to target buffer */

  ptr = (long)RDB[DATA_PART_PTR_SRC_READ];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  
  /* Check that target buffer is empty */

  if (ListSize(ptr) != 1)
    Die(FUNCTION_NAME, "Target buffer is not empty");

  /* Pointer to write buffer */
  
  ptr = (long)RDB[DATA_PART_PTR_SRC_WRITE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get pointer to last particle */

  ptr = LastItem(ptr);

  /* Loop over source and remove all */

  while(1 != 2)
    {
      /* Break if dummy */

      if ((long)RDB[ptr + PARTICLE_TYPE] == PARTICLE_TYPE_DUMMY)
	break;

      /* Check type */

      if ((long)RDB[ptr + PARTICLE_TYPE] != PARTICLE_TYPE_NEUTRON)
	Die(FUNCTION_NAME, "Invalid particle type");

      /* Pointers */

      part = ptr;
      ptr = PrevItem(ptr);

      /* Remove item */
      
      RemoveItem(part);      

      /* Put particle back to stack */

      ToStack(part, -1);
    }

  /* Get pointer to write buffer */

  ptr = (long)RDB[DATA_PART_PTR_SRC_WRITE];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Check that write buffer is empty */

  if (ListSize(ptr) != 1)
    Die(FUNCTION_NAME, "Write buffer is not empty");

}

/*****************************************************************************/
