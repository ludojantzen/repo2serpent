/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : inithistories.                                 */
/*                                                                           */
/* Created:       2011/04/01 (JLe)                                           */
/* Last modified: 2012/10/25 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: Initializes particle stacks, ques, source and bank for       */
/*              transport simulation                                         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "InitHistories:"

/*****************************************************************************/

void InitHistories()
{
  long ptr, loc0, id, np;

  fprintf(out, "Allocating memory for particle structures...\n");

  /***************************************************************************/

  /***** Create lists ********************************************************/

  /* Neutron stacks */

  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_NSTACK] = (double)loc0;

  for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_RNG_IDX] = -1.0;
    }

  /* Gamma stacks */

  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_GSTACK] = (double)loc0;

  for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_RNG_IDX] = -1.0;
    }

  /* Particle ques */

  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_QUE] = (double)loc0;

  for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_RNG_IDX] = -1.0;
    }

  /* Banks */
     
  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_BANK] = (double)loc0;

  for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_RNG_IDX] = -1.0;
    }

  /* Source (no division to threads) */
      
  ptr = NewItem(DATA_PART_PTR_SOURCE, PARTICLE_BLOCK_SIZE);
  WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
  WDB[ptr + PARTICLE_RNG_IDX] = -1.0;

  /***************************************************************************/

  /***** Allocate memory for neutrons and photons ****************************/

  if ((long)RDB[DATA_NEUTRON_TRANSPORT_MODE] == YES)
    {
      /* Number of particles */

      if (RDB[DATA_CRIT_POP] > RDB[DATA_SRC_POP])
	np = (long)(RDB[DATA_PART_NBUF_FACTOR]*RDB[DATA_CRIT_POP]);
      else
	np = (long)(RDB[DATA_PART_NBUF_FACTOR]*RDB[DATA_SRC_POP]);

      /* Allocate memory for neutrons */

      AllocParticleStack(PARTICLE_TYPE_NEUTRON, np);
    }

  if ((long)RDB[DATA_PHOTON_TRANSPORT_MODE] == YES)
    {
      /* Number of particles */
      
      np = (long)(RDB[DATA_PART_GBUF_FACTOR]*RDB[DATA_SRC_POP]);

      /* Allocate memory for neutrons */

      AllocParticleStack(PARTICLE_TYPE_GAMMA, np);
    }

  /* Everything is OK */

  fprintf(out, "OK.\n\n");
  
  /***************************************************************************/
}

/*****************************************************************************/
