/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : radgammasrc.c                                  */
/*                                                                           */
/* Created:       2012/03/29 (JLe)                                           */
/* Last modified: 2012/03/31 (JLe)                                           */
/* Version:       2.1.4                                                      */
/*                                                                           */
/* Description: Gamma source from radioactive decay                          */
/*                                                                           */
/* Comments: - Sampling of material and nuclide should probably be based on  */
/*             total gamma emission rate, rather than activity. I will       */
/*             change that once I understand what the "relative intensity"   */
/*             in the ENDF decay data really means, and how it can be used   */
/*             for setting the particle weight.                              */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "RadGammaSrc:"

/*****************************************************************************/

long RadGammaSrc(long src, double *E, double *wgt, long id)
{
  long mat, nuc, iso, ptr, ne, n;
  double act, adens, lambda;

  /* Check source pointer */

  CheckPointer(FUNCTION_NAME, "(src)", DATA_ARRAY, src);

  /* Get material pointer */

  mat = (long)RDB[src + SRC_PTR_RAD_SRC_MAT];

  /* Check if defined */

  if ((mat != -1) && (mat < VALID_PTR))
    return -1;

  /***************************************************************************/

  /***** Step 1: Sample material *********************************************/

  /* Check if source material is explicitly specified, if not, sample */
  /* material from all radioactive materials in the system. */

  if (mat == -1)
    {
      /* Get total activity */

      act = RDB[DATA_TOT_ACTIVITY];
      
      /* Check */
      
      if (act == 0.0)
	Error(src, "Decay source but total activity is zero");
      
      /* Sample fraction of total activity */
      
      act = act*RandF(id);
      
      /* Loop over materials */
      
      mat = (long)RDB[DATA_PTR_M0];
      while (mat > VALID_PTR)
	{
	  /* Check if specific activity is given but activity is not */
	  /* (this happens if volume is not defined) */

	  if ((RDB[mat + MATERIAL_SPEC_ACTIVITY] > 0.0) &&
	      (RDB[mat + MATERIAL_ACTIVITY] == 0.0))
	    Error(src, "Volume of material %s must be given for gamma source",
		  GetText(mat + MATERIAL_PTR_NAME));
	  
	  /* Compare to material activity */
	  
	  if ((act = act - RDB[mat + MATERIAL_ACTIVITY]) < 0.0)
	    break;
	  
	  /* Next material */
	  
	  mat = NextItem(mat);
	}
      
      /* Check material pointer */
      
      if (mat < VALID_PTR)
	Die(FUNCTION_NAME, "Unable to sample material");
    }
  else
    {
      /* Check material pointer */

      CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

      /* Check that material is radioactive */

      if (RDB[mat + MATERIAL_SPEC_ACTIVITY] == 0.0)
	Error(src, "Radioactivity source in non-radioactive material");
    }

  /***************************************************************************/

  /***** Step 2: Sample nuclide **********************************************/

  /* Avoid compiler warning */

  nuc = -1;

  /* Get material activity */
  
  act = RDB[mat + MATERIAL_SPEC_ACTIVITY]/1E+24;
  CheckValue(FUNCTION_NAME, "act", "", act, ZERO, INFTY);

  /* Sample fraction of material activity */

  act = act*RandF(id);

  /* Loop over composition */

  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > VALID_PTR)
    {
      /* Get atomic density */

      adens = RDB[iso + COMPOSITION_ADENS];

      /* Get pointer to nuclide data */

      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

      /* Get decay constant */

      lambda = RDB[nuc + NUCLIDE_LAMBDA];

      /* Compare to nuclide activity */

      if ((act = act - lambda*adens) < 0.0)
	break;

      /* Next isotope */

      iso = NextItem(iso);
    }

  /* Check nuclide pointer */

  if (nuc < VALID_PTR)
    Die(FUNCTION_NAME, "Unable to sample nuclide");
  
  /***************************************************************************/

  /***** Step 3: Sample emission energy **************************************/

  /* Get pointer to line spectra */

  ptr = (long)RDB[nuc + NUCLIDE_PTR_PHOTON_LINE_SPEC];

  /* Check pointer */

  if (ptr < VALID_PTR)
    Die(FUNCTION_NAME, "Nuclide %s has no photon spectra", 
	GetText(nuc + NUCLIDE_PTR_NAME));
  
  /* Get number of spectral lines */

  ne = ListSize(ptr);

  /* Sample line */

  n = (long)(RandF(id)*((double)ne));

  /* Get pointer to line */

  ptr = ListPtr(ptr, n);

  /* Get energy */

  *E = RDB[ptr + PHOTON_LINE_SPEC_E];

  /* Get intensity and use it as particle weight. This is where things most */
  /* likely start going wrong. This is the value that is stored in the ENDF */
  /* format decay data file. In addition to these (relative?) intensities,  */
  /* there is a "normalisation factor" (line 457 in readdecayfile.c), which */
  /* is currently not used for anything. Also, the list of lines used here  */
  /* contains both discrete gammas and discrete x-rays, and the factor is   */
  /* different for each type. Then there is something called "continuous    */
  /* spectrum", which I don't understand at all. */

  *wgt = RDB[ptr + PHOTON_LINE_SPEC_RI];

  /* Return material pointer */

  return mat;

  /***************************************************************************/
}

/*****************************************************************************/
