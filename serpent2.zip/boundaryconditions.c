/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : Boundaryconditions.c                           */
/*                                                                           */
/* Created:       2010/10/10 (JLe)                                           */
/* Last modified: 2013/04/04 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Reflective and periodic boundary conditions by coordinate    */
/*              transformations                                              */
/*                                                                           */
/* Comments: - From Serpent 1.1.12                                           */
/*                                                                           */
/*           - Luodaan erillinen aliohjelma reflection.c niille mieli-       */
/*             valtaisille heijastuksille?                                   */
/*                                                                           */
/*           - Toi cell pointteri on NULL lattice ja pbed -tyyppisille       */
/*             universumeille, mutta niiden ei pit�isi koskaan olla          */
/*             uloimpana, eli tarkistus OK.                                  */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "BoundaryConditions:"

/*****************************************************************************/

long BoundaryConditions(long *cell, double *x0, double *y0, double *z0, 
			double *u0, double *v0, double *w0, double E,
			double *wgt, long id)
{
  double x, y, z, u, v, w, px, py, pz, xc, yc, zc, x1, y1, a;
  long uni, nst, reg, surf, param, type, i, j, k, bc0, bc1, bc2, bc3, n, ptr;

  /* Check cell type */
  
  if ((long)RDB[*cell + CELL_TYPE] != CELL_TYPE_OUTSIDE)
    return NO;

  /* Check black boundary */

  if ((bc0 = (long)RDB[DATA_GEOM_BC0]) == BC_BLACK)
    return -1;

  /* Avoid compiler warning */

  surf = -1;

  /* Get pointer to universe */

  uni = (long)RDB[*cell + CELL_PTR_UNI];
  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

  /* Get universe type */

  type = (long)RDB[uni + UNIVERSE_TYPE];    

  /* Get pointer to surfaces */

  if (type == UNIVERSE_TYPE_NEST)
    {
      Die(FUNCTION_NAME, "Ne rabotaet");

      /* Pointer to nest */

      nst = (long)RDB[uni + UNIVERSE_PTR_NEST];
      CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

      /* Pointer to region */

      reg = (long)RDB[nst + NEST_PTR_REGIONS];
      CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

      /* Pointer to surface */
      
      surf = (long)RDB[reg + NEST_REG_PTR_SURF_OUT];
      CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);
    }
  else if (type == UNIVERSE_TYPE_CELL)
    {
      /* Pointer to surface list */

      surf = (long)RDB[*cell + CELL_PTR_SURF_LIST];
      CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);

      /* Get pointer to first surface (must be the boundary) */

      surf = (long)RDB[surf];
      CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);
    }
  else
    Die(FUNCTION_NAME, "Invalid level type");

  /* Compare with stored (jos t�� ei ikin� aiheuta ongelmia, niin */
  /* ton yll�olevan h�ss�k�n voi suoraan korvata) NOTE 24.3.2013: */
  /* ei toimi, outside voidaan m��ritell� useammaksi celliksi,    */
  /* eik� yhden ja saman ulkopinnan testaaminen silloin toimi.    */

  /*
  if (surf != (long)RDB[DATA_PTR_BC_SURF])
    Die(FUNCTION_NAME, "Mismatch in boundary surface %ld %ld %s\n",
	surf, (long)RDB[DATA_PTR_BC_SURF], GetText(surf + SURFACE_PTR_NAME));
  */

  /* Get surface type */

  type = (long)RDB[surf + SURFACE_TYPE];

  /* Get pointer to surface parameters */

  param = (long)RDB[surf + SURFACE_PTR_PARAMS];
  CheckPointer(FUNCTION_NAME, "(param)", DATA_ARRAY, param);

  /* Avoid compiler warning */
  
  px = 0.0;
  py = 0.0;
  pz = 0.0;
  
  /* Get partial boundary conditions */

  bc1 = RDB[DATA_GEOM_BC1];
  bc2 = RDB[DATA_GEOM_BC2];
  bc3 = RDB[DATA_GEOM_BC3];

  /* Get coordinates and direction cosines */

  x = *x0;
  y = *y0;
  z = *z0;
  u = *u0;
  v = *v0;
  w = *w0;

  /* Check type */
  
  if ((type = (long)RDB[surf + SURFACE_TYPE]) == SURF_SQC)
    {
      /***** Square lattice **************************************************/
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 2];
      py = 2.0*RDB[param + 2];
      pz = INFTY;
      
      /* Centered co-ordinates */
      
      x = x - RDB[param];
      y = y - RDB[param + 1];
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, x, y, z, &i, &j, &k, LAT_TYPE_S);  
      
      /* Check leakage from partial boundary conditions */
      
      if ((bc1 == BC_BLACK) && (i != 0))
	return -1;
      else if ((bc2 == BC_BLACK) && (j != 0))
	return -1;
      
      /* Calculate new position */
      
      x = x - i*px;
      y = y - j*py;
      
      /* Handle Reflection */
      
      if ((i != 0) && (bc1 == BC_REFLECTIVE))
	{
	  /* Odd number of x-surface crossings. Swap vectors. */
	  
	  x = -x;
	  u = -u;
	}		
      if ((j != 0) && (bc2 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  y = -y;
	  v = -v;
	}
      
      x = x + RDB[param];
      y = y + RDB[param + 1]; 
      
      /***********************************************************************/
    }
  else if (type == SURF_CUBE)
    {
      /***** Cubical 3D-lattice **********************************************/
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 3];
      py = 2.0*RDB[param + 3];
      pz = 2.0*RDB[param + 3];
      
      /* Centered co-ordinates */
	  
      x = x - RDB[param];
      y = y - RDB[param + 1];
      z = z - RDB[param + 2];
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, x, y, z, &i, &j, &k, LAT_TYPE_S);  
      
      /* Check leakage from partial boundary conditions */
      
      if ((bc1 == BC_BLACK) && (i != 0))
	return -1;
      else if ((bc2 == BC_BLACK) && (j != 0))
	return -1;
      else if ((bc3 == BC_BLACK) && (k != 0))
	return -1;
      
      /* Calculate new position */
      
      x = x - i*px;
      y = y - j*py;
      z = z - k*pz;
      
      /* Handle Reflection */
      
      if ((i != 0) && (bc1 == BC_REFLECTIVE))
	{
	  /* Odd number of x-surface crossings. Swap vectors. */
	  
	  x = -x;
	  u = -u;
	}		
      if ((j != 0) && (bc2 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  y = -y;
	  v = -v;
	}
      if ((k != 0) && (bc3 == BC_REFLECTIVE))
	{
	  /* Odd number of z-surface crossings. Swap vectors. */
	  
	  z = -z;
	  w = -w;
	}
      
      x = x + RDB[param];
      y = y + RDB[param + 1]; 
      z = z + RDB[param + 2]; 
      
      /***********************************************************************/
    }
  else if (type == SURF_CUBOID)
    {
      /***** Cuboidal 3D-lattice *********************************************/
      
      /* Get pitches */
      
      px = (RDB[param + 1] - RDB[param]);
      py = (RDB[param + 3] - RDB[param + 2]);
      pz = (RDB[param + 5] - RDB[param + 4]);
      
      /* Center co-ordinates */
      
      xc = (RDB[param] + RDB[param + 1])/2.0;
      yc = (RDB[param + 2] + RDB[param + 3])/2.0;
      zc = (RDB[param + 4] + RDB[param + 5])/2.0;
      
      /* Transfer co-ordinates */
      
      x = x - xc;
      y = y - yc;
      z = z - zc;
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, x, y, z, &i, &j, &k, LAT_TYPE_S);  
      
      /* Check leakage from partial boundary conditions */
      
      if ((bc1 == BC_BLACK) && (i != 0))
	return -1;
      else if ((bc2 == BC_BLACK) && (j != 0))
	return -1;
      else if ((bc3 == BC_BLACK) && (k != 0))
	return -1;
	    
      /* Calculate new position */
      
      x = x - i*px;
      y = y - j*py;
      z = z - k*pz;
      
      /* Handle Reflection */
      
      if ((i != 0) && (bc1 == BC_REFLECTIVE))
	{
	  /* Odd number of x-surface crossings. Swap vectors. */
	  
	  x = -x;
	  u = -u;
	}		
      if ((j != 0) && (bc2 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  y = -y;
	  v = -v;
	}
      if ((k != 0) && (bc3 == BC_REFLECTIVE))
	{
	  /* Odd number of z-surface crossings. Swap vectors. */
	  
	  z = -z;
	  w = -w;
	}
      
      /* Transfer co-ordinates */
      
      x = x + xc;
      y = y + yc;
      z = z + zc;
      
      /***********************************************************************/	
    }
  else if ((type == SURF_HEXYC) || (type == SURF_HEXYPRISM))
    {
      /***** Hexagonal Y-type lattice ****************************************/
	  
      /* Check that boundary conditions match */

      if (bc1 != bc2)
	Error(0, "Radial hexagonal boundary conditions must match");
	  
      /* Center co-ordinates */
      
      xc = RDB[param];
      yc = RDB[param + 1];
      zc = 0.0;
      
      /* Check */
      
      if ((xc != 0.0) || (yc != 0.0))
	Error(0, "Only centred hexagonal repeated boundaries allowed");
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 2];
      py = 2.0*RDB[param + 2];
      
      /* Z-pitch */
      
      if (type == SURF_HEXYPRISM)
	{
	  pz = (RDB[param + 4] - RDB[param + 3]);
	  zc = (RDB[param + 3] + RDB[param + 4])/2.0;
	}
      else
	pz = INFTY;
      
      /* Transfer */
      
      x = x - xc;
      y = y - yc;
      z = z - zc;
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, x, y, z, &i, &j, &k, LAT_TYPE_HY);

      /* Axial leakage */
      
      if ((bc3 == BC_BLACK) && (k != 0))
	return -1;
    
      /* Calculate new position */
      
      y = y - (i*py + COS60*j*py);
      x = x - SIN60*j*px;
      z = z - k*pz;

      /* Axial reflection */
      
      if ((bc3 == BC_REFLECTIVE) && (k != 0))
	{
	  z = -z;
	  w = -w;
	}
      
      /* Radial reflection */
      
      if ((bc1 == BC_REFLECTIVE) && (bc2 == BC_REFLECTIVE))
	{
	  if ((j == 0) && (i != 0))
	    {
	      y = -y;
	      v = -v;
	    }
	  else if ((i == 0) && (j != 0))
	    {
	      y1 = x;
	      x1 = y;
	      
	      y = x1*COS60 - y1*SIN60;
	      x = -x1*SIN60 - y1*COS60;
	      
	      y1 = u;
	      x1 = v;
	      
	      v = x1*COS60 - y1*SIN60;
	      u = -x1*SIN60 - y1*COS60;
	    }
	  else if ((i != 0) && (j != 0))
	    {
	      y1 = x;
	      x1 = y;
	      
	      y = x1*COS60 + y1*SIN60;
	      x = x1*SIN60 - y1*COS60;
	      
	      y1 = u;
	      x1 = v;
	      
	      v = x1*COS60 + y1*SIN60;
	      u = x1*SIN60 - y1*COS60;
	    }
	}		
      
      /* Transfer */
      
      x = x + xc;
      y = y + yc;
      z = z + zc;

      /***********************************************************************/
    }
  else if ((type == SURF_HEXXC) || (type == SURF_HEXXPRISM))
    {
      /***** Hexagonal X-type lattice ****************************************/

      /* Check that boundary conditions match */

      if (bc1 != bc2)
	Error(0, "Radial hexagonal boundary conditions must match");
      
      /* Center co-ordinates */
      
      xc = RDB[param];
      yc = RDB[param + 1];
      zc = 0.0;
	  
      /* Check */
      
      if ((xc != 0.0) || (yc != 0.0))
	Error(0, "Only centred hexagonal repeated boundaries allowed");
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 2];
      py = 2.0*RDB[param + 2];
      
      /* Z-pitch */
      
      if (type == SURF_HEXXPRISM)
	{
	  pz = (RDB[param + 4] - RDB[param + 3]);
	  zc = (RDB[param + 3] + RDB[param + 4])/2.0;
	}
      else
	pz = INFTY;
      
      /* Transfer */
      
      x = x - xc;
      y = y - yc;
      z = z - zc;
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, x, y, z, &i, &j, &k, LAT_TYPE_HX);

      /* Axial leakage */
      
      if ((bc3 == BC_BLACK) && (k != 0))
	return -1;
      
      /* Calculate new position */
      
      x = x - (i*px + COS60*j*px);
      y = y - SIN60*j*py;
      z = z - k*pz;

      /* Axial reflection */
      
      if ((bc3 == BC_REFLECTIVE) && (k != 0))
	{
	  z = -z;
	  w = -w;
	}
      
      /* Radial reflection */

      if ((bc1 == BC_REFLECTIVE) && (bc2 == BC_REFLECTIVE))
	{
	  if ((j == 0) && (i != 0))
	    {
	      x = -x;
	      u = -u;
	    }
	  else if ((i == 0) && (j != 0))
	    {
	      x1 = x;
	      y1 = y;
	      
	      x = x1*COS60 - y1*SIN60;
	      y = -x1*SIN60 - y1*COS60;
	      
	      x1 = u;
	      y1 = v;
	      
	      u = x1*COS60 - y1*SIN60;
	      v = -x1*SIN60 - y1*COS60;
	    }
	  else if ((i != 0) && (j != 0))
	    {
	      x1 = x;
	      y1 = y;
	      
	      x = x1*COS60 + y1*SIN60;
	      y = x1*SIN60 - y1*COS60;
	      
	      x1 = u;
	      y1 = v;
	      
	      u = x1*COS60 + y1*SIN60;
	      v = x1*SIN60 - y1*COS60;
	    }
	}		
      
      /* Transfer */
      
      x = x + xc;
      y = y + yc;
      z = z + zc;
      
      /***********************************************************************/
    }
  else
    {
      /* Other surface types treated as black boundaries. */
      
      return -1;
    }

  /* Calculate number of crossings */

  n = abs(i) + abs(j) + abs(k);
  
  /* Check that lattice indexes have been changed */

  if (n == 0)
    {
      /* Check if universe symmetries are defined */

      if ((long)RDB[DATA_PTR_SYM0] < VALID_PTR)
	Die(FUNCTION_NAME, "No change in lattice indexes (cell %s at %E %E %E",
	    GetText(*cell + CELL_PTR_NAME), *x0, *y0, *z0);
      else
	Error(0, "Universe symmetry not compatible with boundary conditions");
    }

  /* Check albedo and adjust weight (weight is set to -1 in plotter mode) */

  if (((a = RDB[DATA_GEOM_ALBEDO]) != 1.0) && (*wgt > 0.0))
    {
      /* Score albedo leak rate (NOTE: This is scored for both photons */
      /* and neutrons) */

      Die(FUNCTION_NAME, "Noi painot pitaa kattoa uusiksi tracking.c:ssa");

      ptr = (long)RDB[RES_ALB_NEUTRON_LEAKRATE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(1.0 - n*a, *wgt, ptr, id, 0);

      /* Adjust weight */

      *wgt = *wgt*n*a;
    }

  /* Potential numerical problems */
  
  if ((fabs(px/2.0 - x) < 1E-15) || (fabs(py/2.0 - y) < 1E-15) || 
      (fabs(pz/2.0 - z) < 1E-15))
    Die(FUNCTION_NAME, "Infinite loop? (position too close to boudary)"); 

  /* Find location (ei testata koska muuten kosahtaa plotterimoodissa) */

  *cell = WhereAmI(x, y, z, u, v, w, id);

  /* Put coordinates and direction cosines */

  *x0 = x;
  *y0 = y;
  *z0 = z;
  *u0 = u;
  *v0 = v;
  *w0 = w; 

  /* Exit subroutine */
  
  return YES;
}

/*****************************************************************************/
