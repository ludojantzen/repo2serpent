/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readinterface.c                                */
/*                                                                           */
/* Created:       2012/02/14 (JLe)                                           */
/* Last modified: 2013/04/03 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Reads multi-physics interfaces                               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReadInterface:"

/*****************************************************************************/

void ReadInterface()
{
  long loc0, loc1, loc2, loc3, msh, ptr, type, dim, np, nc, nf, n, m;
  long nx, ny, nz, nd, i, j, k, cell, surf, idx, nr, nax;
  double xmin, xmax, ymin, ymax, zmin, zmax, dmax, Tmax, Tmin, rad, **dat;
  double x, y, z, d, T, ex, *lims, rmin, rmax, r1, r2;
  char tmpstr[MAX_STR];
  FILE *fp;

  /* Reset index */

  idx = 0;

  /* Loop over interfaces */

  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /***********************************************************************/

      /***** Common data *****************************************************/

      /* Test file format */
      
      TestDOSFile(GetText(loc0 + IFC_PTR_INPUT_FNAME));
    
      /* Open file for reading */
      
      if ((fp = fopen(GetText(loc0 + IFC_PTR_INPUT_FNAME), "r")) == NULL)
	Error(loc0, "Multi-physics interface file \"%s\" does not exist",
	      GetText(loc0 + IFC_PTR_INPUT_FNAME));

      /* Read interface type */

      if (fscanf(fp, "%ld", &type) == EOF)
	Die(FUNCTION_NAME, "fscanf error");
      
      /* Check type */

      if (type == IFC_TYPE_FUEP)
	{
	  /* Interface to fuel performance codes */

	  WDB[loc0 + IFC_TYPE] = (double)type;
	  WDB[loc0 + IFC_PTR_MAT] = NULLPTR;
	  WDB[loc0 + IFC_CALC_OUTPUT] = (double)YES;

	  /* Reset output flag to avoid going to next loop */

	  n = NO;

	  /* Read output file name */

	  if (fscanf(fp, "%s", tmpstr) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  WDB[loc0 + IFC_PTR_OUTPUT_FNAME] = (double)PutText(tmpstr);
	}
      else
	{
	  /* Read material and output flag */

	  if (fscanf(fp, "%s %ld", tmpstr, &n) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  WDB[loc0 + IFC_TYPE] = (double)type;
	  WDB[loc0 + IFC_PTR_MAT] = (double)PutText(tmpstr);
	  WDB[loc0 + IFC_CALC_OUTPUT] = (double)n;
	}

      /* Put index */

      WDB[loc0 + IFC_IDX] = (double)(++idx);

      /* Read output file name and axial binning for output */

      if (n == YES)
	{
	  /* Check type */
	  
	  if (type == IFC_TYPE_CGNS)
	    {
	      /* Read only file name for CGNS type */

	      if (fscanf(fp, "%s", tmpstr) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      WDB[loc0 + IFC_PTR_OUTPUT_FNAME] = (double)PutText(tmpstr);
	    }
	  else
	    {
	      /* Read file name and binning for other types */

	      if (fscanf(fp, "%s %ld %lf %lf %ld", tmpstr, &nz, &zmin, 
			 &zmax, &nr) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      WDB[loc0 + IFC_PTR_OUTPUT_FNAME] = (double)PutText(tmpstr);
	      
	      /* Put number of axial zones */
	      
	      if (nz < 1)
		Error(loc0, "Error in number of axial zones");
	      else
		WDB[loc0 + IFC_NZ] = (double)nz;
	      
	      /* Put axial limits */

	      if (zmin < zmax)
		{
		  WDB[loc0 + IFC_ZMIN] = zmin;
		  WDB[loc0 + IFC_ZMAX] = zmax;
		}
	      else
		Error(loc0, "Error in axial boundaries");

	      /* Put number of radial zones */
	      
	      if (nr < 1)
		Error(loc0, "Error in number of radial zones");
	      else
		WDB[loc0 + IFC_NR] = (double)nr;
	    }
	}

      /***********************************************************************/

      /* Check type */

      if (type == IFC_TYPE_PT_AVG)
	{
	  /*******************************************************************/

	  /***** Average of points *******************************************/
	  
	  /* Reset limiting values */

	  Tmax = -INFTY;
	  Tmin = INFTY;
	  dmax = 0.0;

	  /* Reset mesh boundaries */
      
	  xmin =  INFTY;
	  xmax = -INFTY;
	  ymin =  INFTY;
	  ymax = -INFTY;
	  zmin =  INFTY;
	  zmax = -INFTY;

	  /* Read dimension, exclusion radius and exponent (TODO: Tohon */
	  /* ne muut tyypit: eksponentiaali, ym.) */

	  if (fscanf(fp, "%ld %lf %lf", &dim, &rad, &ex) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  /* Put dimension */

	  if ((dim < 1) || (dim > 3))
	    Error(loc0, "Error in dimension");
	  else
	    WDB[loc0 + IFC_DIM] = (double)dim;

	  /* Exclusion radius */
	  
	  if (rad > 0.0)
	    WDB[loc0 + IFC_EXCL_RAD] = rad;
	  else
	    Error(loc0, "Invalid exclusion radius entered");

	  /* Exponent */
	  
	  WDB[loc0 + IFC_EXP] = ex;

	  /* Read number of points */
	  
	  if (fscanf(fp, "%ld", &np) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  /* Check number of points */
	  
	  if (np > 0)
	    WDB[loc0 + IFC_NP] = (double)np;
	  else
	    Error(loc0, "Invalid number of points entered");
      
	  /* Loop over points and read data */
      
	  for (n = 0; n < np; n++)
	    {
	      /* Avoid compiler warning */
	      
	      x = 0.0;
	      y = 0.0;
	      z = 0.0;
	      
	      /* Read values */
	      
	      if (dim == 3)
		{
		  if (fscanf(fp, "%lf %lf %lf %lf %lf", 
			     &x, &y, &z, &d, &T) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");
		}
	      else if (dim == 2)
		{
		  if (fscanf(fp, "%lf %lf %lf %lf", &x, &y, &d, &T) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");		   
		}
	      else if (dim == 1)
		{
		  if (fscanf(fp, "%lf %lf %lf", &z, &d, &T) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");
		}
	      else
		Die(FUNCTION_NAME, "error in dimension");
	  
	      /* Allocate memory for point */
	      
	      loc1 = NewItem(loc0 + IFC_PTR_POINTS, IFC_PT_LIST_BLOCK_SIZE);
	      
	      /* Put data */

	      WDB[loc1 + IFC_PT_DF] = d;
	      WDB[loc1 + IFC_PT_TMP] = T;
	      WDB[loc1 + IFC_PT_X] = x;
	      WDB[loc1 + IFC_PT_Y] = y;
	      WDB[loc1 + IFC_PT_Z] = z;

	      /* Compare to limits */

	      if (x - rad < xmin)
		xmin = x - rad;
	      if (x + rad> xmax)
		xmax = x + rad;
	      
	      if (y - rad < ymin)
		ymin = y - rad;
	      if (y + rad > ymax)
		ymax = y + rad;
	      
	      if (z - rad < zmin)
		zmin = z - rad;
	      if (z + rad > zmax)
		zmax = z + rad;
	      
	      if (fabs(d) > fabs(dmax))
		dmax = d;
	      
	      if (T > Tmax)
		Tmax = T;

	      if (T < Tmin)
		Tmin = T;
	    }

	  /* Put maximum density and temperature */

	  WDB[loc0 + IFC_MAX_DENSITY] = dmax;
	  WDB[loc0 + IFC_MAX_TEMP] = Tmax;
	  WDB[loc0 + IFC_MIN_TEMP] = Tmin;
  
	  /* Put boundaries */

	  WDB[loc0 + IFC_MESH_XMIN] = xmin;
	  WDB[loc0 + IFC_MESH_XMAX] = xmax;
	  WDB[loc0 + IFC_MESH_YMIN] = ymin;
	  WDB[loc0 + IFC_MESH_YMAX] = ymax;
	  WDB[loc0 + IFC_MESH_ZMIN] = zmin;
	  WDB[loc0 + IFC_MESH_ZMAX] = zmax;
	  
	  /* Set ETTM on */

	  if (Tmax > 0.0)
	    WDB[DATA_ETTM_MODE] = (double)ETTM_MODE_CE;

	  /*******************************************************************/
	}
      else if (type == IFC_TYPE_MESH)
	{
	  /*******************************************************************/

	  /***** Mesh-based **************************************************/

	  /* Reset limiting values */

	  Tmax = -INFTY;
	  Tmin = INFTY;
	  dmax = 0.0;
	  
	  /* Get mesh type */

	  if (fscanf(fp, "%ld", &n) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");
	  
	  /* Avoid compiler warning */

	  lims = NULL;

	  /* Check type */

	  if (n == MESH_TYPE_CARTESIAN)
	    {
	      /* Cartesian, allocate memory for limits */

	      lims = (double *)Mem(MEM_ALLOC, 6, sizeof(double));

	      /* Read data */
	  
	      if (fscanf(fp, "%ld %lf %lf %ld %lf %lf %ld %lf %lf",
			 &nx, &lims[0], &lims[1], &ny, &lims[2], &lims[3], 
			 &nz, &lims[4], &lims[5]) == EOF)
		Die(FUNCTION_NAME, "fscanf error");
	    }
	  else if (n == MESH_TYPE_ORTHOGONAL)
	    {
	      /* Orthogonal mesh */

	      if (fscanf(fp, "%ld %ld %ld", &nx, &ny, &nz) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      /* Allocate memory */

	      lims = (double *)Mem(MEM_ALLOC, nx + ny + nz + 3, sizeof(double));

	      /* Read data (NOTE: noiden järjestys pitäis tarkistaa) */
	      
	      for (i = 0; i < nx + ny + nz + 3; i++)
		if (fscanf(fp, "%lf", &lims[i]) == EOF)
		  Die(FUNCTION_NAME, "fscanf error");
	    }
	  else
	    Error(loc0, "Invalid mesh type %ld", n);

	  /* Calculate number of values */

	  np = nx*ny*nz;

	  /* Check */

	  if (np < 1)
	    Error(loc0, "Zero mesh size");
      
	  /* Create mesh structure */
      
	  msh = CreateMesh(n, MESH_CONTENT_PTR, nx, ny, nz, lims);
	  
	  /* Put pointer */
      
	  WDB[loc0 + IFC_PTR_SEARCH_MESH] = (double)msh;

	  /* Loop over points and read data */
      
	  n = 0;

	  for (k = 0; k < nz; k++)
	    for (j = 0; j < ny; j++)
	      for (i = 0; i < nx; i++)
		{
		  /* Read values */
		  
		  if (fscanf(fp, "%lf %lf", &d, &T) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");

		  /* Compare to limits */
		  
		  if (fabs(d) > fabs(dmax))
		    dmax = d;
		  
		  if (T > Tmax)
		    Tmax = T;

		  if (T < Tmin)
		    Tmin = T;
		  
		  /* Get mesh pointer */
		      
		  ptr = (long)RDB[msh + MESH_PTR_PTR] + n;
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  /* Allocate memory for data */
	      
		  loc1 = NewItem(ptr, IFC_MSH_LIST_BLOCK_SIZE);
		      
		  /* Put data */
		  
		  WDB[loc1 + IFC_MSH_DF] = d;
		  WDB[loc1 + IFC_MSH_TMP] = T;
		  
		  /* Update index */
		  
		  n++;
		}

	  /* Put maximum density and temperature */

	  WDB[loc0 + IFC_MAX_DENSITY] = dmax;
	  WDB[loc0 + IFC_MAX_TEMP] = Tmax;
	  WDB[loc0 + IFC_MIN_TEMP] = Tmin;

	  /* Set ETTM on */

	  if (Tmax > 0.0)
	    WDB[DATA_ETTM_MODE] = (double)ETTM_MODE_CE;
	  
	  /* Free allocated memory */

	  Mem(MEM_FREE, lims);

	  /*******************************************************************/
	}
      else if (type == IFC_TYPE_FUNC)
	{
	  /*******************************************************************/

	  /***** Functional density distribution *****************************/

	  /* Get number of parameters */
	  
	  if (fscanf(fp, "%ld", &np) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  /* Check */

	  if (np < 1)
	    Error(loc0, "Invalid number of parameters");
	  else
	    WDB[loc0 + IFC_FUNC_NP] = (double)np;

	  /* Allocate memory for parameters */

	  ptr = ReallocMem(DATA_ARRAY, np);
	  
	  /* Put pointer */

	  WDB[loc0 + IFC_FUNC_PTR_PARAM] = (double)ptr;
	  
	  /* Loop over parameters */
      
	  for (n = 0; n < np; n++)
	    {
	      /* Get value */
	      
	      if (fscanf(fp, "%lf", &d) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      /* Put data */

	      WDB[ptr++] = d;
	    }

	  /* Reset maximum density to avoid error in processinterface.c */
	  /* (value is not used for anything) */

	  WDB[loc0 + IFC_MAX_DENSITY] = 0.0;

	  /*******************************************************************/
	}
      else if (type == IFC_TYPE_CGNS)
	{
	  /*******************************************************************/

	  /***** CGNS Mesh ***************************************************/

	  /* Reset mesh boundaries */
	  
	  xmin =  INFTY;
	  xmax = -INFTY;
	  ymin =  INFTY;
	  ymax = -INFTY;
	  zmin =  INFTY;
	  zmax = -INFTY;

	  /* Read number of points */

	  if (fscanf(fp, "%ld", &nd) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  /* Allocate memory for data */
	  
	  dat = (double **)Mem(MEM_ALLOC, 3, sizeof(double *));
      
	  for(n = 0; n < 3; n++)
	    dat[n] = (double *)Mem(MEM_ALLOC, nd, sizeof(double));

	  /* Read points */

	  for (n = 0; n < nd; n++)
	    {
	      /* Read coordinates */

	      if (fscanf(fp, "%lf %lf %lf", &x, &y, &z) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      /* Put data */

	      dat[0][n] = x;
	      dat[1][n] = y;
	      dat[2][n] = z;

	      /* Compare to limits */

	      if (x < xmin)
		xmin = x;
	      if (x> xmax)
		xmax = x;
	      
	      if (y < ymin)
		ymin = y;
	      if (y > ymax)
		ymax = y;
	      
	      if (z < zmin)
		zmin = z;
	      if (z > zmax)
		zmax = z;
	    }	      

	  /* Put boundaries */

	  xmin = -185;
	  xmax =  185;
	  ymin = -185;
	  ymax =  185;
	  zmin = 0.0;
	  zmax = 370;

	  WDB[loc0 + IFC_MESH_XMIN] = xmin;
	  WDB[loc0 + IFC_MESH_XMAX] = xmax;
	  WDB[loc0 + IFC_MESH_YMIN] = ymin;
	  WDB[loc0 + IFC_MESH_YMAX] = ymax;
	  WDB[loc0 + IFC_MESH_ZMIN] = zmin;
	  WDB[loc0 + IFC_MESH_ZMAX] = zmax;

	  /* Read number of cells */

	  if (fscanf(fp, "%ld", &nc) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  /* Reset limiting values */

	  Tmax = -INFTY;
	  Tmin = INFTY;
	  dmax = 0.0; 

	  /* Loop over cells */

	  for (n = 0; n < nc; n++)
	    {
	      /* Allocate memory for CGNS cell */
		  
	      loc1 = NewItem(loc0 + IFC_PTR_CGNS, IFC_CGNS_LIST_BLOCK_SIZE);

	      /* Put index */

	      WDB[loc1 + IFC_CGNS_IDX] = (double)(n + 1);

	      /* Read density, temperature, number of surfaces and output */
	      /* flag. */

	      if (fscanf(fp, "%lf %lf %ld %ld", &d, &T, &nf, &i) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      /* Put values */

	      WDB[loc1 + IFC_CGNS_DF] = d;
	      WDB[loc1 + IFC_CGNS_TMP] = T;
	      WDB[loc1 + IFC_CGNS_STAT_IDX] = (double)i;

	      /* Compare to maxima */

	      if (fabs(d) > fabs(dmax))
		dmax = d;
	      
	      if (T > Tmax)
		Tmax = T;

	      if (T < Tmin)
		Tmin = T;

	      /* Create (geometry) cell */

	      cell = NewItem(loc1 + IFC_CGNS_PTR_CELL, CELL_BLOCK_SIZE);

	      /* Reset surface list pointer */
	  
	      loc2 = -1;

	      /* Reset cell boundaries */

	      xmin =  INFTY;
	      xmax = -INFTY;
	      ymin =  INFTY;
	      ymax = -INFTY;
	      zmin =  INFTY;
	      zmax = -INFTY;

	      /* Loop over facets */
	      
	      for (i = 0; i < nf; i++)
		{
		  /* Create new item in cell intersection list */
	  
		  loc2 = NewItem(cell + CELL_PTR_SURF_INSC, 
				 CELL_INSC_BLOCK_SIZE);
		  		  
		  /* Put side */
	  
		  WDB[loc2 + CELL_INSC_SIDE] = -1.0;
	  
		  /* Allocate memory for counter from private array */
	  
		  WDB[loc2 + CELL_INSC_PTR_OUT_COUNT] =
		    (double)AllocPrivateData(1, PRIVA_ARRAY);

		  /* Create surface */

		  surf = NewItem(DATA_PTR_S0, SURFACE_BLOCK_SIZE);
		  WDB[loc2 + CELL_INSC_PTR_SURF] = (double)surf;

		  /* put surface type and number of parameters */

		  WDB[surf + SURFACE_TYPE] = (double)SURF_PLANE;
		  WDB[surf + SURFACE_N_PARAMS] = 9.0;
		  
		  /* Set used-flag */

		  SetOption(surf + SURFACE_OPTIONS, OPT_USED);

		  /* Allocate memory for parameters */

		  ptr = ReallocMem(DATA_ARRAY, 9);
		  WDB[surf + SURFACE_PTR_PARAMS] = (double)ptr;

		  /* Read number of points */

		  if (fscanf(fp, "%ld", &np) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");

		  /* Check */

		  if (np < 3)
		    Die(FUNCTION_NAME, "Not enough points");

		  /* Read points */
	
		  for (j = 0; j < np; j++)
		    {
		      /* Read point index */

		      if (fscanf(fp, "%ld", &k) == EOF)
			Die(FUNCTION_NAME, "fscanf error");

		      /* Check */

		      if ((k < 1) || (k > nd))
			Die(FUNCTION_NAME, "Invalid point index %ld", k);
		      
		      /* Get point */

		      x = dat[0][k - 1];
		      y = dat[1][k - 1];
		      z = dat[2][k - 1];

		      /* Put surface parameters */

		      if (j < 3)
			{
			  WDB[ptr++] = x;
			  WDB[ptr++] = y;
			  WDB[ptr++] = z;
			}

		      /* Compare to limits */

		      if (x < xmin)
			xmin = x;
		      if (x> xmax)
			xmax = x;
		      
		      if (y < ymin)
			ymin = y;
		      if (y > ymax)
			ymax = y;
		      
		      if (z < zmin)
			zmin = z;
		      if (z > zmax)
			zmax = z;
		    }
		}
	     
	      /* Check pointer and close list */
	      
	      if (loc2 < VALID_PTR)
		Die(FUNCTION_NAME, "No surfaces");
	      else
		CloseList(loc2);

	      /* Put cell boundaries */
	      
	      WDB[loc1 + IFC_CGNS_XMIN] = xmin;
	      WDB[loc1 + IFC_CGNS_XMAX] = xmax;
	      WDB[loc1 + IFC_CGNS_YMIN] = ymin;
	      WDB[loc1 + IFC_CGNS_YMAX] = ymax;
	      WDB[loc1 + IFC_CGNS_ZMIN] = zmin;
	      WDB[loc1 + IFC_CGNS_ZMAX] = zmax;
	    }
	  
	  /* Put maximum temperature and density */
	  
	  WDB[loc0 + IFC_MAX_DENSITY] = dmax;
	  WDB[loc0 + IFC_MAX_TEMP] = Tmax;
	  WDB[loc0 + IFC_MIN_TEMP] = Tmin;

	  /* Free temporary data */
      
	  for(n = 0; n < 3; n++)
	    Mem(MEM_FREE, dat[n]);
	  
	  Mem(MEM_FREE, dat);
	  dat = NULL;

	  /* Set ETTM on */

	  if (Tmax > 0.0)
	    WDB[DATA_ETTM_MODE] = (double)ETTM_MODE_CE;

	  /*******************************************************************/
	}
      else if (type == IFC_TYPE_FUEP)
	{
	  /*******************************************************************/

	  /***** Interface to fuel performance codes *************************/

	  /* Read number of pins */

	  if (fscanf(fp, "%ld", &np) == EOF)
	    Die(FUNCTION_NAME, "fscanf error");

	  /* Loop */

	  for (i = 0; i < np; i++)
	    {
	      /* Allocate memory for structure */
	      
	      loc1 = NewItem(loc0 + IFC_PTR_FUEP, IFC_FUEP_LIST_BLOCK_SIZE);
	  
	      /* Read universe */
	      
	      if (fscanf(fp, "%s", tmpstr) == EOF)
		Die(FUNCTION_NAME, "fscanf error");
	      
	      /* Put value */

	      WDB[loc1 + IFC_FUEP_PTR_UNI] = (double)PutText(tmpstr);

	      /* Read output meshing */

	      if (fscanf(fp, "%ld %lf %lf %ld %lf %lf", &nz, &zmin, &zmax, 
			 &nr, &rmin, &rmax) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      /* Put values */

	      WDB[loc1 + IFC_FUEP_OUT_NZ] = (double)nz;
	      WDB[loc1 + IFC_FUEP_OUT_ZMIN] = zmin;
	      WDB[loc1 + IFC_FUEP_OUT_ZMAX] = zmax;
	      WDB[loc1 + IFC_FUEP_OUT_NR] = (double)nr;
	      WDB[loc1 + IFC_FUEP_OUT_RMIN] = rmin;
	      WDB[loc1 + IFC_FUEP_OUT_RMAX] = rmax;
	      
	      /* Reset pointers (allocinterfacestat.c tarkistaa että jos */
	      /* nää pointterit on null, niin jako generoidaan noista    */
	      /* annetuista minimi-ja maksimiarvoista. Jos jaon lukee    */
	      /* suoraan inputista, niin se pitää tallettaa tässä. Toi   */
	      /* säde annetaan silloin suoraan neliönä.) */

	      WDB[loc1 + IFC_FUEP_OUT_PTR_Z] = NULLPTR;
	      WDB[loc1 + IFC_FUEP_OUT_PTR_R2] = NULLPTR;

	      /* Read number of axial zones */

	      if (fscanf(fp, "%ld", &nax) == EOF)
		Die(FUNCTION_NAME, "fscanf error");

	      /* Put value */

	      WDB[loc1 + IFC_FUEP_N_AX] = (double)nax;

	      /* Loop over zones */
	      
	      for (n = 0; n < nax; n++)
		{
		  /* Allocate memory */
		  
		  loc2 = NewItem(loc1 + IFC_FUEP_PTR_AX, 
				 IFC_FUEP_AX_BLOCK_SIZE);

		  /* Read minimum and maximum height */
		  
		  if (fscanf(fp, "%lf %lf", &zmin, &zmax) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");

		  /* Put values */

		  WDB[loc2 + IFC_FUEP_AX_ZMIN] = zmin;
		  WDB[loc2 + IFC_FUEP_AX_ZMAX] = zmax;

		  /* Read number of radial zones */

		  if (fscanf(fp, "%ld", &nr) == EOF)
		    Die(FUNCTION_NAME, "fscanf error");

		  /* Put value */

		  WDB[loc2 + IFC_FUEP_AX_N_RAD] = nr;

		  /* Loop over radial zones */

		  for (m = 0; m < nr; m++)
		    {
		      /* Allocate memory */
		  
		      loc3 = NewItem(loc2 + IFC_FUEP_AX_PTR_RAD, 
				     IFC_FUEP_RAD_BLOCK_SIZE);

		      /* Read material name, density, temperature and radius */
		    
		      if (fscanf(fp, "%s %lf %lf %lf",tmpstr, &r1, &r2, &T) 
			  == EOF)
			Die(FUNCTION_NAME, "fscanf error");
		  
		      /* Put values */
		      
		      WDB[loc3 + IFC_FUEP_RAD_PTR_MAT] = 
			(double)PutText(tmpstr);
		      WDB[loc3 + IFC_FUEP_RAD_DF] = d;
		      WDB[loc3 + IFC_FUEP_RAD_TEMP] = T;
		      WDB[loc3 + IFC_FUEP_RAD_COLD_R2] = r1;
		      WDB[loc3 + IFC_FUEP_RAD_HOT_R2] = r2;
		    }
		}
	    }

	  /* Set ETTM on */

	  WDB[DATA_ETTM_MODE] = (double)ETTM_MODE_CE;

	  /*******************************************************************/
	}
      else
	Error(loc0, "Invalid inteface type in file");
    
      /* Close file */

      fclose(fp);

      /* Next interface */

      loc0 = NextItem(loc0);
    }
}

/*****************************************************************************/
