/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scoreufs.c                                     */
/*                                                                           */
/* Created:       2012/04/22 (JLe)                                           */
/* Last modified: 2012/12/13 (JLe)                                           */
/* Version:       2.1.11                                                     */
/*                                                                           */
/* Description: Scores reaction rates needed for UFS weight mesh             */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreUFS:"

/*****************************************************************************/

void ScoreUFS(double flx, long mat, double wgt, double x, double y, double z,
	      double E, double g, long id)
{
  long msh, rea, mode;
  double f;

  /* Check that mode is on */
  
  if ((long)RDB[DATA_UFS_MODE] == UFS_MODE_NONE)
    return;

  /* Check active cycles */

  if (RDB[DATA_CYCLE_IDX] > RDB[DATA_CRIT_SKIP])
    return;

  /* Get pointer to mesh */

  msh = (long)RDB[DATA_UFS_PTR_SRC_MESH];
  CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

  /* Get mode */

  mode = (long)RDB[DATA_UFS_MODE];

  /* Reset value */

  f = -1.0;

  /* Check mode */

  if (mode == UFS_MODE_FLUX)
    {
      /* Flux */
      
      f = flx*wgt;      
    }
  else if (mat > VALID_PTR)
    {
      /* Reaction rate */
      
      if (mode == UFS_MODE_COL)
	{
	  /* Total (collision) */      
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_TOTXS]) > VALID_PTR)
	    f = MacroXS(rea, E, id)*flx*wgt*g;
	}
      else if (mode == UFS_MODE_FISS)
	{
	  /* Fission */      
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSXS]) > VALID_PTR)
	    f = MacroXS(rea, E, id)*flx*wgt*g;
	}
      else
	Die(FUNCTION_NAME, "Invalid mode");
    }

  /* Score source point for UFS */

  if (f > 0.0)
    AddMesh(msh, f, x, y, z, id);
}

/*****************************************************************************/
