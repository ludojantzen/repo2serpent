/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : addsearchmesh.c                                */
/*                                                                           */
/* Created:       2012/02/18 (JLe)                                           */
/* Last modified: 2012/09/16 (JLe)                                           */
/* Version:       2.1.9                                                      */
/*                                                                           */
/* Description: Adds an item to search mesh                                  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "AddSearchMesh:"

/*****************************************************************************/

void AddSearchMesh(long msh, long loc0, double xmin, double xmax, 
		   double ymin, double ymax, double zmin, double zmax)
{
  long nx, ny, nz, imin, imax, jmin, jmax, kmin, kmax, i, j, k, loc1, loc2, ptr;
  
  /* Check pointers */

  CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Check mesh type and content */

  if ((long)RDB[msh + MESH_TYPE] != MESH_TYPE_CARTESIAN)
    Die(FUNCTION_NAME, "Invalid mesh type");

  if ((long)RDB[msh + MESH_CONTENT] != MESH_CONTENT_PTR)
    Die(FUNCTION_NAME, "Invalid content type");

  /* Check boundaries */

  if ((xmin < RDB[msh + MESH_MIN0]) || (xmax > RDB[msh + MESH_MAX0]) ||
      (ymin < RDB[msh + MESH_MIN1]) || (ymax > RDB[msh + MESH_MAX1]) ||
      (zmin < RDB[msh + MESH_MIN2]) || (zmax > RDB[msh + MESH_MAX2]))
    Die(FUNCTION_NAME, "Error in boundaries");

  /* Check order */

  if ((xmin > xmax) || (ymin > ymax) || (zmin > zmax))
    Die(FUNCTION_NAME, "Boundaries not in order");

  /* Get mesh size */

  nx = (long)RDB[msh + MESH_N0];
  ny = (long)RDB[msh + MESH_N1];
  nz = (long)RDB[msh + MESH_N2];

  /* Calculate boundaries */

  imin = (long)(((double)nx)*(xmin - RDB[msh + MESH_MIN0])/
		(RDB[msh + MESH_MAX0] - RDB[msh + MESH_MIN0]));

  imax = (long)(((double)nx)*(xmax - RDB[msh + MESH_MIN0])/
		(RDB[msh + MESH_MAX0] - RDB[msh + MESH_MIN0]));

  jmin = (long)(((double)ny)*(ymin - RDB[msh + MESH_MIN1])/
		(RDB[msh + MESH_MAX1] - RDB[msh + MESH_MIN1]));

  jmax = (long)(((double)ny)*(ymax - RDB[msh + MESH_MIN1])/
		(RDB[msh + MESH_MAX1] - RDB[msh + MESH_MIN1]));

  kmin = (long)(((double)nz)*(zmin - RDB[msh + MESH_MIN2])/
		(RDB[msh + MESH_MAX2] - RDB[msh + MESH_MIN2]));

  kmax = (long)(((double)nz)*(zmax - RDB[msh + MESH_MIN2])/
		(RDB[msh + MESH_MAX2] - RDB[msh + MESH_MIN2]));
  
  /* Coordinate at upper boundary */

  if (imax == nx)
    imax = nx - 1;

  if (jmax == ny)
    jmax = ny - 1;

  if (kmax == nz)
    kmax = nz - 1;

  /* Loop over possible cells */
	  
  for (i = imin; i < imax + 1; i++)
    for (j = jmin; j < jmax + 1; j++)
      for (k = kmin; k < kmax + 1; k++)
	{
	  /* Get pointer */
	  
	  loc1 = ReadMeshPtr(msh, i, j, k);

	  /* Allocate memory */

	  loc2 = NewItem(loc1, SEARCH_MESH_CELL_BLOCK_SIZE);

	  /* Put pointer */
	  
	  WDB[loc2 + SEARCH_MESH_CELL_CONTENT] = (double)loc0;

	  /* Allocate memory for counter */

	  if ((long)RDB[loc2 + SEARCH_MESH_PTR_CELL_COUNT] < VALID_PTR)
	    {
	      ptr = AllocPrivateData(1, PRIVA_ARRAY);
	      WDB[loc2 + SEARCH_MESH_PTR_CELL_COUNT] = (double)ptr;
	    }
	}
}

/*****************************************************************************/
