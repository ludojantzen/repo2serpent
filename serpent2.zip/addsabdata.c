/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : addsabdata.c                                   */
/*                                                                           */
/* Created:       2011/01/22 (JLe)                                           */
/* Last modified: 2012/11/05 (JLe)                                           */
/* Version:       2.1.10                                                     */
/*                                                                           */
/* Description: - Adds S(a,b) channels to transport nuclide                  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "AddSabData:"

/*****************************************************************************/

void AddSabData()
{
  long mat, loc0, loc1, iso, nuc, ptr, n, rea, new;
  char tmpstr[MAX_STR];
  double f;

  /* Check if S(a,b) data exists */

  if ((long)RDB[DATA_PTR_T0] < VALID_PTR)
    return;

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check divisor */

      if ((long)RDB[mat + MATERIAL_DIV_PTR_PARENT] > VALID_PTR)
	{
	  /* Next material */

	  mat = NextItem(mat);

	  /* Cycle loop */

	  continue;
	}

      /* Loop over S(a,b) data */
      
      loc0 = (long)RDB[mat + MATERIAL_PTR_SAB];
      while (loc0 > VALID_PTR)
	{
	  /* Pointer to composition */
	  
	  iso = (long)RDB[loc0 + THERM_PTR_COMP];
	  
	  /* Check pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(iso)", DATA_ARRAY, iso);
	  
	  /* Pointer to nuclide */
	  
	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  
	  /* Create new nuclide for combined data */

	  new = NewItem(DATA_PTR_NUC0, NUCLIDE_BLOCK_SIZE);

	  /* Copy data */
	      
	  memcpy(&WDB[new + LIST_DATA_SIZE], &RDB[nuc + LIST_DATA_SIZE], 
		 (NUCLIDE_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

	  /* Reset toxicities */

	  WDB[new + NUCLIDE_SPEC_ING_TOX] = -1.0;
	  WDB[new + NUCLIDE_SPEC_INH_TOX] = -1.0;

	  /* Allocate memory for previous collision velocity and relative */
	  /* energy */

	  WDB[new + NUCLIDE_PREV_COL_Z2] = NULLPTR;
	  WDB[new + NUCLIDE_PREV_COL_COS] = NULLPTR;
	  WDB[new + NUCLIDE_PREV_COL_ER] = NULLPTR;

	  AllocValuePair(new + NUCLIDE_PREV_COL_Z2);
	  AllocValuePair(new + NUCLIDE_PREV_COL_COS);
	  AllocValuePair(new + NUCLIDE_PREV_COL_ER);

	  /* Reset reaction pointer */

	  WDB[new + NUCLIDE_PTR_REA] = NULLPTR;

	  /* Reset used-flag (NOTE: idea on että poistetaan nuklidi */
	  /* muistin säästämiseksi jos sitä ei ole syntynyt minkään */ 
	  /* muun nuklidin ketjussa. Vaatii sen että tätä rutiinia  */
	  /* kutsutaan viimeiseksi, ja että noi flägit on asetettu. */
	  /* Eikä tää välttämättä silti toimi, vaan saattaa johtaa  */
	  /* siihen että nuklidia ei löydy MakeBurnMatrix():ssa.)   */

	  if (!((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_AP) &&
	      !((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DP) &&
	      !((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_FP) &&
	      !((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_BP))
	    ResetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

	  /* Change name */

	  sprintf(tmpstr, "%s", GetText(nuc + NUCLIDE_PTR_NAME));
	  tmpstr[strlen(tmpstr) - 1] = 's';
	  WDB[new + NUCLIDE_PTR_NAME] = (double)PutText(tmpstr);
	      
	  /* Change library ID */

	  sprintf(tmpstr, "%s", GetText(nuc + NUCLIDE_PTR_LIB_ID));
	  tmpstr[strlen(tmpstr) - 1] = 's';
	  WDB[new + NUCLIDE_PTR_LIB_ID] = (double)PutText(tmpstr);

	  /* Set S(a,b) flag */

	  SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_SAB_DATA);

	  /* Copy reaction data (this is needed to get the root */
	  /* pointers right) */

	  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (rea > VALID_PTR)
	    {
	      /* New reaction */

	      ptr = NewItem(new + NUCLIDE_PTR_REA, REACTION_BLOCK_SIZE);

	      /* Copy data */
	      
	      memcpy(&WDB[ptr + LIST_DATA_SIZE], &RDB[rea + LIST_DATA_SIZE], 
		     (REACTION_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

	      /* Next reaction */

	      rea = NextItem(rea);
	    }

	  /* Put pointer */

	  WDB[iso + COMPOSITION_PTR_NUCLIDE] = (double)new;

	  /* Loop over S(a,b) nuclides */
	  
	  for (n = 0; n < 2; n++)
	    {
	      /* Pointer to nuclide */
	      
	      loc1 = (long)RDB[loc0 + THERM_PTR_THERM];
	      
	      if (n == 0)
		{
		  loc1 = (long)RDB[loc1 + THERM_PTR_ISO1];
		  f = RDB[loc0 + THERM_FRAC1];
		}
	      else
		{
		  loc1 = (long)RDB[loc1 + THERM_PTR_ISO2];
		  f = RDB[loc0 + THERM_FRAC2];
		}

	      /* Check pointer */
	      
	      if (loc1 > VALID_PTR)
		{
		  /* Loop over reactions */

		  rea = (long)RDB[loc1 + NUCLIDE_PTR_REA];
		  while(rea > VALID_PTR)
		    {
		      /* Add new reaction */

		      ptr = NewItem(new + NUCLIDE_PTR_REA,
				    REACTION_BLOCK_SIZE);

		      /* Copy data */

		      memcpy(&WDB[ptr + LIST_DATA_SIZE], 
			     &RDB[rea + LIST_DATA_SIZE], 
			     (REACTION_BLOCK_SIZE - LIST_DATA_SIZE)
			     *sizeof(double));
		      
		      /* Set temperature adjustment factor */

		      WDB[ptr + REACTION_SAB_FRAC] = f;

		      /* Compare to nuclide minimum */

		      if (RDB[rea + REACTION_EMIN] < RDB[nuc + NUCLIDE_EMIN])
			WDB[nuc + NUCLIDE_EMIN] = RDB[rea + REACTION_EMIN];
		      
		      /* Compare to nuclide maximum */
		      
		      if (RDB[rea + REACTION_EMAX] > RDB[nuc + NUCLIDE_EMAX])
			WDB[nuc + NUCLIDE_EMAX] = RDB[rea + REACTION_EMAX];

		      /* Next reaction */

		      rea = NextItem(rea);
		    }
		}
	    }
	  
	  /* Next */
	  
	  loc0 = NextItem(loc0);
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /* Remove S(a,b) nuklidit (kokeillaan tätä nyt) */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Check type and remove */

      if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_SAB)
	{
	  /* Copy pointer */

	  ptr = nuc;

	  /* Pointer to next */

	  nuc = NextItem(nuc);

	  /* Remove nuclide */

	  RemoveItem(ptr);
	}
      else
	nuc = NextItem(nuc);
    }

  /* Set used-flags again for initial composition (Tää tarvitaan että */
  /* poistettu nuklidi luetaan mukaan jos sitä on toisen materiaalin  */
  /* alkuperäiskoostumuksessa.) */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Loop over composition */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Pointer to nuclide */

	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];

	  /* Set used-flag */

	  SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

	  /* Next isotope */

	  iso = NextItem(iso);
	}      

      /* Next material */

      mat = NextItem(mat);
    }

  /* Update counters */

  ReactionCount();
}

/*****************************************************************************/
