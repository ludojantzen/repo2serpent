/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scorefission.c                                 */
/*                                                                           */
/* Created:       2011/06/11 (JLe)                                           */
/* Last modified: 2013/04/23 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Scores fission parameters                                    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreFission:"

/*****************************************************************************/

void ScoreFission(long mat, long rea, double tnu, double dnu, double lambda, 
		  long dng, double E0, double E1, double wgt0, double wgt1, 
		  long idx0, long idx1, long id)
{
  long ptr, gcu, ntot, ng, nuc, ncol, tfb, nst, reg, i, loc0, tb, fmx;
  double fE;

  /* Check material, reaction and universe pointers */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);
  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
  ncol = (long)GetPrivateData(ptr, id);

  /* Check neutron type */

  /****************************************************************************/

  /***** Incident neutron *****************************************************/

  if (E0 > 0.0)
    {
      /************************************************************************/

      /***** Fission matrix ***************************************************/

      /* Check matrix indexes */
      
      if ((idx0 > -1) && (idx1 > -1))
	{
	  /* Get pointer to matrix */

	  fmx = (long)RDB[DATA_PTR_FMTX];
	  CheckPointer(FUNCTION_NAME, "(fmx)", DATA_ARRAY, fmx);
	  
	  /* Get pointer to data */
	      
	  ptr = (long)RDB[fmx + FMTX_PTR_MTX];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Score total */
	      
	  AddBuf(tnu, wgt0, ptr, id, -1, 0, idx0, idx1);
	      
	  /* Score prompt or delayed */

	  if (dng == 0)
	    AddBuf(tnu, wgt0, ptr, id, -1, 1, idx0, idx1);
	  else
	    AddBuf(tnu, wgt0, ptr, id, -1, 2, idx0, idx1);
	}

      /************************************************************************/

      /***** Common parameters for incident neutron ***************************/

      /* Fission energy deposition */
	    
      fE = RDB[rea + REACTION_Q]*RDB[DATA_NORM_U235_FISSE]/U235_FISSQ;

      /* Score analog fission nubar for K-eff */
      
      ptr = (long)RDB[RES_ANA_NUBAR];
      CheckPointer(FUNCTION_NAME, "(ptr 1)", DATA_ARRAY, ptr);
      AddBuf(tnu, wgt0, ptr, id, 0);
      
      /* And for burnable and non-burnable materials */

      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	AddBuf(tnu, wgt0, ptr, id, 1);
      else
	AddBuf(tnu, wgt0, ptr, id, 2);

      /* Score analog fission energy for all materials */
      
      ptr = (long)RDB[RES_ANA_FISSE];
      CheckPointer(FUNCTION_NAME, "(ptr 2)", DATA_ARRAY, ptr);
      AddBuf(fE, wgt0, ptr, id, 0);

      /* And for burnable and non-burnable materials */

      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	AddBuf(fE, wgt0, ptr, id, 1);
      else
	AddBuf(fE, wgt0, ptr, id, 2);

      /* Get nuclide pointer */

      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
      
      /* Check neutron number */

      if (((long)RDB[nuc + NUCLIDE_A] - (long)RDB[nuc + NUCLIDE_Z]) % 2)
	{
	  /* Score analog fissile fission rate */

	  ptr = (long)RDB[RES_ANA_CONV_RATIO];
	  CheckPointer(FUNCTION_NAME, "(ptr 3)", DATA_ARRAY, ptr);
	  AddBuf(1.0, wgt0, ptr, id, 2);
	}

      /* Total and nuclide-wise rates */

      ptr = (long)RDB[RES_ANA_FISS_FRAC];
      CheckPointer(FUNCTION_NAME, "(ptr 4)", DATA_ARRAY, ptr);
      AddBuf(1.0, wgt0, ptr, id, 0);
      
      if ((long)RDB[nuc + NUCLIDE_ZAI] == 902320)
	AddBuf(1.0, wgt0, ptr, id, 1);
      else if ((long)RDB[nuc + NUCLIDE_ZAI] == 922330)
	AddBuf(1.0, wgt0, ptr, id, 2);
      else if ((long)RDB[nuc + NUCLIDE_ZAI] == 922350)
	AddBuf(1.0, wgt0, ptr, id, 3);
      else if ((long)RDB[nuc + NUCLIDE_ZAI] == 922380)
	AddBuf(1.0, wgt0, ptr, id, 4);
      else if ((long)RDB[nuc + NUCLIDE_ZAI] == 942390)
	AddBuf(1.0, wgt0, ptr, id, 5);
      
      /* Score analog reaction rate if not implicit mode */

      if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == NO)
	{
	  /* Total reaction rate */

	  ptr = (long)RDB[RES_TOT_NEUTRON_RR];
	  CheckPointer(FUNCTION_NAME, "(ptr 5)", DATA_ARRAY, ptr);
	  AddBuf(1.0, wgt0, ptr, id, 0);
	  
	  /* Total fission rate */

	  ptr = (long)RDB[RES_TOT_FISSRATE];
	  CheckPointer(FUNCTION_NAME, "(ptr 6)", DATA_ARRAY, ptr);
	  AddBuf(1.0, wgt0, ptr, id, 0);
	  
	  /* Check material burn flag */
	  
	  if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	    AddBuf(1.0, wgt0, ptr, id, 1);
	  else
	    AddBuf(1.0, wgt0, ptr, id, 2);
	}
      
      /* Fission rate by delayed neutrons */
      
      if (dng > 0)
	{
	  /* Fission rate for analog delayed neutron k-eff */

	  ptr = (long)RDB[RES_ANA_KEFF];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(tnu, wgt0, ptr, id, 2);
	}
      else
	{
	  /* Fission rate for analog prompt neutron k-eff */

	  ptr = (long)RDB[RES_ANA_KEFF];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(tnu, wgt0, ptr, id, 1);
	}
         
      /************************************************************************/

      /***** Fission power for temperature feedback ***************************/
      
      /* Loop over temperature feedbacks */
      
      tfb = (long)RDB[DATA_PTR_TFB0];
      while (tfb > VALID_PTR)
	{
	  /* Pointer to nest */

	  nst = (long)RDB[tfb + TFB_PTR_NST];
	  CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

	  /* Get pointer to region */
	  
	  if ((reg = (long)TestValuePair(nst + NEST_PTR_COL_REG, ncol, id))
	      > VALID_PTR)
	    {
	      /* Pointer to feedback region */

	      if ((reg = (long)RDB[reg + NEST_REG_PTR_TFB_REG]) > VALID_PTR)
		{
		  /* Get index */

		  i = (long)RDB[reg + TFB_REG_IDX];
		  
		  /* Get time bin index */
		  
		  tb = (long)RDB[DATA_DYN_TB];
		  
		  /* Score fission energy */
	      
		  ptr = (long)RDB[tfb + TFB_PTR_MEAN_POW];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddBuf(fE, wgt0, ptr, id, -1, i, tb);
		}
	      
	      /* Break loop */

	      break;
	    }
	  
	  /* Next feedback */
	  
	  tfb = NextItem(tfb);
	}

      /************************************************************************/

      /***** Group constants in infinite spectrum ****************************/

      /* Check active cycle and corrector step */

      if ((RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP]) ||
	  (((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) &&
	   ((long)RDB[DATA_B1_BURNUP_CORR] == NO)))
	return;

      /* Check that group constants are calculated */

      if ((long)RDB[DATA_OPTI_GC_CALC] == NO)
	return;

      /* Get universe pointer */

      if ((gcu = TestValuePair(DATA_GCU_PTR_UNI, ncol, id)) < VALID_PTR)
	return;

      /* Number of groups */

      ntot = (long)RDB[DATA_ERG_FG_NG];

      /* Get pointer to few-group structure */
  
      ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get few-group index of incident neutron */

      if ((ng = GridSearch(ptr, E0)) > -1)
	{
	  /* Check index */

	  CheckValue(FUNCTION_NAME, "ng", "", ng, 0, ntot - 1);

	  /* Score few-group nubar */
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_NUBAR];
	  CheckPointer(FUNCTION_NAME, "(ptr 7)", DATA_ARRAY, ptr);
	  AddBuf(tnu, wgt0, ptr, id, 0);
	  AddBuf(tnu, wgt0, ptr, id, ntot - ng);
      	}
    
      /* Check pointer to MORA data */

      if ((loc0 = (long)RDB[gcu + GCU_PTR_MORA]) > VALID_PTR)
	{
	  /* Get pointer to energy grid */
  
	  ptr = (long)RDB[loc0 + MORA_PTR_EG];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  
	  /* Find group */
	  
	  if ((ng = GridSearch(ptr, E0)) > -1)
	    {	  
	      /* Score nubar */
	  
	      if (dng == 0)
		ptr = (long)RDB[loc0 + MORA_PTR_PNU];
	      else
		ptr = (long)RDB[loc0 + MORA_PTR_DNU];

	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddBuf(tnu, wgt0, ptr, id, ng);
	    }
	}

      /***********************************************************************/
  
      /***** Micro-group nsf *************************************************/

      /* Get pointer to microgroup energy grid */

      ptr = (long)RDB[DATA_MICRO_PTR_EGRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	

      /* Number of groups */

      ntot = (long)RDB[ptr + ENERGY_GRID_NE] - 1;

      /* Get few-group index of incident neutron */
      
      if ((ng = GridSearch(ptr, E0)) > -1)
	{
	  /* Check index */

	  CheckValue(FUNCTION_NAME, "ng", "", ng, 0, ntot - 1);

	  /* Score fine-group nubar */
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_NSF];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  AddPrivateRes(ptr + ntot - ng - 1, wgt0*tnu, id);
	}
      
      /************************************************************************/
    }

  /****************************************************************************/

  /***** Emitted neutron ******************************************************/

  else if (E1 > 0.0)
    {
      /************************************************************************/

      /***** Chi in infinite spectrum *****************************************/

      /* Check active cycle and corrector step */

      if ((RDB[DATA_CYCLE_IDX] < RDB[DATA_CRIT_SKIP]) ||
	  (((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) &&
	   ((long)RDB[DATA_B1_BURNUP_CORR] == NO)))
	return;

      /* Analog beta-zero and lambda */

      if (dng > 0)
	{
	  ptr = (long)RDB[RES_FWD_ANA_BETA_ZERO];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(wgt1, wgt0, ptr, id, 0);
	  AddBuf(wgt1, wgt0, ptr, id, dng);

	  ptr = (long)RDB[RES_FWD_ANA_LAMBDA];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(lambda, wgt0, ptr, id, 0);
	  AddBuf(lambda, wgt0, ptr, id, dng);
	}

      /* Check that group constants are calculated */

      if ((long)RDB[DATA_OPTI_GC_CALC] == NO)
	return;

      /* Get universe pointer */

      if ((gcu = TestValuePair(DATA_GCU_PTR_UNI, ncol, id)) < VALID_PTR)
	return;

      /* Number of groups */

      ntot = (long)RDB[DATA_ERG_FG_NG];

      /* Get pointer to few-group structure */
  
      ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get few-group index of emitted neutron */

      if ((ng = GridSearch(ptr, E1)) > -1)
	{
	  /* Check index */
	  
	  CheckValue(FUNCTION_NAME, "ng", "", ng, 0, ntot - 1);
	  
	  /* Total chi */
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_CHI];
	  CheckPointer(FUNCTION_NAME, "(ptr 9)", DATA_ARRAY, ptr);
	  AddBuf(wgt1, wgt0, ptr, id, ntot - ng - 1);
	  
	  if (dng == 0)
	    {
	      /* Prompt chi */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_CHIP];
	      CheckPointer(FUNCTION_NAME, "(ptr 10)", DATA_ARRAY, ptr);
	      AddBuf(wgt1, wgt0, ptr, id, ntot - ng - 1);
	    }
	  else
	    {
	      /* Delayed chi */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_CHID];
	      CheckPointer(FUNCTION_NAME, "(ptr 11)", DATA_ARRAY, ptr);
	      AddBuf(wgt1, wgt0, ptr, id, ntot - ng - 1);
	    }
	}

      /* Check pointer to MORA data */

      if ((loc0 = (long)RDB[gcu + GCU_PTR_MORA]) > VALID_PTR)
	{
	  /* Get pointer to energy grid */
  
	  ptr = (long)RDB[loc0 + MORA_PTR_EG];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Number of groups */

	  ntot = (long)RDB[loc0 + MORA_N_EG];

	  /* Find group */
	  
	  if ((ng = GridSearch(ptr, E1)) > -1)
	    {	  
	      /* Score nubar */

	      if (dng == 0)
		ptr = (long)RDB[loc0 + MORA_PTR_CHIP];
	      else
		ptr = (long)RDB[loc0 + MORA_PTR_CHID];

	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddBuf(wgt1, wgt0, ptr, id, ng);
	      AddBuf(wgt1, wgt0, ptr, id, ntot);
	    }
	}

      /************************************************************************/

      /***** Micro-group chi **************************************************/
  
      /* Get pointer to microgroup energy grid */

      ptr = (long)RDB[DATA_MICRO_PTR_EGRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	

      /* Number of groups */

      ntot = (long)RDB[ptr + ENERGY_GRID_NE] - 1;

      /* Get few-group index of emitted neutron */
      
      if ((ng = GridSearch(ptr, E1)) > -1)
	{
	  /* Check index */
	  
	  CheckValue(FUNCTION_NAME, "ng", "", ng, 0, ntot - 1);
	  
	  /* Total chi */
	  
	  ptr = (long)RDB[gcu + GCU_MICRO_CHIT];
	  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	  AddPrivateRes(ptr + ntot - ng - 1, wgt0*wgt1, id);

	  /* Prompt and delayed */

	  if (dng == 0)
	    {
	      ptr = (long)RDB[gcu + GCU_MICRO_CHIP];
	      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	      AddPrivateRes(ptr + ntot - ng - 1, wgt0*wgt1, id);
	    }
	  else
	    {
	      ptr = (long)RDB[gcu + GCU_MICRO_CHID];
	      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	      AddPrivateRes(ptr + ntot - ng - 1, wgt0*wgt1, id);
	    }
	}

      /************************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Both energies are zero");

  /****************************************************************************/
}

/******************************************************************************/
