/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : materialburnup.c                               */
/*                                                                           */
/* Created:       2011/07/07 (JLe)                                           */
/* Last modified: 2013/03/14 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Calculates material-wise burnup for time step                */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MaterialBurnup:"

/*****************************************************************************/

void MaterialBurnup(long mat, double *N, double t, long id)
{
  long dep, nuc, rea, i;
  double flx, adens, mdens, rr, Q;

  /* Check step type */

#ifndef STAB_BURN

  if (!((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE) &&
      ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP))
    return;

#endif

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Get flux and initial fissile mass density */

  flx = RDB[mat + MATERIAL_BURN_FLUX_SSA];
  mdens = RDB[mat + MATERIAL_INI_FISS_MDENS];

  /* Check values */

  if ((mdens == 0.0) || (flx == 0.0))
    return;

  /* Loop over reactions (tota listaa ei oo jos on se totfiss-juttu?) */
  
  dep = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST];
  while (dep > VALID_PTR)
    {
     /* Pointer to reaction */
      
      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

      /* Pointer to nuclide data */
      
      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
 
      /* Get index to composition vector */
 
      if ((i = TestValuePair(nuc + NUCLIDE_PTR_MATRIX_IDX, mat, id)) < 0)
	Die(FUNCTION_NAME, "i < 0");
      
      /* Get atomic density from composition vector */
      
      adens = N[i];

      /* Get deposited energy */

      Q = RDB[rea + REACTION_Q]*RDB[DATA_NORM_U235_FISSE]/U235_FISSQ;

      /* Get reaction rate */
	  
      rr = TestValuePair(rea + REACTION_PTR_TRANSMUXS, mat, id);

      /* Add to material burnup */
	  
      WDB[mat + MATERIAL_BURNUP] = RDB[mat + MATERIAL_BURNUP] 
	+ adens*flx*rr*Q*t/mdens/86400/1.0E3;

      /* Next reaction */

      dep = NextItem(dep);
    }
}

/*****************************************************************************/
