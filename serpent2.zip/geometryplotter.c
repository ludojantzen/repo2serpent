/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : geometryplotter.c                              */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2013/03/18 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Plots geometry                                               */
/*                                                                           */
/* Comments: - Lis�� optio jolla saa valita rajapintojen vs. materiaali-     */
/*             rajojen korostuksen.                                          */
/*                                                                           */
/*           - T�� vuotaa muistia jostain? (Saattoi johtua noista v�ri-      */
/*             m��rittelyist�, jotka korjattiin 10.5.2012 / 2.1.6)           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#ifndef NO_GFX_MODE
#include <gd.h>
#endif

#define FUNCTION_NAME "GeometryPlotter:"

#define COLOURS 256

/*****************************************************************************/

void GeometryPlotter(long ini)
{
#ifndef NO_GFX_MODE

  long n, m, n0, m0, gpl, xp, yp, cell, mat, nerr, old, mode, id, ptr, trk;
  long r[COLOURS], g[COLOURS], b[COLOURS], count, nplot, trk0, idx, idx0, ext;
  long ncol, nifc;
  long **matrix;
  double xmin, xmax, ymin, ymax, zmin, zmax, tmp, x, y, z, u, v, w, d, pixw;
  double dummy, f, T;
  gdImagePtr im;
  FILE *fp;
  long palette[COLOURS];
  unsigned long seed;
  char fname[MAX_STR];

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Pointer to geometry plot */

  if ((gpl = RDB[DATA_PTR_GPL0]) < 1)
    {
      /* Check stop mode */

      if ((long)RDB[DATA_STOP_AFTER_PLOT] == STOP_AFTER_PLOT_GEOM)
	exit(-1);
      
      /* Return */

      return;
    }

  /* Check initial flag and recorded tracks */

  if ((ini == NO) && ((long)RDB[DATA_PTR_TRCK0] < VALID_PTR))
    return;

  if (ini == YES)
    fprintf(out, "Plotting geometry:\n\n");

  /* Boundary mode (1 = plot cell boundaries, 2 = plot material boundaries) */

  mode = 2;

  /* Set plotter mode */
  
  WDB[DATA_PLOTTER_MODE] = (double)YES;

  /* Reset exit flag */

  ext = NO;

  /* Reset dummy weight used for albedo boundary conditions */

  dummy = -1.0;

  /* Init random number sequence */
      
  seed = ReInitRNG(0);
      
  /* Put seed in private data */
      
  ptr = (long)RDB[DATA_PTR_RNG_SEED];
  PutPrivateData(ptr, seed, 0);

  /* Reduce number of colors if IFC is in use */

  if ((ptr = (long)RDB[DATA_PTR_IFC0]) > VALID_PTR)
    {
      ncol = (long)(((double)COLOURS)/2.0);
      nifc = (long)(((double)ncol - 10)/((double)ListSize(ptr)));
    }
  else
    {
      ncol = COLOURS;
      nifc = 0;
    }
  
  /* Random colors */

  for(n = 5; n < COLOURS; n++)
    {
      r[n] = (long)(255.0*(RandF(0) + 1.0)/2);
      g[n] = (long)(255.0*(RandF(0) + 1.0)/2);
      b[n] = (long)(255.0*(RandF(0) + 1.0)/2);
    }

  /* Void colour */
  
  r[0] = 0;
  g[0] = 0;
  b[0] = 0;

  /* No cell error */

  r[1] = 0;
  g[1] = 255;
  b[1] = 0;

  /* Multiple cell error */

  r[2] = 255;
  g[2] = 0;
  b[2] = 0;

  /* Pointer error */

  r[3] = 255;
  g[3] = 255;
  b[3] = 0;

  /* Underined density factor */

  r[4] = 255;
  g[4] = 0;
  b[4] = 255;

  /***************************************************************************/

  /***** Set fixed colors ****************************************************/

  /* User-defined material colours */

  n = 5;

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check pointer to interface */

      if ((long)RDB[mat + MATERIAL_PTR_IFC] < VALID_PTR)
	{
	  /* Check if colour is defined */
	  
	  if ((m = (long)RDB[mat + MATERIAL_RGB]) > 0)
	    {
	      if ((ptr = (long)RDB[mat + MATERIAL_DIV_PTR_PARENT]) > VALID_PTR)
		WDB[mat + MATERIAL_COLOUR_IDX] = RDB[ptr + MATERIAL_COLOUR_IDX];
	      else if (n < ncol)
		{
		  r[n] = (long)(m/1000000.0);
		  g[n] = (long)((m - 1000000.0*r[n])/1000.0);
		  b[n] = (long)(m - 1000000.0*r[n] - 1000.0*g[n]);
		  
		  /* Set index */
		  
		  WDB[mat + MATERIAL_COLOUR_IDX] = (double)n;

		  /* Next colour */
		  
		  n++;
		}
	      else
		WDB[mat + MATERIAL_COLOUR_IDX] = 0;
	    }
	}

      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Put remaining colour indexes */

  m = n;

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check pointer to interface */

      if ((long)RDB[mat + MATERIAL_PTR_IFC] < VALID_PTR)
	{
	  /* Cycle if all are used */

	  if (m > ncol - 1)
	    m = n;

	  /* One more check */

	  if (m > ncol - 1)
	    m = ncol - 1;
	  
	  /* Check if index is not already given */
	  
	  if ((long)RDB[mat + MATERIAL_COLOUR_IDX] == 0)
	    WDB[mat + MATERIAL_COLOUR_IDX] = (double)m++;
	}

      /* Next material */
      
      mat = NextItem(mat);
    }

  /***************************************************************************/

  /***** Set IFC colors ******************************************************/

  /* User-defined material colours */

  n = ncol;

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check pointer to interface */

      if ((long)RDB[mat + MATERIAL_PTR_IFC] > VALID_PTR)
	{
	  /* Check if colour is defined */
	  
	  if ((m = (long)RDB[mat + MATERIAL_RGB]) > 0)
	    {
	      if ((ptr = (long)RDB[mat + MATERIAL_DIV_PTR_PARENT]) > VALID_PTR)
		WDB[mat + MATERIAL_COLOUR_IDX] = RDB[ptr + MATERIAL_COLOUR_IDX];
	      else if (n < COLOURS)
		{
		  r[n] = (long)(m/1000000.0);
		  g[n] = (long)((m - 1000000.0*r[n])/1000.0);
		  b[n] = (long)(m - 1000000.0*r[n] - 1000.0*g[n]);
		  
		  /* Set index */
		  
		  WDB[mat + MATERIAL_COLOUR_IDX] = (double)n;

		  /* Next colour */
		  
		  n = n + nifc;
		}
	      else
		WDB[mat + MATERIAL_COLOUR_IDX] = 0;
	    }
	}

      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Put remaining colour indexes */

  m = n;

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check pointer to interface */

      if ((long)RDB[mat + MATERIAL_PTR_IFC] > VALID_PTR)
	{
	  /* Cycle if all are used */

	  if (m > COLOURS - 1)
	    m = n;

	  /* One more check */

	  if (m > COLOURS - 1)
	    m = COLOURS - 1;

	  /* Check if index is not already given */
	  
	  if ((long)RDB[mat + MATERIAL_COLOUR_IDX] == 0)
	    {
	      WDB[mat + MATERIAL_COLOUR_IDX] = (double)m;
	      m = m + nifc;
	    }
	}

      /* Next material */
      
      mat = NextItem(mat);
    }
  
  /* Create shades */

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check pointer to interface */

      if ((long)RDB[mat + MATERIAL_PTR_IFC] > VALID_PTR)
	{
	  /* Get index to color */

	  if ((n = (long)RDB[mat + MATERIAL_COLOUR_IDX]) < ncol)
	    Die(FUNCTION_NAME, "Indexing error");
	  
	  /* Loop over shades */
		  
	  for (m = 1; m < nifc; m++)
	    {
	      /* Put colours */

	      r[n + nifc - m] = r[n]*((double)(m - 1))/((double)(nifc - 1));
	      b[n + nifc - m] = b[n]*((double)(m - 1))/((double)(nifc - 1));
	      g[n + nifc - m] = g[n]*((double)(m - 1))/((double)(nifc - 1));
	    }
	}

      /* Next material */
      
      mat = NextItem(mat);
    }

  /***************************************************************************/

  /***** Adjust colors for track plotting ************************************/

  /* Check if tracks are recorded for plotting */

  if ((ptr = (long)RDB[DATA_PTR_TRCK0]) > VALID_PTR)
    {
      /* Brighten up... */

      for(n = 4; n < COLOURS; n++)
	{
	  /*
	  if ((r[n] = (long)(1.5*r[n])) > 255)
	    r[n] = 255;
	  if ((g[n] = (long)(1.5*g[n])) > 255)
	    g[n] = 255;
	  if ((b[n] = (long)(1.5*b[n])) > 255)
	    b[n] = 255;
	  */

	  if ((r[n] = (long)(r[n] + 50)) > 255)
	    r[n] = 255;
	  if ((g[n] = (long)(g[n] + 50)) > 255)
	    g[n] = 255;
	  if ((b[n] = (long)(b[n] + 50)) > 255)
	    b[n] = 255;
	}
      
      r[0] = 50;
      g[0] = 50;
      b[0] = 50;
    }

  /***************************************************************************/

  /***** Plot geometry *******************************************************/
  
  /* Reset counter and get number of plots */

  count = 0;
  nplot = ListSize(gpl);

  /* Loop over plots */

  gpl = FirstItem(gpl);
  while (gpl > VALID_PTR)
    {
      if (ini == YES)
	fprintf(out, " %3.0f%% complete\n", 100.0*(count++)/((double)nplot));

      /* Set file name */

      if ((long)RDB[DATA_BURN_STEP] > 0)
	{
	  if ((ptr = (long)RDB[DATA_PTR_TRCK0]) > VALID_PTR)
	    sprintf(fname, "%s_trck%ld_bu%ld.png", 
		    GetText(DATA_PTR_INPUT_FNAME),
		    (long)RDB[gpl + GPL_IDX], (long)RDB[DATA_BURN_STEP]);
	  else      
	    sprintf(fname, "%s_geom%ld__bu%ld.png", 
		    GetText(DATA_PTR_INPUT_FNAME),
		    (long)RDB[gpl + GPL_IDX], (long)RDB[DATA_BURN_STEP]);
	}
      else
	{
	  if ((ptr = (long)RDB[DATA_PTR_TRCK0]) > VALID_PTR)
	    sprintf(fname, "%s_trck%ld.png", GetText(DATA_PTR_INPUT_FNAME),
		    (long)RDB[gpl + GPL_IDX]);
	  else      
	    sprintf(fname, "%s_geom%ld.png", GetText(DATA_PTR_INPUT_FNAME),
		    (long)RDB[gpl + GPL_IDX]);
	}

      /* Reset error counter */

      nerr = 0;

      /***********************************************************************/

      /***** Set boundaries and image size ***********************************/
      
      /* Get boundaries of geometry */

      xmin = RDB[DATA_GEOM_MINX];
      xmax = RDB[DATA_GEOM_MAXX];
      ymin = RDB[DATA_GEOM_MINY];
      ymax = RDB[DATA_GEOM_MAXY];
      zmin = RDB[DATA_GEOM_MINZ];
      zmax = RDB[DATA_GEOM_MAXZ];

      /* Check if boundaries are set by user */

      if (RDB[gpl + GPL_XMIN] != -INFTY)
	xmin = RDB[gpl + GPL_XMIN];

      if (RDB[gpl + GPL_XMAX] !=  INFTY)
	xmax = RDB[gpl + GPL_XMAX];

      if (RDB[gpl + GPL_YMIN] != -INFTY)
	ymin = RDB[gpl + GPL_YMIN];

      if (RDB[gpl + GPL_YMAX] !=  INFTY)
	ymax = RDB[gpl + GPL_YMAX];

      if (RDB[gpl + GPL_ZMIN] != -INFTY)
	zmin = RDB[gpl + GPL_ZMIN];

      if (RDB[gpl + GPL_ZMAX] !=  INFTY)
	zmax = RDB[gpl + GPL_ZMAX];

      /* Check boundaries and swap */

      if (xmin > xmax)
	{
	  tmp = xmax;
	  xmax = xmin;
	  xmin = tmp;
	}

      if (ymin > ymax)
	{
	  tmp = ymax;
	  ymax = ymin;
	  ymin = tmp;
	}

      if (zmin > zmax)
	{
	  tmp = zmax;
	  zmax = zmin;
	  zmin = tmp;
	}

      /* Move limits away from boundaries to avoid numerical errors in some */
      /* systems. */

      xmin = xmin + EXTRAP_L;
      xmax = xmax - EXTRAP_L;
      ymin = ymin + EXTRAP_L;
      ymax = ymax - EXTRAP_L;
      zmin = zmin + EXTRAP_L;
      zmax = zmax - EXTRAP_L;

      /* Set image size */

      xp = (long)RDB[gpl + GPL_PIX_X];
      yp = (long)RDB[gpl + GPL_PIX_Y];

      /* Allocate memory */

      matrix = (long **)Mem(MEM_ALLOC, xp, sizeof(long *));	

      for(n = 0; n < xp; n++)
	matrix[n] = (long *)Mem(MEM_ALLOC, yp, sizeof(long));
	
      /***********************************************************************/

      /***** Draw materials **************************************************/

      /* Start parallel timer */

      StartTimer(TIMER_OMP_PARA);

#ifdef OPEN_MP
#pragma omp parallel private(n, m, x, y, z, u, v, w, cell, mat, ptr, f, T, id)
#endif
      {
	/* Get Open MP thread id */

	id = OMP_THREAD_NUM;

	/* Avoid compiler warnings */

	x = 0;
	y = 0;
	z = 0;
	u = 0;
	v = 0;
	w = 0;
	
	/* Loop over geometry */
	
#ifdef OPEN_MP
#pragma omp for
#endif
	for (n = 0; n < xp; n++)
	  {
	  for (m = 0; m < yp; m++)
	    {
	      /* Reset pixel value */
	      
	      matrix[n][m] = 0;
	      
	      /* Calculate Co-ordinates */
	      
	      switch ((long)RDB[gpl + GPL_TYPE])
		{		
		case PLOT_MODE_YZ:
		  {
		    /* yz-plot */
		    
		    x = RDB[gpl + GPL_POS];
		    y = (n/(xp - 1.0))*(ymax - ymin) + ymin;
		    z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		    
		    u = 0.0;
		    v = 0.0;
		    w = 1.0;
		    
		    break;
		  }
		case PLOT_MODE_XZ:
		  {
		    /* xz-plot */
		    
		    x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		    y = RDB[gpl + GPL_POS];
		    z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		    
		    u = 0.0;
		    v = 0.0;
		    w = 1.0;
		    
		    break;
		  }
		case PLOT_MODE_XY:
		  {
		    
		    /* xy-plot */
		    
		    x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		    y = (m/(yp - 1.0))*(ymax - ymin) + ymin;
		    z = RDB[gpl + GPL_POS];
		    
		    u = 0.0;
		    v = 1.0;
		    w = 0.0;
		    
		    break;
		  }
		default:
		  Die(FUNCTION_NAME, "Invalid plot mode");
		}
	      
	      /* Find location */
	      
	      if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		BoundaryConditions(&cell, &x, &y, &z, &u, &v, &w, -1.0, &dummy, 
				   id);
		  
	      /* Check return value */
	      
	      if (cell < 0)
		{
		  /* Put error condition */
		  
		  nerr = cell;
		  
		  /* Set colour */
		  
		  matrix[n][m] = -cell;
		}
	      else if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
		{
		  /* Get pointer */

		  mat = MatPtr(mat, id);
		  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

		  /* Set colour */
		  
		  matrix[n][m] = (long)RDB[mat + MATERIAL_COLOUR_IDX];

		  /* Reset density and temperature */

		  f = 1.0;
		  T = 0.0;

		  /* Get point from interface */
		  
		  IFCPoint(mat, &f, &T, id);
		  
		  /* Check temperature (overrides density) */

		  if (T > 0.0)
		    {
		      /* Calculate factor */
		      
		      if (RDB[mat + MATERIAL_ETTM_TMAX] -
			  RDB[mat + MATERIAL_ETTM_TMIN] > 0.0)
			f = 0.7*(T - RDB[mat + MATERIAL_ETTM_TMIN])/
			  (RDB[mat + MATERIAL_ETTM_TMAX] - 
			   RDB[mat + MATERIAL_ETTM_TMIN]) + 0.3;
		      else
			f = 1.0;
		    }		  

		  /* Check */

		  if ((f < 0.0) || (f > 1.0))
		    matrix[n][m] = 4;
		  else 
		    matrix[n][m] = matrix[n][m] + (long)((1.0 - f)*(nifc - 1));
		}
	      
	      /***** Plot super-imposed source / detector region *************/
	      
#ifdef mmmmmmmm
	      
	      ptr = (long)RDB[DATA_PTR_SRC0];
	      while (ptr > VALID_PTR)
		{
		  if (InSuperCell((long)RDB[ptr + SRC_PTR_UNIV],
				  (long)RDB[ptr + SRC_PTR_CELL], x, y, z)
		      == YES)
		    matrix[n][m] = 3;
		  
		  /* Next */
	      
		  ptr = NextItem(ptr);
		}
#endif
	      /***************************************************************/
	    }
	  }
      }      
    
      /* Stop parallel timer */

      StopTimer(TIMER_OMP_PARA);

      /* Check for geometry errors */
      
      if ((nerr < 0) && (ini == YES))
	{
	  if (nerr == GEOM_ERROR_NO_CELL)
	    fprintf(out, "Geometry errors in plot %s (no cell).\n", fname);
	  else if (nerr == GEOM_ERROR_MULTIPLE_CELLS)
	    fprintf(out, "Geometry errors in plot %s (overlap).\n", fname);
	  else
	    fprintf(out, "Geometry errors in plot %s (unknown).\n", fname);
	}

      /************************************************************************/

      /***** Plot boundaries  *************************************************/

      /* Start parallel timer */

      StartTimer(TIMER_OMP_PARA);
      
#ifdef OPEN_MP
#pragma omp parallel private(n, m, x, y, z, d, cell, mat, pixw, old, ptr, id)
#endif
      {
	/* Get Open MP thread id */

	id = OMP_THREAD_NUM;

	/* Avoid compiler warnings */
	
	pixw = 0;
	old = -1;
	
	/* Sweep 1 */
	
#ifdef OPEN_MP
#pragma omp for
#endif	

	for (n = 0; n < xp; n++)
	  {
	    /* Reset minimum distance */
	    
	    d = -1.0;
	    
	    for (m = 0; m < yp; m++)
	      {
		/* Calculate Co-ordinates */
		
		switch ((long)RDB[gpl + GPL_TYPE])
		  {		
		  case PLOT_MODE_YZ:
		    {
		      /* yz-plot */
		      
		      x = RDB[gpl + GPL_POS];
		      y = (n/(xp - 1.0))*(ymax - ymin) + ymin;
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (zmax - zmin)/((double)yp);
		      
		      u = 0.0;
		      v = 0.0;
		      w = 1.0;
		      
		      break;
		    }
		  case PLOT_MODE_XZ:
		    {
		      /* xz-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = RDB[gpl + GPL_POS];
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (zmax - zmin)/((double)yp);
		      
		      u = 0.0;
		      v = 0.0;
		      w = 1.0;
		      
		      break;
		    }
		  case PLOT_MODE_XY:
		    {		      
		      /* xy-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = (m/(yp - 1.0))*(ymax - ymin) + ymin;
		      z = RDB[gpl + GPL_POS];
		      
		      pixw = (ymax - ymin)/((double)yp);
		      
		      u = 0.0;
		      v = 1.0;
		      w = 0.0;
		      
		      break;
		    }
		  default:
		    Die(FUNCTION_NAME, "Invalid plot mode");
		  }
		
		/* Check mode */

		if (mode == 1)
		  {
		    /* Find location */

		    if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		      BoundaryConditions(&cell, &x, &y, &z, &u, &v, &w, -1.0,
					 &dummy, id);

		    /* Check pointer */
		    
		    if (cell > VALID_PTR)
		      {
			
			/* Calculate distance to boundary */
			
			d = NearestBoundary(id);
			
			/* Compare minimum distance to pixel width */
			
			if (d < pixw)
			  {
			    /* Set colour */
			    
			    matrix[n][m] = 0;
			  }
		      }
		  }
		else if (mode == 2)
		  {
		    /* Material index */
			
		    mat = matrix[n][m];
			
		    /* Compare to previous */
			
		    if (old != mat)
		      {
			/* Put colour */

			if ((old < ncol) || (mat < ncol) || 
			    ((old > ncol - 1) && (mat > ncol - 1) &&
			     (long)((double)(old - ncol)/((double)nifc)) !=
			     (long)((double)(mat - ncol)/((double)nifc))))
			  if (old != 0)
			    matrix[n][m] = 0;

			/* Set previous pointer */
			
			old = mat;
		      }
		  }
		
		/* Draw border */
		
		if ((m == 0) || (m == yp - 1)) 
		  matrix[n][m] = 0;
	      }
	  }
	
	/* Sweep 2 */

#ifdef OPEN_MP	
#pragma omp for
#endif
	
	for (m = 0; m < yp; m++)
	  {
	    /* Reset minimum distance */
	    
	    d = -1.0;
	    
	    for (n = 0; n < xp; n++)
	      {
		/* Calculate Co-ordinates */
		
		switch ((long)RDB[gpl + GPL_TYPE])
		  {		
		  case PLOT_MODE_YZ:
		    {
		      /* yz-plot */
		      
		      x = RDB[gpl + GPL_POS];
		      y = (n/(xp - 1.0))*(ymax - ymin) + ymin;
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (ymax - ymin)/((double)yp);
		      
		      u = 0.0;
		      v = 1.0;
		      w = 0.0;
		      
		      break;
		    }
		  case PLOT_MODE_XZ:
		    {
		      /* xz-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = RDB[gpl + GPL_POS];
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (xmax - xmin)/((double)xp);
		      
		      u = 1.0;
		      v = 0.0;
		      w = 0.0;
		      
		      break;
		    }
		  case PLOT_MODE_XY:
		    {
		      
		      /* xy-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = (m/(yp - 1.0))*(ymax - ymin) + ymin;
		      z = RDB[gpl + GPL_POS];
		      
		      pixw = (xmax - xmin)/((double)xp);
		      
		      u = 1.0;
		      v = 0.0;
		      w = 0.0;
		      
		      break;
		    }
		  default:
		    Die(FUNCTION_NAME, "Invalid plot mode");
		  }

		/* Check mode */

		if (mode == 1)
		  {		
		    /* Find location */
		
		    if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		      BoundaryConditions(&cell, &x, &y, &z, &u, &v, &w, -1.0,
					 &dummy, id);
		    
		    /* Check pointer */
		    
		    if (cell > VALID_PTR)
		      {
			/* Calculate distance to boundary */
			
			d = NearestBoundary(id);
			
			/* Compare minimum distance to pixel width */
			
			if (d < pixw)
			  {
			    /* Set colour */
			    
			    matrix[n][m] = 0;
			  }
		      }
		  }
		else if (mode == 2)
		  {
		    /* Material index */
			
		    mat = matrix[n][m];
			
		    /* Compare to previous */
			
		    if (old != mat)
		      {
			/* Avoid double lines */

			if ((old < ncol) || (mat < ncol) ||
			    ((old > ncol - 1) && (mat > ncol - 1) &&
			     (long)((double)(old - ncol)/((double)nifc)) !=
			     (long)((double)(mat - ncol)/((double)nifc))))
			  if ((old != 0) && (n > 0) && (matrix[n - 1][m] != 0))
			    matrix[n][m] = 0;
			    
			/* Set previous pointer */
			
			old = mat;
		      }
		  }

		/* Draw border */
		
		if ((n == 0) || (n == xp - 1)) 
		  matrix[n][m] = 0;
	      }
	  }
      }

      /* Stop parallel timer */

      StopTimer(TIMER_OMP_PARA);
    
      /***********************************************************************/

      /***** Draw image ******************************************************/

      /* Check matrix */

      for (n = 0; n < xp; n++)
	for (m = 0; m < yp; m++)
	  if ((matrix[n][m] < 0) || (matrix[n][m] > COLOURS - 1))
	    Die(FUNCTION_NAME, "Invalid colour index %ld (%ld %ld)",
		matrix[n][m], n, m);


      /* Create image */

      im = gdImageCreate(xp, yp);
      
      /* Generate palette */
	  
      for(n = 0; n < COLOURS; n++)
	palette[n] = gdImageColorAllocate(im, r[n], g[n], b[n]);

      /* Start parallel timer */

      StartTimer(TIMER_OMP_PARA);
	      
      /* Draw image */

#ifdef OPEN_MP      
#pragma omp parallel private(n, m)
#endif
      {

#ifdef OPEN_MP
#pragma omp for
#endif
	for (n = 0; n < xp; n++)
	  for (m = 0; m < yp; m++)
	    {
	      /* Flip y-axis in xy-plot */

	      if ((long)RDB[gpl +  GPL_TYPE] == PLOT_MODE_XY)
		gdImageSetPixel(im, n, m, palette[matrix[n][yp - m - 1]]);
	      else
		gdImageSetPixel(im, n, m, palette[matrix[n][m]]);   
	    }
      }

      /* Stop parallel timer */

      StopTimer(TIMER_OMP_PARA);

      /***********************************************************************/

      /***** Plot tracks *****************************************************/

      /* Check if tracks are recorded for plotting */

      if (((ptr = (long)RDB[DATA_PTR_TRCK0]) > VALID_PTR) &&
	  (ptr != (long)RDB[DATA_TRACK_PLOT_PTR_NEXT]))
	{
	  /* Sort points */

	  SortList(ptr, TRACK_PLOT_IDX, SORT_MODE_ASCEND);

	  /* Reset previous points */

	  idx = 0;
	  n0 = -1;
	  m0 = -1;
	  trk0 = -1;
	  idx0 = -1;
	  
	  /* Loop over points and plot tracks */
  
	  while (ptr > VALID_PTR)
	    {
	      /* Get point */

	      x = RDB[ptr + TRACK_PLOT_X];
	      y = RDB[ptr + TRACK_PLOT_Y];
	      z = RDB[ptr + TRACK_PLOT_Z];
	      trk = (long)RDB[ptr + TRACK_PLOT_TRK];

	      /* Check if first or last */

	      if (trk == TRACK_PLOT_LAST)
		break;
	      else if (trk == TRACK_END_STRT)
		{
		  /* Update index */

		  idx++; 

		  /* Check previous */

		  if ((trk0 != TRACK_END_LEAK) && (trk0 != TRACK_END_CAPT) &&
		      (trk0 != TRACK_END_FISS) && (trk0 != TRACK_END_ECUT) && 
		      (trk0 != TRACK_END_WCUT) && (trk0 != TRACK_END_TCUT) &&
		      (trk0 != -1))
		    Die(FUNCTION_NAME, "Error in previous track point");
		}

	      /* Calculate indexes */
		
	      switch ((long)RDB[gpl + GPL_TYPE])
		{		
		case PLOT_MODE_YZ:
		  {
		    /* yz-plot */
		    
		    n = (long)((y - ymin)/(ymax - ymin)*(xp - 1.0));
		    m = (long)((z - zmin)/(zmax - zmin)*(yp - 1.0));
		    m = yp - 1 - m;
		    
		    break;
		  }
		case PLOT_MODE_XZ:
		  {
		    /* xz-plot */
		    
		    n = (long)((x - xmin)/(xmax - xmin)*(xp - 1.0));
		    m = (long)((z - zmin)/(zmax - zmin)*(yp - 1.0));
		    m = yp - 1 - m;
		    
		    break;
		  }
		case PLOT_MODE_XY:
		  {
		    /* xy-plot */
		   
		    n = (long)((x - xmin)/(xmax - xmin)*(xp - 1.0));
		    m = (long)((y - ymin)/(ymax - ymin)*(yp - 1.0));
		    m = yp - 1 - m;

		    break;
		  }
		default:
		  Die(FUNCTION_NAME, "Invalid plot mode");
		}	      		

	      /* Check that points belong to the same history */

	      if (idx == idx0)
		{
		  /* Draw line */
		  
		  if (!((trk0 == TRACK_END_SURF) && (trk == -TRACK_END_SURF)))
		    gdImageLine(im, n0, m0, n, m, 0);
		  
		  /* Mark first point */
		  
		  if (trk0 == TRACK_END_STRT)
		    {
		      gdImageSetPixel(im, n0, m0, 1);
		      
		      if (n0 > 1)
			gdImageSetPixel(im, n0 - 1, m0, 1);
		      if (m0 > 1)
			gdImageSetPixel(im, n0, m0 - 1, 1);
		      if (n0 < xp - 1)
			gdImageSetPixel(im, n0 + 1, m0, 1);
		      if (m0 < xp - 1)
			gdImageSetPixel(im, n0, m0 + 1, 1);
		      if ((n0 > 1) && (m0 > 1))
			gdImageSetPixel(im, n0 - 1, m0 - 1, 0);
		      if ((n0 > 1) && (m0 < yp - 1))
			gdImageSetPixel(im, n0 - 1, m0 + 1, 0);
		      if ((n0 < xp - 1) && (m0 > 1))
			gdImageSetPixel(im, n0 + 1, m0 - 1, 0);
		      if ((n0 < xp - 1) && (m0 < yp - 1))
			gdImageSetPixel(im, n0 + 1, m0 + 1, 0);
		    }
		  
		  /* Mark last point */
		  
		  if ((trk == TRACK_END_LEAK) || (trk == TRACK_END_CAPT) ||
		      (trk == TRACK_END_FISS) || (trk == TRACK_END_ECUT) || 
		      (trk == TRACK_END_WCUT))
		    {
		      gdImageSetPixel(im, n, m, 2);
		      
		      if (n > 1)
			gdImageSetPixel(im, n - 1, m, 2);
		      if (m > 1)
			gdImageSetPixel(im, n, m - 1, 2);
		      if (n < xp - 1)
			gdImageSetPixel(im, n + 1, m, 2);
		      if (m < xp - 1)
			gdImageSetPixel(im, n, m + 1, 2);
		      if ((n > 1) && (m > 1))
			gdImageSetPixel(im, n - 1, m - 1, 0);
		      if ((n > 1) && (m < yp - 1))
			gdImageSetPixel(im, n - 1, m + 1, 0);
		      if ((n < xp - 1) && (m > 1))
			gdImageSetPixel(im, n + 1, m - 1, 0);
		      if ((n < xp - 1) && (m < yp - 1))
			gdImageSetPixel(im, n + 1, m + 1, 0);
		    }
		}

	      /* Remember points */

	      n0 = n;
	      m0 = m;
	      trk0 = trk;
	      idx0 = idx;

	      /* Next point */

	      ptr = NextItem(ptr);
	    }

	  /* Reset previous points */

	  idx = 0;
	  n0 = -1;
	  m0 = -1;
	  trk0 = -1;
	  idx0 = -1;

	  /* Loop over points and plot points */

	  ptr = (long)RDB[DATA_PTR_TRCK0];
	  while (ptr > VALID_PTR)
	    {
	      /* Get point */

	      x = RDB[ptr + TRACK_PLOT_X];
	      y = RDB[ptr + TRACK_PLOT_Y];
	      z = RDB[ptr + TRACK_PLOT_Z];
	      trk = (long)RDB[ptr + TRACK_PLOT_TRK];

	      /* Check if first or last */

	      if (trk == TRACK_PLOT_LAST)
		break;
	      else if (trk == TRACK_END_STRT)
		{
		  /* Update index */

		  idx++; 

		  /* Check previous */

		  if ((trk0 != TRACK_END_LEAK) && (trk0 != TRACK_END_CAPT) &&
		      (trk0 != TRACK_END_FISS) && (trk0 != TRACK_END_ECUT) && 
		      (trk0 != TRACK_END_WCUT) && (trk0 != TRACK_END_TCUT) &&
		      (trk0 != -1))
		    Die(FUNCTION_NAME, "Error in previous track point");
		}

	      /* Calculate indexes */
		
	      switch ((long)RDB[gpl + GPL_TYPE])
		{		
		case PLOT_MODE_YZ:
		  {
		    /* yz-plot */
		    
		    n = (long)((y - ymin)/(ymax - ymin)*(xp - 1.0));
		    m = (long)((z - zmin)/(zmax - zmin)*(yp - 1.0));
		    m = yp - 1 - m;
		    
		    break;
		  }
		case PLOT_MODE_XZ:
		  {
		    /* xz-plot */
		    
		    n = (long)((x - xmin)/(xmax - xmin)*(xp - 1.0));
		    m = (long)((z - zmin)/(zmax - zmin)*(yp - 1.0));
		    m = yp - 1 - m;
		    
		    break;
		  }
		case PLOT_MODE_XY:
		  {
		    /* xy-plot */
		   
		    n = (long)((x - xmin)/(xmax - xmin)*(xp - 1.0));
		    m = (long)((y - ymin)/(ymax - ymin)*(yp - 1.0));
		    m = yp - 1 - m;

		    break;
		  }
		default:
		  Die(FUNCTION_NAME, "Invalid plot mode");
		}	      		

	      /* Check that points belong to the same history */

	      if (idx == idx0)
		{
		  /* Mark time cut-off */
		  
		  if (trk == TRACK_END_TCUT)
		    {
		      gdImageSetPixel(im, n, m, 3);
		      
		      if (n > 1)
			gdImageSetPixel(im, n - 1, m, 3);
		      if (m > 1)
			gdImageSetPixel(im, n, m - 1, 3);
		      if (n < xp - 1)
			gdImageSetPixel(im, n + 1, m, 3);
		      if (m < xp - 1)
			gdImageSetPixel(im, n, m + 1, 3);
		      if ((n > 1) && (m > 1))
			gdImageSetPixel(im, n - 1, m - 1, 0);
		      if ((n > 1) && (m < yp - 1))
			gdImageSetPixel(im, n - 1, m + 1, 0);
		      if ((n < xp - 1) && (m > 1))
			gdImageSetPixel(im, n + 1, m - 1, 0);
		      if ((n < xp - 1) && (m < yp - 1))
			gdImageSetPixel(im, n + 1, m + 1, 0);
		    }
		}

	      /* Remember points */

	      n0 = n;
	      m0 = m;
	      trk0 = trk;
	      idx0 = idx;

	      /* Next point */

	      ptr = NextItem(ptr);
	    }
	  
	  /* Check if all requested tracks are plotted and reset */
	  /* pointer to avoid further function calls */

	  if (NextItem(gpl) < VALID_PTR)
	    if (idx == (long)RDB[DATA_TRACK_PLOTTER_HIS])
	      {
		/* Reset pointer */

		WDB[DATA_PTR_TRCK0] = NULLPTR;

		/* Check stop mode */

		if ((long)RDB[DATA_STOP_AFTER_PLOT] == STOP_AFTER_PLOT_TRACKS)
		  ext = YES;
	      }
	}
    
      /***********************************************************************/

      /***** Write in file and cleanup ***************************************/

      /* Open file for writing */
      
      if ((fp = fopen(fname, "w")) == NULL)      
	Die(FUNCTION_NAME, "Unable to open file for writing"); 

      /* Write image (png format) */
      
      gdImagePng(im, fp);
      
      /* Free image */
      
      gdImageDestroy(im);

      /* Free matrix */
      
      for(n = 0; n < xp; n++)
	Mem(MEM_FREE, matrix[n]);
      
      Mem(MEM_FREE, matrix);

      /* Close file */

      fclose(fp);

      /***********************************************************************/
      
      /* Next plot */

      gpl = NextItem(gpl);
    }  

  /***************************************************************************/

  /* Reset plotter mode */
  
  WDB[DATA_PLOTTER_MODE] = (double)NO;

  /* Done */

  if (ini == YES)
    fprintf(out, " 100%% complete\n\n"); 

  /* Check stop mode */

  if (((long)RDB[DATA_STOP_AFTER_PLOT] == STOP_AFTER_PLOT_GEOM) || 
      (ext == YES))
    exit(-1);

#endif
}

/*****************************************************************************/
