/*****************************************************************************/

/***** Main data array (direct pointers) *************************************/

/* Data sizes */

#define DATA_ASCII_DATA_SIZE              0
#define DATA_ALLOC_MAIN_SIZE              1
#define DATA_REAL_MAIN_SIZE               3
#define DATA_ALLOC_ACE_SIZE               4
#define DATA_REAL_ACE_SIZE                5
#define DATA_ALLOC_PRIVA_SIZE             6
#define DATA_REAL_PRIVA_SIZE              7
#define DATA_ALLOC_RES1_SIZE              8
#define DATA_REAL_RES1_SIZE               9
#define DATA_ALLOC_RES2_SIZE             10
#define DATA_REAL_RES2_SIZE              11
#define DATA_ALLOC_BUF_SIZE              12
#define DATA_REAL_BUF_SIZE               13

#define DATA_TOTAL_BYTES                 14
#define DATA_REAL_BYTES                  15
#define DATA_BYTE_COUNT                  16

#define DATA_TOT_XS_BYTES                17
#define DATA_TOT_MAT_BYTES               18
#define DATA_TOT_RES_BYTES               19
#define DATA_TOT_MISC_BYTES              20

/* Cpu name and memory size */

#define DATA_CPU_MEM                     21
#define DATA_PTR_CPU_NAME                22
#define DATA_CPU_MHZ                     23

/* Date */

#define DATA_PTR_DATE                    24

/* Title */

#define DATA_PTR_TITLE                   25

/* CPU time */

#define DATA_CPU_T0                      30
#define DATA_CPU_TIME                    35

/* List pointers */

#define DATA_PTR_S0                      90
#define DATA_PTR_T0                      91
#define DATA_PTR_M0                      92
#define DATA_PTR_NUC0                    93
#define DATA_PTR_ACE0                    94
#define DATA_PTR_DECAY_ACE0              95
#define DATA_PTR_TRANSMU_ACE0            96
#define DATA_PTR_C0                      97
#define DATA_PTR_NST0                    98
#define DATA_PTR_TR0                     99
#define DATA_PTR_GPL0                   100
#define DATA_PTR_MPL0                   101
#define DATA_PTR_PB0                    102
#define DATA_PTR_L0                     103
#define DATA_PTR_LVL0                   104
#define DATA_PTR_SCORE0                 105
#define DATA_PTR_U0                     106
#define DATA_PTR_SRC0                   107
#define DATA_PTR_DET0                   108
#define DATA_PTR_ENE0                   109
#define DATA_PTR_GCU0                   110
#define DATA_PTR_TFB0                   111
#define DATA_PTR_IFC0                   112
#define DATA_PTR_TRCK0                  113
#define DATA_PTR_DIV0                   114
#define DATA_PTR_MVOL0                  115
#define DATA_PTR_SYM0                   116
#define DATA_PTR_REP0                   117
#define DATA_PTR_TME0                   119
#define DATA_PTR_RIA0                   120
#define DATA_PTR_SIM0                   121
#define DATA_PTR_ADF0                   122
#define DATA_PTR_MORA0                  123

/* File names and paths */

#define DATA_PTR_ACEDATA_FNAME_LIST     131
#define DATA_PTR_INPUT_FNAME            132
#define DATA_PTR_DECDATA_FNAME_LIST     133
#define DATA_PTR_NFYDATA_FNAME_LIST     134
#define DATA_PTR_SFYDATA_FNAME_LIST     135
#define DATA_PTR_IBR_FNAME              136

/* Stuff for burnup calculation */

#define DATA_BU_SPECTRUM_COLLAPSE       141
#define DATA_BU_URES_EMIN               144
#define DATA_BU_URES_EMAX               145
#define DATA_BU_ACT_MIN_Z               146
#define DATA_BU_ACT_MAX_Z               147

/* Nuclide counters */

#define DATA_N_TOT_NUCLIDES             150
#define DATA_N_TRANSPORT_NUCLIDES       151
#define DATA_N_DOSIMETRY_NUCLIDES       152
#define DATA_N_DECAY_NUCLIDES           153
#define DATA_N_PHOTON_NUCLIDES          154

/* Geometry level data */

#define DATA_PTR_ROOT_UNIVERSE          158
#define DATA_GEOM_LEVELS                159
#define DATA_PTR_COLLISION_UNI          160

/* Global zone index */

#define DATA_PTR_ZONE_IDX               161

/* Geometry dimensions */

#define DATA_GEOM_MINX                  162
#define DATA_GEOM_MAXX                  163
#define DATA_GEOM_MINY                  164
#define DATA_GEOM_MAXY                  165
#define DATA_GEOM_MINZ                  166
#define DATA_GEOM_MAXZ                  167

#define DATA_GEOM_DIM                   168

/* ACE data pointers */

#define DATA_PTR_ACE_NFY_DATA           170
#define DATA_PTR_ACE_SFY_DATA           171

/* Fission product lists. (These are used to find the  */
/* ace data for FP nuclides in CombineFissionYields()) */

#define DATA_TOT_FP_NUCLIDES            180
#define DATA_PTR_FP_LIB_ID_LIST         181
#define DATA_PTR_FP_ZAI_LIST            182
#define DATA_PTR_AC_ZAI_LIST            183

/* Pointer to lost nuclide data */

#define DATA_PTR_NUCLIDE_LOST           185

/* Reaction counters */

#define DATA_N_TRANSPORT_REA            190
#define DATA_N_SPECIAL_REA              191
#define DATA_N_DECAY_REA                192
#define DATA_N_TRANSMUTATION_REA        193
#define DATA_N_TRANSPORT_BRANCH         194
#define DATA_N_DECAY_BRANCH             195
#define DATA_N_DEAD_PATH                196

/* Delayed neutron precursor groups */

#define DATA_PRECURSOR_GROUPS           210

/* Counters */

#define DATA_N_GEOM_PLOTS               220
#define DATA_N_PBED                     225
#define DATA_N_MATERIALS                226
#define DATA_N_BURN_MATERIALS           227
#define DATA_N_TOT_CELLS                228
#define DATA_N_UNION_CELLS              229

/*
#define DATA_N_CELLS                      0
#define DATA_N_SURFACES                   0
#define DATA_N_UNIVERSES                  0
#define DATA_N_LEVELS                     0

#define DATA_N_DETECTORS                  0
#define DATA_N_DEP                        0
#define DATA_N_MESH_PLOTS                 0
#define DATA_N_ISO                        0
#define DATA_N_TRANSP_ISO                 0
#define DATA_N_DECAY_ISO                  0
#define DATA_N_TOT_REA                    0 
#define DATA_N_BURN_MAT                   0
#define DATA_N_TRANSMU_REA                0
*/

/* Global and unionized energy grid data */

#define DATA_ERG_TOL                    241
#define DATA_ERG_INITIAL_PTS            242
#define DATA_ERG_IMPORTANT_PTS          243
#define DATA_ERG_PTR_UNIONIZED_NGRID    244
#define DATA_ERG_PTR_UNIONIZED_PGRID    245

/* Minimum and maximum energy allowed in transport calculation */

#define DATA_NEUTRON_EMIN               246
#define DATA_NEUTRON_EMAX               247

#define DATA_PHOTON_EMIN                248
#define DATA_PHOTON_EMAX                249

#define DATA_NEUTRON_XS_EMIN            250
#define DATA_NEUTRON_XS_EMAX            251

#define DATA_PHOTON_XS_EMIN             252
#define DATA_PHOTON_XS_EMAX             253

/* Minimum macroscopic cross section */

#define DATA_MIN_NMACROXS               254
#define DATA_MIN_PMACROXS               255

/* Boundary condition and albedo */

#define DATA_PTR_BC_SURF                256
#define DATA_GEOM_BC0                   257
#define DATA_GEOM_BC1                   258
#define DATA_GEOM_BC2                   259
#define DATA_GEOM_BC3                   260
#define DATA_GEOM_ALBEDO                261

/* Cut-offs */

#define DATA_DEP_TTA_CUTOFF             262
#define DATA_DEP_HALF_LIFE_CUTOFF       263
#define DATA_DEP_FP_YIELD_CUTOFF        264
#define DATA_MIN_TOTXS                  265
#define DATA_URES_DILU_CUT              266
#define DATA_TIME_CUT_TMIN              267
#define DATA_TIME_CUT_TMAX              268
#define DATA_GEN_CUT                    269

/* Equilibrium Xe-135 calculation */

#define DATA_XE135_DC                   270
#define DATA_I135_DC                    271
#define DATA_PM149_DC                   272

#define DATA_MAX_XENON_PTR_MAT          273
#define DATA_MAX_SAMARIUM_PTR_MAT       274
#define DATA_XENON_EQUILIBRIUM_MODE     275
#define DATA_SAMARIUM_EQUILIBRIUM_MODE  276
#define DATA_PTR_XENON_MAT_LIST         277
#define DATA_PTR_SAMARIUM_MAT_LIST      278

/* Xenon entropy */

#define DATA_XENON_ENTROPY              279

/* Warning messages */

#define DATA_WARN_NFY_SUM               280
#define DATA_WARN_SFY_SUM               281
#define DATA_WARN_ERROR_AWR             282
#define DATA_WARN_ERROR_BRANCH          283

/* Dummy variable (used by GetText(), etc.) */

#define DATA_DUMMY                      300

/* Geometry plotter */

#define DATA_STOP_AFTER_PLOT            310
#define DATA_PLOTTER_MODE               311
#define DATA_QUICK_PLOT_MODE            312

/* Monte Carlo volume calculation */

#define DATA_VOLUME_MC_NMAX             320
#define DATA_VOLUME_MC_TMAX             321
#define DATA_VOLUME_MC_EMAX             322

/* URES variables */

#define DATA_URES_AVAIL                 327
#define DATA_USE_URES                   328
#define DATA_URES_PTR_USE_LIST          329
#define DATA_URES_USED                  330
#define DATA_URES_EMIN                  331
#define DATA_URES_EMAX                  332

/* DBRC */

#define DATA_USE_DBRC                   335
#define DATA_PTR_DBRC                   336
#define DATA_DBRC_EMIN                  337
#define DATA_DBRC_EMAX                  338
#define DATA_PTR_DBRC_COUNT             339
#define DATA_PTR_DBRC_EXCEED_COUNT      340

/* Normalization */

#define DATA_PTR_NORM                   341
#define DATA_NORM_U235_FISSE            342
#define DATA_NORM_INCLUDE_DH            343
#define DATA_NORM_BURN                  344
#define DATA_INI_FMASS                  345
#define DATA_INI_BURN_FMASS             346
#define DATA_TOT_FMASS                  347
#define DATA_TOT_BURN_FMASS             348

/* Isomeric branching ratio data */

#define DATA_PTR_IBR_LIST               349

/* Majorants */

#define DATA_PTR_MAJORANT               350
#define DATA_PTR_PHOTON_MAJORANT        351

/* Optimization and memory/data options */

#define DATA_OPTI_MODE                  352
#define DATA_OPTI_UNIONIZE_GRID         353
#define DATA_OPTI_RECONSTRUCT_MICROXS   355
#define DATA_OPTI_RECONSTRUCT_MACROXS   356
#define DATA_OPTI_INCLUDE_SPECIALS      357
#define DATA_OPTI_MODE0_INCLUDE_TOTAL   358
#define DATA_OPTI_IMPLICIT_RR           359
#define DATA_OPTI_GC_CALC               360
#define DATA_OPTI_MG_MODE               361
#define DATA_OPTI_SHARED_BUF            363
#define DATA_OPTI_SHARED_RES2           364
#define DATA_OPTI_OMP_REPRODUCIBILITY   365
#define DATA_OPTI_REPLAY                366
#define DATA_OPTI_ENTROPY_CALC          367
#define DATA_OPTI_PRINT_HIS             368
#define DATA_OPTI_MPI_REPRODUCIBILITY   369
#define DATA_OPTI_POISON_CALC           370
#define DATA_OPTI_MPI_BATCH_SIZE        371

#define DATA_MPI_TOT_PARTICLES          372

/* Delta-tracking */

#define DATA_OPT_USE_DT                 373
#define DATA_DT_NTHRESH                 374
#define DATA_DT_PTHRESH                 375
#define DATA_DT_PTR_BLOCK_LIST          376
#define DATA_DT_PTR_FORCE_LIST          377

/* Implicit Monte Carlo (TODO: ota toi OPT pois nimest�) */

#define DATA_OPT_IMPL_CAPT              380
#define DATA_OPT_IMPL_FISS              381
#define DATA_OPT_IMPL_NXN               382
#define DATA_OPT_ROULETTE_W0            383
#define DATA_OPT_ROULETTE_P0            384

/* Cross section plotter */

#define DATA_XSPLOT_NE                  390
#define DATA_XSPLOT_EMIN                391
#define DATA_XSPLOT_EMAX                392

/* Run parameters */

#define DATA_CRIT_POP                   402
#define DATA_CRIT_CYCLES                403
#define DATA_CRIT_SKIP                  404
#define DATA_SRC_POP                    405
#define DATA_SRC_BATCHES                406
#define DATA_SIMUL_BATCH_SIZE           407
#define DATA_SIMULATION_MODE            408
#define DATA_CYCLE_IDX                  409
#define DATA_SIMULATION_COMPLETED       410
#define DATA_BATCH_INTERVAL             411
#define DATA_BATCH_COUNT                412
#define DATA_DYN_PTR_TIME_BINS          413
#define DATA_DYN_POP_MIN                414
#define DATA_DYN_POP_MAX                415
#define DATA_DYN_TMIN                   416
#define DATA_DYN_TMAX                   417
#define DATA_DYN_NB                     418
#define DATA_DYN_TB                     419
#define DATA_DYN_WGT0                   420

#define DATA_OMP_MAX_THREADS            421
#define DATA_PTR_OMP_HISTORY_COUNT      422

/* Running modes */

#define DATA_NEUTRON_TRANSPORT_MODE     423
#define DATA_PHOTON_TRANSPORT_MODE      424
#define DATA_BURNUP_CALCULATION_MODE    425
#define DATA_VOLUME_CALCULATION_MODE    426
#define DATA_PARTICLE_DISPERSER_MODE    427

/* Storage space for neutrons and gammas */

#define DATA_PART_PTR_NSTACK            429
#define DATA_PART_PTR_GSTACK            430
#define DATA_PART_PTR_QUE               431
#define DATA_PART_PTR_SOURCE            432
#define DATA_PART_PTR_BANK              433
#define DATA_PART_ALLOC_N               434
#define DATA_PART_ALLOC_G               435
#define DATA_PART_NBUF_FACTOR           436
#define DATA_PART_GBUF_FACTOR           437
#define DATA_PART_MIN_NSTACK            438
#define DATA_PART_MIN_GSTACK            439

/* Size of history list */

#define DATA_HIST_LIST_SIZE             440

/* Run-time variables */

#define DATA_CYCLE_PROMPT_WGT           441
#define DATA_CYCLE_DELAYED_WGT          442
#define DATA_CYCLE_KEFF                 443
#define DATA_NHIST_TOT                  444
#define DATA_N_POP_EIG                  445
#define DATA_POP_EIG                    446

/* N�� on ehk� sama asia ? */

#define DATA_NHIST_CYCLE                447
#define DATA_CYCLE_BATCH_SIZE           448

/* Estimated running times */

#define DATA_ESTIM_CYCLE_TIME           449
#define DATA_ESTIM_TOT_TIME             450

/* Radioactivity data */

#define DATA_TOT_ING_TOX                451
#define DATA_TOT_INH_TOX                452
#define DATA_TOT_ACTIVITY               453
#define DATA_TOT_SFRATE                 454
#define DATA_TOT_DECAY_HEAT             455
#define DATA_BURN_SFRATE                456
#define DATA_BURN_DECAY_HEAT            457
#define DATA_ACT_ACTIVITY               458
#define DATA_ACT_DECAY_HEAT             459
#define DATA_FP_ACTIVITY                460
#define DATA_FP_DECAY_HEAT              461
#define DATA_SR90_ACTIVITY              462
#define DATA_TE132_ACTIVITY             463
#define DATA_I131_ACTIVITY              464
#define DATA_I132_ACTIVITY              465
#define DATA_CS134_ACTIVITY             466
#define DATA_CS137_ACTIVITY             467

/* Group constant generation */

#define DATA_ERG_FG_NG                  468
#define DATA_ERG_FG_PTR_GRID            469
#define DATA_ERG_FG_PTR_PREDEF          470
#define DATA_GCU_PTR_UNI                471

/* Core power distribution */

#define DATA_CORE_PDE_DEPTH             472
#define DATA_CORE_PDE_NZ                473
#define DATA_CORE_PDE_ZMIN              474
#define DATA_CORE_PDE_ZMAX              475
#define DATA_CORE_PDE_PTR_CORE          476
#define DATA_CORE_PDE_PTR_ASS           477
#define DATA_CORE_PDE_PTR_RES0          478
#define DATA_CORE_PDE_PTR_RES1          479
#define DATA_CORE_PDE_PTR_RES2          480
#define DATA_CORE_PDE_N0                481
#define DATA_CORE_PDE_N1                482
#define DATA_CORE_PDE_N2                483

/* Uniform fission source */

#define DATA_UFS_MODE                   484
#define DATA_UFS_PTR_FACTORS            485
#define DATA_UFS_PTR_SRC_MESH           486
#define DATA_UFS_ORDER                  487
#define DATA_UFS_MIN                    488
#define DATA_UFS_MAX                    489

/* Fission source entropy */

#define DATA_ENTROPY_NX                 490
#define DATA_ENTROPY_NY                 491
#define DATA_ENTROPY_NZ                 492
#define DATA_ENTROPY_XMIN               493
#define DATA_ENTROPY_XMAX               494
#define DATA_ENTROPY_YMIN               495
#define DATA_ENTROPY_YMAX               496
#define DATA_ENTROPY_ZMIN               497
#define DATA_ENTROPY_ZMAX               498
#define DATA_ENTROPY_PTR_SPT_STAT       499
#define DATA_ENTROPY_PTR_SWG_STAT       500

/* Burnup calculation stuff */

#define DATA_BURN_CALC_INI_MASS         501
#define DATA_BURN_DECAY_CALC            502
#define DATA_BURN_STEP_PC               503
#define DATA_BURN_BUMODE                504
#define DATA_BURN_CRAM_K                505
#define DATA_BURN_STEP                  506
#define DATA_BURN_TIME_INTERVAL         507
#define DATA_BURN_BURNUP_INTERVAL       508
#define DATA_BURN_PTR_DEP               509
#define DATA_BURN_CUM_BURNTIME          510
#define DATA_BURN_CUM_BURNUP            511
#define DATA_BURN_CUM_REAL_BURNUP       512
#define DATA_BURN_PTR_INVENTORY         513
#define DATA_BURN_INVENTORY_NUCLIDES    514
#define DATA_BURN_PRINT_DEPMTX          515
#define DATA_BURN_ENECUT                516
#define DATA_BURN_TOT_STEPS             517
#define DATA_BURN_PRED_STEP             518
#define DATA_BURN_CORR_STEP             519
#define DATA_BURN_PRINT_COMP            520
#define DATA_BURN_PRINT_COMP_LIM        521
#define DATA_BURN_STEP_TYPE             522
#define DATA_BURN_MAT_OUTPUT            523
#define DATA_BURN_MATERIALS_FLAG        524
#define DATA_BURN_PREV_KEFF             525
#define DATA_BURN_PREV_DKEFF            526

/* Counters needed for burnup calculation */

#define DATA_TOT_NUCLIDES               527
#define DATA_PRED_TRANSPORT_TIME        528
#define DATA_CORR_TRANSPORT_TIME        529

/* Parameters for top inventory calculation */

#define DATA_BURN_INV_TOP_MASS          530
#define DATA_BURN_INV_TOP_ACTIVITY      531
#define DATA_BURN_INV_TOP_SF            532
#define DATA_BURN_INV_TOP_DECAY_HEAT    533
#define DATA_BURN_INV_TOP_ING_TOX       534
#define DATA_BURN_INV_TOP_INH_TOX       535

/* Fundamental mode calculation */

#define DATA_B1_CALC                    536
#define DATA_B1_BURNUP_CORR             537
#define DATA_FUM_ERR_LIMIT              538

/* Micro-group structure (for Diffusion coefficient and B1) */

#define DATA_MICRO_CALC_MODE            540
#define DATA_MICRO_PTR_EGRID            541
#define DATA_MICRO_PTR_IDX_MAP          542

/* lengths of the previous step and preceding predictor (AIs) */

#define DATA_BURN_PS1_LENGTH            546
#define DATA_BURN_PRED_LENGTH           547

/* Old total powers, used in SetDepStepSize only. (AIs) */

#define DATA_BURN_POW_PS1               548
#define DATA_BURN_POW_BOS               549
#define DATA_BURN_POW_EOS               550

/* weights in the coefficients of 2. order poly fit for burnup calculation */
/* see depletionpolyfit.c for more (AIs)*/

#define DATA_BURN_FIT_C2W1              551
#define DATA_BURN_FIT_C2W2              552
#define DATA_BURN_FIT_C2W3              553
#define DATA_BURN_FIT_C1W1              554
#define DATA_BURN_FIT_C1W2              555
#define DATA_BURN_FIT_C1W3              556
#define DATA_BURN_FIT_C0W1              557
#define DATA_BURN_FIT_C0W2              558
#define DATA_BURN_FIT_C0W3              559
#define DATA_BURN_FIT_TYPE              560

#define DATA_BURN_PRED_TYPE             561
#define DATA_BURN_PRED_NSS              562
#define DATA_BURN_CORR_TYPE             563
#define DATA_BURN_CORR_NSS              564

/* Energy grid for coarse multi-group cross sections */

#define DATA_COARSE_MG_NE               565
#define DATA_COARSE_MG_PTR_GRID         566

/* Delayed nubar option */

#define DATA_USE_DELNU                  568

/* Doppler-broadening mode and temperature feedback */

#define DATA_USE_DOPPLER_PREPROCESSOR   577
#define DATA_ETTM_MODE                  579
#define DATA_USE_TFB                    581
#define DATA_USE_DENSITY_FACTOR         582
#define DATA_ETTM_PTR_FAIL_STAT         583

/* RNG seed (updated) and tracking collison counter */

#define DATA_PTR_RNG_SEED               590
#define DATA_PTR_COLLISION_COUNT        591

/* Buffer and RES2 reduced flag */

#define DATA_BUF_REDUCED                592
#define DATA_RES2_REDUCED               593

/* Include scattering production in removal xs */

#define DATA_GC_REMXS_MULT              594

/* Calculation of analog reaction rates */

#define DATA_ANA_RR_NCALC               595
#define DATA_ANA_RR_PCALC               596

/* Recorded track points for plots */

#define DATA_TRACK_PLOTTER_HIS          597
#define DATA_TRACK_PLOT_PTR_NEXT        598

/* Pointers to pre-allocated work arrays */

#define DATA_PTR_WORK_GRID1             599
#define DATA_PTR_WORK_GRID2             600

/* Reaction sampling */

#define DATA_NPHYS_SAMPLE_FISS          605
#define DATA_NPHYS_SAMPLE_CAPT          606
#define DATA_NPHYS_SAMPLE_SCATT         607

/* Other stuff */

#define DATA_PRINT_PREV_COMPLETE        608
#define DATA_RESEED_QUE                 609
#define DATA_ALLOW_MEM_OP               610
#define DATA_PTR_CRIT_SRC_DET           611
#define DATA_PTR_RIA_SRC                612
#define DATA_ALPHA_EIG                  613
#define DATA_NORM_COEF_N                614
#define DATA_NORM_COEF_G                615

/* Minimum xs for CFE */

#define DATA_CFE_N_MIN_L                617
#define DATA_CFE_N_MIN_T                618
#define DATA_CFE_G_MIN_L                619
#define DATA_CFE_G_MIN_T                620

/* Brute-force S(a,b) */

#define DATA_BF_SAB_NE                  621
#define DATA_BF_SAB_NMU                 622
#define DATA_BF_SAB_LIM                 623
#define DATA_BF_SAB_FRAC                624

/* Cache-optimized xs block */

#define DATA_PTR_CACHE_OPTI_XS          625
#define DATA_CACHE_OPTI_EMAX            626
#define DATA_CACHE_OPTI_NE              627
#define DATA_CACHE_OPTI_NREA            628

/* Fission matrix */

#define DATA_PTR_FMTX                   629
#define DATA_FMTX_TYPE                  630

/* extra burnup algorithm parameters for corrector iteration (AIs) */

#define DATA_BURN_CI_TYPE               656 /* see below (AIs) */     
#define DATA_BURN_CI_MAXI               657 /* max # of iterations (AIs)*/
#define DATA_BURN_CI_I                  658 /* curent iter. (AIs) */
#define DATA_BURN_CI_LAST               659 /* YES/NO flags last iteration */

#define DATA_BURN_CI_NBATCH             660
#define DATA_BURN_CI_CYCLES             661
#define DATA_BURN_CI_SKIP               662

/* Number of progenies for beta-eff and prompt lifetime calculation */

#define DATA_IFP_OPT_PRINT_ALL          663
#define DATA_IFP_CHAIN_LENGTH           664
#define DATA_PERT_VAR_A                 665
#define DATA_PERT_VAR_C                 666
#define DATA_PERT_N_BATCH               667

/* Output for simulator codes */

#define DATA_SIMULATOR_DATA             668
#define DATA_CAX_OUTPUT                 669

/* Homogenized diffusion Monte Carlo -viritelm� */

#define DATA_RUN_HDMC                   700
#define DATA_HDMC_POP                   701
#define DATA_HDMC_CYCLES                702
#define DATA_HDMC_SKIP                  703
#define DATA_HDMC_KEFF                  704

/* Last value in data block */

#define DATA_LAST_VALUE                 710

/*****************************************************************************/

/***** Statistical variables *************************************************/

#define RES_TOT_NEUTRON_LEAKRATE        DATA_LAST_VALUE + 1
#define RES_TOT_NEUTRON_LOSSRATE        DATA_LAST_VALUE + 2
#define RES_TOT_NEUTRON_SRCRATE         DATA_LAST_VALUE + 3
#define RES_TOT_NEUTRON_CUTRATE         DATA_LAST_VALUE + 4
#define RES_TOT_NEUTRON_RR              DATA_LAST_VALUE + 5
#define RES_TOT_NEUTRON_FLUX            DATA_LAST_VALUE + 6
#define RES_TOT_NEUTRON_POWER           DATA_LAST_VALUE + 7
#define RES_TOT_PHOTON_LEAKRATE         DATA_LAST_VALUE + 8
#define RES_TOT_PHOTON_LOSSRATE         DATA_LAST_VALUE + 9
#define RES_TOT_PHOTON_SRCRATE          DATA_LAST_VALUE + 10
#define RES_TOT_PHOTON_CUTRATE          DATA_LAST_VALUE + 11
#define RES_TOT_PHOTON_RR               DATA_LAST_VALUE + 12
#define RES_TOT_PHOTON_FLUX             DATA_LAST_VALUE + 13
#define RES_TOT_PHOTON_HEATRATE         DATA_LAST_VALUE + 14
#define RES_ANA_NUBAR                   DATA_LAST_VALUE + 15
#define RES_ANA_FISSE                   DATA_LAST_VALUE + 16
#define RES_IMP_FISSE                   DATA_LAST_VALUE + 17
#define RES_TOT_FISSRATE                DATA_LAST_VALUE + 18
#define RES_TOT_CAPTRATE                DATA_LAST_VALUE + 19
#define RES_TOT_INLPRODRATE             DATA_LAST_VALUE + 20
#define RES_TOT_ELARATE                 DATA_LAST_VALUE + 21
#define RES_TOT_ABSRATE                 DATA_LAST_VALUE + 22
#define RES_TOT_POWDENS                 DATA_LAST_VALUE + 23
#define RES_IMP_KEFF                    DATA_LAST_VALUE + 24
#define RES_IMP_KINF                    DATA_LAST_VALUE + 25
#define RES_ANA_KEFF                    DATA_LAST_VALUE + 26
#define RES_COL_KEFF                    DATA_LAST_VALUE + 27
#define RES_MEAN_POP_SIZE               DATA_LAST_VALUE + 28
#define RES_MEAN_POP_WGT                DATA_LAST_VALUE + 29
#define RES_SRC_MULT                    DATA_LAST_VALUE + 30
#define RES_TOT_GENRATE                 DATA_LAST_VALUE + 31
#define RES_TOT_RECIPVEL                DATA_LAST_VALUE + 32

#define RES_ANA_FISS_FRAC               DATA_LAST_VALUE + 41
#define RES_ANA_CONV_RATIO              DATA_LAST_VALUE + 42

#define RES_CYCLE_RUNTIME               DATA_LAST_VALUE + 43
#define RES_CPU_USAGE                   DATA_LAST_VALUE + 44
#define RES_INI_SRC_WGT                 DATA_LAST_VALUE + 57
#define RES_NEW_SRC_WGT                 DATA_LAST_VALUE + 58
#define RES_EXT_K                       DATA_LAST_VALUE + 59
#define RES_NORM_COEF                   DATA_LAST_VALUE + 60

#define RES_ALB_NEUTRON_LEAKRATE        DATA_LAST_VALUE + 69
#define RES_GEOM_ALBEDO                 DATA_LAST_VALUE + 70

/* Forward-weighted time constants */

#define RES_FWD_IMP_GEN_TIME            DATA_LAST_VALUE + 77
#define RES_FWD_IMP_LIFETIME            DATA_LAST_VALUE + 78
#define RES_FWD_ANA_BETA_ZERO           DATA_LAST_VALUE + 79
#define RES_FWD_ANA_LAMBDA              DATA_LAST_VALUE + 80

/* Adjoint-weighted time constants */

#define RES_ADJ_MEULEKAMP_BETA_EFF      DATA_LAST_VALUE + 81
#define RES_ADJ_MEULEKAMP_LAMBDA        DATA_LAST_VALUE + 82
#define RES_ADJ_IFP_GEN_TIME            DATA_LAST_VALUE + 83
#define RES_ADJ_IFP_LIFETIME            DATA_LAST_VALUE + 84
#define RES_ADJ_IFP_BETA_EFF            DATA_LAST_VALUE + 85
#define RES_ADJ_IFP_LAMBDA              DATA_LAST_VALUE + 86
#define RES_ADJ_IFP_ROSSI_ALPHA         DATA_LAST_VALUE + 87
#define RES_ADJ_PERT_GEN_TIME           DATA_LAST_VALUE + 88
#define RES_ADJ_PERT_LIFETIME           DATA_LAST_VALUE + 89
#define RES_ADJ_PERT_BETA_EFF           DATA_LAST_VALUE + 90
#define RES_ADJ_PERT_ROSSI_ALPHA        DATA_LAST_VALUE + 91

/* Misc. analog time constants */

#define RES_ANA_PHOTON_LIFETIME         DATA_LAST_VALUE + 92
#define RES_ANA_DELAYED_EMTIME          DATA_LAST_VALUE + 93
#define RES_ANA_SLOW_TIME               DATA_LAST_VALUE + 94
#define RES_ANA_THERM_TIME              DATA_LAST_VALUE + 95
#define RES_ANA_THERM_FRAC              DATA_LAST_VALUE + 96

#define RES_ST_TRACK_FRAC               DATA_LAST_VALUE + 100
#define RES_DT_TRACK_FRAC               DATA_LAST_VALUE + 101
#define RES_DT_TRACK_EFF                DATA_LAST_VALUE + 102
#define RES_IFC_COL_EFF                 DATA_LAST_VALUE + 103
#define RES_TOT_COL_EFF                 DATA_LAST_VALUE + 104
#define RES_REA_SAMPLING_EFF            DATA_LAST_VALUE + 105
#define RES_REA_SAMPLING_FAIL           DATA_LAST_VALUE + 106
#define RES_AVG_SURF_CROSS              DATA_LAST_VALUE + 107

#define RES_MEAN_NGEN                   DATA_LAST_VALUE + 108

#define RES_DYN_PERIOD                  DATA_LAST_VALUE + 109
#define RES_DYN_POP                     DATA_LAST_VALUE + 110

/* Myrkyt */

#define RES_I135_EQUIL_CONC             DATA_LAST_VALUE + 111
#define RES_XE135_EQUIL_CONC            DATA_LAST_VALUE + 112
#define RES_XE135_ABSRATE               DATA_LAST_VALUE + 113

#define RES_PM149_EQUIL_CONC            DATA_LAST_VALUE + 114
#define RES_SM149_EQUIL_CONC            DATA_LAST_VALUE + 115
#define RES_SM149_ABSRATE               DATA_LAST_VALUE + 116


#define RES_ETTM_SAMPLING_EFF           DATA_LAST_VALUE + 117
#define RES_MIN_MACROXS                 DATA_LAST_VALUE + 118

#define RES_STAT_VARIABLES              118

/* Size of fixed data block and minimum acceptable pointer (NOTE: tossa */
/* pit�� nyt olla + 1 koska noi viittaa samaan blokkiin. Sin�ns� turhan */
/* monimutkaisesti tehty. */

#define DATA_FIXED_BLOCK_SIZE           DATA_LAST_VALUE + RES_STAT_VARIABLES + 1
#define VALID_PTR                       DATA_FIXED_BLOCK_SIZE - 1

/*****************************************************************************/

/***** List data *************************************************************/

/* This is data stored for every item */

#define LIST_DATA_SIZE   4

#define LIST_PTR_NEXT    0
#define LIST_PTR_PREV    1
#define LIST_PTR_COMMON  2
#define LIST_PTR_DIRECT  3

/* This is common data in a separate structure */

#define LIST_COMMON_DATA_SIZE  5

#define LIST_COMMON_ITEM_SIZE      0
#define LIST_COMMON_PTR_ROOT       1
#define LIST_COMMON_N_ITEMS        2
#define LIST_COMMON_PTR_FIRST      3
#define LIST_COMMON_PTR_LAST       4

/*****************************************************************************/

/***** Common variables for input parameters *********************************/

/* PARAM_N_COMMON:iin ei lis�t� LIST_DATA_SIZE:a */

#define PARAM_N_COMMON   3

#define PARAM_PTR_NAME   LIST_DATA_SIZE + 0
#define PARAM_PTR_FNAME  LIST_DATA_SIZE + 1
#define PARAM_LINE       LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Material block ********************************************************/

/* TODO: N�it� nimi� pit�� seriously j�rkev�itt�� !!! */

#define MATERIAL_BLOCK_SIZE            LIST_DATA_SIZE + PARAM_N_COMMON + 103

#define MATERIAL_OPTIONS               LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define MATERIAL_PTR_NAME              LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define MATERIAL_PTR_COMP              LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define MATERIAL_PTR_MIX               LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define MATERIAL_RGB                   LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define MATERIAL_VOLUME                LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define MATERIAL_VOLUME_GIVEN          LIST_DATA_SIZE + PARAM_N_COMMON + 7
#define MATERIAL_MASS                  LIST_DATA_SIZE + PARAM_N_COMMON + 8
#define MATERIAL_MASS_GIVEN            LIST_DATA_SIZE + PARAM_N_COMMON + 9
#define MATERIAL_INI_FISS_MDENS        LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define MATERIAL_PTR_MC_VOLUME         LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define MATERIAL_BURN_RINGS            LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define MATERIAL_COLOUR_IDX            LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define MATERIAL_ADENS                 LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define MATERIAL_MDENS                 LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define MATERIAL_PTR_TOT_REA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define MATERIAL_PTR_ELA_REA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define MATERIAL_PTR_ABS_REA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define MATERIAL_PTR_FISS_REA_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define MATERIAL_PTR_INLP_REA_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define MATERIAL_PTR_PHOT_TOT_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define MATERIAL_PTR_PHOT_HEAT_LIST    LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define MATERIAL_PTR_TOT_URES_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define MATERIAL_PTR_ABS_URES_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define MATERIAL_PTR_ELA_URES_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define MATERIAL_PTR_FISS_URES_LIST    LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define MATERIAL_PTR_TMP_MAJORANT_LIST LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define MATERIAL_PTR_TOTXS             LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define MATERIAL_PTR_ELAXS             LIST_DATA_SIZE + PARAM_N_COMMON + 29
#define MATERIAL_PTR_ABSXS             LIST_DATA_SIZE + PARAM_N_COMMON + 30
#define MATERIAL_PTR_FISSXS            LIST_DATA_SIZE + PARAM_N_COMMON + 31
#define MATERIAL_PTR_INLPXS            LIST_DATA_SIZE + PARAM_N_COMMON + 32
#define MATERIAL_PTR_FISSE             LIST_DATA_SIZE + PARAM_N_COMMON + 33
#define MATERIAL_PTR_TOTPHOTXS         LIST_DATA_SIZE + PARAM_N_COMMON + 34
#define MATERIAL_PTR_HEATPHOTXS        LIST_DATA_SIZE + PARAM_N_COMMON + 35
#define MATERIAL_PTR_TMP_MAJORANTXS    LIST_DATA_SIZE + PARAM_N_COMMON + 36
#define MATERIAL_MEM_SIZE              LIST_DATA_SIZE + PARAM_N_COMMON + 37
#define MATERIAL_TOT_DIV_MEM_SIZE      LIST_DATA_SIZE + PARAM_N_COMMON + 38
#define MATERIAL_PTR_SAB               LIST_DATA_SIZE + PARAM_N_COMMON + 39
#define MATERIAL_PTR_DEP_TRA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 40
#define MATERIAL_PTR_DEP_FISS_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 41
#define MATERIAL_ACTIVITY              LIST_DATA_SIZE + PARAM_N_COMMON + 42
#define MATERIAL_SPEC_ACTIVITY         LIST_DATA_SIZE + PARAM_N_COMMON + 43
#define MATERIAL_SFRATE                LIST_DATA_SIZE + PARAM_N_COMMON + 44
#define MATERIAL_DECAY_HEAT            LIST_DATA_SIZE + PARAM_N_COMMON + 45
#define MATERIAL_PTR_FLUX_SPEC         LIST_DATA_SIZE + PARAM_N_COMMON + 46
#define MATERIAL_PTR_FLUX_SPEC_SUM     LIST_DATA_SIZE + PARAM_N_COMMON + 47
#define MATERIAL_PTR_BURN_FLUX         LIST_DATA_SIZE + PARAM_N_COMMON + 48
#define MATERIAL_BURN_FLUX_PS1         LIST_DATA_SIZE + PARAM_N_COMMON + 49
#define MATERIAL_BURN_FLUX_BOS         LIST_DATA_SIZE + PARAM_N_COMMON + 50
#define MATERIAL_BURN_FLUX_EOS         LIST_DATA_SIZE + PARAM_N_COMMON + 51
#define MATERIAL_BURN_FLUX_SSA         LIST_DATA_SIZE + PARAM_N_COMMON + 52
#define MATERIAL_BURNUP                LIST_DATA_SIZE + PARAM_N_COMMON + 53
#define MATERIAL_OMP_ID                LIST_DATA_SIZE + PARAM_N_COMMON + 54
#define MATERIAL_MPI_ID                LIST_DATA_SIZE + PARAM_N_COMMON + 55
#define MATERIAL_PTR_DATA_BLOCK        LIST_DATA_SIZE + PARAM_N_COMMON + 56
#define MATERIAL_DATA_BLOCK_SIZE       LIST_DATA_SIZE + PARAM_N_COMMON + 57
#define MATERIAL_PTR_IFC               LIST_DATA_SIZE + PARAM_N_COMMON + 58
#define MATERIAL_PROC_IDX              LIST_DATA_SIZE + PARAM_N_COMMON + 59
#define MATERIAL_BURN_IDX              LIST_DATA_SIZE + PARAM_N_COMMON + 60
#define MATERIAL_PTR_GCU               LIST_DATA_SIZE + PARAM_N_COMMON + 61
#define MATERIAL_PTR_DIV               LIST_DATA_SIZE + PARAM_N_COMMON + 63
#define MATERIAL_DIV_TYPE              LIST_DATA_SIZE + PARAM_N_COMMON + 64
#define MATERIAL_DIV_PTR_PARENT        LIST_DATA_SIZE + PARAM_N_COMMON + 65
#define MATERIAL_DIV_N_TOT_ZONES       LIST_DATA_SIZE + PARAM_N_COMMON + 66
#define MATERIAL_DIV_N_SUB_ZONES       LIST_DATA_SIZE + PARAM_N_COMMON + 67
#define MATERIAL_DIV_N_ZONES           LIST_DATA_SIZE + PARAM_N_COMMON + 68
#define MATERIAL_DIV_ZONE_IDX          LIST_DATA_SIZE + PARAM_N_COMMON + 69
#define MATERIAL_BURN_PRINT_OUTPUT     LIST_DATA_SIZE + PARAM_N_COMMON + 70
#define MATERIAL_DT_MODE               LIST_DATA_SIZE + PARAM_N_COMMON + 71
#define MATERIAL_URES_EMIN             LIST_DATA_SIZE + PARAM_N_COMMON + 72
#define MATERIAL_URES_EMAX             LIST_DATA_SIZE + PARAM_N_COMMON + 73
#define MATERIAL_VOL_COUNT             LIST_DATA_SIZE + PARAM_N_COMMON + 74
#define MATERIAL_BURN_SORT_FLAG        LIST_DATA_SIZE + PARAM_N_COMMON + 75
#define MATERIAL_TFB_DF                LIST_DATA_SIZE + PARAM_N_COMMON + 76
#define MATERIAL_FMTX_IDX              LIST_DATA_SIZE + PARAM_N_COMMON + 77
#define MATERIAL_PTR_I135_ISO          LIST_DATA_SIZE + PARAM_N_COMMON + 78
#define MATERIAL_PTR_XE135_ISO         LIST_DATA_SIZE + PARAM_N_COMMON + 79
#define MATERIAL_PTR_PM149_ISO         LIST_DATA_SIZE + PARAM_N_COMMON + 80
#define MATERIAL_PTR_SM149_ISO         LIST_DATA_SIZE + PARAM_N_COMMON + 81
#define MATERIAL_PTR_I135_PROD_RATE    LIST_DATA_SIZE + PARAM_N_COMMON + 82
#define MATERIAL_PTR_XE135_PROD_RATE   LIST_DATA_SIZE + PARAM_N_COMMON + 83
#define MATERIAL_PTR_PM149_PROD_RATE   LIST_DATA_SIZE + PARAM_N_COMMON + 84
#define MATERIAL_PTR_SM149_PROD_RATE   LIST_DATA_SIZE + PARAM_N_COMMON + 85
#define MATERIAL_PTR_I135_ABS_RATE     LIST_DATA_SIZE + PARAM_N_COMMON + 86
#define MATERIAL_PTR_XE135_ABS_RATE    LIST_DATA_SIZE + PARAM_N_COMMON + 87
#define MATERIAL_PTR_PM149_ABS_RATE    LIST_DATA_SIZE + PARAM_N_COMMON + 88
#define MATERIAL_PTR_SM149_ABS_RATE    LIST_DATA_SIZE + PARAM_N_COMMON + 89
#define MATERIAL_XENON_EQUIL_CALC      LIST_DATA_SIZE + PARAM_N_COMMON + 90
#define MATERIAL_SAMARIUM_EQUIL_CALC   LIST_DATA_SIZE + PARAM_N_COMMON + 91
#define MATERIAL_PTR_I135_CONC         LIST_DATA_SIZE + PARAM_N_COMMON + 92
#define MATERIAL_PTR_XE135_CONC        LIST_DATA_SIZE + PARAM_N_COMMON + 93
#define MATERIAL_PTR_PM149_CONC        LIST_DATA_SIZE + PARAM_N_COMMON + 94
#define MATERIAL_PTR_SM149_CONC        LIST_DATA_SIZE + PARAM_N_COMMON + 95
#define MATERIAL_DEFAULT_PTR_LIB_ID    LIST_DATA_SIZE + PARAM_N_COMMON + 96
#define MATERIAL_DEFAULT_TMP           LIST_DATA_SIZE + PARAM_N_COMMON + 97
#define MATERIAL_DOPPLER_TEMP          LIST_DATA_SIZE + PARAM_N_COMMON + 98
#define MATERIAL_ETTM_MODE             LIST_DATA_SIZE + PARAM_N_COMMON + 99
#define MATERIAL_ETTM_TMIN             LIST_DATA_SIZE + PARAM_N_COMMON + 100
#define MATERIAL_ETTM_TMAX             LIST_DATA_SIZE + PARAM_N_COMMON + 101
#define MATERIAL_USE_IFC               LIST_DATA_SIZE + PARAM_N_COMMON + 102

/*****************************************************************************/

/***** Nuclide composition in material ***************************************/

/* TODO: muuta tän nimi ISO:ksi? */

#define COMPOSITION_BLOCK_SIZE   LIST_DATA_SIZE + 3

#define COMPOSITION_PTR_NUCLIDE  LIST_DATA_SIZE + 0
#define COMPOSITION_ADENS        LIST_DATA_SIZE + 1
#define COMPOSITION_ADENS_BOS    LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Mixture composition ***************************************************/

/* TODO: muuta tän nimi ISO:ksi? */

#define MIXTURE_BLOCK_SIZE  LIST_DATA_SIZE + 3

#define MIXTURE_PTR_MAT     LIST_DATA_SIZE + 0
#define MIXTURE_VFRAC       LIST_DATA_SIZE + 1
#define MIXTURE_MFRAC       LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** XS data array *********************************************************/

#define NUCLIDE_BLOCK_SIZE             LIST_DATA_SIZE + 88

#define NUCLIDE_PTR_NAME               LIST_DATA_SIZE +  0
#define NUCLIDE_TYPE                   LIST_DATA_SIZE +  1
#define NUCLIDE_OPTIONS                LIST_DATA_SIZE +  2
#define NUCLIDE_TYPE_FLAGS             LIST_DATA_SIZE +  3
#define NUCLIDE_ZAI                    LIST_DATA_SIZE +  4
#define NUCLIDE_ZA                     LIST_DATA_SIZE +  5
#define NUCLIDE_Z                      LIST_DATA_SIZE +  6
#define NUCLIDE_A                      LIST_DATA_SIZE +  7
#define NUCLIDE_I                      LIST_DATA_SIZE +  8
#define NUCLIDE_AW                     LIST_DATA_SIZE +  9
#define NUCLIDE_AWR                    LIST_DATA_SIZE + 10
#define NUCLIDE_PTR_LIB_ID             LIST_DATA_SIZE + 16
#define NUCLIDE_PTR_ACE                LIST_DATA_SIZE + 17
#define NUCLIDE_PTR_DECAY_ACE          LIST_DATA_SIZE + 18
#define NUCLIDE_PTR_PHOTON_ACE         LIST_DATA_SIZE + 19
#define NUCLIDE_PTR_REA                LIST_DATA_SIZE + 20
#define NUCLIDE_N_TRANSPORT_REA        LIST_DATA_SIZE + 21
#define NUCLIDE_N_SPECIAL_REA          LIST_DATA_SIZE + 22
#define NUCLIDE_N_DECAY_REA            LIST_DATA_SIZE + 23
#define NUCLIDE_N_TRANSPORT_BRANCH     LIST_DATA_SIZE + 24
#define NUCLIDE_N_DECAY_BRANCH         LIST_DATA_SIZE + 25
#define NUCLIDE_N_TRANSMUTATION_REA    LIST_DATA_SIZE + 26
#define NUCLIDE_N_DEAD_PATH            LIST_DATA_SIZE + 27
#define NUCLIDE_N_TRANSMUTATION_PATH   LIST_DATA_SIZE + 28
#define NUCLIDE_LAMBDA                 LIST_DATA_SIZE + 29
#define NUCLIDE_DECAY_E                LIST_DATA_SIZE + 30
#define NUCLIDE_SFBR                   LIST_DATA_SIZE + 31
#define NUCLIDE_PTR_NFY_DATA           LIST_DATA_SIZE + 32
#define NUCLIDE_PTR_SFY_DATA           LIST_DATA_SIZE + 33
#define NUCLIDE_NFY_NE                 LIST_DATA_SIZE + 34
#define NUCLIDE_PATH_LEVEL             LIST_DATA_SIZE + 35
#define NUCLIDE_PTR_EGRID              LIST_DATA_SIZE + 36
#define NUCLIDE_EGRID_NE               LIST_DATA_SIZE + 37
#define NUCLIDE_EMIN                   LIST_DATA_SIZE + 38
#define NUCLIDE_EMAX                   LIST_DATA_SIZE + 39
#define NUCLIDE_MAX_TOTXS              LIST_DATA_SIZE + 40
#define NUCLIDE_PTR_TOTXS              LIST_DATA_SIZE + 41
#define NUCLIDE_PTR_SUM_ABSXS          LIST_DATA_SIZE + 42
#define NUCLIDE_PTR_ELAXS              LIST_DATA_SIZE + 43
#define NUCLIDE_PTR_FISSXS             LIST_DATA_SIZE + 44
#define NUCLIDE_PTR_NGAMMAXS           LIST_DATA_SIZE + 45
#define NUCLIDE_PTR_PHOTON_INCOHEXS    LIST_DATA_SIZE + 46
#define NUCLIDE_PTR_PHOTON_COHEXS      LIST_DATA_SIZE + 47
#define NUCLIDE_PTR_PHOTON_PHOTOELXS   LIST_DATA_SIZE + 48
#define NUCLIDE_PTR_PHOTON_PAIRPRODXS  LIST_DATA_SIZE + 49
#define NUCLIDE_PTR_PHOTON_HEATPRODXS  LIST_DATA_SIZE + 50
#define NUCLIDE_PTR_SAMPLE_REA_LIST    LIST_DATA_SIZE + 51
#define NUCLIDE_URES_EMIN              LIST_DATA_SIZE + 52
#define NUCLIDE_URES_EMAX              LIST_DATA_SIZE + 53
#define NUCLIDE_PTR_URES_RND           LIST_DATA_SIZE + 54
#define NUCLIDE_PTR_MATRIX_IDX         LIST_DATA_SIZE + 55
#define NUCLIDE_MEMSIZE                LIST_DATA_SIZE + 56
#define NUCLIDE_PTR_PHOTON_LINE_SPEC   LIST_DATA_SIZE + 57
#define NUCLIDE_IDX                    LIST_DATA_SIZE + 58
#define NUCLIDE_INVENTORY_IDX          LIST_DATA_SIZE + 59
#define NUCLIDE_TMP_IDX                LIST_DATA_SIZE + 60
#define NUCLIDE_PTR_TOTFISS_REA        LIST_DATA_SIZE + 61
#define NUCLIDE_SPEC_ING_TOX           LIST_DATA_SIZE + 62
#define NUCLIDE_SPEC_INH_TOX           LIST_DATA_SIZE + 63
#define NUCLIDE_ACE_PREC_GROUPS        LIST_DATA_SIZE + 64
#define NUCLIDE_PREV_COL_Z2            LIST_DATA_SIZE + 65
#define NUCLIDE_PREV_COL_COS           LIST_DATA_SIZE + 66
#define NUCLIDE_PREV_COL_ER            LIST_DATA_SIZE + 67
#define NUCLIDE_MIN_AFRAC              LIST_DATA_SIZE + 68
#define NUCLIDE_MAX_AFRAC              LIST_DATA_SIZE + 69
#define NUCLIDE_URES_SAMPLING          LIST_DATA_SIZE + 70
#define NUCLIDE_PTR_PHOTON_DATA        LIST_DATA_SIZE + 71
#define NUCLIDE_URES_INT               LIST_DATA_SIZE + 72
#define NUCLIDE_TMP_ADENS              LIST_DATA_SIZE + 73
#define NUCLIDE_TOT_MASS               LIST_DATA_SIZE + 74
#define NUCLIDE_TOT_ACTIVITY           LIST_DATA_SIZE + 75
#define NUCLIDE_TOT_SF                 LIST_DATA_SIZE + 76
#define NUCLIDE_TOT_DECAY_HEAT         LIST_DATA_SIZE + 77
#define NUCLIDE_TOT_ING_TOX            LIST_DATA_SIZE + 78
#define NUCLIDE_TOT_INH_TOX            LIST_DATA_SIZE + 79
#define NUCLIDE_TEMP                   LIST_DATA_SIZE + 80
#define NUCLIDE_XS_TEMP                LIST_DATA_SIZE + 81
#define NUCLIDE_MAJORANT_TEMP          LIST_DATA_SIZE + 84
#define NUCLIDE_ETTM_MIN_TEMP          LIST_DATA_SIZE + 85
#define NUCLIDE_ETTM_MAX_TEMP          LIST_DATA_SIZE + 86
#define NUCLIDE_DBRC_MAX_TEMP          LIST_DATA_SIZE + 87

/*****************************************************************************/

/****** FP identifier ********************************************************/

#define FP_IDENT_BLOCK_SIZE  LIST_DATA_SIZE + 3

#define FP_IDENT_PTR_ID      LIST_DATA_SIZE + 0
#define FP_IDENT_TEMP        LIST_DATA_SIZE + 1
#define FP_IDENT_ETTM        LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Photon spectrum *******************************************************/

#define PHOTON_LINE_SPEC_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define PHOTON_LINE_SPEC_E           LIST_DATA_SIZE + 0
#define PHOTON_LINE_SPEC_RI          LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Statistical variable **************************************************/

/* T�h�n ei voi laittaa LIST_DATA_SIZE:a */

#define STAT_BLOCK_SIZE              3

#define STAT_N                       0
#define STAT_X                       1
#define STAT_X2                      2

#define BUF_BLOCK_SIZE               3

#define BUF_VAL                      0
#define BUF_WGT                      1
#define BUF_N                        2

/*****************************************************************************/

/***** ACE data array ********************************************************/

/* T�ss� ei tarvita list dataa koska pointterit viittaa ACE taulukkoon */

#define ACE_BLOCK_SIZE                23

#define ACE_PTR_ALIAS                  0
#define ACE_PTR_NAME                   1
#define ACE_TYPE                       2
#define ACE_AW                         3
#define ACE_AWR                        4
#define ACE_ZAI                        5
#define ACE_ZA                         6
#define ACE_I                          7
#define ACE_TEMP                       8
#define ACE_PTR_LIB_ID                 9
#define ACE_PTR_NXS                   10
#define ACE_PTR_JXS                   11
#define ACE_PTR_XSS                   12
#define ACE_PTR_FILE                  13
#define ACE_LAMBDA                    14
#define ACE_DECAY_E                   15
#define ACE_PTR_DECAY_LIST            16
#define ACE_SFBR                      17
#define ACE_DECAY_NDK                 18
#define ACE_BOUND_ZA                  19
#define ACE_PTR_RAD_SPEC              20
#define ACE_DELNU_PREC                21
#define ACE_PTR_NEXT                  22

/*****************************************************************************/

/***** Energy grid structure *************************************************/

/* NOTE: T�m� on bin��ripuurakenne joka ei k�yt� linkitetyn listan */
/*       pointtereita tai rutiineja. */

#define ENERGY_GRID_BLOCK_SIZE    16

#define ENERGY_GRID_NE             0
#define ENERGY_GRID_I0             1
#define ENERGY_GRID_EMIN           2
#define ENERGY_GRID_EMAX           3
#define ENERGY_GRID_EMID           4
#define ENERGY_GRID_PTR_LOW        5
#define ENERGY_GRID_PTR_HIGH       6
#define ENERGY_GRID_PTR_DATA       7
#define ENERGY_GRID_NB             8
#define ENERGY_GRID_PTR_BINS       9
#define ENERGY_GRID_LOG_EMIN      10
#define ENERGY_GRID_LOG_EMAX      11
#define ENERGY_GRID_TYPE          12
#define ENERGY_GRID_PTR_PREV_VAL  13
#define ENERGY_GRID_INTERP_MODE   14
#define ENERGY_GRID_ALLOC_NE      15

/*****************************************************************************/

/***** Reaction data array ***************************************************/

#define REACTION_BLOCK_SIZE             LIST_DATA_SIZE + 65

#define REACTION_TYPE                   LIST_DATA_SIZE +  0
#define REACTION_NR                     LIST_DATA_SIZE +  1
#define REACTION_MT                     LIST_DATA_SIZE +  2
#define REACTION_RTYP2                  LIST_DATA_SIZE +  3
#define REACTION_RTYP3                  LIST_DATA_SIZE +  4
#define REACTION_RTYP4                  LIST_DATA_SIZE +  5
#define REACTION_RTYP5                  LIST_DATA_SIZE +  6
#define REACTION_BR                     LIST_DATA_SIZE +  7
#define REACTION_RFS                    LIST_DATA_SIZE +  8
#define REACTION_AWR                    LIST_DATA_SIZE +  9
#define REACTION_Q                      LIST_DATA_SIZE + 10
#define REACTION_TY                     LIST_DATA_SIZE + 11
#define REACTION_WGT_F                  LIST_DATA_SIZE + 12
#define REACTION_EMIN                   LIST_DATA_SIZE + 13
#define REACTION_EMAX                   LIST_DATA_SIZE + 14
#define REACTION_PTR_EGRID              LIST_DATA_SIZE + 15
#define REACTION_PTR_XS                 LIST_DATA_SIZE + 16
#define REACTION_XS_I0                  LIST_DATA_SIZE + 17
#define REACTION_XS_NE                  LIST_DATA_SIZE + 18
#define REACTION_TGT_ZAI                LIST_DATA_SIZE + 19
#define REACTION_PTR_TGT                LIST_DATA_SIZE + 20
#define REACTION_PTR_BRANCH_PARENT      LIST_DATA_SIZE + 21
#define REACTION_BRANCH_MT              LIST_DATA_SIZE + 22
#define REACTION_PTR_FISSY              LIST_DATA_SIZE + 23
#define REACTION_PTR_PARTIAL_LIST       LIST_DATA_SIZE + 24
#define REACTION_PTR_PARTIAL_URES_LIST  LIST_DATA_SIZE + 25
#define REACTION_PTR_NUCLIDE            LIST_DATA_SIZE + 26
#define REACTION_PTR_MAT                LIST_DATA_SIZE + 27
#define REACTION_PTR_PREV_XS            LIST_DATA_SIZE + 28
#define REACTION_PTR_PREV_XS0           LIST_DATA_SIZE + 29
#define REACTION_PTR_MAJORANT_XS        LIST_DATA_SIZE + 30
#define REACTION_PTR_URES               LIST_DATA_SIZE + 31
#define REACTION_PTR_ANG                LIST_DATA_SIZE + 32
#define REACTION_PTR_PHOTON_DIST        LIST_DATA_SIZE + 33
#define REACTION_URES_EMIN              LIST_DATA_SIZE + 34
#define REACTION_URES_EMAX              LIST_DATA_SIZE + 35
#define REACTION_PTR_ANA_RATE           LIST_DATA_SIZE + 36
#define REACTION_ITP                    LIST_DATA_SIZE + 37
#define REACTION_SAB_EMAX               LIST_DATA_SIZE + 38
#define REACTION_SAB_FRAC               LIST_DATA_SIZE + 39
#define REACTION_PTR_IBR                LIST_DATA_SIZE + 40
#define REACTION_PTR_TNUBAR             LIST_DATA_SIZE + 41
#define REACTION_PTR_DNUBAR             LIST_DATA_SIZE + 42
#define REACTION_PTR_PREC_LIST          LIST_DATA_SIZE + 43
#define REACTION_PTR_ERG                LIST_DATA_SIZE + 44
#define REACTION_PTR_TRANSMUXS          LIST_DATA_SIZE + 45
#define REACTION_FISSY_IE0              LIST_DATA_SIZE + 46
#define REACTION_FISSY_IE1              LIST_DATA_SIZE + 47
#define REACTION_FISSY_IE2              LIST_DATA_SIZE + 48
#define REACTION_I135_YIELD             LIST_DATA_SIZE + 49
#define REACTION_XE135_YIELD            LIST_DATA_SIZE + 50
#define REACTION_PM149_YIELD            LIST_DATA_SIZE + 51
#define REACTION_SM149_YIELD            LIST_DATA_SIZE + 52
#define REACTION_MODE                   LIST_DATA_SIZE + 53
#define REACTION_PTR_MGXS               LIST_DATA_SIZE + 54
#define REACTION_PTR_URES_MAX           LIST_DATA_SIZE + 55
#define REACTION_URES_MAX_N0            LIST_DATA_SIZE + 56
#define REACTION_URES_MAX_NP            LIST_DATA_SIZE + 57
#define REACTION_URES_INT               LIST_DATA_SIZE + 58
#define REACTION_SAB_MIN_EM_E           LIST_DATA_SIZE + 59
#define REACTION_SAB_MAX_EM_E           LIST_DATA_SIZE + 60
#define REACTION_PTR_NEW_SAB            LIST_DATA_SIZE + 61
#define REACTION_CACHE_OPTI_IDX         LIST_DATA_SIZE + 62
#define REACTION_PTR_TMP_MAJORANT       LIST_DATA_SIZE + 63
#define REACTION_PTR_0K_DATA            LIST_DATA_SIZE + 64

/*****************************************************************************/

/***** S(a,b) testi **********************************************************/

/* TODO: muuta nimi */

#define BRAVE_NEW_SAB_BLOCK_SIZE        LIST_DATA_SIZE +  7

#define BRAVE_NEW_SAB_NEI               LIST_DATA_SIZE +  0
#define BRAVE_NEW_SAB_NE                LIST_DATA_SIZE +  1
#define BRAVE_NEW_SAB_NMU               LIST_DATA_SIZE +  2
#define BRAVE_NEW_SAB_PTR_EI            LIST_DATA_SIZE +  3
#define BRAVE_NEW_SAB_PTR_EGRID         LIST_DATA_SIZE +  4
#define BRAVE_NEW_SAB_PTR_MUGRID        LIST_DATA_SIZE +  5
#define BRAVE_NEW_SAB_PTR_DATA          LIST_DATA_SIZE +  6

/*****************************************************************************/

/***** Reaction list array ***************************************************/

/* TODO: muuta noi nimet */

/*
#define LIST_ROOT_BLOCK_SIZE          LIST_DATA_SIZE + 9

#define LIST_ROOT_PTR_MAT             LIST_DATA_SIZE + 0
#define LIST_ROOT_REA_MODE            LIST_DATA_SIZE + 1
#define LIST_ROOT_N_REA               LIST_DATA_SIZE + 2
#define LIST_ROOT_N_MAX               LIST_DATA_SIZE + 3
#define LIST_ROOT_PTR_REA_LIST        LIST_DATA_SIZE + 4
#define LIST_ROOT_PTR_NEXT_REA        LIST_DATA_SIZE + 5
#define LIST_ROOT_PTR_NEXT_ISO        LIST_DATA_SIZE + 6
#define LIST_ROOT_PTR_NEXT_LST        LIST_DATA_SIZE + 7
#define LIST_ROOT_LIST_TYPE           LIST_DATA_SIZE + 8

#define REA_LIST_BLOCK_SIZE           LIST_DATA_SIZE + 6

#define REA_LIST_PTR_REA              LIST_DATA_SIZE + 0
#define REA_LIST_ADENS                LIST_DATA_SIZE + 1
#define REA_LIST_EMIN                 LIST_DATA_SIZE + 2
#define REA_LIST_EMAX                 LIST_DATA_SIZE + 3
#define REA_LIST_PTR_COUNT            LIST_DATA_SIZE + 4
#define REA_LIST_COMP_IDX             LIST_DATA_SIZE + 5
*/

#define RLS_BLOCK_SIZE          LIST_DATA_SIZE + 4

#define RLS_PTR_MAT             LIST_DATA_SIZE + 0
#define RLS_REA_MODE            LIST_DATA_SIZE + 1
#define RLS_PTR_REA0            LIST_DATA_SIZE + 2
#define RLS_PTR_NEXT            LIST_DATA_SIZE + 3

#define RLS_DATA_BLOCK_SIZE     LIST_DATA_SIZE + 8

#define RLS_DATA_PTR_NUCLIDE    LIST_DATA_SIZE + 0
#define RLS_DATA_PTR_REA        LIST_DATA_SIZE + 1
#define RLS_DATA_COMP_IDX       LIST_DATA_SIZE + 2
#define RLS_DATA_EMIN           LIST_DATA_SIZE + 3
#define RLS_DATA_EMAX           LIST_DATA_SIZE + 4
#define RLS_DATA_PTR_COUNT      LIST_DATA_SIZE + 5
#define RLS_DATA_MAX_ADENS      LIST_DATA_SIZE + 6
#define RLS_DATA_CUT            LIST_DATA_SIZE + 7

/*****************************************************************************/

/***** Nubar data ************************************************************/

#define NUBAR_BLOCK_SIZE              LIST_DATA_SIZE + 5

#define NUBAR_DATA_TYPE               LIST_DATA_SIZE + 0
#define NUBAR_PTR_POLY_DATA           LIST_DATA_SIZE + 1
#define NUBAR_PTR_EGRID               LIST_DATA_SIZE + 2
#define NUBAR_PTR_PTS                 LIST_DATA_SIZE + 3
#define NUBAR_PTR_PREV_VAL            LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Precursor data ********************************************************/

#define PREC_BLOCK_SIZE               LIST_DATA_SIZE + 5

#define PREC_IDX                      LIST_DATA_SIZE + 0
#define PREC_LAMBDA                   LIST_DATA_SIZE + 1
#define PREC_PTR_EGRID                LIST_DATA_SIZE + 2
#define PREC_PTR_PTS                  LIST_DATA_SIZE + 3
#define PREC_PTR_ERG                  LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** RIA simulation ********************************************************/

#define RIA_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 2

#define RIA_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define RIA_PTR_TME                   LIST_DATA_SIZE + PARAM_N_COMMON + 1

/*****************************************************************************/

/***** Energy distribution data **********************************************/

#define ERG_BLOCK_SIZE                LIST_DATA_SIZE + 7

#define ERG_PTR_EGRID                 LIST_DATA_SIZE + 0
#define ERG_PTR_PROB                  LIST_DATA_SIZE + 1
#define ERG_LAW                       LIST_DATA_SIZE + 2
#define ERG_INTERP                    LIST_DATA_SIZE + 3
#define ERG_PTR_DATA                  LIST_DATA_SIZE + 4
#define ERG_NR                        LIST_DATA_SIZE + 5
#define ERG_PTR_INTERP                LIST_DATA_SIZE + 6

/*****************************************************************************/

/***** Photon distribution data **********************************************/

#define PHOTON_DIST_BLOCK_SIZE        LIST_DATA_SIZE + 12

#define PHOTON_DIST_MCOH              LIST_DATA_SIZE + 0
#define PHOTON_DIST_PTR_WCO           LIST_DATA_SIZE + 1
#define PHOTON_DIST_PTR_COH_FFINT     LIST_DATA_SIZE + 2
#define PHOTON_DIST_PTR_COH_FF        LIST_DATA_SIZE + 3
#define PHOTON_DIST_MINC              LIST_DATA_SIZE + 4
#define PHOTON_DIST_PTR_VIC           LIST_DATA_SIZE + 5
#define PHOTON_DIST_PTR_INC_FF        LIST_DATA_SIZE + 6
#define PHOTON_DIST_FLO_N             LIST_DATA_SIZE + 7
#define PHOTON_DIST_PTR_FLO_E         LIST_DATA_SIZE + 8
#define PHOTON_DIST_PTR_FLO_PHI       LIST_DATA_SIZE + 9
#define PHOTON_DIST_PTR_FLO_Y         LIST_DATA_SIZE + 10
#define PHOTON_DIST_PTR_FLO_F         LIST_DATA_SIZE + 11

/*****************************************************************************/

/***** Isomeric branching ratio data *****************************************/

#define IBR_LIST_BLOCK_SIZE           LIST_DATA_SIZE + 6

#define IBR_LIST_ZAI                  LIST_DATA_SIZE + 0
#define IBR_LIST_MT                   LIST_DATA_SIZE + 1
#define IBR_LIST_BR                   LIST_DATA_SIZE + 2
#define IBR_LIST_NE                   LIST_DATA_SIZE + 3
#define IBR_LIST_PTR_EGRID            LIST_DATA_SIZE + 4
#define IBR_LIST_PTR_DATA             LIST_DATA_SIZE + 5

/*****************************************************************************/

/***** Depletion transmutation list ******************************************/

#define DEP_TRA_BLOCK_SIZE            LIST_DATA_SIZE + 6

#define DEP_TRA_PTR_REA               LIST_DATA_SIZE + 0
#define DEP_TRA_E0                    LIST_DATA_SIZE + 1
#define DEP_TRA_PTR_RESU              LIST_DATA_SIZE + 2
#define DEP_TRA_PS1                   LIST_DATA_SIZE + 3
#define DEP_TRA_BOS                   LIST_DATA_SIZE + 4
#define DEP_TRA_EOS                   LIST_DATA_SIZE + 5

/*****************************************************************************/

/***** Fission yield data array **********************************************/

/* Data block */

#define FISSION_YIELD_BLOCK_SIZE       LIST_DATA_SIZE + 6

#define FISSION_YIELD_PARENT_ZAI       LIST_DATA_SIZE + 0
#define FISSION_YIELD_E                LIST_DATA_SIZE + 1
#define FISSION_YIELD_NFP              LIST_DATA_SIZE + 2
#define FISSION_YIELD_ORIG_NFP         LIST_DATA_SIZE + 3
#define FISSION_YIELD_PTR_DISTR        LIST_DATA_SIZE + 4
#define FISSION_YIELD_PTR_NEXT         LIST_DATA_SIZE + 5

/* Yield entry */

#define FY_BLOCK_SIZE                  LIST_DATA_SIZE + 4

#define FY_TGT_ZAI                     LIST_DATA_SIZE + 0
#define FY_PTR_TGT                     LIST_DATA_SIZE + 1
#define FY_INDEPENDENT_FRAC            LIST_DATA_SIZE + 2
#define FY_CUMULATIVE_FRAC             LIST_DATA_SIZE + 3

/*****************************************************************************/

/***** Decay array ***********************************************************/

#define DECAY_BLOCK_SIZE               LIST_DATA_SIZE + 8

#define DECAY_RTYP1                    LIST_DATA_SIZE + 0
#define DECAY_RTYP2                    LIST_DATA_SIZE + 1
#define DECAY_RTYP3                    LIST_DATA_SIZE + 2
#define DECAY_RTYP4                    LIST_DATA_SIZE + 3
#define DECAY_RTYP5                    LIST_DATA_SIZE + 4
#define DECAY_RFS                      LIST_DATA_SIZE + 5
#define DECAY_Q                        LIST_DATA_SIZE + 6
#define DECAY_BR                       LIST_DATA_SIZE + 7

/*****************************************************************************/

/***** Radiation spectrum block size *****************************************/

#define RAD_SPEC_BLOCK_SIZE            LIST_DATA_SIZE + 10

#define RAD_SPEC_TYPE                  LIST_DATA_SIZE + 0
#define RAD_SPEC_AVG_E                 LIST_DATA_SIZE + 1
#define RAD_SPEC_DISC_NORM             LIST_DATA_SIZE + 2
#define RAD_SPEC_DISC_NE               LIST_DATA_SIZE + 3
#define RAD_SPEC_PTR_DISC_E            LIST_DATA_SIZE + 4
#define RAD_SPEC_PTR_DISC_RI           LIST_DATA_SIZE + 5
#define RAD_SPEC_CONT_NORM             LIST_DATA_SIZE + 6
#define RAD_SPEC_CONT_NE               LIST_DATA_SIZE + 7
#define RAD_SPEC_PTR_CONT_E            LIST_DATA_SIZE + 8
#define RAD_SPEC_PTR_CONT_RI           LIST_DATA_SIZE + 9

/*****************************************************************************/

/***** Thermal scattering library data ***************************************/

/* TODO: Muuta t�n nimi SAB:ksi */

#define THERM_BLOCK_SIZE              LIST_DATA_SIZE + PARAM_N_COMMON + 12

#define THERM_OPTIONS                 LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define THERM_PTR_ALIAS               LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define THERM_ZA                      LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define THERM_T                       LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define THERM_PTR_ISO1                LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define THERM_T1                      LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define THERM_FRAC1                   LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define THERM_PTR_ISO2                LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define THERM_T2                      LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define THERM_FRAC2                   LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define THERM_PTR_THERM               LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define THERM_PTR_COMP                LIST_DATA_SIZE + PARAM_N_COMMON + 11

/*****************************************************************************/

/***** Unresolved resonance probability table data ***************************/

#define URES_BLOCK_SIZE               LIST_DATA_SIZE + 8

#define URES_PTR_EGRID                LIST_DATA_SIZE + 0
#define URES_NP                       LIST_DATA_SIZE + 1
#define URES_PTR_PROB                 LIST_DATA_SIZE + 2
#define URES_IFF                      LIST_DATA_SIZE + 3
#define URES_PTR_FACT                 LIST_DATA_SIZE + 4
#define URES_PTR_MAXF                 LIST_DATA_SIZE + 5
#define URES_PTR_RND                  LIST_DATA_SIZE + 6
#define URES_PTR_PREV_FACT            LIST_DATA_SIZE + 7

/*****************************************************************************/

/***** Angular distribution **************************************************/

#define ANG_BLOCK_SIZE                LIST_DATA_SIZE + 5

#define ANG_PTR_EGRID                 LIST_DATA_SIZE + 0
#define ANG_TYPE                      LIST_DATA_SIZE + 1
#define ANG_PTR_D0                    LIST_DATA_SIZE + 2
#define ANG_BINS                      LIST_DATA_SIZE + 3
#define ANG_INTT                      LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Surface ***************************************************************/

/* Surface types */

#define SURFACE_TYPES   28

#define SURF_CYL         1
#define SURF_PX          2
#define SURF_PY          3
#define SURF_PZ          4
#define SURF_INF         5
#define SURF_SQC         6
#define SURF_HEXYC       7
#define SURF_HEXXC       8
#define SURF_SPH         9
#define SURF_CROSS      10
#define SURF_PAD        11
#define SURF_CUBE       12
#define SURF_CONE       13
#define SURF_SVC        14
#define SURF_CUBOID     15
#define SURF_HEXYPRISM  16
#define SURF_HEXXPRISM  17
#define SURF_DODE       18
#define SURF_OCTA       19
#define SURF_ASTRA      20
#define SURF_PLANE      21
#define SURF_QUADRATIC  22
#define SURF_CYLX       23
#define SURF_CYLY       24
#define SURF_CYLZ       25
#define SURF_GCROSS     26
#define SURF_PPD        27
#define SURF_USER       28

/* Data block */

#define SURFACE_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 6

#define SURFACE_PTR_NAME    LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define SURFACE_OPTIONS     LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define SURFACE_TYPE        LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define SURFACE_PTR_PARAMS  LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define SURFACE_N_PARAMS    LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define SURFACE_PTR_TRANS   LIST_DATA_SIZE + PARAM_N_COMMON + 5

/*****************************************************************************/

/***** Cell ******************************************************************/

/* Cell types */

#define CELL_TYPE_MAT      1
#define CELL_TYPE_VOID     2
#define CELL_TYPE_OUTSIDE  3
#define CELL_TYPE_FILL     4

/* Data block */

#define CELL_BLOCK_SIZE     LIST_DATA_SIZE + PARAM_N_COMMON + 13

#define CELL_PTR_NAME       LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define CELL_TYPE           LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define CELL_OPTIONS        LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define CELL_PTR_UNI        LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define CELL_PTR_MAT        LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define CELL_PTR_FILL       LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define CELL_PTR_SURF_LIST  LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define CELL_PTR_SURF_COMP  LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define CELL_PTR_SURF_INSC  LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define CELL_COL_COUNT      LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define CELL_VOLUME         LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define CELL_VOL_COUNT      LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define CELL_PTR_REG_MAT    LIST_DATA_SIZE + PARAM_N_COMMON + 12

/* Universe cell list */

#define CELL_LIST_BLOCK_SIZE  LIST_DATA_SIZE + 3

#define CELL_LIST_PTR_CELL    LIST_DATA_SIZE + 0
#define CELL_LIST_PTR_COUNT   LIST_DATA_SIZE + 1
#define CELL_LIST_REG_IDX     LIST_DATA_SIZE + 2

/* List of intersections */

#define CELL_INSC_BLOCK_SIZE      LIST_DATA_SIZE + 3

#define CELL_INSC_PTR_SURF        LIST_DATA_SIZE + 0
#define CELL_INSC_SIDE            LIST_DATA_SIZE + 1
#define CELL_INSC_PTR_OUT_COUNT   LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Nest ******************************************************************/

#define NEST_BLOCK_SIZE         LIST_DATA_SIZE + PARAM_N_COMMON + 7

#define NEST_PTR_NAME           LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define NEST_OPTIONS            LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define NEST_PTR_UNI            LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define NEST_PTR_REGIONS        LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define NEST_TYPE               LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define NEST_PTR_COL_REG        LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define NEST_COUNT              LIST_DATA_SIZE + PARAM_N_COMMON + 6

#define NEST_REG_BLOCK_SIZE     LIST_DATA_SIZE + 8

#define NEST_REG_PTR_FILL       LIST_DATA_SIZE + 0

#define NEST_REG_TMP_PTR        LIST_DATA_SIZE + 1
#define NEST_REG_PTR_SURF_IN    LIST_DATA_SIZE + 2
#define NEST_REG_PTR_SURF_OUT   LIST_DATA_SIZE + 3
#define NEST_REG_PTR_CELL       LIST_DATA_SIZE + 4
#define NEST_REG_PTR_TFB_REG    LIST_DATA_SIZE + 5
#define NEST_REG_IDX            LIST_DATA_SIZE + 6

/*****************************************************************************/

/***** Coordinate transformation *********************************************/

#define TRANS_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 37

#define TRANS_PTR_NAME    LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define TRANS_TYPE        LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define TRANS_PTR_UNI     LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define TRANS_PTR_SURF    LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define TRANS_OPTIONS     LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define TRANS_ROT         LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define TRANS_X0          LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define TRANS_Y0          LIST_DATA_SIZE + PARAM_N_COMMON + 7
#define TRANS_Z0          LIST_DATA_SIZE + PARAM_N_COMMON + 8
#define TRANS_RX1         LIST_DATA_SIZE + PARAM_N_COMMON + 9
#define TRANS_RX2         LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define TRANS_RX3         LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define TRANS_RX4         LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define TRANS_RX5         LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define TRANS_RX6         LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define TRANS_RX7         LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define TRANS_RX8         LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define TRANS_RX9         LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define TRANS_RY1         LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define TRANS_RY2         LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define TRANS_RY3         LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define TRANS_RY4         LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define TRANS_RY5         LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define TRANS_RY6         LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define TRANS_RY7         LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define TRANS_RY8         LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define TRANS_RY9         LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define TRANS_RZ1         LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define TRANS_RZ2         LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define TRANS_RZ3         LIST_DATA_SIZE + PARAM_N_COMMON + 29
#define TRANS_RZ4         LIST_DATA_SIZE + PARAM_N_COMMON + 30
#define TRANS_RZ5         LIST_DATA_SIZE + PARAM_N_COMMON + 31
#define TRANS_RZ6         LIST_DATA_SIZE + PARAM_N_COMMON + 32
#define TRANS_RZ7         LIST_DATA_SIZE + PARAM_N_COMMON + 33
#define TRANS_RZ8         LIST_DATA_SIZE + PARAM_N_COMMON + 34
#define TRANS_RZ9         LIST_DATA_SIZE + PARAM_N_COMMON + 35
#define TRANS_PTR_LVL     LIST_DATA_SIZE + PARAM_N_COMMON + 36

/*****************************************************************************/

/***** Geometry plotter ******************************************************/

#define GPL_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 11

#define GPL_IDX         LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define GPL_TYPE        LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define GPL_PIX_X       LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define GPL_PIX_Y       LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define GPL_POS         LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define GPL_XMIN        LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define GPL_XMAX        LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define GPL_YMIN        LIST_DATA_SIZE + PARAM_N_COMMON + 7
#define GPL_YMAX        LIST_DATA_SIZE + PARAM_N_COMMON + 8
#define GPL_ZMIN        LIST_DATA_SIZE + PARAM_N_COMMON + 9
#define GPL_ZMAX        LIST_DATA_SIZE + PARAM_N_COMMON + 10

/*****************************************************************************/

/***** First N collision points for history plotting *************************/

#define TRACK_PLOT_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 5

#define TRACK_PLOT_X           LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define TRACK_PLOT_Y           LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define TRACK_PLOT_Z           LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define TRACK_PLOT_IDX         LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define TRACK_PLOT_TRK         LIST_DATA_SIZE + PARAM_N_COMMON + 4

/*****************************************************************************/

/***** Pebble bed geometry ***************************************************/

#define PBED_BLOCK_SIZE               LIST_DATA_SIZE + PARAM_N_COMMON + 22

#define PBED_OPTIONS                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define PBED_PTR_FNAME                LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define PBED_N_PEBBLES                LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define PBED_PTR_NAME                 LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define PBED_PTR_UNI                  LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define PBED_PTR_PEBBLES              LIST_DATA_SIZE + PARAM_N_COMMON +  5

/*
#define PBED_MESH_MINX                LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define PBED_MESH_MAXX                LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define PBED_MESH_MINY                LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define PBED_MESH_MAXY                LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define PBED_MESH_MINZ                LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define PBED_MESH_MAXZ                LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define PBED_MESH_NX                  LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define PBED_MESH_NY                  LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define PBED_MESH_NZ                  LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define PBED_MESH_PTR_CELLS           LIST_DATA_SIZE + PARAM_N_COMMON + 16
*/

#define PBED_PTR_SEARCH_MESH          LIST_DATA_SIZE + PARAM_N_COMMON +  6

#define PBED_PTR_BG_UNIV              LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define PBED_CALC_RESULTS             LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define PBED_PTR_COL_PEBBLE           LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define PBED_PTR_PEBBLE_TYPES         LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define PBED_PTR_POW                  LIST_DATA_SIZE + PARAM_N_COMMON + 21

#define PEBBLE_BLOCK_SIZE              LIST_DATA_SIZE + 6

#define PEBBLE_PTR_UNIV                LIST_DATA_SIZE + 0
#define PEBBLE_X0                      LIST_DATA_SIZE + 1
#define PEBBLE_Y0                      LIST_DATA_SIZE + 2
#define PEBBLE_Z0                      LIST_DATA_SIZE + 3
#define PEBBLE_RAD                     LIST_DATA_SIZE + 4
#define PEBBLE_IDX                     LIST_DATA_SIZE + 5

#define PEBTYPE_BLOCK_SIZE             LIST_DATA_SIZE + 2

#define PEBTYPE_PTR_UNIV               LIST_DATA_SIZE + 0
#define PEBTYPE_COUNT                  LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Search mesh ***********************************************************/

/* List for search mesh */

#define SEARCH_MESH_CELL_BLOCK_SIZE    LIST_DATA_SIZE + 2

#define SEARCH_MESH_CELL_CONTENT       LIST_DATA_SIZE + 0
#define SEARCH_MESH_PTR_CELL_COUNT     LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Multi-physics interface ***********************************************/

#define IFC_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 34

#define IFC_IDX                       LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define IFC_DIM                       LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define IFC_PTR_INPUT_FNAME           LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define IFC_PTR_OUTPUT_FNAME          LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define IFC_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define IFC_EXCL_RAD                  LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define IFC_EXP                       LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define IFC_PTR_MAT                   LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define IFC_MAX_DENSITY               LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define IFC_MIN_TEMP                  LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define IFC_MAX_TEMP                  LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define IFC_PTR_SEARCH_MESH           LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define IFC_NP                        LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define IFC_PTR_OUTPUT                LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define IFC_NZ                        LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define IFC_ZMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define IFC_ZMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define IFC_NR                        LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define IFC_PTR_OUT                   LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define IFC_PTR_POINTS                LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define IFC_FUNC_NP                   LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define IFC_FUNC_PTR_PARAM            LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define IFC_CALC_OUTPUT               LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define IFC_PTR_CGNS                  LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define IFC_MESH_XMIN                 LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define IFC_MESH_XMAX                 LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define IFC_MESH_YMIN                 LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define IFC_MESH_YMAX                 LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define IFC_MESH_ZMIN                 LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define IFC_MESH_ZMAX                 LIST_DATA_SIZE + PARAM_N_COMMON + 29
#define IFC_PTR_SCORE                 LIST_DATA_SIZE + PARAM_N_COMMON + 30
#define IFC_PTR_STAT                  LIST_DATA_SIZE + PARAM_N_COMMON + 31
#define IFC_STAT_NREG                 LIST_DATA_SIZE + PARAM_N_COMMON + 32
#define IFC_PTR_FUEP                  LIST_DATA_SIZE + PARAM_N_COMMON + 33

/* Type 1: Points */

#define IFC_PT_LIST_BLOCK_SIZE        LIST_DATA_SIZE + 5

#define IFC_PT_X                      LIST_DATA_SIZE + 0
#define IFC_PT_Y                      LIST_DATA_SIZE + 1
#define IFC_PT_Z                      LIST_DATA_SIZE + 2
#define IFC_PT_DF                     LIST_DATA_SIZE + 3
#define IFC_PT_TMP                    LIST_DATA_SIZE + 4

/* Type 2: Mesh */

#define IFC_MSH_LIST_BLOCK_SIZE       LIST_DATA_SIZE + 2

#define IFC_MSH_DF                    LIST_DATA_SIZE + 0
#define IFC_MSH_TMP                   LIST_DATA_SIZE + 1

/* Type 4: CGNS */

#define IFC_CGNS_LIST_BLOCK_SIZE       LIST_DATA_SIZE + 11

#define IFC_CGNS_IDX                   LIST_DATA_SIZE +  0
#define IFC_CGNS_PTR_CELL              LIST_DATA_SIZE +  1
#define IFC_CGNS_DF                    LIST_DATA_SIZE +  2
#define IFC_CGNS_TMP                   LIST_DATA_SIZE +  3
#define IFC_CGNS_XMIN                  LIST_DATA_SIZE +  4
#define IFC_CGNS_XMAX                  LIST_DATA_SIZE +  5
#define IFC_CGNS_YMIN                  LIST_DATA_SIZE +  6
#define IFC_CGNS_YMAX                  LIST_DATA_SIZE +  7
#define IFC_CGNS_ZMIN                  LIST_DATA_SIZE +  8
#define IFC_CGNS_ZMAX                  LIST_DATA_SIZE +  9
#define IFC_CGNS_STAT_IDX              LIST_DATA_SIZE + 10

/* Type 5: Interface for fuel performance codes */

#define IFC_FUEP_LIST_BLOCK_SIZE       LIST_DATA_SIZE + 13

#define IFC_FUEP_PTR_UNI               LIST_DATA_SIZE +  1
#define IFC_FUEP_OUT_NZ                LIST_DATA_SIZE +  2
#define IFC_FUEP_OUT_ZMIN              LIST_DATA_SIZE +  3
#define IFC_FUEP_OUT_ZMAX              LIST_DATA_SIZE +  4
#define IFC_FUEP_OUT_PTR_Z             LIST_DATA_SIZE +  5
#define IFC_FUEP_OUT_NR                LIST_DATA_SIZE +  6
#define IFC_FUEP_OUT_RMIN              LIST_DATA_SIZE +  7
#define IFC_FUEP_OUT_RMAX              LIST_DATA_SIZE +  8
#define IFC_FUEP_OUT_PTR_R2            LIST_DATA_SIZE +  9
#define IFC_FUEP_PTR_POWER             LIST_DATA_SIZE + 10
#define IFC_FUEP_N_AX                  LIST_DATA_SIZE + 11
#define IFC_FUEP_PTR_AX                LIST_DATA_SIZE + 12

#define IFC_FUEP_AX_BLOCK_SIZE         LIST_DATA_SIZE +  5

#define IFC_FUEP_AX_ZMIN               LIST_DATA_SIZE +  1
#define IFC_FUEP_AX_ZMAX               LIST_DATA_SIZE +  2
#define IFC_FUEP_AX_N_RAD	       LIST_DATA_SIZE +  3
#define IFC_FUEP_AX_PTR_RAD            LIST_DATA_SIZE +  4

#define IFC_FUEP_RAD_BLOCK_SIZE        LIST_DATA_SIZE +  7

#define IFC_FUEP_RAD_PTR_MAT           LIST_DATA_SIZE +  1
#define IFC_FUEP_RAD_PTR_REG           LIST_DATA_SIZE +  2
#define IFC_FUEP_RAD_DF                LIST_DATA_SIZE +  3
#define IFC_FUEP_RAD_TEMP              LIST_DATA_SIZE +  4
#define IFC_FUEP_RAD_COLD_R2           LIST_DATA_SIZE +  5
#define IFC_FUEP_RAD_HOT_R2            LIST_DATA_SIZE +  6

/* Scoring regions (this is needed to keep list sorted based on geometry */
/* region index, while the output list is sorted based on coordinates).  */

#define IFC_SCORE_LIST_BLOCK_SIZE     LIST_DATA_SIZE + 3

#define IFC_SCORE_REG_IDX             LIST_DATA_SIZE + 0
#define IFC_SCORE_STAT_IDX            LIST_DATA_SIZE + 1
#define IFC_SCORE_PTR_OUT             LIST_DATA_SIZE + 2

/* Output for power distribution (other types than CGNS) */

#define IFC_OUT_LIST_BLOCK_SIZE       LIST_DATA_SIZE + 5

#define IFC_OUT_X0                    LIST_DATA_SIZE + 0
#define IFC_OUT_Y0                    LIST_DATA_SIZE + 1
#define IFC_OUT_R                     LIST_DATA_SIZE + 2
#define IFC_OUT_PTR_IFC               LIST_DATA_SIZE + 3
#define IFC_OUT_PTR_SCORE             LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Lattice ***************************************************************/

#define LATTICE_TYPES    13

#define LAT_TYPE_S       1
#define LAT_TYPE_HX      2
#define LAT_TYPE_HY      3
#define LAT_TYPE_CLU     4
#define LAT_TYPE_RND     5  
#define LAT_TYPE_INFS    6
#define LAT_TYPE_INFHY   7
#define LAT_TYPE_INFHX   8
#define LAT_TYPE_ZSTACK  9
#define LAT_TYPE_CUBOID  11
#define LAT_TYPE_XPRISM  12
#define LAT_TYPE_YPRISM  13

#define LAT_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 19

#define LAT_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define LAT_PTR_UNI                   LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define LAT_OPTIONS                   LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define LAT_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define LAT_ORIG_X0                   LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define LAT_ORIG_Y0                   LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define LAT_ORIG_Z0                   LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define LAT_PITCH                     LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define LAT_PITCHX                    LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define LAT_PITCHY                    LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define LAT_PITCHZ                    LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define LAT_NX                        LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define LAT_NY                        LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define LAT_NZ                        LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define LAT_NTOT                      LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define LAT_N_RINGS                   LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define LAT_PTR_FILL                  LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define LAT_PTR_Z                     LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define LAT_COL_COUNT                 LIST_DATA_SIZE + PARAM_N_COMMON + 18

#define RING_BLOCK_SIZE                LIST_DATA_SIZE + 5
#define RING_N_SEC                     LIST_DATA_SIZE + 0
#define RING_RAD                       LIST_DATA_SIZE + 1
#define RING_RLIM                      LIST_DATA_SIZE + 2
#define RING_TILT                      LIST_DATA_SIZE + 3
#define RING_PTR_FILL                  LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Depletion history *****************************************************/

/* Depletion step types */

#define DEP_STEP_BU_STEP   1
#define DEP_STEP_BU_TOT    2
#define DEP_STEP_DAY_STEP  3
#define DEP_STEP_DAY_TOT   4
#define DEP_STEP_DEC_STEP  5
#define DEP_STEP_DEC_TOT   6

/* predictor and corrector types available for burnup calculations (AIs) */

#define PRED_TYPE_CONSTANT   10
#define PRED_TYPE_LINEAR     11 
#define CORR_TYPE_NONE       19
#define CORR_TYPE_CONSTANT   20
#define CORR_TYPE_LINEAR     21
#define CORR_TYPE_QUADRATIC  22

/* NOTE: predictor =/= the last corrector iteration, keep as NO on pred. steps*/

/* the types */

#define CI_TYPE_NONE                   -1
#define CI_TYPE_INNER                   0
#define CI_TYPE_OUTER                   1 

/* inner iteration means that pEOS flux is iterated as in Dufek's method,
   i.e., using backwards constant extrapolation, after which the final round
   uses the selected corrector scheme. Outer iteration means that each 
   iteration uses the selected corrector scheme. Default is OUTER with MAXI=1
   which results in the old (no iteration) behavior. (AIs) */


#define DEP_HIS_BLOCK_SIZE            LIST_DATA_SIZE + PARAM_N_COMMON +  9

#define DEP_HIS_STEP_TYPE             LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define DEP_HIS_N_STEPS               LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define DEP_HIS_PTR_STEPS             LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define DEP_HIS_PTR_NORM              LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define DEP_HIS_PRED_TYPE             LIST_DATA_SIZE + PARAM_N_COMMON +  4 
#define DEP_HIS_PRED_NSS              LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define DEP_HIS_CORR_TYPE             LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define DEP_HIS_CORR_NSS              LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define DEP_HIS_PTR_REPROC            LIST_DATA_SIZE + PARAM_N_COMMON +  8

/*****************************************************************************/

/***** Source array **********************************************************/

#define SRC_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 32

#define SRC_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define SRC_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define SRC_WGT                       LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define SRC_E                         LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define SRC_PTR_XSDATA                LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define SRC_PTR_REA                   LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define SRC_PTR_MAT                   LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define SRC_PTR_CELL                  LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define SRC_PTR_UNIV                  LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define SRC_PTR_EBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define SRC_PTR_SURF                  LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define SRC_SURF_SIDE                 LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define SRC_X0                        LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define SRC_Y0                        LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define SRC_Z0                        LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define SRC_U0                        LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define SRC_V0                        LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define SRC_W0                        LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define SRC_XMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define SRC_XMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define SRC_YMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define SRC_YMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define SRC_ZMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define SRC_ZMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define SRC_PTR_RAD_SRC_MAT           LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define SRC_READ_FILE_TYPE            LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define SRC_READ_PTR_FILE             LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define SRC_READ_PTR_BUF              LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define SRC_READ_BUF_SZ               LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define SRC_READ_BUF_IDX              LIST_DATA_SIZE + PARAM_N_COMMON + 29
#define SRC_READ_FILE_POS             LIST_DATA_SIZE + PARAM_N_COMMON + 30
#define SRC_PTR_USR                   LIST_DATA_SIZE + PARAM_N_COMMON + 31

/* Source energy bin */

#define SRC_EBIN_BLOCK_SIZE           LIST_DATA_SIZE + 2

#define SRC_EBIN_EMAX                 LIST_DATA_SIZE + 0
#define SRC_EBIN_WGT                  LIST_DATA_SIZE + 1

/* Source buffer entry (toi ei oo lista) */

#define SRC_BUF_BLOCK_SIZE            9

#define SRC_BUF_X                     0
#define SRC_BUF_Y                     1
#define SRC_BUF_Z                     2
#define SRC_BUF_U                     3
#define SRC_BUF_V                     4
#define SRC_BUF_W                     5
#define SRC_BUF_E                     6
#define SRC_BUF_WGT                   7
#define SRC_BUF_T                     8

/* User-defined routine */

#define SRC_USR_BLOCK_SIZE            2
#define SRC_USR_NP                    0
#define SRC_USR_PTR_PARAMS            1

/*****************************************************************************/

/***** Detector array ********************************************************/

#define DET_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 29

#define DET_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define DET_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define DET_PTR_EGRID                 LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define DET_PTR_RBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define DET_PTR_UBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define DET_PTR_LBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define DET_PTR_MBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define DET_PTR_CBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define DET_PTR_SBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define DET_PTR_TME                   LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define DET_N_EBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define DET_N_UBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define DET_N_CBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define DET_N_MBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define DET_N_LBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define DET_N_RBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define DET_N_TBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define DET_N_TOT_BINS                LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define DET_PTR_STAT                  LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define DET_VOL                       LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define DET_PTR_MUL                   LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define DET_PTR_ADJOINT               LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define DET_PTR_MESH                  LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define DET_PARTICLE                  LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define DET_WRITE_PTR_FILE            LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define DET_WRITE_PTR_BUF             LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define DET_WRITE_BUF_SZ              LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define DET_WRITE_BUF_IDX             LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define DET_WRITE_PROB                LIST_DATA_SIZE + PARAM_N_COMMON + 28

/* Detector reaction bin */

#define DET_RBIN_BLOCK_SIZE           LIST_DATA_SIZE + 4

#define DET_RBIN_PTR_MAT              LIST_DATA_SIZE + 0
#define DET_RBIN_MT                   LIST_DATA_SIZE + 1
#define DET_RBIN_PTR_REA              LIST_DATA_SIZE + 2
#define DET_RBIN_VOID_MODE            LIST_DATA_SIZE + 3

/* Detector universe bin */

#define DET_UBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_UBIN_PTR_UNI              LIST_DATA_SIZE + 0

/* Detector lattice bin */

#define DET_LBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_LBIN_PTR_LAT              LIST_DATA_SIZE + 0

/* Detector material bin */

#define DET_MBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_MBIN_PTR_MAT              LIST_DATA_SIZE + 0

/* Detector cell bin */

#define DET_CBIN_BLOCK_SIZE           LIST_DATA_SIZE + 2

#define DET_CBIN_PTR_CELL             LIST_DATA_SIZE + 0
#define DET_CBIN_SUPER_CELL           LIST_DATA_SIZE + 1

/* Bins for super-imposed */

#define DET_SBIN_BLOCK_SIZE           LIST_DATA_SIZE + 3

#define DET_SBIN_TYPE                 LIST_DATA_SIZE + 0
#define DET_SBIN_PTR_SURF             LIST_DATA_SIZE + 1
#define DET_SBIN_SURF_NORM            LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** User-defined energy grid **********************************************/

#define ENE_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON +  7

#define ENE_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define ENE_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define ENE_NB                        LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define ENE_EMIN                      LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define ENE_EMAX                      LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define ENE_PTR_GRID                  LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define ENE_PTR_PREDEF                LIST_DATA_SIZE + PARAM_N_COMMON +  6

/*****************************************************************************/

/***** User-defined time binning *********************************************/

#define TME_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON +  6

#define TME_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define TME_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define TME_NB                        LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define TME_TMIN                      LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define TME_TMAX                      LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define TME_PTR_BINS                  LIST_DATA_SIZE + PARAM_N_COMMON +  5

/*****************************************************************************/

/***** Geometry levels *******************************************************/

/* Data stored in common array */

#define LVL_BLOCK_SIZE        LIST_DATA_SIZE + 5

#define LVL_NUMBER            LIST_DATA_SIZE + 0
#define LVL_PTR_PRIVATE_DATA  LIST_DATA_SIZE + 1
#define LVL_MAX_REGIONS       LIST_DATA_SIZE + 2
#define LVL_CUM_MAX_REGIONS   LIST_DATA_SIZE + 3
#define LVL_ZONE_IDX_MULT     LIST_DATA_SIZE + 4

/* Data stored in private array */

#define LVL_PRIV_BLOCK_SIZE     24

#define LVL_PRIV_TYPE            0
#define LVL_PRIV_PTR_NEST_REG    1
#define LVL_PRIV_PTR_LAT         2
#define LVL_PRIV_PTR_CELL        3
#define LVL_PRIV_PTR_PBED        4
#define LVL_PRIV_PTR_PEBBLE      5
#define LVL_PRIV_X               6
#define LVL_PRIV_Y               7
#define LVL_PRIV_Z               8
#define LVL_PRIV_U               9
#define LVL_PRIV_V              10
#define LVL_PRIV_W              11
#define LVL_PRIV_LAST           12
#define LVL_PRIV_PTR_MAT        13
#define LVL_PRIV_LAT_SURF_TYPE  14
#define LVL_PRIV_LAT_SURF_NP    15
#define LVL_PRIV_LAT_SURF_C0    16
#define LVL_PRIV_LAT_SURF_C1    17
#define LVL_PRIV_LAT_SURF_C2    18
#define LVL_PRIV_LAT_SURF_C3    19
#define LVL_PRIV_LAT_SURF_C4    20
#define LVL_PRIV_LAT_SURF_C5    21
#define LVL_PRIV_PTR_UNIV       22
#define LVL_PRIV_ZONE_IDX       23

/*****************************************************************************/

/***** Score block ***********************************************************/

#define SCORE_BLOCK_SIZE  LIST_DATA_SIZE + 7

#define SCORE_PTR_NAME    LIST_DATA_SIZE + 0
#define SCORE_DIM         LIST_DATA_SIZE + 1
#define SCORE_PTR_NMAX    LIST_DATA_SIZE + 2
#define SCORE_PTR_DATA    LIST_DATA_SIZE + 3
#define SCORE_PTR_BUF     LIST_DATA_SIZE + 4
#define SCORE_STAT_SIZE   LIST_DATA_SIZE + 5
#define SCORE_PTR_HIS     LIST_DATA_SIZE + 6

/*****************************************************************************/

/***** Universe **************************************************************/

/* Universe types */

#define UNIVERSE_TYPE_CELL     1
#define UNIVERSE_TYPE_NEST     2
#define UNIVERSE_TYPE_LATTICE  3
#define UNIVERSE_TYPE_PBED     4
#define UNIVERSE_TYPE_SUPER    5

/* Data block */

#define UNIVERSE_BLOCK_SIZE     LIST_DATA_SIZE + 26

#define UNIVERSE_PTR_NAME       LIST_DATA_SIZE +  0
#define UNIVERSE_OPTIONS        LIST_DATA_SIZE +  1
#define UNIVERSE_TYPE           LIST_DATA_SIZE +  2
#define UNIVERSE_PTR_CELL_LIST  LIST_DATA_SIZE +  3
#define UNIVERSE_PTR_NEST       LIST_DATA_SIZE +  4
#define UNIVERSE_PTR_LAT        LIST_DATA_SIZE +  5
#define UNIVERSE_PTR_PBED       LIST_DATA_SIZE +  6
#define UNIVERSE_PTR_TRANS      LIST_DATA_SIZE +  7
#define UNIVERSE_PTR_SYM        LIST_DATA_SIZE +  8
#define UNIVERSE_MINX           LIST_DATA_SIZE +  9
#define UNIVERSE_MAXX           LIST_DATA_SIZE + 10
#define UNIVERSE_MINY           LIST_DATA_SIZE + 11
#define UNIVERSE_MAXY           LIST_DATA_SIZE + 12
#define UNIVERSE_MINZ           LIST_DATA_SIZE + 13
#define UNIVERSE_MAXZ           LIST_DATA_SIZE + 14
#define UNIVERSE_DIM            LIST_DATA_SIZE + 15
#define UNIVERSE_COL_COUNT      LIST_DATA_SIZE + 16
#define UNIVERSE_PTR_GCU        LIST_DATA_SIZE + 17
#define UNIVERSE_LEVEL          LIST_DATA_SIZE + 18
#define UNIVERSE_PTR_PRIVA_X    LIST_DATA_SIZE + 19
#define UNIVERSE_PTR_PRIVA_Y    LIST_DATA_SIZE + 20
#define UNIVERSE_PTR_PRIVA_Z    LIST_DATA_SIZE + 21
#define UNIVERSE_PTR_PREV_REG   LIST_DATA_SIZE + 22
#define UNIVERSE_FMTX_IDX       LIST_DATA_SIZE + 23
#define UNIVERSE_PTR_IFC_FUEP   LIST_DATA_SIZE + 24
#define UNIVERSE_GCU_IDX        LIST_DATA_SIZE + 25

/*****************************************************************************/

/***** Particle (neutron / photon) *******************************************/

/* Particle types (indeksit pit�� menn� noin ett� sorttaus tyypin mukaan */
/* menee oikein) */

#define PARTICLE_TYPE_DUMMY    0
#define PARTICLE_TYPE_GAMMA    1
#define PARTICLE_TYPE_NEUTRON  2

/* Data block */

#define PARTICLE_BLOCK_SIZE       LIST_DATA_SIZE + 29

#define PARTICLE_HISTORY_IDX      LIST_DATA_SIZE +  0
#define PARTICLE_RNG_IDX          LIST_DATA_SIZE +  1
#define PARTICLE_TYPE             LIST_DATA_SIZE +  2
#define PARTICLE_X                LIST_DATA_SIZE +  3
#define PARTICLE_Y                LIST_DATA_SIZE +  4
#define PARTICLE_Z                LIST_DATA_SIZE +  5
#define PARTICLE_U                LIST_DATA_SIZE +  6
#define PARTICLE_V                LIST_DATA_SIZE +  7
#define PARTICLE_W                LIST_DATA_SIZE +  8
#define PARTICLE_E                LIST_DATA_SIZE +  9
#define PARTICLE_WGT              LIST_DATA_SIZE + 10
#define PARTICLE_T0               LIST_DATA_SIZE + 11
#define PARTICLE_T                LIST_DATA_SIZE + 12
#define PARTICLE_TD               LIST_DATA_SIZE + 13
#define PARTICLE_TT               LIST_DATA_SIZE + 14
#define PARTICLE_FMTX_IDX         LIST_DATA_SIZE + 15
#define PARTICLE_PREV_IMP         LIST_DATA_SIZE + 16
#define PARTICLE_PREV_IDX         LIST_DATA_SIZE + 17
#define PARTICLE_PREV_X           LIST_DATA_SIZE + 18
#define PARTICLE_PREV_Y           LIST_DATA_SIZE + 19
#define PARTICLE_PREV_Z           LIST_DATA_SIZE + 20
#define PARTICLE_PTR_HIST         LIST_DATA_SIZE + 21
#define PARTICLE_PTR_MAT          LIST_DATA_SIZE + 22
#define PARTICLE_MPI_ID           LIST_DATA_SIZE + 23
#define PARTICLE_GEN_IDX          LIST_DATA_SIZE + 24
#define PARTICLE_DN_GROUP         LIST_DATA_SIZE + 25
#define PARTICLE_DN_LAMBDA        LIST_DATA_SIZE + 26
#define PARTICLE_RESEED           LIST_DATA_SIZE + 27
#define PARTICLE_PTR_FISS_PROG    LIST_DATA_SIZE + 28

/* History data */

#define HIST_BLOCK_SIZE         LIST_DATA_SIZE + 14

#define HIST_X                  LIST_DATA_SIZE +  0
#define HIST_Y                  LIST_DATA_SIZE +  1
#define HIST_Z                  LIST_DATA_SIZE +  2
#define HIST_U                  LIST_DATA_SIZE +  3
#define HIST_V                  LIST_DATA_SIZE +  4
#define HIST_W                  LIST_DATA_SIZE +  5
#define HIST_E                  LIST_DATA_SIZE +  6
#define HIST_T                  LIST_DATA_SIZE +  7
#define HIST_WGT                LIST_DATA_SIZE +  8
#define HIST_FLX                LIST_DATA_SIZE +  9
#define HIST_PTR_REA            LIST_DATA_SIZE + 10
#define HIST_PTR_MAT            LIST_DATA_SIZE + 11
#define HIST_TRK                LIST_DATA_SIZE + 12
#define HIST_IDX                LIST_DATA_SIZE + 13

/* Fission progenies */

#define FISS_PROG_BLOCK_SIZE    LIST_DATA_SIZE + 3

#define FISS_PROG_DN_GROUP      LIST_DATA_SIZE + 0
#define FISS_PROG_LIFETIME      LIST_DATA_SIZE + 1
#define FISS_PROG_LAMBDA        LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Mesh plot *************************************************************/

#define MPL_BLOCK_SIZE          LIST_DATA_SIZE + PARAM_N_COMMON + 24

#define MPL_NDIST               LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define MPL_DIV                 LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define MPL_AX                  LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define MPL_NX                  LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define MPL_NY                  LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define MPL_SYM                 LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define MPL_XMIN                LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define MPL_XMAX                LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define MPL_YMIN                LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define MPL_YMAX                LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define MPL_ZMIN                LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define MPL_ZMAX                LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define MPL_MIN1                LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define MPL_MAX1                LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define MPL_MIN2                LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define MPL_MAX2                LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define MPL_PTR_VAL1            LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define MPL_PTR_VAL2            LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define MPL_PTR_DIV1            LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define MPL_PTR_DIV2            LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define MPL_PTR_FNAME           LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define MPL_TYPE                LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define MPL_COLMAP              LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define MPL_PTR_DET             LIST_DATA_SIZE + PARAM_N_COMMON + 23

/*****************************************************************************/

/***** Temperature feedback **************************************************/

#define TFB_BLOCK_SIZE          LIST_DATA_SIZE + PARAM_N_COMMON + 14

#define TFB_PTR_REG_LIST        LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define TFB_TLIM                LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define TFB_PTR_NST             LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define TFB_N_REG               LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define TFB_PTR_MEAN_POW        LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define TFB_PTR_MEAN_VTEMP      LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define TFB_PTR_MAX_TEMP        LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define TFB_PTR_MIN_TEMP        LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define TFB_PTR_MEAN_FTEMP      LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define TFB_PTR_MEAN_MDENS      LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define TFB_PTR_MEAN_RAD        LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define TFB_PTR_MEAN_HC         LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define TFB_ITER_POW            LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define TFB_MODE                LIST_DATA_SIZE + PARAM_N_COMMON + 13

#define TFB_REG_BLOCK_SIZE      LIST_DATA_SIZE + 23

#define TFB_REG_IDX             LIST_DATA_SIZE + 0
#define TFB_REG_PTR_MAT         LIST_DATA_SIZE + 1
#define TFB_REG_ETTM_TMIN       LIST_DATA_SIZE + 2
#define TFB_REG_ETTM_TMAX       LIST_DATA_SIZE + 3
#define TFB_REG_ITER_TEMP       LIST_DATA_SIZE + 4
#define TFB_REG_ITER_POW        LIST_DATA_SIZE + 5
#define TFB_REG_ITER_POWIN      LIST_DATA_SIZE + 6
#define TFB_REG_HC              LIST_DATA_SIZE + 7
#define TFB_REG_R0              LIST_DATA_SIZE + 8
#define TFB_REG_R1              LIST_DATA_SIZE + 9
#define TFB_REG_ITER_R0         LIST_DATA_SIZE + 10
#define TFB_REG_ITER_R1         LIST_DATA_SIZE + 11
#define TFB_REG_ITER_C0         LIST_DATA_SIZE + 12
#define TFB_REG_ITER_C1         LIST_DATA_SIZE + 13
#define TFB_REG_ITER_C2         LIST_DATA_SIZE + 14
#define TFB_REG_MAT_TYPE        LIST_DATA_SIZE + 15
#define TFB_REG_PTR_RAD_IN      LIST_DATA_SIZE + 16
#define TFB_REG_PTR_RAD_OUT     LIST_DATA_SIZE + 17

/* Aikariippuvassa laskussa ensimm�isen aika-askeleen arvot tallennetaan */
/* n�ihin seuraavaa alkuarvausta varten. */

#define TFB_REG_INI_R0          LIST_DATA_SIZE + 18
#define TFB_REG_INI_R1          LIST_DATA_SIZE + 19
#define TFB_REG_INI_C0          LIST_DATA_SIZE + 20
#define TFB_REG_INI_C1          LIST_DATA_SIZE + 21
#define TFB_REG_INI_C2          LIST_DATA_SIZE + 22

/*****************************************************************************/

/***** Normalization *********************************************************/

#define NORM_BLOCK_SIZE         LIST_DATA_SIZE + 9

#define NORM_POWER              LIST_DATA_SIZE + 0
#define NORM_POWDENS            LIST_DATA_SIZE + 1
#define NORM_GENRATE            LIST_DATA_SIZE + 2
#define NORM_FISSRATE           LIST_DATA_SIZE + 3
#define NORM_ABSRATE            LIST_DATA_SIZE + 4
#define NORM_LOSSRATE           LIST_DATA_SIZE + 5
#define NORM_FLUX               LIST_DATA_SIZE + 6
#define NORM_SRCRATE            LIST_DATA_SIZE + 7
#define NORM_SFRATE             LIST_DATA_SIZE + 8

/*****************************************************************************/

/***** Mesh ******************************************************************/

#define MESH_BLOCK_SIZE         LIST_DATA_SIZE + 16

#define MESH_TYPE               LIST_DATA_SIZE +  0
#define MESH_CONTENT            LIST_DATA_SIZE +  1
#define MESH_N0                 LIST_DATA_SIZE +  2
#define MESH_N1                 LIST_DATA_SIZE +  3
#define MESH_N2                 LIST_DATA_SIZE +  4
#define MESH_MIN0               LIST_DATA_SIZE +  5
#define MESH_MAX0               LIST_DATA_SIZE +  6
#define MESH_MIN1               LIST_DATA_SIZE +  7
#define MESH_MAX1               LIST_DATA_SIZE +  8
#define MESH_MIN2               LIST_DATA_SIZE +  9
#define MESH_MAX2               LIST_DATA_SIZE + 10
#define MESH_PTR_RES2           LIST_DATA_SIZE + 11
#define MESH_PTR_PTR            LIST_DATA_SIZE + 12
#define MESH_ORTHO_PTR_XLIM     LIST_DATA_SIZE + 13
#define MESH_ORTHO_PTR_YLIM     LIST_DATA_SIZE + 14
#define MESH_ORTHO_PTR_ZLIM     LIST_DATA_SIZE + 15

/*****************************************************************************/

/***** Core power distribution ***********************************************/

#define CPD_BLOCK_SIZE          LIST_DATA_SIZE +  2

#define CPD_PTR_LAT             LIST_DATA_SIZE +  0
#define CPD_COL_COUNT           LIST_DATA_SIZE +  1

/*****************************************************************************/

/***** Fission matrix ********************************************************/

#define FMTX_BLOCK_SIZE  LIST_DATA_SIZE +  8

#define FMTX_PTR_MTX     LIST_DATA_SIZE +  1
#define FMTX_PTR_SRC     LIST_DATA_SIZE +  2
#define FMTX_SIZE        LIST_DATA_SIZE +  3
#define FMTX_PTR_MAT     LIST_DATA_SIZE +  4
#define FMTX_PTR_UNI     LIST_DATA_SIZE +  5
#define FMTX_LVL         LIST_DATA_SIZE +  6
#define FMTX_PTR_MESH    LIST_DATA_SIZE +  7

/*****************************************************************************/

/***** Material divider for burnup calculation *******************************/

#define DIV_BLOCK_SIZE           LIST_DATA_SIZE  + PARAM_N_COMMON + 12

#define DIV_PTR_MAT              LIST_DATA_SIZE  + PARAM_N_COMMON + 0
#define DIV_NAX                  LIST_DATA_SIZE  + PARAM_N_COMMON + 1
#define DIV_ZMIN                 LIST_DATA_SIZE  + PARAM_N_COMMON + 2
#define DIV_ZMAX                 LIST_DATA_SIZE  + PARAM_N_COMMON + 3
#define DIV_NRAD                 LIST_DATA_SIZE  + PARAM_N_COMMON + 4
#define DIV_RMIN                 LIST_DATA_SIZE  + PARAM_N_COMMON + 5
#define DIV_RMAX                 LIST_DATA_SIZE  + PARAM_N_COMMON + 6
#define DIV_NSEG                 LIST_DATA_SIZE  + PARAM_N_COMMON + 7
#define DIV_SEG0                 LIST_DATA_SIZE  + PARAM_N_COMMON + 8
#define DIV_SEP                  LIST_DATA_SIZE  + PARAM_N_COMMON + 9
#define DIV_PTR_MAT_LIST         LIST_DATA_SIZE  + PARAM_N_COMMON + 10
#define DIV_OUTPUT_FLAG          LIST_DATA_SIZE  + PARAM_N_COMMON + 11

/* Divisor material lists */

#define DIV_MAT_LIST_BLOCK_SIZE  LIST_DATA_SIZE + 3

#define DIV_MAT_LIST_ZONE_IDX    LIST_DATA_SIZE + 0
#define DIV_MAT_LIST_PTR_UNIV    LIST_DATA_SIZE + 1
#define DIV_MAT_LIST_PTR_REG     LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Universe symmetry *****************************************************/

#define SYMMETRY_BLOCK_SIZE     LIST_DATA_SIZE + PARAM_N_COMMON + 8

#define SYMMETRY_PTR_UNI        LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define SYMMETRY_AXIS           LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define SYMMETRY_BC             LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define SYMMETRY_THETA0         LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define SYMMETRY_ROT            LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define SYMMETRY_X0             LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define SYMMETRY_Y0             LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define SYMMETRY_SYM            LIST_DATA_SIZE + PARAM_N_COMMON + 7

/*****************************************************************************/

/***** Reprocessing **********************************************************/

#define REPROC_BLOCK_SIZE       LIST_DATA_SIZE + PARAM_N_COMMON + 5

#define REPROC_PTR_NAME         LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define REPROC_OPTIONS          LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define REPROC_PTR_SWAP_LIST    LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define REPROC_PTR_RPL_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define REPROC_PTR_REM_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 4

/* Swap list */

#define REPROC_SWAP_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define REPROC_SWAP_PTR_UNI1    LIST_DATA_SIZE + 0
#define REPROC_SWAP_PTR_UNI2    LIST_DATA_SIZE + 1

/* Replace list */

#define REPROC_RPL_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define REPROC_RPL_PTR_UNI1    LIST_DATA_SIZE + 0
#define REPROC_RPL_PTR_UNI2    LIST_DATA_SIZE + 1

/* Removal list */

#define REPROC_REM_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define REPROC_REM_PTR_MAT1    LIST_DATA_SIZE + 0
#define REPROC_REM_PTR_MAT2    LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Nuclide inventory list ************************************************/

#define INVENTORY_BLOCK_SIZE    LIST_DATA_SIZE +  2

#define INVENTORY_PTR_NAME      LIST_DATA_SIZE +  0
#define INVENTORY_ZAI           LIST_DATA_SIZE +  1

/*****************************************************************************/

/***** Assembly discontinuity factors ****************************************/

#define ADF_BLOCK_SIZE          LIST_DATA_SIZE + 11

#define ADF_PTR_GCU             LIST_DATA_SIZE +  0
#define ADF_PTR_SURF            LIST_DATA_SIZE +  1
#define ADF_PTR_CURR_IN         LIST_DATA_SIZE +  2
#define ADF_PTR_CURR_OUT        LIST_DATA_SIZE +  3
#define ADF_PTR_CURR_NET        LIST_DATA_SIZE +  4
#define ADF_NSURF               LIST_DATA_SIZE +  5
#define ADF_NCORN               LIST_DATA_SIZE +  6
#define ADF_SURF_AREA           LIST_DATA_SIZE +  7
#define ADF_CORN_AREA           LIST_DATA_SIZE +  8
#define ADF_VOL                 LIST_DATA_SIZE +  9
#define ADF_BC                  LIST_DATA_SIZE + 10

/*****************************************************************************/

/***** Simulator output block ************************************************/

#define SIM_BLOCK_SIZE          LIST_DATA_SIZE + 265

#define SIM_PTR_TITLE           LIST_DATA_SIZE +  0
#define SIM_PTR_FILE            LIST_DATA_SIZE +  1
#define SIM_BURNUP              LIST_DATA_SIZE +  2
#define SIM_BURN_DAYS           LIST_DATA_SIZE +  3
#define SIM_CR                  LIST_DATA_SIZE +  4
#define SIM_VHI                 LIST_DATA_SIZE +  5
#define SIM_PTR_GCU             LIST_DATA_SIZE +  6
#define SIM_NFG                 LIST_DATA_SIZE +  7
#define SIM_NDFS                LIST_DATA_SIZE +  8
#define SIM_NDFC                LIST_DATA_SIZE +  9
#define SIM_ADF_SURF_TYPE       LIST_DATA_SIZE + 20
#define SIM_NDG                 LIST_DATA_SIZE + 21
#define SIM_PTR_GROUPS          LIST_DATA_SIZE + 22
#define SIM_ADF_NET_INCURR      LIST_DATA_SIZE + 23
#define SIM_ADF_SURF_FLX        LIST_DATA_SIZE + 24
#define SIM_ADF_CORN_FLX        LIST_DATA_SIZE + 25
#define SIM_ADFS                LIST_DATA_SIZE + 26
#define SIM_ADFC                LIST_DATA_SIZE + 27
#define SIM_ADF_VOL_FLX         LIST_DATA_SIZE + 28
#define SIM_BETA_EFF            LIST_DATA_SIZE + 29
#define SIM_BETA_ZERO           LIST_DATA_SIZE + 30
#define SIM_LAMBDA              LIST_DATA_SIZE + 40
#define SIM_RECIPVEL            LIST_DATA_SIZE + 41
#define SIM_NEUTRON_GENTIME     LIST_DATA_SIZE + 42
#define SIM_INF_FLX             LIST_DATA_SIZE + 99
#define SIM_INF_PROMPT_LIFE     LIST_DATA_SIZE + 100
#define SIM_INF_REP_TIME        LIST_DATA_SIZE + 101
#define SIM_INF_TOT             LIST_DATA_SIZE + 102
#define SIM_INF_CAPT            LIST_DATA_SIZE + 103
#define SIM_INF_FISS            LIST_DATA_SIZE + 104
#define SIM_INF_ABS             LIST_DATA_SIZE + 105
#define SIM_INF_NSF             LIST_DATA_SIZE + 106
#define SIM_INF_KAPPA           LIST_DATA_SIZE + 107
#define SIM_INF_INVV            LIST_DATA_SIZE + 108
#define SIM_INF_NUBAR           LIST_DATA_SIZE + 109
#define SIM_INF_RABSXS          LIST_DATA_SIZE + 110
#define SIM_INF_REMXS           LIST_DATA_SIZE + 111
#define SIM_INF_CHIT            LIST_DATA_SIZE + 112
#define SIM_INF_CHIP            LIST_DATA_SIZE + 113
#define SIM_INF_CHID            LIST_DATA_SIZE + 114
#define SIM_INF_S0              LIST_DATA_SIZE + 115
#define SIM_INF_S1              LIST_DATA_SIZE + 116
#define SIM_INF_S2              LIST_DATA_SIZE + 117
#define SIM_INF_S3              LIST_DATA_SIZE + 118
#define SIM_INF_S4              LIST_DATA_SIZE + 119
#define SIM_INF_S5              LIST_DATA_SIZE + 120
#define SIM_INF_S6              LIST_DATA_SIZE + 121
#define SIM_INF_S7              LIST_DATA_SIZE + 122
#define SIM_INF_SP0             LIST_DATA_SIZE + 123
#define SIM_INF_SP1             LIST_DATA_SIZE + 124
#define SIM_INF_SP2             LIST_DATA_SIZE + 125
#define SIM_INF_SP3             LIST_DATA_SIZE + 126
#define SIM_INF_SP4             LIST_DATA_SIZE + 127
#define SIM_INF_SP5             LIST_DATA_SIZE + 128
#define SIM_INF_SP6             LIST_DATA_SIZE + 129
#define SIM_INF_SP7             LIST_DATA_SIZE + 130
#define SIM_INF_SCATT0          LIST_DATA_SIZE + 131
#define SIM_INF_SCATT1          LIST_DATA_SIZE + 132
#define SIM_INF_SCATT2          LIST_DATA_SIZE + 133
#define SIM_INF_SCATT3          LIST_DATA_SIZE + 134
#define SIM_INF_SCATT4          LIST_DATA_SIZE + 135
#define SIM_INF_SCATT5          LIST_DATA_SIZE + 136
#define SIM_INF_SCATT6          LIST_DATA_SIZE + 137
#define SIM_INF_SCATT7          LIST_DATA_SIZE + 138
#define SIM_INF_SCATTP0         LIST_DATA_SIZE + 139
#define SIM_INF_SCATTP1         LIST_DATA_SIZE + 140
#define SIM_INF_SCATTP2         LIST_DATA_SIZE + 141
#define SIM_INF_SCATTP3         LIST_DATA_SIZE + 142
#define SIM_INF_SCATTP4         LIST_DATA_SIZE + 143
#define SIM_INF_SCATTP5         LIST_DATA_SIZE + 144
#define SIM_INF_SCATTP6         LIST_DATA_SIZE + 145
#define SIM_INF_SCATTP7         LIST_DATA_SIZE + 146
#define SIM_INF_I135_YIELD      LIST_DATA_SIZE + 147
#define SIM_INF_XE135_YIELD     LIST_DATA_SIZE + 148
#define SIM_INF_PM149_YIELD     LIST_DATA_SIZE + 149
#define SIM_INF_SM149_YIELD     LIST_DATA_SIZE + 150
#define SIM_INF_I135_ABS        LIST_DATA_SIZE + 151
#define SIM_INF_XE135_ABS       LIST_DATA_SIZE + 152
#define SIM_INF_PM149_ABS       LIST_DATA_SIZE + 153
#define SIM_INF_SM149_ABS       LIST_DATA_SIZE + 154
#define SIM_INF_I135_MACRO_ABS  LIST_DATA_SIZE + 155
#define SIM_INF_XE135_MACRO_ABS LIST_DATA_SIZE + 156
#define SIM_INF_PM149_MACRO_ABS LIST_DATA_SIZE + 157
#define SIM_INF_SM149_MACRO_ABS LIST_DATA_SIZE + 158
#define SIM_INF_TRANSPXS        LIST_DATA_SIZE + 159
#define SIM_INF_DIFFCOEF        LIST_DATA_SIZE + 160
#define SIM_B1_PROMPT_LIFE      LIST_DATA_SIZE + 198
#define SIM_B1_REP_TIME         LIST_DATA_SIZE + 199
#define SIM_B1_KINF             LIST_DATA_SIZE + 200
#define SIM_B1_B2               LIST_DATA_SIZE + 201
#define SIM_B1_ERR              LIST_DATA_SIZE + 202
#define SIM_B1_FLX              LIST_DATA_SIZE + 203
#define SIM_B1_TOT              LIST_DATA_SIZE + 204
#define SIM_B1_CAPT             LIST_DATA_SIZE + 205
#define SIM_B1_FISS             LIST_DATA_SIZE + 206
#define SIM_B1_ABS              LIST_DATA_SIZE + 207
#define SIM_B1_NSF              LIST_DATA_SIZE + 208
#define SIM_B1_KAPPA            LIST_DATA_SIZE + 209
#define SIM_B1_INVV             LIST_DATA_SIZE + 210
#define SIM_B1_NUBAR            LIST_DATA_SIZE + 211
#define SIM_B1_RABSXS           LIST_DATA_SIZE + 212
#define SIM_B1_REMXS            LIST_DATA_SIZE + 213
#define SIM_B1_CHIT             LIST_DATA_SIZE + 214
#define SIM_B1_CHIP             LIST_DATA_SIZE + 215
#define SIM_B1_CHID             LIST_DATA_SIZE + 216
#define SIM_B1_S0               LIST_DATA_SIZE + 217
#define SIM_B1_S1               LIST_DATA_SIZE + 218
#define SIM_B1_S2               LIST_DATA_SIZE + 219
#define SIM_B1_S3               LIST_DATA_SIZE + 220
#define SIM_B1_S4               LIST_DATA_SIZE + 221
#define SIM_B1_S5               LIST_DATA_SIZE + 222
#define SIM_B1_S6               LIST_DATA_SIZE + 223
#define SIM_B1_S7               LIST_DATA_SIZE + 224
#define SIM_B1_SP0              LIST_DATA_SIZE + 225
#define SIM_B1_SP1              LIST_DATA_SIZE + 226
#define SIM_B1_SP2              LIST_DATA_SIZE + 227
#define SIM_B1_SP3              LIST_DATA_SIZE + 228
#define SIM_B1_SP4              LIST_DATA_SIZE + 229
#define SIM_B1_SP5              LIST_DATA_SIZE + 230
#define SIM_B1_SP6              LIST_DATA_SIZE + 231
#define SIM_B1_SP7              LIST_DATA_SIZE + 232
#define SIM_B1_SCATT0           LIST_DATA_SIZE + 233
#define SIM_B1_SCATT1           LIST_DATA_SIZE + 234
#define SIM_B1_SCATT2           LIST_DATA_SIZE + 235
#define SIM_B1_SCATT3           LIST_DATA_SIZE + 236
#define SIM_B1_SCATT4           LIST_DATA_SIZE + 237
#define SIM_B1_SCATT5           LIST_DATA_SIZE + 238
#define SIM_B1_SCATT6           LIST_DATA_SIZE + 239
#define SIM_B1_SCATT7           LIST_DATA_SIZE + 240
#define SIM_B1_SCATTP0          LIST_DATA_SIZE + 241
#define SIM_B1_SCATTP1          LIST_DATA_SIZE + 242
#define SIM_B1_SCATTP2          LIST_DATA_SIZE + 243
#define SIM_B1_SCATTP3          LIST_DATA_SIZE + 244
#define SIM_B1_SCATTP4          LIST_DATA_SIZE + 245
#define SIM_B1_SCATTP5          LIST_DATA_SIZE + 246
#define SIM_B1_SCATTP6          LIST_DATA_SIZE + 247
#define SIM_B1_SCATTP7          LIST_DATA_SIZE + 248
#define SIM_B1_I135_YIELD       LIST_DATA_SIZE + 249
#define SIM_B1_XE135_YIELD      LIST_DATA_SIZE + 250
#define SIM_B1_PM149_YIELD      LIST_DATA_SIZE + 251
#define SIM_B1_SM149_YIELD      LIST_DATA_SIZE + 252
#define SIM_B1_I135_ABS         LIST_DATA_SIZE + 253
#define SIM_B1_XE135_ABS        LIST_DATA_SIZE + 254
#define SIM_B1_PM149_ABS        LIST_DATA_SIZE + 255
#define SIM_B1_SM149_ABS        LIST_DATA_SIZE + 256
#define SIM_B1_I135_MACRO_ABS   LIST_DATA_SIZE + 257
#define SIM_B1_XE135_MACRO_ABS  LIST_DATA_SIZE + 258
#define SIM_B1_PM149_MACRO_ABS  LIST_DATA_SIZE + 259
#define SIM_B1_SM149_MACRO_ABS  LIST_DATA_SIZE + 260
#define SIM_B1_TRANSPXS         LIST_DATA_SIZE + 261
#define SIM_B1_DIFFCOEF         LIST_DATA_SIZE + 262

#define SIM_KINF                LIST_DATA_SIZE + 263
#define SIM_POWDENS             LIST_DATA_SIZE + 264

/*****************************************************************************/

/***** Material volumes list *************************************************/

#define MVOL_BLOCK_SIZE         LIST_DATA_SIZE +  3

#define MVOL_PTR_MAT            LIST_DATA_SIZE +  0
#define MVOL_REG_IDX            LIST_DATA_SIZE +  1
#define MVOL_VOL                LIST_DATA_SIZE +  2

/*****************************************************************************/

/***** Mora output ***********************************************************/

#define MORA_BLOCK_SIZE         LIST_DATA_SIZE + 16

#define MORA_PTR_FNAME          LIST_DATA_SIZE +  0
#define MORA_PTR_UNIV           LIST_DATA_SIZE +  1
#define MORA_PTR_EG             LIST_DATA_SIZE +  2
#define MORA_N_EG               LIST_DATA_SIZE +  3
#define MORA_N_COS              LIST_DATA_SIZE +  4
#define MORA_PTR_TOT            LIST_DATA_SIZE +  5
#define MORA_PTR_CAPT           LIST_DATA_SIZE +  6
#define MORA_PTR_FISS           LIST_DATA_SIZE +  7
#define MORA_PTR_SCATTP         LIST_DATA_SIZE +  8
#define MORA_PTR_SCATTW         LIST_DATA_SIZE +  9
#define MORA_PTR_PNU            LIST_DATA_SIZE + 10
#define MORA_PTR_DNU            LIST_DATA_SIZE + 11
#define MORA_PTR_KAPPA          LIST_DATA_SIZE + 12
#define MORA_PTR_CHIP           LIST_DATA_SIZE + 13
#define MORA_PTR_CHID           LIST_DATA_SIZE + 14
#define MORA_PTR_FLX            LIST_DATA_SIZE + 15

/*****************************************************************************/

/***** Group constant generation *********************************************/

#define GCU_BLOCK_SIZE                 LIST_DATA_SIZE + 360

#define GCU_PTR_UNIV                   LIST_DATA_SIZE +  0
#define GCU_PTR_ADF                    LIST_DATA_SIZE +  1
#define GCU_RES_FG_FLX                 LIST_DATA_SIZE +  2
#define GCU_RES_FG_LEAK                LIST_DATA_SIZE +  3
#define GCU_RES_FG_TOTXS               LIST_DATA_SIZE +  4
#define GCU_RES_FG_FISSXS              LIST_DATA_SIZE +  5
#define GCU_RES_FG_CAPTXS              LIST_DATA_SIZE +  6
#define GCU_RES_FG_ABSXS               LIST_DATA_SIZE +  7
#define GCU_RES_FG_RABSXS              LIST_DATA_SIZE +  8
#define GCU_RES_FG_ELAXS               LIST_DATA_SIZE +  9
#define GCU_RES_FG_INLXS               LIST_DATA_SIZE + 10
#define GCU_RES_FG_SCATTXS             LIST_DATA_SIZE + 11
#define GCU_RES_FG_SCATTPRODXS         LIST_DATA_SIZE + 12
#define GCU_RES_FG_REMXS               LIST_DATA_SIZE + 13
#define GCU_RES_FG_NUBAR               LIST_DATA_SIZE + 14
#define GCU_RES_FG_NSF                 LIST_DATA_SIZE + 15
#define GCU_RES_FG_RECIPVEL            LIST_DATA_SIZE + 16
#define GCU_RES_FG_FISSE               LIST_DATA_SIZE + 17 
#define GCU_RES_FG_CHI                 LIST_DATA_SIZE + 18 
#define GCU_RES_FG_CHIP                LIST_DATA_SIZE + 19 
#define GCU_RES_FG_CHID                LIST_DATA_SIZE + 20 
#define GCU_RES_FG_GTRANSP             LIST_DATA_SIZE + 21
#define GCU_RES_FG_GTRANSXS            LIST_DATA_SIZE + 22
#define GCU_RES_FG_GPRODP              LIST_DATA_SIZE + 23
#define GCU_RES_FG_GPRODXS             LIST_DATA_SIZE + 24
#define GCU_RES_FG_SCATT0              LIST_DATA_SIZE + 25
#define GCU_RES_FG_SCATT1              LIST_DATA_SIZE + 26
#define GCU_RES_FG_SCATT2              LIST_DATA_SIZE + 27
#define GCU_RES_FG_SCATT3              LIST_DATA_SIZE + 28
#define GCU_RES_FG_SCATT4              LIST_DATA_SIZE + 29
#define GCU_RES_FG_SCATT5              LIST_DATA_SIZE + 30
#define GCU_RES_FG_I135_PROD_XS        LIST_DATA_SIZE + 31
#define GCU_RES_FG_XE135_PROD_XS       LIST_DATA_SIZE + 32
#define GCU_RES_FG_PM149_PROD_XS       LIST_DATA_SIZE + 33
#define GCU_RES_FG_SM149_PROD_XS       LIST_DATA_SIZE + 34
#define GCU_RES_FG_I135_ABS_XS         LIST_DATA_SIZE + 35
#define GCU_RES_FG_XE135_ABS_XS        LIST_DATA_SIZE + 36
#define GCU_RES_FG_PM149_ABS_XS        LIST_DATA_SIZE + 37
#define GCU_RES_FG_SM149_ABS_XS        LIST_DATA_SIZE + 38
#define GCU_RES_FG_P1_FLUX             LIST_DATA_SIZE + 41
#define GCU_RES_FG_P1_TRANSPXS         LIST_DATA_SIZE + 42
#define GCU_RES_FG_P1_DIFFCOEF         LIST_DATA_SIZE + 43
#define GCU_RES_FG_P1_MUBAR            LIST_DATA_SIZE + 44
#define GCU_RES_FG_DF_HET_SURF_FLUX    LIST_DATA_SIZE + 45
#define GCU_RES_FG_DF_HET_CORN_FLUX    LIST_DATA_SIZE + 46
#define GCU_RES_FG_DF_HET_VOL_FLUX     LIST_DATA_SIZE + 47
#define GCU_RES_FG_DF_SURF_DF          LIST_DATA_SIZE + 48
#define GCU_RES_FG_DF_CORN_DF          LIST_DATA_SIZE + 49
#define GCU_RES_FG_DF_IN_CURR          LIST_DATA_SIZE + 50
#define GCU_RES_FG_DF_OUT_CURR         LIST_DATA_SIZE + 51
#define GCU_RES_FG_DF_NET_CURR         LIST_DATA_SIZE + 52
#define GCU_RES_FG_DF_HOM_SURF_FLUX    LIST_DATA_SIZE + 53
#define GCU_RES_FG_DF_HOM_CORN_FLUX    LIST_DATA_SIZE + 54
#define GCU_RES_FG_DF_HOM_VOL_FLUX     LIST_DATA_SIZE + 55
#define GCU_FUM_PTR_SPEC_CORR          LIST_DATA_SIZE + 76
#define GCU_FUM_FG_B1_KINF             LIST_DATA_SIZE + 77
#define GCU_FUM_FG_B1_BUCKLING         LIST_DATA_SIZE + 78
#define GCU_FUM_FG_B1_DIFFCOEF         LIST_DATA_SIZE + 79
#define GCU_FUM_FG_B1_ABSXS            LIST_DATA_SIZE + 80
#define GCU_FUM_FG_B1_RABSXS           LIST_DATA_SIZE + 81
#define GCU_FUM_FG_B1_NSF              LIST_DATA_SIZE + 82
#define GCU_FUM_FG_B1_FISSXS           LIST_DATA_SIZE + 83
#define GCU_FUM_FG_B1_SCATTXS          LIST_DATA_SIZE + 84
#define GCU_FUM_FG_B1_SCATTPRODXS      LIST_DATA_SIZE + 85
#define GCU_FUM_FG_B1_TOTXS            LIST_DATA_SIZE + 86
#define GCU_FUM_FG_B1_FLUX             LIST_DATA_SIZE + 87
#define GCU_FUM_FG_B1_CHI              LIST_DATA_SIZE + 88
#define GCU_FUM_FG_B1_REMXS            LIST_DATA_SIZE + 89
#define GCU_FUM_FG_I135_PROD_XS        LIST_DATA_SIZE + 90
#define GCU_FUM_FG_XE135_PROD_XS       LIST_DATA_SIZE + 91
#define GCU_FUM_FG_PM149_PROD_XS       LIST_DATA_SIZE + 92
#define GCU_FUM_FG_SM149_PROD_XS       LIST_DATA_SIZE + 93
#define GCU_FUM_FG_I135_ABS_XS         LIST_DATA_SIZE + 94
#define GCU_FUM_FG_XE135_ABS_XS        LIST_DATA_SIZE + 95
#define GCU_FUM_FG_PM149_ABS_XS        LIST_DATA_SIZE + 96
#define GCU_FUM_FG_SM149_ABS_XS        LIST_DATA_SIZE + 97
#define GCU_PTR_MORA                   LIST_DATA_SIZE + 98

/* Micro-group data */

#define GCU_MICRO_FLX                  LIST_DATA_SIZE + 100 
#define GCU_MICRO_FISS_FLX             LIST_DATA_SIZE + 101
#define GCU_MICRO_TOT                  LIST_DATA_SIZE + 102
#define GCU_MICRO_ABS                  LIST_DATA_SIZE + 103
#define GCU_MICRO_FISS                 LIST_DATA_SIZE + 104
#define GCU_MICRO_NSF                  LIST_DATA_SIZE + 105
#define GCU_MICRO_FISSE                LIST_DATA_SIZE + 106
#define GCU_MICRO_INV_V                LIST_DATA_SIZE + 107
#define GCU_MICRO_CHIT                 LIST_DATA_SIZE + 108
#define GCU_MICRO_CHIP                 LIST_DATA_SIZE + 109
#define GCU_MICRO_CHID                 LIST_DATA_SIZE + 110
#define GCU_MICRO_SCATT0               LIST_DATA_SIZE + 111
#define GCU_MICRO_SCATT1               LIST_DATA_SIZE + 112
#define GCU_MICRO_SCATT2               LIST_DATA_SIZE + 113
#define GCU_MICRO_SCATT3               LIST_DATA_SIZE + 114
#define GCU_MICRO_SCATT4               LIST_DATA_SIZE + 115
#define GCU_MICRO_SCATT5               LIST_DATA_SIZE + 116
#define GCU_MICRO_SCATT6               LIST_DATA_SIZE + 117
#define GCU_MICRO_SCATT7               LIST_DATA_SIZE + 118
#define GCU_MICRO_SCATTP0              LIST_DATA_SIZE + 119
#define GCU_MICRO_SCATTP1              LIST_DATA_SIZE + 120
#define GCU_MICRO_SCATTP2              LIST_DATA_SIZE + 121
#define GCU_MICRO_SCATTP3              LIST_DATA_SIZE + 122
#define GCU_MICRO_SCATTP4              LIST_DATA_SIZE + 123
#define GCU_MICRO_SCATTP5              LIST_DATA_SIZE + 124
#define GCU_MICRO_SCATTP6              LIST_DATA_SIZE + 125
#define GCU_MICRO_SCATTP7              LIST_DATA_SIZE + 126
#define GCU_MICRO_I135_YIELD           LIST_DATA_SIZE + 127
#define GCU_MICRO_XE135_YIELD          LIST_DATA_SIZE + 128
#define GCU_MICRO_PM149_YIELD          LIST_DATA_SIZE + 129
#define GCU_MICRO_SM149_YIELD          LIST_DATA_SIZE + 130
#define GCU_MICRO_I135_ABS             LIST_DATA_SIZE + 131
#define GCU_MICRO_XE135_ABS            LIST_DATA_SIZE + 132
#define GCU_MICRO_PM149_ABS            LIST_DATA_SIZE + 133
#define GCU_MICRO_SM149_ABS            LIST_DATA_SIZE + 134
#define GCU_MICRO_I135_MACRO_ABS       LIST_DATA_SIZE + 135
#define GCU_MICRO_XE135_MACRO_ABS      LIST_DATA_SIZE + 136
#define GCU_MICRO_PM149_MACRO_ABS      LIST_DATA_SIZE + 137
#define GCU_MICRO_SM149_MACRO_ABS      LIST_DATA_SIZE + 138
#define GCU_MICRO_ADF_SURF_FLUX        LIST_DATA_SIZE + 139
#define GCU_MICRO_ADF_CORN_FLUX        LIST_DATA_SIZE + 140
#define GCU_MICRO_ADF_CELL_FLUX        LIST_DATA_SIZE + 141
#define GCU_MICRO_ADF_IN_CURR          LIST_DATA_SIZE + 142
#define GCU_MICRO_ADF_OUT_CURR         LIST_DATA_SIZE + 143
#define GCU_MICRO_B1_FLX               LIST_DATA_SIZE + 144
#define GCU_MICRO_B1_DIFFCOEF          LIST_DATA_SIZE + 145

#define GCU_HDMC_KEFF                  LIST_DATA_SIZE + 180

#define GCU_INF_FLX                    LIST_DATA_SIZE + 192
#define GCU_INF_FISS_FLX               LIST_DATA_SIZE + 193
#define GCU_INF_KINF                   LIST_DATA_SIZE + 194
#define GCU_INF_REP_TIME               LIST_DATA_SIZE + 195
#define GCU_INF_PROMPT_LIFE            LIST_DATA_SIZE + 196
#define GCU_INF_TOT                    LIST_DATA_SIZE + 197
#define GCU_INF_CAPT                   LIST_DATA_SIZE + 198
#define GCU_INF_FISS                   LIST_DATA_SIZE + 199
#define GCU_INF_ABS                    LIST_DATA_SIZE + 200
#define GCU_INF_NSF                    LIST_DATA_SIZE + 201
#define GCU_INF_KAPPA                  LIST_DATA_SIZE + 202
#define GCU_INF_INVV                   LIST_DATA_SIZE + 203
#define GCU_INF_NUBAR                  LIST_DATA_SIZE + 204
#define GCU_INF_RABSXS                 LIST_DATA_SIZE + 205
#define GCU_INF_REMXS                  LIST_DATA_SIZE + 206
#define GCU_INF_CHIT                   LIST_DATA_SIZE + 207
#define GCU_INF_CHIP                   LIST_DATA_SIZE + 208
#define GCU_INF_CHID                   LIST_DATA_SIZE + 209
#define GCU_INF_S0                     LIST_DATA_SIZE + 210
#define GCU_INF_S1                     LIST_DATA_SIZE + 211
#define GCU_INF_S2                     LIST_DATA_SIZE + 212
#define GCU_INF_S3                     LIST_DATA_SIZE + 213
#define GCU_INF_S4                     LIST_DATA_SIZE + 214
#define GCU_INF_S5                     LIST_DATA_SIZE + 215
#define GCU_INF_S6                     LIST_DATA_SIZE + 216
#define GCU_INF_S7                     LIST_DATA_SIZE + 217
#define GCU_INF_SP0                    LIST_DATA_SIZE + 218
#define GCU_INF_SP1                    LIST_DATA_SIZE + 219
#define GCU_INF_SP2                    LIST_DATA_SIZE + 220
#define GCU_INF_SP3                    LIST_DATA_SIZE + 221
#define GCU_INF_SP4                    LIST_DATA_SIZE + 222
#define GCU_INF_SP5                    LIST_DATA_SIZE + 223
#define GCU_INF_SP6                    LIST_DATA_SIZE + 224
#define GCU_INF_SP7                    LIST_DATA_SIZE + 225
#define GCU_INF_SCATT0                 LIST_DATA_SIZE + 226
#define GCU_INF_SCATT1                 LIST_DATA_SIZE + 227
#define GCU_INF_SCATT2                 LIST_DATA_SIZE + 228
#define GCU_INF_SCATT3                 LIST_DATA_SIZE + 229
#define GCU_INF_SCATT4                 LIST_DATA_SIZE + 230
#define GCU_INF_SCATT5                 LIST_DATA_SIZE + 231
#define GCU_INF_SCATT6                 LIST_DATA_SIZE + 232
#define GCU_INF_SCATT7                 LIST_DATA_SIZE + 233
#define GCU_INF_SCATTP0                LIST_DATA_SIZE + 234
#define GCU_INF_SCATTP1                LIST_DATA_SIZE + 235
#define GCU_INF_SCATTP2                LIST_DATA_SIZE + 236
#define GCU_INF_SCATTP3                LIST_DATA_SIZE + 237
#define GCU_INF_SCATTP4                LIST_DATA_SIZE + 238
#define GCU_INF_SCATTP5                LIST_DATA_SIZE + 239
#define GCU_INF_SCATTP6                LIST_DATA_SIZE + 240
#define GCU_INF_SCATTP7                LIST_DATA_SIZE + 241
#define GCU_INF_I135_YIELD             LIST_DATA_SIZE + 242
#define GCU_INF_XE135_YIELD            LIST_DATA_SIZE + 243
#define GCU_INF_PM149_YIELD            LIST_DATA_SIZE + 244
#define GCU_INF_SM149_YIELD            LIST_DATA_SIZE + 245
#define GCU_INF_I135_ABS               LIST_DATA_SIZE + 246
#define GCU_INF_XE135_ABS              LIST_DATA_SIZE + 247
#define GCU_INF_PM149_ABS              LIST_DATA_SIZE + 248
#define GCU_INF_SM149_ABS              LIST_DATA_SIZE + 249
#define GCU_INF_I135_MACRO_ABS         LIST_DATA_SIZE + 250
#define GCU_INF_XE135_MACRO_ABS        LIST_DATA_SIZE + 251
#define GCU_INF_PM149_MACRO_ABS        LIST_DATA_SIZE + 252
#define GCU_INF_SM149_MACRO_ABS        LIST_DATA_SIZE + 253
#define GCU_INF_TRANSPXS               LIST_DATA_SIZE + 254
#define GCU_INF_DIFFCOEF               LIST_DATA_SIZE + 255

#define GCU_B1_KEFF                    LIST_DATA_SIZE + 293
#define GCU_B1_KINF                    LIST_DATA_SIZE + 294
#define GCU_B1_B2                      LIST_DATA_SIZE + 295
#define GCU_B1_REP_TIME                LIST_DATA_SIZE + 296
#define GCU_B1_PROMPT_LIFE             LIST_DATA_SIZE + 297
#define GCU_B1_ERR                     LIST_DATA_SIZE + 298
#define GCU_B1_FISS_FLX                LIST_DATA_SIZE + 299
#define GCU_B1_FLX                     LIST_DATA_SIZE + 300
#define GCU_B1_TOT                     LIST_DATA_SIZE + 301
#define GCU_B1_CAPT                    LIST_DATA_SIZE + 302
#define GCU_B1_FISS                    LIST_DATA_SIZE + 303
#define GCU_B1_ABS                     LIST_DATA_SIZE + 304
#define GCU_B1_NSF                     LIST_DATA_SIZE + 305
#define GCU_B1_KAPPA                   LIST_DATA_SIZE + 306
#define GCU_B1_INVV                    LIST_DATA_SIZE + 307
#define GCU_B1_NUBAR                   LIST_DATA_SIZE + 308
#define GCU_B1_RABSXS                  LIST_DATA_SIZE + 309
#define GCU_B1_REMXS                   LIST_DATA_SIZE + 310
#define GCU_B1_CHIT                    LIST_DATA_SIZE + 311
#define GCU_B1_CHIP                    LIST_DATA_SIZE + 312
#define GCU_B1_CHID                    LIST_DATA_SIZE + 313
#define GCU_B1_S0                      LIST_DATA_SIZE + 314
#define GCU_B1_S1                      LIST_DATA_SIZE + 315
#define GCU_B1_S2                      LIST_DATA_SIZE + 316
#define GCU_B1_S3                      LIST_DATA_SIZE + 317
#define GCU_B1_S4                      LIST_DATA_SIZE + 318
#define GCU_B1_S5                      LIST_DATA_SIZE + 319
#define GCU_B1_S6                      LIST_DATA_SIZE + 320
#define GCU_B1_S7                      LIST_DATA_SIZE + 321
#define GCU_B1_SP0                     LIST_DATA_SIZE + 322
#define GCU_B1_SP1                     LIST_DATA_SIZE + 323
#define GCU_B1_SP2                     LIST_DATA_SIZE + 324
#define GCU_B1_SP3                     LIST_DATA_SIZE + 325
#define GCU_B1_SP4                     LIST_DATA_SIZE + 326
#define GCU_B1_SP5                     LIST_DATA_SIZE + 327
#define GCU_B1_SP6                     LIST_DATA_SIZE + 328
#define GCU_B1_SP7                     LIST_DATA_SIZE + 329
#define GCU_B1_SCATT0                  LIST_DATA_SIZE + 330
#define GCU_B1_SCATT1                  LIST_DATA_SIZE + 331
#define GCU_B1_SCATT2                  LIST_DATA_SIZE + 332
#define GCU_B1_SCATT3                  LIST_DATA_SIZE + 333
#define GCU_B1_SCATT4                  LIST_DATA_SIZE + 334
#define GCU_B1_SCATT5                  LIST_DATA_SIZE + 335
#define GCU_B1_SCATT6                  LIST_DATA_SIZE + 336
#define GCU_B1_SCATT7                  LIST_DATA_SIZE + 337
#define GCU_B1_SCATTP0                 LIST_DATA_SIZE + 338
#define GCU_B1_SCATTP1                 LIST_DATA_SIZE + 339
#define GCU_B1_SCATTP2                 LIST_DATA_SIZE + 340
#define GCU_B1_SCATTP3                 LIST_DATA_SIZE + 341
#define GCU_B1_SCATTP4                 LIST_DATA_SIZE + 342
#define GCU_B1_SCATTP5                 LIST_DATA_SIZE + 343
#define GCU_B1_SCATTP6                 LIST_DATA_SIZE + 344
#define GCU_B1_SCATTP7                 LIST_DATA_SIZE + 345
#define GCU_B1_I135_YIELD              LIST_DATA_SIZE + 346
#define GCU_B1_XE135_YIELD             LIST_DATA_SIZE + 347
#define GCU_B1_PM149_YIELD             LIST_DATA_SIZE + 348
#define GCU_B1_SM149_YIELD             LIST_DATA_SIZE + 349
#define GCU_B1_I135_ABS                LIST_DATA_SIZE + 350
#define GCU_B1_XE135_ABS               LIST_DATA_SIZE + 351
#define GCU_B1_PM149_ABS               LIST_DATA_SIZE + 352
#define GCU_B1_SM149_ABS               LIST_DATA_SIZE + 353
#define GCU_B1_I135_MACRO_ABS          LIST_DATA_SIZE + 354
#define GCU_B1_XE135_MACRO_ABS         LIST_DATA_SIZE + 355
#define GCU_B1_PM149_MACRO_ABS         LIST_DATA_SIZE + 356
#define GCU_B1_SM149_MACRO_ABS         LIST_DATA_SIZE + 357
#define GCU_B1_TRANSPXS                LIST_DATA_SIZE + 358
#define GCU_B1_DIFFCOEF                LIST_DATA_SIZE + 359

/*****************************************************************************/
