/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processburnmat.c                               */
/*                                                                           */
/* Created:       2011/01/25 (JLe)                                           */
/* Last modified: 2013/02/22 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Additional processing for materials used in burnup           */
/*              calculation                                                  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessBurnMat:"

/*****************************************************************************/

void ProcessBurnMat()
{
  long mat, ptr, loc0, loc1, ne, mat0, sz;
  double mem;

  /* Check burnup mode */

 if ((long)RDB[DATA_BURNUP_CALCULATION_MODE] == NO)
   return;

  /* Check burnup step */

  if ((long)RDB[DATA_BURN_STEP] > 0)
    Die(FUNCTION_NAME, "Should not be here");

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Reset burn-flags for non-physical materials (this is needed for */
      /* detector and source materials) */
      
      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_PHYSICAL_MAT))
	ResetOption(mat + MATERIAL_OPTIONS, OPT_BURN_MAT);

      /* Next material */

      mat = NextItem(mat);
    }

  /* Print */

  fprintf(out, "Allocating memory for burnup calculation...\n");

  /***************************************************************************/

  /***** Allocate memory from RES2 block to speed up calculation *************/

  /* Calculate memory size */

  sz = 0;

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check burn flag and pointer to parent */

      if (((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT) &&
	  ((mat0 = (long)RDB[mat + MATERIAL_DIV_PTR_PARENT]) > VALID_PTR))
	{
	  /* Add sum of spectrum */

	  sz = sz + 1;
	  
	  /* Add transmutation cross sections */

	  if ((ptr = (long)RDB[mat0 + MATERIAL_PTR_DEP_TRA_LIST]) > VALID_PTR)
	    sz = sz + ListSize(ptr);

	  /* Add fission cross sections */

	  if ((ptr = (long)RDB[mat0 + MATERIAL_PTR_DEP_FISS_LIST]) > VALID_PTR)
	    sz = sz + ListSize(ptr);

	  /* Add flux spectrum */
	  
	  if (((long)RDB[DATA_BURN_DECAY_CALC] == NO) &&
	      ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES))
	    {
	      /* Pointer to unionized energy grid */
	      
	      ptr = (long)RDB[DATA_ERG_PTR_UNIONIZED_NGRID];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Add number of points */

	      sz = sz + (long)RDB[ptr + ENERGY_GRID_NE];
	    }
	}
      
      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Allocate memory */

  PreallocMem(sz, RES2_ARRAY);

  /***************************************************************************/

  /***** Process material-wise data ******************************************/

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /***********************************************************************/

      /***** Check flags, etc. ***********************************************/

      /* Check burn flag */

      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	{
	  /* Next material */

	  mat = NextItem(mat);

	  /* Cycle loop */

	  continue;
	}

      /* Check composition */
      
      if ((long)RDB[mat + MATERIAL_PTR_COMP] < VALID_PTR)
	Die(FUNCTION_NAME, "Material %s has no nuclides", 
	    GetText(mat + MATERIAL_PTR_NAME));
      
      /* Check mixture */
      
      if ((long)RDB[mat + MATERIAL_PTR_MIX] > VALID_PTR)
	Die(FUNCTION_NAME, "Burnable mixture %s?", 
	    GetText(mat + MATERIAL_PTR_NAME));

      /* Check div type */

      if ((long)RDB[mat + MATERIAL_DIV_TYPE] == MAT_DIV_TYPE_PARENT)
	Die(FUNCTION_NAME, "Parent material");

      /* Put output flag if not parent or divided */
      
      if ((long)RDB[mat + MATERIAL_DIV_TYPE] == MAT_DIV_TYPE_NONE)
	WDB[mat + MATERIAL_BURN_PRINT_OUTPUT] = (double)YES;

      /* Calculate bytes */

      CalculateBytes();

      /* Get memory size */
      
      mem = RDB[DATA_TOTAL_BYTES];      

      /***********************************************************************/
      
      /***** Copy transmutation and fission lists from parent ****************/

      /* Get pointer to parent material */

      if ((mat0 = (long)RDB[mat + MATERIAL_DIV_PTR_PARENT]) > VALID_PTR)
	{
	  /* Copy doppler mode */

	  WDB[mat + MATERIAL_ETTM_MODE] = WDB[mat0 + MATERIAL_ETTM_MODE];
	  
	  /* Reset pointer */

	  loc1 = -1;

	  /* Loop over transmutation list */
	  
	  loc0 = (long)RDB[mat0 + MATERIAL_PTR_DEP_TRA_LIST];
	  while (loc0 > VALID_PTR)
	    {
	      /* Allocate memory */
	      
	      loc1  = NewItem(mat + MATERIAL_PTR_DEP_TRA_LIST, 
			      DEP_TRA_BLOCK_SIZE);

	      /* Copy values */

	      WDB[loc1 + DEP_TRA_PTR_REA] = RDB[loc0 + DEP_TRA_PTR_REA];
	      WDB[loc1 + DEP_TRA_E0] = RDB[loc0 + DEP_TRA_E0];
		  
	      /* Next */
	      
	      loc0 = NextItem(loc0);
	    }

	  /* Close list */
	  
	  if (loc1 > VALID_PTR)
	    CloseList(loc1);

	  /* Reset pointer */

	  loc1 = -1;

	  /* Loop over fission list */
	  
	  loc0 = (long)RDB[mat0 + MATERIAL_PTR_DEP_FISS_LIST];
	  while (loc0 > VALID_PTR)
	    {
	      /* Allocate memory */
	      
	      loc1  = NewItem(mat + MATERIAL_PTR_DEP_FISS_LIST, 
			      DEP_TRA_BLOCK_SIZE);

	      /* Copy values */

	      WDB[loc1 + DEP_TRA_PTR_REA] = RDB[loc0 + DEP_TRA_PTR_REA];
	      WDB[loc1 + DEP_TRA_E0] = RDB[loc0 + DEP_TRA_E0];
	
	      /* Next */
	      
	      loc0 = NextItem(loc0);
	    }

	  /* Close list */
	  
	  if (loc1 > VALID_PTR)
	    CloseList(loc1);
	}
      
      /************************************************************************/

      /***** Allocate memory for results **************************************/

      /* Transmutation cross sections */
	  
      loc0 = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST];
      while (loc0 > VALID_PTR)
	{
	  /* Allocate memory */
	  
	  ptr = AllocPrivateData(1, RES2_ARRAY);
	  WDB[loc0 + DEP_TRA_PTR_RESU] = (double)ptr;

	  /* Next */
	      
	  loc0 = NextItem(loc0);
	}

      /* Fission cross sections */
	  
      loc0 = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST];
      while (loc0 > VALID_PTR)
	{
	  /* Allocate memory */
	  
	  ptr = AllocPrivateData(1, RES2_ARRAY);
	  WDB[loc0 + DEP_TRA_PTR_RESU] = (double)ptr;

	  /* Next */
	      
	  loc0 = NextItem(loc0);
	}
	
      /* Allocate memory for flux spectrum */

      if (((long)RDB[DATA_BURN_DECAY_CALC] == NO) &&
	  ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES))
	{
	  /* Pointer to unionized grid */
	  
	  if ((ptr = (long)RDB[DATA_ERG_PTR_UNIONIZED_NGRID]) < VALID_PTR)
	    Die(FUNCTION_NAME, "Energy grid not unionized");
	  
	  /* Get number of points */
	  
	  ne = (long)RDB[ptr + ENERGY_GRID_NE];

	  /* Allocate memory */
	  
	  ptr = AllocPrivateData(ne, RES2_ARRAY);
	  WDB[mat + MATERIAL_PTR_FLUX_SPEC] = (double)ptr;      
	}
      
      /* Allocate memory for burn flux */

      ptr = NewStat("BURN_FLUX", 1, 1);
      WDB[mat + MATERIAL_PTR_BURN_FLUX] = (double)ptr;  

      /* Allocate memory for sum of spectrum */

      ptr = AllocPrivateData(1, RES2_ARRAY);
      WDB[mat + MATERIAL_PTR_FLUX_SPEC_SUM] = (double)ptr;      
      
      /************************************************************************/

      /* Calculate bytes */

      CalculateBytes();

      /* Update memory size */
      
      WDB[mat + MATERIAL_MEM_SIZE] = RDB[mat + MATERIAL_MEM_SIZE] + 
	RDB[DATA_TOTAL_BYTES] - mem;
      
      /* Next material */
      
      mat = NextItem(mat);
    }
  
  /* Calculate data size */
  
  CalculateBytes();

  /***************************************************************************/

  fprintf(out, "OK.\n\n");
}

/*****************************************************************************/
