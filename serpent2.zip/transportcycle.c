/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : transportcycle.c                               */
/*                                                                           */
/* Created:       2011/05/23 (JLe)                                           */
/* Last modified: 2013/04/18 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Prepares and runs the main transport cycle                   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "TransportCycle:"

/*****************************************************************************/

void TransportCycle()
{
  long nb, maxb, nn, nt, maxt, id, idx, ptr, tme;
  double t0;

  /***************************************************************************/

  /***** Main transport cycle ************************************************/

  /* Reset total and active timer */

  ResetTimer(TIMER_TRANSPORT);
  ResetTimer(TIMER_TRANSPORT_ACTIVE);

  /* Start transport timer */
      
  StartTimer(TIMER_TRANSPORT);
  StartTimer(TIMER_TRANSPORT_TOTAL);

  /* Reset completed flag */

  WDB[DATA_SIMULATION_COMPLETED] = 0.0;

  /* Check mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      /***********************************************************************/

      /***** External source simulation **************************************/

      /* Reset skip cycles */

      WDB[DATA_CRIT_SKIP] = 0.0;

      /* Set cycle-wise batch size */

      WDB[DATA_CYCLE_BATCH_SIZE] = RDB[DATA_SRC_POP];
      
      /* Set number of source points in batch */

      WDB[DATA_NHIST_CYCLE] = RDB[DATA_SRC_POP];

      /* Get number of bins */

      maxt = (long)RDB[DATA_DYN_NB];
      CheckValue(FUNCTION_NAME, "maxt", "", maxt, 1, 1000000000);

      /* Get pointer to time bin structure */

      tme = (long)RDB[DATA_DYN_PTR_TIME_BINS];
      CheckPointer(FUNCTION_NAME, "(tme)", DATA_ARRAY, tme);
      
      /* Get pointer to bins */

      tme = (long)RDB[tme + TME_PTR_BINS];
      CheckPointer(FUNCTION_NAME, "(tme)", DATA_ARRAY, tme);    
     
      /* Start active transport timer */

      StartTimer(TIMER_TRANSPORT_ACTIVE);

      /* Start cycle-wise transport timer */

      ResetTimer(TIMER_TRANSPORT_CYCLE);
      StartTimer(TIMER_TRANSPORT_CYCLE);
      
      /* Loop over batches */
      
      for (nb = 0; nb < (long)RDB[DATA_SRC_BATCHES]; nb++)
	{
	  /* Reset time bin index */

	  WDB[DATA_DYN_TB] = 0.0;

	  /* Re-initialize temperature feedbacks (needed for dynamic mode) */

	  if (nb > 0)
	    ReinitTFB();

	  /* First batch must be discarded if temperature feeback is */
	  /* in use because zero values are stored in statistics. */
	  
	  if (((long)RDB[DATA_USE_TFB] == YES) && (nb == 1))
	    ClearStat(-1);

	  /* Clear micro-group data */

	  ClearMicroGroupXS();

	  /* Set time cut-off for first cycle */
	  
	  WDB[DATA_TIME_CUT_TMIN] = RDB[tme];
	  WDB[DATA_TIME_CUT_TMAX] = RDB[tme + 1];

	  /* Reset cycle k-eff and put starting weight */

	  WDB[DATA_CYCLE_KEFF] = 1.0;
	  WDB[DATA_DYN_WGT0] = RDB[DATA_SRC_POP];

	  /* Set batch counter */

	  WDB[DATA_BATCH_COUNT] = RDB[DATA_BATCH_INTERVAL];

	  /* Put cycle index */

	  WDB[DATA_CYCLE_IDX] = (double)nb;

	  /* Get beginning time */

	  t0 = TimerVal(TIMER_TRANSPORT);

	  /* Start parallel timer */

	  StartTimer(TIMER_OMP_PARA);

	  /* Parallel loop over histories */

#ifdef OPEN_MP
#pragma omp parallel private(id, idx, nn) 
#endif
	  {
	    /* Get Open MP thread id */
		
	    id = OMP_THREAD_NUM;
		
#ifdef OPEN_MP
#pragma omp for schedule(dynamic)
#endif	  
	    /* Loop over source neutrons */
	  
	    for (nn = 0; nn < (long)RDB[DATA_SRC_POP]; nn++)
	      {
		/* Calculate particle index */

		idx = (long)RDB[DATA_NHIST_TOT];
		idx = idx + (long)(nb*RDB[DATA_SRC_POP]) + nn;

		/* Sample source point */

		SampleSrcPoint(id, nn, idx);

		/* Track */

		Tracking(id);
	      }
	  }

	  /* Stop parallel timer */

	  StopTimer(TIMER_OMP_PARA);

	  /* Collect data from interval */

	  CollectDynData();
	  
	  /* Reset normalization coefficients (pitää kutsua tässä) */
	  
	  WDB[DATA_NORM_COEF_N] = -1.0;
	  WDB[DATA_NORM_COEF_G] = -1.0;
	      
	  /* Check for remaining time intervals */

	  if (maxt > 1)
	    {
	      /* Fix normalization to first step */
	      
	      if ((long)RDB[DATA_NEUTRON_TRANSPORT_MODE] == YES)
		NormCoef(PARTICLE_TYPE_NEUTRON);
	      if ((long)RDB[DATA_PHOTON_TRANSPORT_MODE] == YES)
		NormCoef(PARTICLE_TYPE_GAMMA);
	      
	      /* Re-open buffer for writing */

	      WDB[DATA_BUF_REDUCED] = (double)NO;
	      
	      /* Loop over remaining time intervals */
	      
	      for (nt = 1; nt < maxt; nt++)
		{
		  /* Get data for temperature feedback */
		  
		  CollectTfb();	      
		  
		  /* Re-open buffer for writing */
		  
		  WDB[DATA_BUF_REDUCED] = (double)NO;

		  /* Handle temperature feedback */

		  IterateTFB();

		  /* Set time bin index */

		  WDB[DATA_DYN_TB] = (double)nt;

		  /* Set new time cut-off */

		  WDB[DATA_TIME_CUT_TMIN] = RDB[tme + nt];
		  WDB[DATA_TIME_CUT_TMAX] = RDB[tme + nt + 1];
		  
		  /* Normalize source */
		  
		  if (NormalizeDynSrc() < 0)
		    break;
		  
		  /* Start parallel timer */
		  
		  StartTimer(TIMER_OMP_PARA);
		  
		  /* Loop until source is empty */
		  
#ifdef OPEN_MP
#pragma omp parallel private(id)
#endif
		  {
		    /* Get Open MP thread id */
		    
		    id = OMP_THREAD_NUM;
		    
		    /* Loop over source */
		    
		    while(FromSrc(id) > VALID_PTR)
		      Tracking(id);      
		  }

		  /* Collect data from interval */

		  CollectDynData();
		  
		  /* Stop parallel timer */
		  
		  StopTimer(TIMER_OMP_PARA);
		}
	    }
	      
	  /* Get end time */

	  t0 = TimerVal(TIMER_TRANSPORT) - t0;

	  /* Score time */

	  ptr = (long)RDB[RES_CYCLE_RUNTIME];
	  AddStat(t0, ptr, 0); 
  
	  /* Collect and clear buffered results */

	  CollectResults();
	  CollectDet();
	  CollectTfb();
	  PoisonEq();
	  CalcMicroGroupXS();
	  MicroCalc();
	  ClearBuf();

	  /* Temperature feedback for next interval */
	  
	  IterateTFB();

	  /* Flush bank */

	  FlushBank();

	  /* Stop cycle-wise transport timer */

	  StopTimer(TIMER_TRANSPORT_CYCLE);
	  
	  if (TimerVal(TIMER_TRANSPORT_CYCLE) > 0.0)
	    t0 = TimerCPUVal(TIMER_TRANSPORT_CYCLE)/
	      TimerVal(TIMER_TRANSPORT_CYCLE);
	  else
	    t0 = 0.0;

	  /* CPU usage */

	  ptr = (long)RDB[RES_CPU_USAGE];
	  AddStat(t0, ptr, 0); 

	  /* Print cycle-wise output */

	  PrintCycleOutput();

	  /* Reset and restart cycle-wise transport timer */

	  ResetTimer(TIMER_TRANSPORT_CYCLE);
	  StartTimer(TIMER_TRANSPORT_CYCLE);

	  /* Sort lists */

	  SortAll();

	  /* Print results */
	  
	  if (!((nb + 1) % 10))
	    {
	      MatlabOutput();
	      DetectorOutput();
	      MeshPlotter();
	      PrintCoreDistr();
	      PrintHistoryOutput();
	      PrintPBData();
	      PrintTFBOutput();
	      PrintInterfaceOutput();
	      RROutput();
	      GeometryPlotter(NO);
	      FissMtxOutput();
	      MORAOutput();
	    }
	}

      /* Update number of neutron histories run */

      WDB[DATA_NHIST_TOT] = WDB[DATA_NHIST_TOT] +
	RDB[DATA_SRC_BATCHES]*RDB[DATA_SRC_POP];

      /* Stop cycle-wise transport timer */

      StopTimer(TIMER_TRANSPORT_CYCLE);

      /***********************************************************************/
    }
  else if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
    {
      /***********************************************************************/
      
      /***** Neutron criticality source simulation ***************************/

      /* Reset simulated batch size */
      
      WDB[DATA_SIMUL_BATCH_SIZE] = 0.0;

      /* Reset time bin index */

      WDB[DATA_DYN_TB] = 0.0;

      /* Generate initial source */

      fprintf(out, "Sampling initial source...\n");

#ifdef OPEN_MP
#pragma omp parallel private(id, idx) 
#endif
      {
	/* Get Open MP thread id */
	
	id = OMP_THREAD_NUM;
	
#ifdef OPEN_MP
#pragma omp for schedule(dynamic)
#endif	  
	/* Loop over source neutrons */
	  
	for (nn = 0; nn < (long)RDB[DATA_CRIT_POP]; nn++)
	  {
	    /* Calculate particle index */

	    idx = (long)RDB[DATA_NHIST_TOT] + nn;

	    /* Sample source point */
		
	    SampleSrcPoint(id, nn, idx);
	  }
      }

      fprintf(out, "OK.\n\n");

      /* Start cycle-wise transport timer */

      ResetTimer(TIMER_TRANSPORT_CYCLE);
      StartTimer(TIMER_TRANSPORT_CYCLE);

      /* Set number of batches */

#ifdef MPI_MODE1
      
      maxb = (long)RDB[DATA_CRIT_CYCLES];

#else

      maxb = (long)(RDB[DATA_CRIT_CYCLES]/mpitasks);

#endif

      /* Loop over batches */
      
      for (nb = 0; nb < maxb + (long)RDB[DATA_CRIT_SKIP]; nb++)
	{
	  /* Check number of skip cycles */

	  if (nb == (long)RDB[DATA_CRIT_SKIP])
	    {
	      /* Clear statistics */
	      
	      ClearStat(-1);

	      /* Start active transport timer */

	      StartTimer(TIMER_TRANSPORT_ACTIVE);

	      /* Reset number of active neutron histories */

	      WDB[DATA_NHIST_CYCLE] = 0.0;
	    }

	  /* Clear micro-group data */

	  ClearMicroGroupXS();

	  /* Put cycle index */

	  WDB[DATA_CYCLE_IDX] = (double)nb;

	  /* Normalize source */

	  NormalizeCritSrc();

	  /* Get beginning time */

	  t0 = TimerVal(TIMER_TRANSPORT);

	  /* Start parallel timer */

	  StartTimer(TIMER_OMP_PARA);

	  /* Loop until source is empty */

#ifdef OPEN_MP
#pragma omp parallel private(id)
#endif
	  {
	    /* Get Open MP thread id */

	    id = OMP_THREAD_NUM;

	    /* Loop over source */

	    while(FromSrc(id) > VALID_PTR)
	      Tracking(id);      
	  }

	  /* Stop parallel timer */

	  StopTimer(TIMER_OMP_PARA);

	  /* Get end time */

	  t0 = TimerVal(TIMER_TRANSPORT) - t0;

	  /* Score time */

	  ptr = (long)RDB[RES_CYCLE_RUNTIME];
	  AddStat(t0, ptr, 0); 

	  /* Reset normalization coefficients */

	  WDB[DATA_NORM_COEF_N] = -1.0;
	  WDB[DATA_NORM_COEF_G] = -1.0;

	  /* Add to batch counter */

	  WDB[DATA_BATCH_COUNT] = RDB[DATA_BATCH_COUNT] + 1.0;

	  /* Check batch interval */

	  if ((long)RDB[DATA_BATCH_COUNT] == (long)RDB[DATA_BATCH_INTERVAL])
	    {
	      /* Collect and clear buffered results */

	      CollectResults();
	      CalcMicroGroupXS();
	      MicroCalc();
	      B1Solver();
	      CollectDet();
	      CollectTfb();
	      PoisonEq();
	      ClearBuf();

	      /* Temperature feedback for next cycle */

	      IterateTFB();

	      /* Reset batch counter */
	      
	      WDB[DATA_BATCH_COUNT] = 0.0;
	    }

	  /* Stop cycle-wise transport timer */

	  StopTimer(TIMER_TRANSPORT_CYCLE);
	  
	  if (TimerVal(TIMER_TRANSPORT_CYCLE) > 0.0)
	    t0 = TimerCPUVal(TIMER_TRANSPORT_CYCLE)/
	      TimerVal(TIMER_TRANSPORT_CYCLE);
	  else
	    t0 = 0.0;

	  /* CPU usage */

	  ptr = (long)RDB[RES_CPU_USAGE];
	  AddStat(t0, ptr, 0); 

	  /* Print cycle-wise output */

	  PrintCycleOutput();

	  /* Reset and restart cycle-wise transport timer */

	  ResetTimer(TIMER_TRANSPORT_CYCLE);
	  StartTimer(TIMER_TRANSPORT_CYCLE);

	  /* Sort lists */

	  SortAll();

	  /* Print results */
	  
	  if (!((nb + 1) % 50))
	    {
	      MatlabOutput();
	      DetectorOutput();
	      MeshPlotter();
	      PrintCoreDistr();
	      PrintHistoryOutput();
	      PrintPBData();
	      PrintTFBOutput();
	      PrintInterfaceOutput();
	      RROutput();
	      GeometryPlotter(NO);
	      FissMtxOutput();
 	      MORAOutput();
	    }
	}

      /* Flush bank */

      FlushBank();

      /* Stop cycle-wise transport timer */

      StopTimer(TIMER_TRANSPORT_CYCLE);

      /***********************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Invalid mode");
       
  /***************************************************************************/

  /***** Transport cycle completed *******************************************/

  /* Collect results from MPI tasks */

  CollectParallelData();

  /* Put completed flag */

  WDB[DATA_SIMULATION_COMPLETED] = 1.0;

  /* Dump buffered source points into file */

  WriteSourceFile(-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1);

  /* Critical spectrum stuff */

  CalcMicroGroupXS();
  MicroCalc();
  HDMC();
  B1Solver();
  ClearMicroGroupXS();
  ClearBuf();

  /* Stop transport timers */

  StopTimer(TIMER_TRANSPORT);
  StopTimer(TIMER_TRANSPORT_TOTAL);

  if (((long)RDB[DATA_CRIT_CYCLES] > 0) || ((long)RDB[DATA_SRC_BATCHES] > 0))
    StopTimer(TIMER_TRANSPORT_ACTIVE);

  /* Remember previous value */

  if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    WDB[DATA_PRED_TRANSPORT_TIME] = TimerVal(TIMER_TRANSPORT);
  else
    WDB[DATA_CORR_TRANSPORT_TIME] = TimerVal(TIMER_TRANSPORT);

  /* Put keff for burnup iteration */

  if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == YES)
    ptr = (long)RDB[RES_IMP_KEFF];
  else
    ptr = (long)RDB[RES_COL_KEFF];  

  WDB[DATA_BURN_PREV_KEFF] = Mean(ptr, 0);
  WDB[DATA_BURN_PREV_DKEFF] = StdDev(ptr, 0);

  /* Put poison concentrations */

  PutPoisonConc();

  /* Calculate activities */

  CalculateActivities();

  /* Store simulator output data */

  StoreSimData();

  /* Print output */

  MatlabOutput();
  DetectorOutput();
  MeshPlotter();
  PrintCoreDistr();
  PrintHistoryOutput();
  PrintPBData();
  PrintTFBOutput();
  PrintInterfaceOutput();
  RROutput();
  GeometryPlotter(NO);
  FissMtxOutput();
  MORAOutput();
  CAXOutput();
  /*
  ARESOutput();
  */



  /***************************************************************************/
}

/*****************************************************************************/
