/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : findnestregion.c                               */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2013/04/03 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Finds nest region based on coordinates                       */
/*                                                                           */
/* Comments: - Ton edellisen alueen testaamisen hyöty on vähän kyseenalainen */
/*             kun nää alueet on kuitenkin yleensä suht pieniä verrattuna    */
/*             mfp.                                                          */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FindNestRegion:"

/*****************************************************************************/

long FindNestRegion(long uni0, long nst, double x, double y, double z, long id)
{
  long ptr, n, reg, surf;
  double r2;
  
  /* Check pointers */

  CheckPointer(FUNCTION_NAME, "(uni0)", DATA_ARRAY, uni0);
  CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

  /***************************************************************************/

  /***** Fuel performance interface ******************************************/

  if ((ptr = (long)RDB[uni0 + UNIVERSE_PTR_IFC_FUEP]) > VALID_PTR)
    {
      /* Loop over axial zones */

      ptr = (long)RDB[ptr + IFC_FUEP_PTR_AX];
      while (ptr > VALID_PTR)
	{
	  /* Compare coordinates */

	  if ((z >= RDB[ptr + IFC_FUEP_AX_ZMIN]) &&
	      (z < RDB[ptr + IFC_FUEP_AX_ZMAX]))
	    break;

	  /* Next */

	  ptr = NextItem(ptr);
	}

      /* Check pointer */

      if (ptr > VALID_PTR)
	{
	  /* Calculate square radius */

	  r2 = x*x + y*y;

	  /* Loop over radial zones */
      
	  ptr = (long)RDB[ptr + IFC_FUEP_AX_PTR_RAD];
	  while (ptr > VALID_PTR)
	    {
	      /* Compare radii */
	      
	      if (r2 < RDB[ptr + IFC_FUEP_RAD_HOT_R2])
		{
		  /* Get pointer to region */

		  reg = (long)RDB[ptr + IFC_FUEP_RAD_PTR_REG];
		  CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

		  /* Return pointer */

		  return reg;
		}

	      /* Next region */

	      ptr = NextItem(ptr);
	    }
	}
    }

  /***************************************************************************/

  /***** Regular nest ********************************************************/

  /* Check previous */

  ptr = RDB[uni0 + UNIVERSE_PTR_PREV_REG];
  if ((reg = GetPrivateData(ptr, id)) > VALID_PTR)
    {
      /* Get pointer to first surface */

      if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_IN]) > VALID_PTR)
	{
	  /* Test surface */

	  if (TestSurface(surf, x, y, z, NO, id) == YES)
	    {
	      /* Get pointer to second surface */

	      if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_OUT]) > VALID_PTR)
		{
		  /* Test surface */
		  
		  if (TestSurface(surf, x, y, z, NO, id) == NO)
		    return reg;
		}
	      else
		{
		  /* Innermost region, point is in */

		  return reg;
		}
	    }
	}
    }
	
  /* Get pointer to regions */
	      
  ptr = (long)RDB[nst + NEST_PTR_REGIONS];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  
  /* Loop over regions */ 

  n = 0;
  while ((reg = ListPtr(ptr, n++)) > VALID_PTR)
    {
      /* Get pointer to surface */

      if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_IN]) < VALID_PTR)
	{
	  /* Put previous pointer */

	  ptr = RDB[uni0 + UNIVERSE_PTR_PREV_REG];
	  PutPrivateData(ptr, reg, id);

	  /* Return region */

	  return reg;
	}

      /* Test surface */

      if (TestSurface(surf, x, y, z, NO, id) == YES)
	{
	  /* Put previous pointer */
	  
	  ptr = RDB[uni0 + UNIVERSE_PTR_PREV_REG];
	  PutPrivateData(ptr, reg, id);
	  
	  /* Return region */

	  return reg;
	}
    }

  /***************************************************************************/

  /* Something wrong */

  Die(FUNCTION_NAME, "Unable to find nest region");

  /* Avoid warning message */

  return 0;
}

/*****************************************************************************/
