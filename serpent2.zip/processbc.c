/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : Processbc.c                                    */
/*                                                                           */
/* Created:       2013/03/07 (JLe)                                           */
/* Last modified: 2013/03/22 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Finds outermost geometry boundary for repeated boundary      */
/*              conditions                                                   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessBC:"

/*****************************************************************************/

void ProcessBC()
{
  long uni, type, loc0, loc1, nst, reg, surf, cell;

  /* Get pointer to root universe */

  uni = (long)RDB[DATA_PTR_ROOT_UNIVERSE];
  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

  /* Reset surface pointer */

  surf = -1;

  /* Get universe type */

  type = (long)RDB[uni + UNIVERSE_TYPE];    

  /* Get pointer to surfaces */

  if (type == UNIVERSE_TYPE_NEST)
    {
      /* Pointer to nest */

      nst = (long)RDB[uni + UNIVERSE_PTR_NEST];
      CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);

      /* Pointer to region */

      reg = (long)RDB[nst + NEST_PTR_REGIONS];
      CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

      /* Loop until outermost */

      while (reg > VALID_PTR)
	{
	  if (NextItem(reg) < VALID_PTR)
	    break;
	  else
	    reg = NextItem(reg);
	}

      /* Pointer to surface */

      surf = (long)RDB[reg + NEST_REG_PTR_SURF_OUT];
      CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);
    }
  else if (type == UNIVERSE_TYPE_CELL)
    {
      /* Pointer to cell list */

      loc0 = (long)RDB[uni + UNIVERSE_PTR_CELL_LIST];
      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);  

      /* Loop over cells */

      while (loc0 > VALID_PTR)
	{
	  /* Pointer to cell */

	  cell = (long)RDB[loc0 + CELL_LIST_PTR_CELL];
	  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);  

	  /* Check type */

	  if ((long)RDB[cell + CELL_TYPE] == CELL_TYPE_OUTSIDE)
	    {
	      /* Pointer to surface list */

	      loc1 = (long)RDB[cell + CELL_PTR_SURF_LIST];
	      CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

	      /* Loop over surfaces */

	      while ((surf = (long)RDB[loc1++] ) > VALID_PTR)
		{
		  /* Get surface type */

		  type = (long)RDB[surf + SURFACE_TYPE];

		  /* Check allowed types */

		  if (type == SURF_SQC)
		    break;
		  else if ((type == SURF_CUBE) || (type == SURF_CUBOID))
		    break;
		  else if ((type == SURF_HEXYC) || (type == SURF_HEXXC))
		    break;
		  else if ((type == SURF_HEXYPRISM) || (type == SURF_HEXXPRISM))
		    break;
		}

	      /* Break second loop if found */

	      if (surf > VALID_PTR)
		break;
	    }

	  /* Next cell */

	  loc0 = NextItem(loc0);
	}
    }
  else
    Die(FUNCTION_NAME, "Invalid root universe type");

  /* Check surface and boundary conditions */

  if ((surf < VALID_PTR) && 
      (((long)RDB[DATA_GEOM_BC1] != BC_BLACK) ||
       ((long)RDB[DATA_GEOM_BC2] != BC_BLACK) ||
       ((long)RDB[DATA_GEOM_BC3] != BC_BLACK)))
    Error(0, "Invalid outer boundary for repeated boundary conditions");

  /* Put pointer */

  WDB[DATA_PTR_BC_SURF] = (double)surf;
}

/*****************************************************************************/
