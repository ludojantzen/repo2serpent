/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : tracking.c                                     */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2013/04/03 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Main tracking loop for single particle and secondaries       */
/*                                                                           */
/* Comments: - Fission neutrons are treated as secondaries in external       */
/*             source mode. In criticality source mode they form the         */
/*             source distribution for the next generation.                  */
/*                                                                           */
/*           - Completely revised 3.10.2012 / 2.1.9                          */
/*                                                                           */
/*           - Density factorin käsittelyä on muutettu niin että se on nyt   */
/*             pelkkä rejektio siinä vaiheessa kun arvotaan että mennäänkö   */
/*             törmäykseen vai ei. Vuo otetaan kuitenkin täyden tiheyden     */
/*             vaikutusalasta. Näyttää siltä että makroskooppiset reaktio-   */
/*             nopeudet saattaa mennä tolla tavalla ihan tsägällä oikein,    */
/*             lukuunottamatta niitä rutiineja joissa kutsutaan MacroXS():ää */
/*             kokonaisvaikutusalalle.                                       */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Tracking:"

#define MAX_TRACK_LOOP 1000000

/*****************************************************************************/

void Tracking(long id)
{
  long part, cell, mat, type, loop, ptr, trk, mode, bc;
  double x, y, z, u, v, w, E, wgt, l, totxs, majorant, minxs, xs;
  double spd, t, dt, g, x0, y0, z0, t0;

  /* Add to OpenMP history counter (onko tää vähän turha?, tää menee */
  /* pieleen dynamic criticality source moodissa) */

  ptr = (long)RDB[DATA_PTR_OMP_HISTORY_COUNT];
  AddPrivateData(ptr, 1.0, id);

  /* Main loop over particle history and secondaries */

  while ((part = FromQue(id)) > VALID_PTR)
    {          
      /***********************************************************************/
      
      /***** Start history ***************************************************/

      /* Check MPI index (this is for reproducible MPI mode) */

      if ((long)RDB[part + PARTICLE_MPI_ID] != mpiid)
	{
	  /* Check reproducibility */

	  if ((long)RDB[DATA_OPTI_MPI_REPRODUCIBILITY] == NO)
	    Die(FUNCTION_NAME, "Error in mpi mode");

	  /* Put particle back in stack */
	      
	  ToStack(part, id);

	  /* Return */

	  return;
	}

      /* Check generation cut-off */

      if ((long)RDB[part + PARTICLE_GEN_IDX] >= (long)RDB[DATA_GEN_CUT])
	{
	  /* Put particle back in stack */
	      
	  ToStack(part, id);

	  /* Break loop */

	  continue;
	}

      /* Get particle type */

      type = (long)RDB[part + PARTICLE_TYPE];    

      /* Get spatial coordinates */

      x = RDB[part + PARTICLE_X];
      y = RDB[part + PARTICLE_Y];
      z = RDB[part + PARTICLE_Z];

      /* Get direction cosines */

      u = RDB[part + PARTICLE_U];
      v = RDB[part + PARTICLE_V];
      w = RDB[part + PARTICLE_W];
      
      /* Get energy, weight and time */

      E = RDB[part + PARTICLE_E];
      wgt = RDB[part + PARTICLE_WGT];
      t = RDB[part + PARTICLE_T];

      /* Remember initial time */

      t0 = t;

      /* Check with cut-off */

      if ((t0 < RDB[DATA_TIME_CUT_TMIN]) || (t0 >= RDB[DATA_TIME_CUT_TMAX]))
	Die(FUNCTION_NAME, "Error in time (%1.2E : %1.2E %1.2E)",
	    t0, RDB[DATA_TIME_CUT_TMIN], RDB[DATA_TIME_CUT_TMAX]);

      /* Store point for track plotter */

      AddTrackPt(x, y, z, part, TRACK_END_STRT);

      /* Find initial location */
	      
      cell = WhereAmI(x, y, z, u, v, w, id);
      CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

      /* Get material pointer */

      mat = (long)RDB[cell + CELL_PTR_MAT];
      mat = MatPtr(mat, id);

      /* Store starting point in history array */
      
      StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E, t, wgt, -1.0, 
			TRACK_END_STRT);

      /***********************************************************************/

      /***** Tracking loop ***************************************************/
    
      for (loop = 0; loop < MAX_TRACK_LOOP; loop++)
	{
	  /* Calculate speed */

	  spd = Speed(type, E);

	  /* Get minimum cross section */

	  minxs = MinXS(type, spd, id);

	  /* Add to track counter */

	  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
	  AddPrivateData(ptr, 1.0, id);

	  /* Get total cross section and majorant */

	  totxs = TotXS(mat, type, E, id);
	  majorant = DTMajorant(type, E, id);

	  /* Compare majorant to minimum */

	  if (majorant < minxs)
	    majorant = minxs;

	  /* Check cross sections */	      

	  CheckValue(FUNCTION_NAME, "majorant", "", majorant, ZERO, INFTY);
	  CheckValue(FUNCTION_NAME, "minxs", "", minxs, ZERO, INFTY);
	  CheckValue(FUNCTION_NAME, "totxs", "", totxs, 0.0, INFTY);

	  /* Store previous coordinates */

	  x0 = x;
	  y0 = y;
	  z0 = z;

	  /* Avoid compiler warning */

	  trk = -1;
	  cell = -1;

	  /* Get tracking mode and move particle forward */
	  
	  mode = TrackMode(part, mat, totxs, majorant, type);

	  if (mode == TRACK_MODE_DT)
	    {
	      /* Use delta-tracking */
	      
	      trk = MoveDT(part, majorant, minxs, &cell, &xs, &x, &y, &z, &l,
			   u, v, w, E, id);
	    }
	  else if (mode == TRACK_MODE_ST)
	    {
	      /* Use surface-tracking */
	      
	      trk = MoveST(part, totxs, minxs, &cell, &xs, &x, &y, &z, &l,
			   u, v, w, id);
	    }
	  else
	    Die(FUNCTION_NAME, "Invalid tracking mode");

	  /* Calculate change in time (suhtis?) */

	  dt = l/spd;
	  
	  /* Do time cut-off */
	
	  trk = TimeCutoff(trk, part, &cell, &dt, &l, &x, &y, &z, u, v, w, E, 
			   t, wgt, spd, xs, mode, id);
	
	  /* Update time */

	  t = t + dt;

	  /* Check cell pointer */

	  if (cell < VALID_PTR)
	    Die(FUNCTION_NAME, "Particle lost");

	  /* Get material pointer */

	  mat = (long)RDB[cell + CELL_PTR_MAT];
	  mat = MatPtr(mat, id);

	  /* Score super-imposed detectors */

	  SuperDet(part, x0, y0, z0, u, v, w, l, E, t, wgt, id);
	  
	  /* Score discontinuity factors */

	  ScoreDF(x0, y0, z0, u, v, w, l, E, wgt, id);

	  /* Check track type */

	  if (trk == TRACK_END_VIRT)
	    {
	      /***************************************************************/

	      /***** Virtual collision ***************************************/

	      /* Weight adjustment in alpha-eigenvalue mode */

	      Alpha(E, majorant, &wgt);

	      /* Score collision (NOTE: Cross section is set to -1 if the */
	      /* collision is not to be scored) */

	      if (xs > 0.0)
		{
		  /* Get density factor */
		  
		  g = DensityFactor(mat, x, y, z, t, id);
		  CheckValue(FUNCTION_NAME, "g", "", g, 0.0, 1.0);

		  /* Store point in history array */

		  StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E, 
				    t, wgt, -1.0, trk);

		  /* Score collision */

		  Score(mat, part, 1.0/xs, x, y, z, u, v, w, E, wgt, t, 
			spd, g, id);
		}

	      /**************************************************************/
	    }
	  else if (trk == TRACK_END_COLL)
	    {
	      /***************************************************************/

	      /***** Physical collision **************************************/

	      /* Weight adjustment in alpha-eigenvalue mode */

	      Alpha(E, majorant, &wgt);

	      /* Check material pointer */

	      CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

	      /* Get density factor */
	      
	      g = DensityFactor(mat, x, y, z, t, id);
	      CheckValue(FUNCTION_NAME, "g", "", g, 0.0, 1.0);
	      	      
	      /* Score collision */

	      Score(mat, part, 1.0/xs, x, y, z, u, v, w, E, wgt, t, spd, 
		    g, id);

	      /* Additional rejection by density factor */

	      if (RandF(id) < g)
		{
		  /* Sample collision */
		  
		  trk = Collision(mat, part, x, y, z, &u, &v, &w, &E, 
				  &wgt, t, id);

		  /* Store point for track plotter */
		  
		  AddTrackPt(x, y, z, part, trk);
		}
	      else
		{
		  /* Virtual collision, change track type */

		  trk = TRACK_END_VIRT;
		}

	      /* Store point in history array */
	      
	      StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E,
				t, wgt, -1.0, trk);
	      
	      /* Score efficiency of ifc collision rejection */
	      
	      if ((long)RDB[mat + MATERIAL_USE_IFC] == YES)
		{
		  ptr = (long)RDB[RES_IFC_COL_EFF];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddBuf(g, 1.0, ptr, id, 2 - type);
		}
	      
	      /* Score total collision effiency */

	      if (trk != TRACK_END_VIRT)
		{
		  ptr = (long)RDB[RES_TOT_COL_EFF];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  AddBuf(g, 1.0, ptr, id, 2 - type);
		}	      

	      /* Check termination */

	      if ((trk == TRACK_END_CAPT) || (trk == TRACK_END_FISS) ||
		  (trk == TRACK_END_ECUT) || (trk == TRACK_END_WCUT))
		break;

	      /***************************************************************/
	    }
	  else if (trk == TRACK_END_SURF)
	    {
	      /***************************************************************/

	      /***** Surface crossing ****************************************/

	      /* Score surface crossing */
	      
	      ptr = (long)RDB[RES_AVG_SURF_CROSS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddBuf(1.0, 1.0, ptr, id, 2 - type);	      

	      /* Store first point in history array */

	      StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E,
				t, wgt, -1.0, trk);
	      
	      /* Store point for track plotter */
	      
	      AddTrackPt(x, y, z, part, trk);
		
	      /* Apply boundary conditions */

	      bc = BoundaryConditions(&cell, &x, &y, &z, &u, &v, &w, E,
				      &wgt, id);

	      /* Check cell pointer */

	      if (cell < VALID_PTR)
		Die(FUNCTION_NAME, "Particle lost");

	      /* Check leakage and repeated */

	      if (bc < 0)
		{
		  /* Score leakage */

		  Leak(part, x, y, z, u, v, w, E, wgt, id);
		  
		  /* Set track type to leak */

		  trk = TRACK_END_LEAK;

		  /* Store point for track plotter */
	      
		  AddTrackPt(x, y, z, part, trk);

		  /* Break loop */

		  break;
		}
	      else if (bc == YES)
		{	     
		  /* Get material pointer */

		  mat = (long)RDB[cell + CELL_PTR_MAT];
		  mat = MatPtr(mat, id);

		  /* Store second point in history array */

		  StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E, 
				    t, wgt, -1.0, trk);

		  /* Store point for track plotter */
	      
		  AddTrackPt(x, y, z, part, -trk);
 		}

	      /***************************************************************/
	    }
	  else if (trk == TRACK_END_TCUT)
	    {
	      /***************************************************************/

	      /***** Time cut-off ********************************************/

	      /* Store point for track plotter */
	      
	      AddTrackPt(x, y, z, part, trk);

	      /* Break loop */
	      
	      break;

	      /***************************************************************/
	    }
	  else 
	    Die(FUNCTION_NAME, "Invalid track type %ld", trk);

	  /* Check track type */

	  if (trk == TRACK_END_VIRT)
	    {
	      /* Score total collision efficency */
	      
	      ptr = (long)RDB[RES_TOT_COL_EFF];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddBuf(1.0, 1.0, ptr, id, 4 - type);	      
	    }
	  else if ((trk != TRACK_END_SCAT) && (trk != TRACK_END_SURF))
	    Die(FUNCTION_NAME, "Loop not terminated by track type %ld", trk);
	}

      /***********************************************************************/
     
      /***** History terminated **********************************************/
 
      /* Check for infinite loop */

      if (loop == MAX_TRACK_LOOP)
	Die(FUNCTION_NAME, "Infinite tracking loop");

      /* Score time constants (kato toi) */

      ScoreTimeConstants(t, wgt, part, trk, id);
      
      /* Store point in history array */

      StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E, t, wgt, -1.0, trk);

      /***********************************************************************/
    }
}

/*****************************************************************************/
