/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : main.c                                         */
/*                                                                           */
/* Created:       2010/11/22 (JLe)                                           */
/* Last modified: 2013/04/08 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Main program file                                            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Main:"

/*****************************************************************************/

int main(int argc, char** argv)
{
  long ptr;
  char str[MAX_STR];

  /* Start runtime and init timers */

  StartTimer(TIMER_RUNTIME);
  StartTimer(TIMER_INIT);

  /* Initialise MPI */

  InitMPI(argc, argv);

  /* Init main data block */
  
  InitData();

  /***************************************************************************/

  /***** Initial processing before MPI parallelization ***********************/

  /* Check MPI id number */

  if (mpiid == 0)
    {
      /* Get system stat */
      
      SystemStat();
   
      /* Process command line */
      
      if (ParseCommandLine(argc, argv) < 0)
	return 0;

      /* Init OpenMP related stuff */

      InitOMP();

      /* Check particle disperser mode */

      if ((long)RDB[DATA_PARTICLE_DISPERSER_MODE] == YES)
	{
	  /* Run disperse subroutine */

	  Disperse();

	  /* Free memory */

	  FreeMem();

	  /* Exit */

	  exit(-1);
	}

      /* Remove warning message file */
      
      sprintf(str, "%s.wrn", GetText(DATA_PTR_INPUT_FNAME));
      remove(str);
      
      /* print title */

      PrintTitle();
      
      fprintf(out, "Begin calculation on %s\n\n", GetText(DATA_PTR_DATE));

      /* Read input */
      
      ReadInput(GetText(DATA_PTR_INPUT_FNAME));
      fprintf(out, "\n");

      /* Reset burnup mode if no burnable materials are defined */
      
      if ((long)RDB[DATA_BURN_MATERIALS_FLAG] == NO)
	WDB[DATA_BURNUP_CALCULATION_MODE] = (double)NO;

      /* Process time binnings */

      ProcessTimeBins();

      /* Check duplicate input definitions */

      CheckDuplicates();

      /* Read multi-physics inteface */

      ReadInterface();

      /* Read pebble bed geometries */

      ReadPBGeometry();

      /* Process depletion history (voidaan kutsua jo tässä) */

      ProcessDepHis();

      /* Set optimization */

      SetOptimization();

      /* Initialize secondary RNG */
      
      srand48(parent_seed);

      /* Update memory size */

      WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

      /* Process burnup material divisors */

      ProcessDivisors();

      /* Divide burnable zones */

      DivideBurnMat();

      /* Update memory size */

      WDB[DATA_TOT_MAT_BYTES] = WDB[DATA_TOT_MAT_BYTES] + MemCount();

      /* Process stochastic geometries */

      ProcessPBGeometry();

      /* Create universes in geometry */

      CreateGeometry();

      /* Process reprocessors */

      ProcessReprocessors();

      /* Count number of zones */

      ZoneCount(-1, -1, 0);

      /* Process universe transformations */

      ProcessTransformations();

      /* Process universe symmetries */

      ProcessSymmetries();

      /* Check and remove unused stuff */

      CheckUnused();

      /* Process cells */

      ProcessCells();

      /* Process nests */
      
      ProcessNests();

      /* Set material pointers */
      
      FindMaterialPointers();

      /* Process boundary conditions */

      ProcessBC();

      /* Update memory size */

      WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

      /* Make depletion zones */

      MakeDepletionZones(-1, -1, 0, 0, 0);

      /* Update memory size */

      WDB[DATA_TOT_MAT_BYTES] = WDB[DATA_TOT_MAT_BYTES] + MemCount();

      /* Process sources, energy grids and detectors (must be done before */
      /* unused cells and materials are removed) */

      ProcessSources();
      ProcessUserEGrids();

      /* Update memory size */

      WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

      /* Process detectors */

      ProcessDetectors();

      /* Update memory size */

      WDB[DATA_TOT_RES_BYTES] = WDB[DATA_TOT_RES_BYTES] + MemCount();
      
      /* Remove unused materials */
      
      ptr = (long)RDB[DATA_PTR_M0];
      RemoveFlaggedItems(ptr, MATERIAL_OPTIONS, OPT_USED, NO);

      /* Process lattices */

      ProcessLattices();

      /* Find universe boundaries */

      UniverseBoundaries();
      
      /* Calculate nest volumes */

      NestVolumes();
      
      /* Calculate cell volumes */

      CellVolumes();

      /* Count number of cells */

      CellCount(-1, -1, 0, 1);

      /* Calculate material volumes */

      MaterialVolumes();

      /* Print geometry data to output file */

      PrintGeometryData();

      /* Update memory size */

      WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();
      
      /* Process core power distributions */

      ProcessCPD();

      /* Process statistics */

      ProcessStats();

      /* Process entropy stuff */

      ProcessEntropy();

      /* Process GC stuff */

      ProcessGC();

      /* Remove unused surfaces (poistaa nyt kaikki) */

      ptr = (long)RDB[DATA_PTR_S0];
      RemoveFlaggedItems(ptr, SURFACE_OPTIONS, OPT_USED, NO);

      /* Update memory size */

      WDB[DATA_TOT_RES_BYTES] = WDB[DATA_TOT_RES_BYTES] + MemCount();

      /* Process temperature feedbacks */

      ProcessTFB();

      /* Process multi-physics interfaces */

      ProcessInterface();

      /* Monte Carlo volume calculator */

      VolumesMC();

      /* Break if command-line volume MC mode */

      if ((long)RDB[DATA_VOLUME_CALCULATION_MODE] == YES)
	return -1;

      /* Plot geometry */
      
      GeometryPlotter(YES);

      /* Update memory size */

      WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

      /* Process nuclides */
      
      ProcessNuclides();

      /* Update memory size */

      WDB[DATA_TOT_XS_BYTES] = WDB[DATA_TOT_XS_BYTES] + MemCount();

      /* Process inventory list */
      
      ProcessInventory();

      /* Update memory size */

      WDB[DATA_TOT_RES_BYTES] = WDB[DATA_TOT_RES_BYTES] + MemCount();
    }

  /***************************************************************************/

  /**** MPI parallel part ****************************************************/

  /* Distribute data to parallel MPI tasks */

  ShareInputData();

  /* Update memory size */

  WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

  /* Process energy grids */

  UnionizeGrid();

  /* Process XS data */

  ProcessXSData();
  SABDataTester();

  /* Generate cache-optimized block */

  CacheXS();

  /* Update memory size */

  WDB[DATA_TOT_XS_BYTES] = WDB[DATA_TOT_XS_BYTES] + MemCount();

  /* Process mesh plots */

  ProcessMeshPlots();

  /* Update memory size */

  WDB[DATA_TOT_RES_BYTES] = WDB[DATA_TOT_RES_BYTES] + MemCount();

  /* Process variance reduction stuff */

  ProcessVR();

  /* Update memory size */

  WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

  /* Process materials */

  ProcessMaterials();

  /* Update memory size */

  WDB[DATA_TOT_MAT_BYTES] = WDB[DATA_TOT_MAT_BYTES] + MemCount();

  /* Link reactions to sources and detectors */

  LinkReactions();

  /* Allocate memory for interface statistics */

  AllocInterfaceStat();

  /* Update memory size */

  WDB[DATA_TOT_MISC_BYTES] = WDB[DATA_TOT_MISC_BYTES] + MemCount();

  /* Process fission matrixes */

  ProcessFissMtx();

  /* Update memory size */

  WDB[DATA_TOT_RES_BYTES] = WDB[DATA_TOT_RES_BYTES] + MemCount();

  /* Init particle structures */

  InitHistories();

  /* Disallow memory allocation from here on*/

  Mem(MEM_DENY);

  /* Check if calculation should proceed */

  if (((long)RDB[DATA_NEUTRON_TRANSPORT_MODE] == YES) ||
      ((long)RDB[DATA_PHOTON_TRANSPORT_MODE] == YES) ||
      ((long)RDB[DATA_BURNUP_CALCULATION_MODE] == YES))
    {
      /* Stop init timer */
      
      StopTimer(TIMER_INIT);
      
      /* Check mode and start calculation */

      if ((long)RDB[DATA_PTR_RIA0] > VALID_PTR)
	{
	  /* RIA simulation */

	  RIACycle();
	}
      else if ((long)RDB[DATA_BURNUP_CALCULATION_MODE] == YES)
	{
	  /* Internal burnup mode, go to burnup cycle */

	  BurnupCycle();
	  /*
	  UCBBurnupCycle();
	  */
	}
      else
	{
	  /* Single transport cycle */
	  
	  PrepareTransportCycle();
	  TransportCycle();
	}
    }

  /* Free memory */
      
  FreeMem();

  /* Finalize MPI */

  FinalizeMPI();
  
  /* Exit */
  
  return 0;
}

/*****************************************************************************/

