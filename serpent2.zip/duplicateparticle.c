/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : duplicateparticle.c                            */
/*                                                                           */
/* Created:       2011/03/09 (JLe)                                           */
/* Last modified: 2013/04/19 (JLe)                                           */
/* Version:       2.1.14                                                     */
/*                                                                           */
/* Description: Duplicates particle                                          */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DuplicateParticle:"

/*****************************************************************************/

long DuplicateParticle(long ptr, long id)
{
  long new, hst0, hst1, prg0, prg1;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get particle from stack */

  new = FromStack((long)RDB[ptr + PARTICLE_TYPE], id);

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(new)", DATA_ARRAY, new);

  /* Get history pointers */

  hst0 = (long)RDB[ptr + PARTICLE_PTR_HIST];
  hst1 = (long)RDB[new + PARTICLE_PTR_HIST];

  /* Gett fission progeny pointers */

  prg0 = (long)RDB[ptr + PARTICLE_PTR_FISS_PROG];
  prg1 = (long)RDB[new + PARTICLE_PTR_FISS_PROG];

  /* Copy data */

  memcpy(&WDB[new + LIST_DATA_SIZE], &RDB[ptr + LIST_DATA_SIZE],
	 (PARTICLE_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

  /* Restore pointers */
  
  WDB[new + PARTICLE_PTR_HIST] = (double)hst1;
  WDB[new + PARTICLE_PTR_FISS_PROG] = (double)prg1;

  /* Copy fission progeny data */

  while (prg0 > VALID_PTR)
    {
      /* Check second pointer */
      
      CheckPointer(FUNCTION_NAME, "(prg1)", DATA_ARRAY, prg1);

      /* Copy data */

      memcpy(&WDB[prg1 + LIST_DATA_SIZE], &RDB[prg0 + LIST_DATA_SIZE],
	     (FISS_PROG_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

      /* Pointers to next */

      prg0 = NextItem(prg0);
      prg1 = NextItem(prg1);
    }
  
  /* Check history pointer */

  if (hst0 > VALID_PTR)
    {
      /* Check second pointer */
      
      CheckPointer(FUNCTION_NAME, "(hst1)", DATA_ARRAY, hst1);

      /* Loop over data */

      do
	{
	  /* Check second pointer */

	  CheckPointer(FUNCTION_NAME, "(hst1)", DATA_ARRAY, hst1);

	  /* Copy data */

	  memcpy(&WDB[hst1 + LIST_DATA_SIZE], &RDB[hst0 + LIST_DATA_SIZE],
		 (HIST_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

	  /* Pointers to previous */

	  hst0 = PrevItem(hst0);
	  hst1 = PrevItem(hst1);
	}
      while (hst0 != (long)RDB[ptr + PARTICLE_PTR_HIST]);
    }

  /* Return pointer */
  
  return new;
}

/*****************************************************************************/
