/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : writedepfile.c                                 */
/*                                                                           */
/* Created:       2011/05/24 (JLe)                                           */
/* Last modified: 2013/02/01 (JLe)                                           */
/* Version:       2.1.12                                                     */
/*                                                                           */
/* Description: Writes binary file containing data from burnup calculation   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "WriteDepFile:"

/*****************************************************************************/

void WriteDepFile()
{
  long nuc, mat, nnuc, nmat, iso, n, m, count;
  char tmpstr[MAX_STR];
  double adens, val;
  FILE *fp;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* File name */

  sprintf(tmpstr, "%s.dep", GetText(DATA_PTR_INPUT_FNAME));

  /* Open file for writing */

  if ((long)RDB[DATA_BURN_STEP] == 0)
    fp = fopen(tmpstr, "w");
  else
    fp = fopen(tmpstr, "a");

  /* Check pointer */

  if (fp == NULL)
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /* Get number of nuclides */
      
  nnuc = (long)RDB[DATA_TOT_NUCLIDES];

  /* Calculate number of materials */

  nmat = 0;

  mat = (long)RDB[DATA_PTR_M0];
  while(mat > VALID_PTR)
    {
      /* Check output flag */

      if ((long)RDB[mat + MATERIAL_BURN_PRINT_OUTPUT] == YES)
	nmat++;
      
      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Check first step */
  
  if ((long)RDB[DATA_BURN_STEP] == 0)
    {
      /***** Nuclide data ****************************************************/

      /* Write number of materials */
  
      fwrite(&nmat, sizeof(long), 1, fp);

      /* Write number of nuclides */
  
      fwrite(&nnuc, sizeof(long), 1, fp);

      /* Loop over nuclides */

      nuc = (long)RDB[DATA_PTR_NUC0];
      while (nuc > VALID_PTR)
	{
	  /* Write ZAI */

	  n = (long)RDB[nuc + NUCLIDE_ZAI];
	  fwrite(&n, sizeof(long), 1, fp);

	  /* Write Z */

	  n = (long)RDB[nuc + NUCLIDE_Z];
	  fwrite(&n, sizeof(long), 1, fp);

	  /* Write atomic weight */

	  val = RDB[nuc + NUCLIDE_AW];
	  fwrite(&val, sizeof(double), 1, fp);

	  /* Decay constant */

	  val = RDB[nuc + NUCLIDE_LAMBDA];
	  fwrite(&val, sizeof(double), 1, fp);

	  /* Decay heat */

	  val = RDB[nuc + NUCLIDE_DECAY_E]*RDB[nuc + NUCLIDE_LAMBDA];
	  fwrite(&val, sizeof(double), 1, fp);

	  /* Spontaneous fission rate */

	  val = RDB[nuc + NUCLIDE_SFBR]*RDB[nuc + NUCLIDE_LAMBDA];
	  fwrite(&val, sizeof(double), 1, fp);

	  /* Specific ingestion toxicity */

	  if ((val = RDB[nuc + NUCLIDE_SPEC_ING_TOX]) < 0.0)
	    val = 0.0;
	    
	  fwrite(&val, sizeof(double), 1, fp);

	  /* Specific inhalation toxicity */

	  if ((val = RDB[nuc + NUCLIDE_SPEC_INH_TOX]) < 0.0)
	    val = 0.0;

	  fwrite(&val, sizeof(double), 1, fp);
	  
	  /* Next nuclide */

	  nuc = NextItem(nuc);
	}

      /***********************************************************************/
    }

  /***************************************************************************/
  
  /***** Reset some nuclide-wise quantities **********************************/

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR )
    {    
      WDB[nuc + NUCLIDE_TOT_MASS] = 0.0;
      WDB[nuc + NUCLIDE_TOT_ACTIVITY] = 0.0;
      WDB[nuc + NUCLIDE_TOT_SF] = 0.0;
      WDB[nuc + NUCLIDE_TOT_DECAY_HEAT] = 0.0;
      WDB[nuc + NUCLIDE_TOT_ING_TOX] = 0.0;
      WDB[nuc + NUCLIDE_TOT_INH_TOX] = 0.0;

      /* Next */
      
      nuc = NextItem(nuc); 
    }

  /***************************************************************************/

  /***** Material-wise data **************************************************/
  
  /* Reset index */

  m = 0;

  mat = (long)RDB[DATA_PTR_M0];
  while(mat > VALID_PTR)
    {
      /* Check output flag */

      if ((long)RDB[mat + MATERIAL_BURN_PRINT_OUTPUT] == NO)
	{
	  /* Next material */

	  mat = NextItem(mat);
	  
	  /* Cycle loop */

	  continue;
	}

      /* Calculate number of nuclides */

      count = 0;

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Get atomic density */

	  adens = RDB[iso + COMPOSITION_ADENS];
	  CheckValue(FUNCTION_NAME, "adens", "", adens, 0.0, INFTY);

	  /* Check that value is non-zero */
	  
	  if (adens > ZERO)
	    count++;
	  
	  /* Next nuclide in composition */

	  iso = NextItem(iso);
	}

      /* Write burnup (nää vie tilaa mutta yksinkertaistaa lukemista) */
      
      val = RDB[DATA_BURN_CUM_BURNUP];
      fwrite(&val, sizeof(double), 1, fp);

      val = RDB[DATA_BURN_CUM_REAL_BURNUP];
      fwrite(&val, sizeof(double), 1, fp);
      
      /* Write burn time */
      
      val = RDB[DATA_BURN_CUM_BURNTIME]/24.0/60.0/60.0;
      fwrite(&val, sizeof(double), 1, fp);

      /* Write number of nuclides */

      fwrite(&count, sizeof(long), 1, fp);

      /* Write material volume */

      val = RDB[mat + MATERIAL_VOLUME];
      fwrite(&val, sizeof(double), 1, fp);

      /* Write material burnup */

      val = RDB[mat + MATERIAL_BURNUP];
      fwrite(&val, sizeof(double), 1, fp);

      /* Write length of material name and name */

      sprintf(tmpstr, "%s", GetText(mat + MATERIAL_PTR_NAME));
      n = strlen(tmpstr);

      fwrite(&n, sizeof(long), 1, fp);
      fwrite(tmpstr, sizeof(char), n, fp);

      /* Write index */

      fwrite(&m, sizeof(long), 1, fp);

      /* Write burnup step */
      
      n = (long)RDB[DATA_BURN_STEP];
      fwrite(&n, sizeof(long), 1, fp);

      /* Loop over composition */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Pointer to nuclide */

	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  
	  /* Nuclide index */

	  n = (long)RDB[nuc + NUCLIDE_IDX];

	  /* Atomic density */

	  adens = RDB[iso + COMPOSITION_ADENS];
	  CheckValue(FUNCTION_NAME, "adens", "", adens, 0.0, INFTY);

	  /* Check that value is non-zero */

	  if (adens > ZERO)
	    {
	      /* Write index */

	      fwrite(&n, sizeof(long), 1, fp);
	      
	      /* Write composition */

	      fwrite(&adens, sizeof(double), 1, fp);

	      /* Convert atomic density to number of nuclides */

	      adens = adens*RDB[mat + MATERIAL_VOLUME];

	      /* Add to totals */
	      
	      WDB[nuc + NUCLIDE_TOT_MASS] = WDB[nuc + NUCLIDE_TOT_MASS] 
		+ adens*RDB[nuc + NUCLIDE_AW]/N_AVOGADRO;

	      WDB[nuc + NUCLIDE_TOT_ACTIVITY] = WDB[nuc + NUCLIDE_TOT_ACTIVITY]
		+ adens*RDB[nuc + NUCLIDE_LAMBDA]/BARN;

	      WDB[nuc + NUCLIDE_TOT_SF] = WDB[nuc + NUCLIDE_TOT_SF]
		+ adens*RDB[nuc + NUCLIDE_SFBR]*RDB[nuc + NUCLIDE_LAMBDA]/BARN;

	      WDB[nuc + NUCLIDE_TOT_DECAY_HEAT] = 
		WDB[nuc + NUCLIDE_TOT_DECAY_HEAT]
		+ adens*RDB[nuc + NUCLIDE_DECAY_E]*
		RDB[nuc + NUCLIDE_LAMBDA]*MEV/BARN;
	      
	      WDB[nuc + NUCLIDE_TOT_ING_TOX] = WDB[nuc + NUCLIDE_TOT_ING_TOX] 
		+ adens*RDB[nuc + NUCLIDE_SPEC_ING_TOX]*
		RDB[nuc + NUCLIDE_LAMBDA]/BARN;
	      
	      WDB[nuc + NUCLIDE_TOT_INH_TOX] = 
		WDB[nuc + NUCLIDE_TOT_INH_TOX] 
		+ adens*RDB[nuc + NUCLIDE_SPEC_INH_TOX]*
		RDB[nuc + NUCLIDE_LAMBDA]/BARN;	      
	    }

	  /* Next nuclide in composition */

	  iso = NextItem(iso);
	}

      /* Update index */

      m++;

      /* Write burnup step */

      n = (long)RDB[DATA_BURN_STEP];
      fwrite(&n, sizeof(long), 1, fp);
      
      /* Next material */

      mat = NextItem(mat);
    }

  /* Check index */

  if (m == 0)
    Die(FUNCTION_NAME, "No material data written");

  /***************************************************************************/

  /* Close file and exit */

  fclose(fp);  
}

/*****************************************************************************/
