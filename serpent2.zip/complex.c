#include "header.h"

/* complex.c: modified 24.2.2009 - Version 1.1.0 (MPu) */

/*****************************************************************************/

/* kompleksiluvut */

/*--------------------------------------------------------------------*/
complex c_add(complex x, complex y){
  complex z;
  z.re = x.re + y.re;
  z.im = x.im + y.im; 
  return z;
}
/*--------------------------------------------------------------------*/
complex c_sub(complex x, complex y){
  complex z;
  z.re = x.re - y.re;
  z.im = x.im - y.im;
  return z;
}
/*--------------------------------------------------------------------*/
complex c_mul(complex x, complex y){
  complex z;
  z.re = x.re * y.re - x.im * y.im; 
  z.im = x.re * y.im + x.im * y.re; 
  return z;
}
/*--------------------------------------------------------------------*/
double c_norm(complex x){
  double norm; 
  norm = x.re * x.re + x.im * x.im;
  norm = sqrt(norm); 
  return norm;
}
/*--------------------------------------------------------------------*/
complex c_div(complex x, complex y){
  complex z;
  double n = c_norm(y); 
  n = n*n;
  z.re = (x.re * y.re + x.im * y.im) / n;
  z.im = (x.im * y.re - x.re * y.im) / n; 
  return z;
}
/*--------------------------------------------------------------------*/
complex c_con(complex x){
  complex z;
  z.re = x.re;
  z.im = -x.im; 
  return z;
}
/*--------------------------------------------------------------------*/

/*****************************************************************************/
