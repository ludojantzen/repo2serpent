/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : initdata.c                                     */
/*                                                                           */
/* Created:       2010/11/21 (JLe)                                           */
/* Last modified: 2013/04/25 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Inits values in main data block                              */
/*                                                                           */
/* Comments: - Tää vaatii vielä paljon työtä                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "InitData:"

/*****************************************************************************/

void InitData()
{
  long ptr;
  char *path, *seed;
  time_t t0;
  clock_t cput0;

  /* Set error pointer */

  err = stdout;

  /* Check that system is 64 bit */

  if (sizeof(long) != 8)
    {
      /* Print error */

      fprintf(err, "\nSerpent 2 must be run in a 64-bit system. ");
      
      if (sizeof(long) == 4)
	fprintf(err, "Your system appears to be 32-bit.");

      fprintf(err, "\n\n");

      /* Abort */

      exit(-1);
    }

  /* Reset pointers */

  WDB = NULL;
  ACE = NULL;
  ASCII = NULL;
  PRIVA = NULL;
  BUF = NULL;
  RES1 = NULL;
  RES2 = NULL;

  /* Set pointer to standard output */
  
  if (mpiid == 0)
    out = stdout;
  else
    {
      out = fopen("/dev/null", "w");
      return;
    }

  /* Set line-buffering for stdout */

  setlinebuf(out);

  /* Allocate memory for main data block */

  ReallocMem(DATA_ARRAY, DATA_FIXED_BLOCK_SIZE);

  /* Allow memory allocation */

  Mem(MEM_ALLOW);

  /* Allocate data at the beginning of RES1 array to simplify error testing */
  
  ReallocMem(RES1_ARRAY, DATA_FIXED_BLOCK_SIZE);

  /* Allocate memory for ASCII data block to simplify error testing */

  ASCII = (char *)Mem(MEM_ALLOC, (long)(VALID_PTR + 1), sizeof(char)); 
  WDB[DATA_ASCII_DATA_SIZE] = (double)(VALID_PTR + 1);

  /* Init list pointers */

  WDB[DATA_PTR_C0] = NULLPTR;
  WDB[DATA_PTR_S0] = NULLPTR;
  WDB[DATA_PTR_M0] = NULLPTR;
  WDB[DATA_PTR_L0] = NULLPTR;
  WDB[DATA_PTR_T0] = NULLPTR;
  WDB[DATA_PTR_NST0] = NULLPTR;
  WDB[DATA_PTR_GPL0] = NULLPTR;
  WDB[DATA_PTR_TR0] = NULLPTR;
  WDB[DATA_PTR_PB0] = NULLPTR;
  WDB[DATA_PTR_IFC0] = NULLPTR;
  WDB[DATA_PTR_DIV0] = NULLPTR;

  /* Init file names */

  WDB[DATA_PTR_ACEDATA_FNAME_LIST] = NULLPTR;
  WDB[DATA_PTR_DECDATA_FNAME_LIST] = NULLPTR;
  WDB[DATA_PTR_NFYDATA_FNAME_LIST] = NULLPTR;
  WDB[DATA_PTR_SFYDATA_FNAME_LIST] = NULLPTR;

  /* Few-group constant generation */

  WDB[DATA_ERG_FG_PTR_PREDEF] = (double)PutText("2");

  /* Thinning tolerance and energy boundaries (tarkista noi fotonirajat) */

  WDB[DATA_ERG_TOL] = -1.0;

  WDB[DATA_NEUTRON_EMIN] = 1E-11;
  WDB[DATA_NEUTRON_EMAX] = 20.0;

  WDB[DATA_PHOTON_EMIN] = 1E-3;
  WDB[DATA_PHOTON_EMAX] = 10.0;

  /* Set boundary condition and albedo */

  WDB[DATA_GEOM_BC0] = (double)BC_BLACK;
  WDB[DATA_GEOM_BC1] = (double)BC_BLACK;
  WDB[DATA_GEOM_BC2] = (double)BC_BLACK;
  WDB[DATA_GEOM_BC3] = (double)BC_BLACK;
  WDB[DATA_GEOM_ALBEDO] = 1.0;

  /* Set initial date */

  WDB[DATA_PTR_DATE] = (double)PutText(TimeStamp());

  /* Get initial cpu time */

  cput0 = clock();
  WDB[DATA_CPU_T0] = (double)cput0;

  /* Reset calculation modes */

  WDB[DATA_NEUTRON_TRANSPORT_MODE] = (double)NO;
  WDB[DATA_PHOTON_TRANSPORT_MODE] = (double)NO;
  WDB[DATA_BURNUP_CALCULATION_MODE] = (double)NO;
  WDB[DATA_VOLUME_CALCULATION_MODE] = (double)NO;
  WDB[DATA_PARTICLE_DISPERSER_MODE] = (double)NO;
  WDB[DATA_QUICK_PLOT_MODE] = (double)NO;

  /* Normalisation */

  WDB[DATA_PTR_NORM] = NULLPTR;
  WDB[DATA_NORM_U235_FISSE] = U235_FISSE;

  /* Replay mode */

  WDB[DATA_OPTI_REPLAY] = (double)NO;

  /* Set default random number seed */

  time(&t0);
  parent_seed = (unsigned long)t0;

  /* Override with environment variable */

  if ((seed = getenv("SERPENT_RNG_SEED")) != NULL)
    {
      parent_seed = (unsigned long)atoi(seed);
      WDB[DATA_OPTI_REPLAY] = (double)YES;
    }

  /* XS data plotter parameters */

  WDB[DATA_XSPLOT_NE] = -1.0;
  WDB[DATA_XSPLOT_EMIN] = -1.0;
  WDB[DATA_XSPLOT_EMAX] = -1.0;

  /* Print compositions */

  WDB[DATA_BURN_PRINT_COMP] = (double)NO;
  WDB[DATA_BURN_PRINT_COMP_LIM] = 1.0;
  WDB[DATA_BURN_MAT_OUTPUT] = (double)BURN_OUT_MAT_PARENT;

  /* Decay only mode */

  WDB[DATA_BURN_DECAY_CALC] = (double)NO;

  /* Print histories */
  
  WDB[DATA_OPTI_PRINT_HIS] = (double)NO;

  /* Depletion cut-offs */

  WDB[DATA_DEP_HALF_LIFE_CUTOFF] = INFTY;
  WDB[DATA_DEP_TTA_CUTOFF]       = 1E-18;

  /* Time cut-off for transport simulation */

  WDB[DATA_TIME_CUT_TMIN] = 0.0;
  WDB[DATA_TIME_CUT_TMAX] = INFTY;

  /* Reset generation cut-off */

  WDB[DATA_GEN_CUT] = (double)MAX_GENERATIONS;

  /* Fission source entropy */

  WDB[DATA_OPTI_ENTROPY_CALC] = (double)NO;

  WDB[DATA_ENTROPY_NX] = 5.0;
  WDB[DATA_ENTROPY_NY] = 5.0;
  WDB[DATA_ENTROPY_NZ] = 5.0;

  WDB[DATA_ENTROPY_XMIN] = -INFTY;
  WDB[DATA_ENTROPY_XMAX] =  INFTY;

  WDB[DATA_ENTROPY_YMIN] = -INFTY;
  WDB[DATA_ENTROPY_YMAX] =  INFTY;

  WDB[DATA_ENTROPY_ZMIN] = -INFTY;
  WDB[DATA_ENTROPY_ZMAX] =  INFTY;

  /* Microscopic partial total cross section limit for including nuclide */
  /* in reaction lists. */

  WDB[DATA_MIN_TOTXS] = 1E-5;

  /* Use unresolved resonance probability tables (turned off by default) */

  WDB[DATA_USE_URES] = (double)NO;
  WDB[DATA_URES_PTR_USE_LIST] = NULLPTR;

  /* Plotter */

  WDB[DATA_STOP_AFTER_PLOT] = (double)STOP_AFTER_PLOT_NONE;
  WDB[DATA_PLOTTER_MODE] = (double)NO;

  /* Optimization and memory/data options */

  WDB[DATA_OPTI_MODE] = 4.0;
  WDB[DATA_OPTI_UNIONIZE_GRID] = -1.0;
  WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = -1.0;
  WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = -1.0;
  WDB[DATA_OPTI_INCLUDE_SPECIALS] = (double)NO;

  /* Delta-tracking */

  WDB[DATA_OPT_USE_DT] = (double)YES;
  WDB[DATA_DT_NTHRESH] = 0.1;
  WDB[DATA_DT_PTHRESH] = 0.1;

  /* Implicit Monte Carlo */

  WDB[DATA_OPT_IMPL_FISS] = (double)NO;
  WDB[DATA_OPT_IMPL_CAPT] = (double)NO;
  WDB[DATA_OPT_IMPL_NXN] = (double)YES;
  WDB[DATA_OPT_ROULETTE_W0] = 0.001;
  WDB[DATA_OPT_ROULETTE_P0] = 1.0/6.0;

  /* Run-time variables */

  WDB[DATA_CYCLE_KEFF] = 1.0;

  /* Simulation mode and batching interval */

  WDB[DATA_SIMULATION_MODE] = -1.0;
  WDB[DATA_BATCH_INTERVAL] = 1.0;

  /* OpenMP stuff */

  WDB[DATA_OMP_MAX_THREADS] = 1.0;

  /****************************************************************/

  /* uudet: */

  /* Allocate empty memory ACE array to deal with zero pointers */

  WDB[DATA_PTR_ACE0] = NULLPTR;
  ReallocMem(ACE_ARRAY, DATA_FIXED_BLOCK_SIZE);

  WDB[DATA_PTR_ACE_NFY_DATA] = NULLPTR;
  WDB[DATA_PTR_ACE_SFY_DATA] = NULLPTR;

  /* Root universe */

  WDB[DATA_PTR_ROOT_UNIVERSE] = (double)PutText("0");

  /* History list size */

  WDB[DATA_HIST_LIST_SIZE] = -50.0;

  /* Monte Carlo volume calculation */

  WDB[DATA_VOLUME_MC_NMAX] = -1.0;
  WDB[DATA_VOLUME_MC_TMAX] = -1.0;
  WDB[DATA_VOLUME_MC_EMAX] = -1.0;

  /* DBRC */

  WDB[DATA_USE_DBRC] = (double)NO;
  WDB[DATA_PTR_DBRC] = NULLPTR;
  WDB[DATA_DBRC_EMIN] = 0.4E-6;
  WDB[DATA_DBRC_EMAX] = 210E-6;

  /* Energy cut-off for transmutation reactions */

  WDB[DATA_BURN_ENECUT] = 10.0;

  /* Normalization */

  WDB[DATA_NORM_BURN] = BURN_NORM_ALL;

  /* Burnup mode */

  WDB[DATA_BURN_BUMODE] = (double)BUMODE_CRAM;
  WDB[DATA_BU_SPECTRUM_COLLAPSE] = -1.0;

  /* CRAM:n asteluku */

  WDB[DATA_BURN_CRAM_K] = 14.0;

  /* Predictor-corrector calculation */

  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_CONSTANT;
  WDB[DATA_BURN_PRED_NSS] = 1.0;
  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_LINEAR;
  WDB[DATA_BURN_CORR_NSS] = 1.0;

  /* Corrector iteration NEW (AIs) */
  
  WDB[DATA_BURN_CI_TYPE] = (double)CI_TYPE_OUTER;
  WDB[DATA_BURN_CI_MAXI] = 1.0;
  WDB[DATA_BURN_CI_LAST] = (double)NO;
  
  WDB[DATA_BURN_CI_NBATCH] = -1.0;
  WDB[DATA_BURN_CI_CYCLES] = -1.0;
  WDB[DATA_BURN_CI_SKIP]   = -1.0;

  /* Core power distribution */

  WDB[DATA_CORE_PDE_DEPTH] = -1.0;

  /* Uniform fission source method */

  WDB[DATA_UFS_PTR_SRC_MESH] = NULLPTR;
  WDB[DATA_UFS_ORDER] = 1.0;
  WDB[DATA_UFS_MIN] = 0.001;
  WDB[DATA_UFS_MAX] = 10.0;

  /* Energy grid for coarse multi-group xs */

  WDB[DATA_COARSE_MG_NE] = 4000.0;
  WDB[DATA_OPTI_MG_MODE] = -1.0;

  /* Reset minimum and maximum energies of cross section data */

  WDB[DATA_NEUTRON_XS_EMIN] = INFTY;
  WDB[DATA_NEUTRON_XS_EMAX] = -INFTY;

  WDB[DATA_PHOTON_XS_EMIN] = INFTY;
  WDB[DATA_PHOTON_XS_EMAX] = -INFTY;

  /* Delayed nubar flag */

  WDB[DATA_USE_DELNU] = -1.0;

  /* Doppler broadening mode and temperature feedback */

  WDB[DATA_ETTM_MODE] = ETTM_MODE_NONE;
  WDB[DATA_USE_TFB] = (double)NO;
  WDB[DATA_USE_DENSITY_FACTOR] = (double)NO;
  WDB[DATA_USE_DOPPLER_PREPROCESSOR] = (double)NO;

  /* Ures energy boundaries */

  WDB[DATA_URES_EMIN] = INFTY;
  WDB[DATA_URES_EMAX] = -INFTY;

  /* Fundamental mode calculation */

  WDB[DATA_B1_CALC] = (double)NO;
  WDB[DATA_B1_BURNUP_CORR] = (double)NO;
  WDB[DATA_FUM_ERR_LIMIT] = 1E-3;

  /* Default micro-group structure */

  WDB[DATA_MICRO_PTR_EGRID] = (double)PutText("cas40");

  /* Micro-group calculation mode */

  WDB[DATA_MICRO_CALC_MODE] = (double)MICRO_CALC_MODE_END;

  /* Shared scoring buffer */

  WDB[DATA_OPTI_SHARED_BUF] = (double)NO;

  /* Shared RES2 array */

  WDB[DATA_OPTI_SHARED_RES2] = (double)YES;

  /* Reproducibility in OpenMP and MPI modes */

  WDB[DATA_OPTI_OMP_REPRODUCIBILITY] = (double)YES;
  WDB[DATA_OPTI_MPI_REPRODUCIBILITY] = (double)NO;

  /* Include scattering production in removal xs */

  WDB[DATA_GC_REMXS_MULT] = (double)YES;

  /* Analog reaction rate calculation */

  WDB[DATA_ANA_RR_NCALC] = (double)ARR_MODE_NONE;
  WDB[DATA_ANA_RR_PCALC] = (double)ARR_MODE_NONE;

  /* Recorded tracks for plots */

  WDB[DATA_TRACK_PLOTTER_HIS] = -1.0;

  /* Number of parallel eigenvalue calculations */

  WDB[DATA_N_POP_EIG] = 1.0;

  /* UFS mode */

  WDB[DATA_UFS_MODE] = (double)UFS_MODE_NONE;

  /* Default cross section data library */

  if ((path = getenv("SERPENT_ACELIB")) != NULL)
    {
      ptr = ReallocMem(DATA_ARRAY, 2);
      WDB[DATA_PTR_ACEDATA_FNAME_LIST] = (double)ptr;
      WDB[ptr++] = (double)PutText(path);
      WDB[ptr] = NULLPTR;
    }

  /* Re-seed random number sequence for qued particles (tää tarvitaan että */
  /* saadaan luotua track-plotterilla animaatioita) */

  WDB[DATA_RESEED_QUE] = (double)NO;

  /* Reset neutron and gamma buffer factors */

  WDB[DATA_PART_NBUF_FACTOR] = -1.0;  
  WDB[DATA_PART_GBUF_FACTOR] = -1.0;

  /* Reaction sampling */

  WDB[DATA_NPHYS_SAMPLE_FISS] = (double)YES;
  WDB[DATA_NPHYS_SAMPLE_CAPT] = (double)YES;
  WDB[DATA_NPHYS_SAMPLE_SCATT] = (double)YES;

  /* Number of time bins */

  WDB[DATA_DYN_NB] = 1.0;

  /* Alpha eigenvalue */

  WDB[DATA_ALPHA_EIG] = 0.0; /* 1.431E+04 = EPR-laskun kriittinen alpha */

  /* Minimum xs for CFE */

  WDB[DATA_CFE_N_MIN_L] = 100.0;
  WDB[DATA_CFE_N_MIN_T] = -1.0;
  WDB[DATA_CFE_G_MIN_L] = 100.0;
  WDB[DATA_CFE_G_MIN_T] = -1.0;

  /* Energy boundary for cache-optimized xs block */

  WDB[DATA_CACHE_OPTI_EMAX] = 1E-5;

  /* Ures infinite dilution cut-off */

  WDB[DATA_URES_DILU_CUT] = 1E-9;

  /* Poison calculation */

  WDB[DATA_OPTI_POISON_CALC] = (double)NO;

  /* Equilibrium poison calculation */

  WDB[DATA_XENON_EQUILIBRIUM_MODE] = -1.0;
  WDB[DATA_SAMARIUM_EQUILIBRIUM_MODE] = -1.0;

  /* MPI batch size */

  WDB[DATA_OPTI_MPI_BATCH_SIZE] = 10000.0;

  /* Actinide limits for burnup calculation */

  WDB[DATA_BU_ACT_MIN_Z] = 90.0;
  WDB[DATA_BU_ACT_MAX_Z] = 96.0;

  /* Number of progenies for beta-eff and prompt lifetime calculation */

  WDB[DATA_IFP_OPT_PRINT_ALL] = (double)NO;
  WDB[DATA_IFP_CHAIN_LENGTH] = 15.0;
  WDB[DATA_PERT_VAR_A] = 1E-8;
  WDB[DATA_PERT_VAR_C] = 1E-6;
  WDB[DATA_PERT_N_BATCH] = 9.0;

  /* Simulator output */

  WDB[DATA_SIMULATOR_DATA] = (double)NO;
  WDB[DATA_CAX_OUTPUT] = (double)NO;

  /* Homogenized diffusion Monte Carlo -viritelmä */

  WDB[DATA_RUN_HDMC] = (double)NO;
  WDB[DATA_HDMC_POP] = 1000.0;
  WDB[DATA_HDMC_CYCLES] = 500.0;
  WDB[DATA_HDMC_SKIP] = 10.0;
  WDB[DATA_HDMC_KEFF] = 1.0;

  /***************************************************************************/
}

/*****************************************************************************/
