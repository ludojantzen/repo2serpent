/***** External libraries ****************************************************/

#define _XOPEN_SOURCE 600
#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <limits.h>
#include <time.h>
#include <sys/types.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/timeb.h>

/* This is used with stable burnup routine under development */
/*
#define STAB_BURN
*/
/*****************************************************************************/

/***** Parallel calculation **************************************************/

#ifdef MPI

/* MPI library header */

#include <mpi.h>

/* mpirun executable path */

#define MPIRUN_PATH "mpirun"

#endif

#ifdef OPEN_MP

/* OpenMP library header */

#include <omp.h>

#endif

/* MPI mode: 1 = divide source size, 2 = divide number of active cycles */

#define MPI_MODE1

/*****************************************************************************/

/***** Code name and version *************************************************/

#define CODE_NAME     "Serpent"
#define CODE_VERSION  "2.1.13"
#define CODE_DATE     "February 4, 2013"
#define CODE_AUTHOR   "Jaakko.Leppanen@vtt.fi"

/*****************************************************************************/

/***** Constants *************************************************************/

/* Zero and infinity */

#define INFTY       1e+37
#define ZERO        1e-37

/* Natural constants */

#define M_NEUTRON   1.0086649670000E+00  /* neutron mass in amu              */
#define N_AVOGADRO  6.0220434469282E-01  /* Avogadro's constant in 1E-24     */
#define SHAKE       1E-8                 /* ancient time unit used at LANL   */
#define KELVIN      8.6173E-11           /* MeV per kelvin                   */
#define E_RESTMASS  0.511008             /* Electron rest mass in MeV        */
#define MEV         1.6021765314E-13     /* J per MeV                        */
#define ETOV2       1.9131290731E+18     /* square speed (cm2/s2) per energy */
#define BARN        1E-24                /* barn in cm3                      */

#ifdef wanhat

#define SPD_C       29979245800.0        /* Speed of light in cm/s           */
#define NEUTRON_E0  939.668854490302     /* Neutron rest mass in MeV         */

#else
#define SPD_C       29979250000.0        /* Speed of light in cm/s           */
#define NEUTRON_E0  9.3958000000000E+02  /* Neutron rest mass in MeV         */

#endif


/* U-235 fission Q-value and energy deposition per fission */

#define U235_FISSQ 1.9372E+02
#define U235_FISSE 202.27*MEV

/* Math constants */

#define LOG2    0.69314718055995
#define PI      3.14159265358979
#define SQRT2   1.41421356237309
#define SQRT3   1.73205080756888
#define SIN30   0.50000000000000
#define COS30   0.86602540378444
#define SIN45   0.70710678118655
#define SIN60   0.86602540378444
#define COS60   0.50000000000000

/* Random number stride between neutrons = 2^STRIDE (Fast implementations */
/* for STRIDE values 12-19 are implemented for use in serial mode. (TVi)) */

#define STRIDE 16

/* Extrapolation length for boundary distances */

#define EXTRAP_L 1E-6

/* very negative null pointer for data arrays */

#define NULLPTR -1E+6

/* yes and no */

#define YES 1
#define NO  0

/* Maximum array sizes */

#define MAX_STR               256
#define MAX_FP_NUCLIDES       1500
#define MAX_ISOTOPES          1000
#define MAX_INPUT_PARAMS      100000
#define MAX_CELL_SURFACES     1000
#define MAX_LATTICE_ITEMS     100*100
#define MAX_SURFACE_PARAMS    100
#define MAX_EGRID_NE          100000000
#define MAX_PRECURSOR_GROUPS  8
#define MAX_GEOMETRY_LEVELS   10000
#define MAX_EXT_K_GEN         5
#define MAX_GENERATIONS       1000000000

/* Maximum allowed number of OpenMP threads */

#define MAX_OMP_THREADS 10000

/* Limiting values for parameters */

#define MAX_XS       5E+9   /* Maximum microscopic cross section  */
#define E_CHECK_MAX  200.0  /* Maximum energy (used for checking) */

/* Energy grid types */

#define EG_INTERP_MODE_LIN 1
#define EG_INTERP_MODE_LOG 2

/* Run mode options */

#define MODE_NORMAL         0
#define MODE_REPLAY         2
#define MODE_MPI            4

/* Simulation modes */

#define SIMULATION_MODE_CRIT  1
#define SIMULATION_MODE_SRC   2

/* Microgroup calculation modes */

#define MICRO_CALC_MODE_END    1
#define MICRO_CALC_MODE_CYCLE  2

/* UFS mode */

#define UFS_MODE_NONE  0
#define UFS_MODE_COL   1
#define UFS_MODE_FLUX  2
#define UFS_MODE_FISS  3

/* Burnup modes (solution method for Bateman's equations) */

#define BUMODE_TTA  1
#define BUMODE_CRAM 2

/* Normalization in burnup mode */

#define BURN_NORM_ALL       1
#define BURN_NORM_BURN      2
#define BURN_NORM_NOT_BURN  3

/* Array types */

#define DATA_ARRAY     1 
#define RES1_ARRAY     2
#define ACE_ARRAY      3
#define PRIVA_ARRAY    4
#define BUF_ARRAY      5
#define RES2_ARRAY     6

/* XS data types */

#define XS_TYPE_SAB         3
/*
#define XS_TYPE_NONE        0
#define XS_TYPE_CONTINUOUS  1
#define XS_TYPE_DOSIMETRY   2
#define XS_TYPE_DECAY       4
*/

/* Calculation of analog reaction rates */

#define ARR_MODE_NONE  0
#define ARR_MODE_BALA  1
#define ARR_MODE_ALL   2

/* Nuclide types */

#define NUCLIDE_TYPE_NONE        0
#define NUCLIDE_TYPE_TRANSPORT   1
#define NUCLIDE_TYPE_DOSIMETRY   2
#define NUCLIDE_TYPE_SAB         3
#define NUCLIDE_TYPE_DECAY       4
#define NUCLIDE_TYPE_PHOTON      5
#define NUCLIDE_TYPE_DBRC        6
#define NUCLIDE_TYPE_TRANSMUXS   7

/* Nuclide flags */

#define NUCLIDE_FLAG_INITIAL              1
#define NUCLIDE_FLAG_AP                   2
#define NUCLIDE_FLAG_DP                   4
#define NUCLIDE_FLAG_FP                   8
#define NUCLIDE_FLAG_BP                  16
#define NUCLIDE_FLAG_TRANSPORT_DATA      32
#define NUCLIDE_FLAG_DOSIMETRY_DATA      64
#define NUCLIDE_FLAG_DECAY_DATA         128
#define NUCLIDE_FLAG_NFY_DATA           256
#define NUCLIDE_FLAG_SFY_DATA           512
#define NUCLIDE_FLAG_IBR_DATA          1024
#define NUCLIDE_FLAG_URES_AVAIL        2048
#define NUCLIDE_FLAG_URES_USED         4096
#define NUCLIDE_FLAG_FISSILE           8192
#define NUCLIDE_FLAG_SAB_DATA         16384
#define NUCLIDE_FLAG_SRC              32768
#define NUCLIDE_FLAG_PHOTON_DATA      65536
#define NUCLIDE_FLAG_DBRC            131072
#define NUCLIDE_FLAG_DEP             262144
#define NUCLIDE_FLAG_DELNU_PREC      524288
#define NUCLIDE_FLAG_TRANSMU_DATA   1048576
#define NUCLIDE_FLAG_NEW_DAUGHTERS  2097152
#define NUCLIDE_FLAG_ETTM           4194304

/* Reaction types */

#define REACTION_TYPE_SUM         1
#define REACTION_TYPE_PARTIAL     2
#define REACTION_TYPE_SPECIAL     3
#define REACTION_TYPE_DECAY       4
#define REACTION_TYPE_TRA_BRANCH  5
#define REACTION_TYPE_DEC_BRANCH  6

/* Macroscopic reaction MT's (also used with detector response functions) */

#define MT_MACRO_TOTXS           -1
#define MT_MACRO_ABSXS           -2
#define MT_MACRO_ELAXS           -3
#define MT_MACRO_FISSXS          -6
#define MT_MACRO_NSF             -7
#define MT_MACRO_FISSE           -8
#define MT_MACRO_MAJORANT        -9

#define MT_NEUTRON_DENSITY      -15
#define MT_MACRO_INLPRODXS      -16

#define MT_MACRO_TOTPHOTXS      -25
#define MT_MACRO_HEATPHOTXS     -26

#define MT_MACRO_TMP_MAJORANTXS -30

/* Energy grid types */

#define GRID_TYPE_LIN  1
#define GRID_TYPE_LOG  2

/* User energy grid types */

#define EG_TYPE_ARB     1
#define EG_TYPE_UNI_E   2
#define EG_TYPE_UNI_L   3
#define EG_TYPE_PREDEF  4

/* User time binning types */

#define TB_TYPE_ARB       1
#define TB_TYPE_UNI_T     2
#define TB_TYPE_UNI_LOGT  3

/* Angular distribution types */

#define ANG_TYPE_EQUIBIN 1
#define ANG_TYPE_TABULAR 2

/* General options */

#define OPT_USED              1
#define OPT_EXISTS            2
#define OPT_BURN_MAT          4
#define OPT_FISSILE_MAT       8
#define OPT_PHYSICAL_MAT     16

/* Sort modes */

#define SORT_MODE_ASCEND         1
#define SORT_MODE_DESCEND        2
#define SORT_MODE_ASCEND_PRIVA   3
#define SORT_MODE_DESCEND_PRIVA  4

/* Fission yield types (used to identify fission reactions in   */
/* transmu chains, these must be different from all ENDF MT's). */

#define FISSION_YIELD_TYPE_NFY  -1
#define FISSION_YIELD_TYPE_SFY  -2

/* Data sizes in bytes */

#define KILO        1024.0
#define MEGA     1048576.0
#define GIGA  1073741824.0

/* Input parameter types */

#define PTYPE_LOGICAL 1
#define PTYPE_REAL    2
#define PTYPE_INT     3

/* Plotter modes */

#define PLOT_MODE_YZ 1
#define PLOT_MODE_XZ 2
#define PLOT_MODE_XY 3

/* Boundary conditions */

#define BC_BLACK       1
#define BC_REFLECTIVE  2
#define BC_PERIODIC    3

/* Transformation types */

#define TRANS_TYPE_UNI   1
#define TRANS_TYPE_SURF  2

/* Discontinuity factor region types */

#define ADF_REG_TYPE_FUEL 1
#define ADF_REG_TYPE_REF  2

/* Relative width of ADF corner region */

#define ADF_CORN_WIDTH 0.1

/* Surface list operators */

#define SURF_OP_NOT    -1
#define SURF_OP_AND    -2
#define SURF_OP_OR     -3
#define SURF_OP_LEFT   -4
#define SURF_OP_RIGHT  -5

/* Timers */

#define TOT_TIMERS                19

#define TIMER_TRANSPORT            1
#define TIMER_TRANSPORT_ACTIVE     2
#define TIMER_TRANSPORT_TOTAL      3
#define TIMER_TRANSPORT_CYCLE      4
#define TIMER_BURNUP               5
#define TIMER_BURNUP_TOTAL         6
#define TIMER_PROCESS              7
#define TIMER_PROCESS_TOTAL        8
#define TIMER_BATEMAN              9
#define TIMER_BATEMAN_TOTAL       10
#define TIMER_RUNTIME             11
#define TIMER_INIT                12
#define TIMER_VOLUME_CALC         13
#define TIMER_OMP_PARA            15
#define TIMER_MPI_OVERHEAD        16
#define TIMER_MPI_OVERHEAD_TOTAL  17
#define TIMER_TFB                 18
#define TIMER_MISC                19

/* Geometry errors */

#define GEOM_ERROR_NO_CELL         -1
#define GEOM_ERROR_MULTIPLE_CELLS  -2
/*

#define GEOM_ERROR_POINTER_ERROR   -3
*/

/* MPI methods */

#define MPI_METH_BC  1
#define MPI_METH_RED 2

/* Mesh types */

#define MESH_TYPE_CARTESIAN    1
#define MESH_TYPE_CYLINDRICAL  2
#define MESH_TYPE_SPHERICAL    3
#define MESH_TYPE_HEXX         4
#define MESH_TYPE_HEXY         5
#define MESH_TYPE_ORTHOGONAL   6

/* Mesh content */

#define MESH_CONTENT_DATA  1
#define MESH_CONTENT_PTR   2

/* Predictor and corrector steps */

#define PREDICTOR_STEP  0
#define CORRECTOR_STEP  1

/* Mesh plot types (numbers 1-3 are reserved for default) */

#define MPL_TYPE_FLUXPOW    4
#define MPL_TYPE_COLPT      5
#define MPL_TYPE_COLWGT     6
#define MPL_TYPE_GAMMAHEAT  7
#define MPL_TYPE_DET        8
#define MPL_TYPE_DET_IMP    9
#define MPL_TYPE_FLUXTEMP  10
#define MPL_TYPE_DENSITY   11
#define MPL_TYPE_DT_NEFF   12
#define MPL_TYPE_DT_GEFF   13

/* Color palettes for mesh plots */

#define PALETTE_HOT      1
#define PALETTE_COLD     2
#define PALETTE_HOTCOLD  3
#define PALETTE_JET      4
#define PALETTE_BW       5

/* Surface current detector type */

#define SURF_DET_TYPE_SURF 1
#define SURF_DET_TYPE_UNIV 2

/* Doppler-broadening modes */
/*
#define DOPPLER_MODE_NONE         0
#define DOPPLER_MODE_PREPROCESS   1
#define DOPPLER_MODE_MG_ETTM      2
#define DOPPLER_MODE_CE_ETTM      3
#define DOPPLER_MODE_CE_ETTM_EBT  4
*/

/* ETTM modes (järjestyksellä on väliä) */

#define ETTM_MODE_NONE 0
#define ETTM_MODE_MG   1
#define ETTM_MODE_CE   2

/* Entropy calculation mode */

#define ENTROPY_CALC_NONE        0
#define ENTROPY_CALC_SRC         1
#define ENTROPY_CALC_ALL         2

/* Memory allocation */

#define MEM_ALLOC    1
#define MEM_REALLOC  2
#define MEM_FREE     3
#define MEM_ALLOW    4
#define MEM_DENY     5

/* Multi-physics interface types */

#define IFC_TYPE_PT_AVG   1
#define IFC_TYPE_MESH     2
#define IFC_TYPE_FUNC     3
#define IFC_TYPE_CGNS     4
#define IFC_TYPE_FUEP     5

/* Material-wise delta-tracking modes */

#define DT_MAT_BLOCK  1
#define DT_MAT_FORCE  2

/* Source files */

#define SRC_FILE_BUF_SIZE 1000000

#define SRC_FILE_TYPE_SERPENT1   1
#define SRC_FILE_TYPE_S1_RENORM  2

/* Plot only mode */

#define STOP_AFTER_PLOT_NONE    0
#define STOP_AFTER_PLOT_GEOM    1
#define STOP_AFTER_PLOT_TRACKS  2 

/* Material divisor flags (keksi noille paremmat nimet) */

#define MAT_DIV_TYPE_NONE    0
#define MAT_DIV_TYPE_PARENT  1
#define MAT_DIV_TYPE_S1      2 
#define MAT_DIV_TYPE_NEW     3

/* Materials in burnup output */

#define BURN_OUT_MAT_DIV     1
#define BURN_OUT_MAT_PARENT  2
#define BURN_OUT_MAT_BOTH    3

/* Tracking modes */

#define TRACK_MODE_DT 1
#define TRACK_MODE_ST 2

/* Super-imposed detector types */

#define SUPERDET_TYPE_CURRENT 1
#define SUPERDET_TYPE_CFLUX   2

/* TFB material types */

#define TFB_MAT_TYPE_UNDEFINED  0
#define TFB_MAT_TYPE_FUEL       1
#define TFB_MAT_TYPE_ZIRCALOY   2
#define TFB_MAT_TYPE_HELIUM     3
#define TFB_MAT_TYPE_WATER      4

/* Track types */

#define TRACK_END_STRT   0
#define TRACK_END_SURF   1
#define TRACK_END_LEAK   2
#define TRACK_END_COLL   3
#define TRACK_END_VIRT   4
#define TRACK_END_TCUT   5

/* Additional types */

#define TRACK_END_CAPT   6
#define TRACK_END_FISS   7
#define TRACK_END_SCAT   8
#define TRACK_END_ECUT   9
#define TRACK_END_WCUT  10

/* Last track point for plotter */

#define TRACK_PLOT_LAST 1000

/* Fission matrix types */

#define FISSION_MATRIX_TYPE_MAT  1 
#define FISSION_MATRIX_TYPE_UNI  2 
#define FISSION_MATRIX_TYPE_LVL  3 
#define FISSION_MATRIX_TYPE_XYZ  4

/*****************************************************************************/

/***** Structures ************************************************************/

/* Complex number */

typedef struct {
  double re;
  double im;
} complex;


/* Matrix in compressed sparse column format*/

struct ccsMatrix{

  long m;            /* rivit */
  long n;            /* sarakket */
  long nnz;          /* nollasta eroavien lkm */

  long *colptr;      /* osoittimet 1. nollasta eroavaan joka sarakkeessa */
                     /* pituus on (n+1) */
  long *rowind;      /* rivi-indeksit */
  long *colind;      /* sarake-ineksit */
  long *rowptr;
  long *next;       
  complex *values;   /* nollasta eroavien arvot */  

};

/* Data structure to store nuclide data in depletion files */

struct depnuc {
  long ZAI;
  long Z;
  double AW;
  double lambda;
  double dh;
  double sf;
  double ingtox;
  double inhtox;  
};

/*****************************************************************************/

/***** Function prototypes ***************************************************/

void AddBranching(long);

void AddBuf(double, double, long, long, long, ...);

void AddChains(long, long, long);

void AddItem(long, long);

void AddMesh(long, double, double, double, double, long);

long AddNuclide(char *, long, char *, double, long, long);

void AddPrivateRes(long, double, long);

double *AddPts(double *, long *, const double *, long);

void AddTrackPt(double, double, double, long, long);

void AddSabData();

void AddSearchMesh(long, long, double, double, double, double, double, double);

void AddSortItem(long, long, long, long, long);

void AddStableNuclides();

void AddStat(double, long, ...);

void AddValuePair(long, double, double, long);

void AdjustEnergyGrid(long, long, const double *);

void AdjustSabData(long);

void AllocInterfaceStat();

void AllocMacroXS();

void AllocMicroXS();

void AllocParticleStack(long, long);

long AllocPrivateData(long, long);

void AllocValuePair(long);

void AllocStatHistory(long);

void Alpha(double, double, double *);

double AlphaXS(double);

void ARESOutput();

long AtoI(char *, char *, char *, long);

double AtoF(char *, char *,char *, long);

void AverageTransmuXS(long, double, double, long);

void AziRot(double, double *, double *, double *, long);

double B1FluxCorr(long gcu, double E);

long B1Flux(long, long, const double *, const double *, const double *, 
	    const double *, const double *, const double *, const double *, 
	    double *, double *);

void B1Solver();

long BoundaryConditions(long *, double *, double *, double *, double *, 
			double *, double *, double, double *, long);

void BroadCrossSection(long, long, long, double, double, double, double *, 
		       long *, long, long);

double BufMean(long, ...);

double BufN(long, ...);

double BufVal(long, ...);

double BufWgt(long, ...);

void BurnMatCompositions();

void BurnMaterials(long, long);

long BurnMatrixSize(long);

void BurnupCycle();

complex c_add (complex, complex); 

complex c_con (complex); 

complex c_div (complex, complex); 

complex c_mul (complex, complex);

double  c_norm(complex);

complex c_sub (complex, complex);

void CacheXS();

void CalcMicroGroupXS();

void CalculateActivities();

void CalculateBytes();

void CalculateDTMajorants();

void CalculateEntropies();

void CalculateMajorant(long, double);

void CalculateMasses();

void CalculateMGXS();

void CalculateTransmuXS(long, long);

void CalculateUresMajorants(long);

void CAXOutput();

void ccsMatrixColSpace(struct ccsMatrix *, long , long );

void ccsMatrixCopy(struct ccsMatrix *, struct ccsMatrix *);

void ccsMatrixIsort(struct ccsMatrix *);

struct ccsMatrix *ccsMatrixNew(long, long, long);

void ccsMatrixFree(struct ccsMatrix  *);

void ccsMatrixPrint(struct ccsMatrix *); 

void CellCount(long, long, long, long);

void CellVolumes();

void CheckDuplicates();

void CheckNuclideData();

void CheckReaListSum(long, double, long, long);

void CheckUnused();

void ClearBuf();

void ClearMicroGroupXS();

void ClearPrivateData(long);

void ClearPrivateRes();

void ClearStat(long);

void ClearTransmuXS();

void CloseList(long);

void CombineActinides();

void CombineFissionYields();

long CompareStr(long, long);

void ColDet(long, long, double, double, double, double, double, double, double,
	    double, double, double, double, long);

void CollectBuf();

void CollectBurnData();

void CollectDet();

void CollectDynData();

void CollectParallelData();

void CollectResults();

void CollectTfb();

void CollectVRMeshData();

long Collision(long, long, double, double, double, double *, double *, 
	       double *, double *, double *, double, long);

void ComptonScattering(double *, double *, double *, double *, long);

void CoordExpans(long, double *, double *, double *, long);

void CoordTrans(long, double *, double *, double *, double *, double *, 
		double *, long);

void CreateGeometry();

long CreateMesh(long, long, long, long, long, const double *);

long CreateUniverse(long, char *, long);

double DensityFactor(long, double, double, double, double, long);

void DepletionPolyFit(long, long);

long DetBin(long, long, double, double, double, double, double, long, long);

void DetectorOutput();

long DetIdx(long, long, long, long, long, long, long, long, long, long, long);

double DetResponse(long, long, long, double, double, long);

void DFPos(long, double, double, double, long*, long *, long *, long *, 
	   double *, double *, double *);

int Die(char *, ...);

void Disperse();

void DistributeMaterialData();

void DivideBurnMat();

void DivideZone(long, long, long);

double DopMicroXS(long, long, double, double *, double, long);

void DopplerBroad();

double DTMajorant(long, double, long);

long DuplicateItem(long);

long DuplicateParticle(long, long);

void ElasticScattering(long, double *, double *, double *, double *, long);

double ENDFColF(long, char *);

long ENDFColI(long, char *);

double ENDFInterp(long, double, double, double, double, double);

void ENDFNewLine(char *, char *, FILE *);

void Error(long, ...);

void EstimateRuntime();

void FinalizeMPI();

long FindCGNSCell(long, double, double, double, long);

void FindInterfaceRegions(long, long, long, long, double, double, double, long);

long FindLatticeRegion(long, long, double *, double *, double *, long *, long);

void FindMaterialPointers();

long FindNestRegion(long, long, double, double, double, long);

long FindNuclideData(char *, long, char *, double, long, long);

long FindPBRegion(long, long, double *, double *, double *, long *, long *, 
		  long);

void FindRowIndexes(struct ccsMatrix *);

long FindUniverseCell(long, double, double, double, long *, long);

long *FindXSLimits(long, long, double, double, double, double *, long *);

long FirstItem(long);

long FissMtxIndex(long, long);

void FissMtxOutput();

void Fission(long, long, long, double *, double, double, double, double, 
	     double *, double *, double *, double, double *, long);

void FlushBank();

void FormTransmuPaths(long, long, double, double, long, long);

void FreeMem();

long FromBank(long);

long FromSrc(long);

long FromStack(long, long);

long FromQue(long);

void GaussianSubst(struct ccsMatrix *, complex *, complex *, complex *);

void GetBurnIDs();

double *GetImportantPts(long, long *, long *, long *);

long GetLatticeIndexes(double, double, double, double, double, double, long *, 
		       long *, long *, long);

long GetLineNumber(char *, long);

char **GetParams(char *, char *, long *, long *, long, long, char *);

double GetTemp(long, long);

char *GetText(long);

void GeometryPlotter(long);

double GridFactor(long, double, long);

long GridSearch(long, double);

void HDMC();

double HisMean(long, long, ...);

double HisRelErr(long, long, ...);

double HisVal(long, long, ...);

void IFCPoint(long, double *, double *, long);

void IdentifyTFBMat();

long InCell(long, double, double, double, long, long);

void InelasticScattering(long, double *, double *, double *, double *, long);

void InitData();

void InitHistories();

void InitMPI(int, char **);

void InitOMP();

long InSuperCell(long, long, double, double, double, long);

long InterpolateData(const double *, double *, long, const double *, 
		     const double *, long, long, long *, long *);

void IntersectionList(long, long *, long);

void IsotopeFractions(long);

long IsotoZAI(char *);

void IsotropicDirection(double *, double *, double *, long);

void IterateTFB();

void KleinNishina(double, double *, double *, long);

long LastItem(long);

void Leak(long, double, double, double, double, double, double, double, 
	  double, long);

void LevelScattering(long, double *, double *, double *, double *, long);

void LinkGCUMaterials(long, long);

void LinkReactions();

void LinkSabData();

double MacroXS(long, double, long);

double MajorantXS(long, double, long);

double *MakeArray(double, double, long, long);

struct ccsMatrix *MakeBurnMatrix(long, long);

void MakeDepletionZones(long, long, long, long, long);

long MakeEnergyGrid(long, long, long, long, const double *, long);

void MakePalette(long *, long *, long *, long, long);

void MakeRing(long);

void MaterialBurnup(long, double *, double, long);

void MaterialTotals();

void MaterialVolumes();

void MatlabOutput();

long MatPtr(long, long);

double *MatrixExponential(struct ccsMatrix *, double *, double);

void MaxSurfDimensions(long, double *, double *, double *, double *, 
			  double *, double *);

double MaxwellEnergy(double, long);

double Mean(long, ...);

void *Mem(long, ...);

long MemCount();

long MeshIndex(long, double, double, double);

void MeshPlotter();

long MeshPtr(long, double, double, double);

double MeshTot(long);

double MeshVal(long, double, double, double);

double MGXS(long, double, long, long);

void MicroCalc();

double MicroXS(long, double, long);

double MinXS(long, double, long);

void MORAOutput();

long MoveDT(long, double, double, long *, double *, double *, double *, 
	    double*, double *, double, double, double, double, long);

void MoveItemFirst(long);

void MoveItemRight(long);

long MoveST(long, double, double, long *, double *, double *, double *,
	    double *, double *, double, double, double, long);

void MPITransfer(double *, double *, long, long, long);

long MyParallelMat(long, long);

double NearestBoundary(long);

double NearestPBSurf(long, double, double, double, double, double, double,
		     long);

void NestVolumes();

long NewItem(long, long);

void NewReaList(long, long);

long NewStat(char *, long, ...);

long NextReaction(long, long *, double *, double *, double *, long);

long NextWord(char *, char *);

double NormCoef(long);

void NormalizeCompositions();

void NormalizeCritSrc();

long NormalizeDynSrc();

void Note(long, ...);

double Nubar(long, double, long);

void NumericGauss(struct ccsMatrix *, complex *, complex, complex *); 

void Nxn(long, long, double *, double, double, double, double *, double *, 
	 double *, double, double *, double, long);

void OmpTester();

FILE *OpenDataFile(long, char *);

void PairProduction(long, long, double, double, double, double, double, long);

long ParseCommandLine(int, char **);

void PhotoElectric(long, long, double, double, double, double, double, double, 
		   double, long);

double PhotonMacroXS(long, double, long);

double PhotonMicroXS(long, double, long);

void PoisonEq();

double PoisonXS(long, double, long, long);

double PolarAngle(double, double);

double PotCorr(long, double, double);

void PreallocMem(long, long);

void PrepareTransportCycle();

void PrintCompositions(long);

void PrintCoreDistr();

void PrintCycleOutput();

void PrintDepMatrix(long, struct ccsMatrix *, double t, double *, double *,
		    long id);

void PrintDepOutput();

void PrintDepVals(FILE *, char *, struct depnuc *, long, long, double **, 
		  double *, double *);

void PrintGeometryData();

void PrintHistoryOutput();

void PrintInterfaceOutput();

void PrintMaterialData();

void PrintNuclideData(long, long);

void PrintPBData();

void PrintProgress(long, long);

void PrintReactionLists();

void PrintTFBOutput();

void PrintTitle();

void PrintValues(FILE *, char *, long, long, long, long, long, long);

void ProcessBC();

void ProcessBurnMat();

void ProcessBurnupEGroups();

void ProcessCells();

void ProcessCPD();

void ProcessDecayData(long);

void ProcessDepHis();

void ProcessDetectors();

void ProcessDivisors();

void ProcessEDistributions(long, long);

void ProcessEntropy();

void ProcessFissionYields(long);

void ProcessFissMtx();

void ProcessGC();

void ProcessInterface();

void ProcessInventory();

void ProcessLattices();

void ProcessMaterials();

void ProcessMeshPlots();

void ProcessMixture(long, long);

void ProcessMuDistributions(long);

void ProcessNests();

void ProcessNubarData(long);

void ProcessNuclides();

void ProcessPBGeometry();

void ProcessPhotonRea(long);

void ProcessPoisons();

void ProcessReactionLists();

void ProcessReprocessors();

void ProcessSources();

void ProcessStats();

void ProcessSymmetries();

void ProcessTmpData();

void ProcessTFB();

void ProcessTimeBins();

void ProcessTransformations();

void ProcessUresData(long); 

void ProcessUserEGrids();

void ProcessVR();

void ProcessXSData();

void PutCompositions();

void PutPoisonConc();

long PutText(char *);

long RadGammaSrc(long, double *, double *, long);

double Rand64(unsigned long *);

double RandF(long);

void ReactionCount();

void ReactionCutoff();

long ReactionTargetZAI(long);

char *ReactionMT(long);

void ReadACEFile(long);

void ReadDecayFile();

void ReadDirectoryFile();

void ReadFissionYields();

void ReadIBRFile();

long ReadInfix(long, long *, long *);

void ReadInput(char *);

void ReadInterface();

double ReadMesh(long, long, long, long);

long ReadMeshPtr(long, long, long, long);

void ReadPBGeometry();

void ReadPhotonData();

void ReadSourceFile(long, double *, double *, double *, double *, double *, 
		    double *, double *, double *, double *);

char *ReadTextFile(char *);

long ReallocMem(long, long);

void ReDistributeStacks();

void ReduceBuffer();

void ReducePrivateRes();

void RefreshInventory();

double RelErr(long, ...);

long RemoveFlaggedItems(long, long, long, long);

void RemoveItem(long);

void Rendezvous(long *, double *);

void ReplaceItem(long, long);

void Reprocess(long);

void ResetOption(long, long);

void ResetPoisonConc();

void ResetTimer(long);

void RetrieveComposition(long, long);

void RIACycle();

void RROutput();

void SABDataTester();

void SabScattering(long, double *, double *, double *, double *, long);

void SampleENDFLaw(long, long, double, double *, double *, long);

double SampleMu(long, double, long);

long SampleNu(double, long);

long SamplePrecursorGroup(long, double, long);

long SampleReaction(long, long, double, double, long);

long SampleSrcPoint(long, long, long);

void Score(long, long, double, double, double, double, double, double, double, 
	   double, double, double, double, double, long);

void ScoreAdjoint(long, long, long, double, double, double, double, double, 
		  double, double, double, double, double, double, long);

void ScoreDF(double, double, double, double, double, double, double, double, 
	     double, long);

void ScorePoison(double, long, double, double, double, long);

void ScorePB(double, double, long);

void ScoreCapture(long, long, double, long);

void ScoreCPD(double, double, double, long);

void ScoreFission(long, long, double, double, double, long, double,
		  double, double, double, long, long, long);

void ScoreGC(double, long, double, double, double, double, long);

void ScoreInterfacePower(double, double, double, double, double, long);

void ScoreMesh(long, long, double, double, double, double, double, double, 
	       double, double, long);

void ScoreScattering(long, long, double, double, double, double, double, long);

void ScoreTemp(long, double, long, double);

void ScoreTimeConstants(double, double, long, long, long);

void ScoreTransmuXS(double, long, double, double, long);

void ScoreUFS(double, long, double, double, double, double, double, double,
	      long);

long SearchArray(const double *, double, long);

long SeekList(long, long, double, long);

long SeekListStr(long, long, char *);

void SetDepStepSize(long, long);

void SetDirectPointers(long);

void SetOption(long, long);

void SetOptimization();

void SetPathLevels(long, long);

void SetPrecursorGroups();

void ShareInputData();

void ShuntingYard(long, long *, long);

unsigned long ReInitRNG(long);

void ReinitTFB();

void SortAll();

void SortArray(double *, long);

void SortList(long, long, long);

double Speed(long, double);

void StartTimer(long);

long StatBin(long, ...);

void StdComp(char *, char *);

double StdDev(long, ...);

long StopAtBoundary (long *, double *, double *, double *, double *, double, 
		     double, double, long);

void StopTimer(long);

void StoreComposition(long, long);

void StoreHistoryPoint(long, long, long, double, double, double, double, 
		       double, double, double, double, double, double, long); 

void StoreSimData();

void StoreTransmuXS(long, long, long, long);

void StoreValuePair(long, double, double, long);

void SumDivCompositions();

double SumPrivateData(long);

double SumPrivateRes(long);

void SumTotXS(long);

void SuperDet(long, double, double, double, double, double, double, double, 
	      double, double, double, long);

double SurfaceDistance(long, const double *, long, long, double, double, 
		       double, double, double, double, long);

void SurfaceSrc(long, long, double *, double *, double *, double *, double *, 
		double *, long);

double SurfaceVol(long);

void SwapItems(long, long);

void SwapUniverses(long, long);

struct ccsMatrix *SymbolicLU(struct ccsMatrix *);

void SystemStat();

void TargetVelocity(long, double, double *, double *, double *, double, double,
		    double, double, long);

void TmpMajorants();

void TestDOSFile(char *);

double TestParam(char *, char *, long, char *, long, ...);

long TestSurface(long, double, double, double, long, long);

double TestValuePair(long, double, long);

void TestXS();

double *ThinGrid(double *, long *, double);

void ThompsonScattering(long, double, double *, double *, double *, long);

long TimeCutoff(long, long, long *, double *, double *, double *, double *, 
		double *, double, double, double, double, double, double, 
		double, double, long, long);

char *TimeIntervalStr(double);

char *TimeStamp();

char *TimeStr(long);

double TimerCPUVal(long);

double TimerVal(long);

void ToBank(long, long);

void ToQue(long, long);

void ToStack(long, long);

double TotXS(long, long, double, long);

void Tracking(long);

long TrackMode(long, long, double, double, long);

void TransportCycle();

double Truncate(double, long);

double *TTA(struct ccsMatrix *, double *, double);

double TTAChain(int, double, double *, double *);

void TTALoop (long, double, long, double *, double, double, double, double, 
	      double *, struct ccsMatrix *,long);

void UCBBurnupCycle();

double UFSFactor(double, double, double);

void UnionizeGrid();

void UniSym(long, double *, double *, double *, double *, double *, double *);

void UniverseBoundaries();

void UpdateTFBgeom(long);

void UpdateTFBhc(long);

double UresFactor(long, double, long);

void UserIFC(long, double *, double *, double, double, double, double, 
	     long, const double *);

void UserSrc(long, double *, double *, double *, double *,  double *, double *,
	     double *, double *, double *, long);

void UserSurf(long, long, const double *, double *, double *, double *, 
	      double *, double *, double *, long *, double *, double, double, 
	      double, double, double, double);

long VrTester(long, double, double, double, double, double, double, double, 
	      double *, long);

void VolumesMC();

void Warn(char *, ...);

long WeightWindow(long, long, double, double, double, double, double, double, 
		  double, double *, double, long);

long WhereAmI(double, double, double, double, double, double, long);

double *WorkArray(long, long, long, long);

void WriteDepFile();

void WriteSourceFile(long, double, double, double, double, double, double, 
		     double, double, double, long);

void XSPlotter();

char *ZAItoIso(long, long);

void ZoneCount(long, long, long);

/*****************************************************************************/

/***** Functions replaced by macros in non-OpenMP mode ***********************/

#ifdef OPEN_MP

#define OMP_THREAD_NUM omp_get_thread_num()

#ifdef DEBUG

void AddPrivateData(long, double, long);
double GetPrivateData(long, long);
void PutPrivateData(long, double, long);

#else

#define AddPrivateData(a,b,c)(PRIVA[a + c*(long)RDB[DATA_REAL_PRIVA_SIZE]] += (double)b)
#define GetPrivateData(a,b)(PRIVA[a + b*(long)RDB[DATA_REAL_PRIVA_SIZE]])
#define PutPrivateData(a,b,c)(PRIVA[a + c*(long)RDB[DATA_REAL_PRIVA_SIZE]] = (double)b)

#endif

#else

#define OMP_THREAD_NUM 0

#ifdef DEBUG

void AddPrivateData(long, double, long);
double GetPrivateData(long, long);
double *PrivateDataPtr(long, long);
void PutPrivateData(long, double, long);

#else 

#define AddPrivateData(a,b,c)(PRIVA[a] += (double)b)
#define GetPrivateData(a,b)(PRIVA[a])
#define PrivateDataPtr(a,b)(&PRIVA[a])
#define PutPrivateData(a,b,c)(PRIVA[a] = (double)b)

#endif

#endif


/*****************************************************************************/

/***** Functions replaced by macros in non-debug mode ************************/

#ifdef DEBUG

void CheckPointer(char *, char *, long, long);

void CheckValue(char *, char *, char *, double, double, double);

long ListPtr(long, long);

long NextItem(long);

long PrevItem(long);

double GetPrivateRes(long);

#else

#define CheckPointer(a, b, c, d)

#define CheckValue(a, b, c, d, e, f)

#define ListPtr(a, b)((long)RDB[(long)RDB[a + LIST_PTR_DIRECT] + b + 1])

#define NextItem(a)((long)RDB[a + LIST_PTR_NEXT])

#define PrevItem(a)((long)RDB[a + LIST_PTR_PREV])

#define GetPrivateRes(a)(RES2[a])

#endif

/*****************************************************************************/

/***** Additional macros *****************************************************/

#define ListCommon(a)((long)RDB[a + LIST_PTR_COMMON])
#define ListSize(a)((long)RDB[ListCommon(a) + LIST_COMMON_N_ITEMS])
#define ListRoot(a)((long)RDB[ListCommon(a) + LIST_COMMON_PTR_ROOT])
#define OMPPtr(a, b)((long)RDB[a] + b)

/*****************************************************************************/

/***** Global arrays and variables *******************************************/
/*                                                                           */
/* Serpent 2 stores data in the following arrays:                            */
/*                                                                           */
/* WDB    Writable main data block that contains nuclear data, geometry,     */
/*        pointters and calculation parameters. Must be OpenMP protected     */
/*        when written during threaded routines.                             */
/*                                                                           */
/* RDB    Pointer to WDB array, but type-cast to constant double. This is to */
/*        induce a compiler warning when trying to write in the main data    */
/*        at the wrong place.                                                */
/*                                                                           */
/* PRV    Data block for storing OpenMP private values. Divided into         */
/*        segments and can be accessed by special routines without atomic or */
/*        critical pragmas.                                                  */
/*                                                                           */
/* BUF    Buffer for storing cycle/batch wise data for statistics. Divided   */
/*        into segments or accessed with atomic pragmas by special routines. */
/*                                                                           */
/* RES1   First results array, used for storing statistics. Not accessed by  */
/*        OpenMP threads.                                                    */
/*                                                                           */
/* RES2   Second results array, containing large tables of integral data for */
/*        which the statistics is not needed. Divided into segments or       */
/*        accessed with atomic pragmas by special routines.                  */
/*                                                                           */
/* ASCII  Data array for storing text strings.                               */
/*                                                                           */
/* ACE    Data array for storing cross sections and nuclide data before      */
/*        processing. Freed before transport cycle.                          */
/*                                                                           */
/*****************************************************************************/

/* Arrays */

double *ACE;
double *WDB;
double *PRIVA;
double *BUF;
double *RES1;
double *RES2;

const double *RDB;

char *ASCII;

/*****************************************************************************/

/* Output pointers */

FILE *err;
FILE *out;

/* Number of mpi tasks and id */

int mpitasks;
int mpiid;

/* Random number seed */

unsigned long parent_seed;

/* Collision counter */

/* Timers */

struct {
  double t0;
  double t;
  double cpu_t0;
  double cpu_t;
  int on;
} timer[TOT_TIMERS + 1];

/*****************************************************************************/
