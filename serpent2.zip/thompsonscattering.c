/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : thompsonscattering.c                           */
/*                                                                           */
/* Created:       2011/04/15 (JLe)                                           */
/* Last modified: 2012/02/12 (JLe)                                           */
/* Version:       2.1.2                                                      */
/*                                                                           */
/* Description: Handles coherent Thompson scattering for photons             */
/*                                                                           */
/* Comments: Kuvaus on kopioitu MCNP5:n rutiinista colidp.F90. Tälle pitäisi */
/*           kaivaa jostain viite LA-5157-MS, ja viitata siihen.             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ThompsonScattering:"

/*****************************************************************************/

void ThompsonScattering(long rea, double E, double *u, double *v, double *w,
			long id)
{
  long ptd, mcoh, loc0, loc1, i;
  double alpha, t3, t5, t7, f, mu;

  /* Check reaction pointer */
 
  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

  /* Pointer to photon reaction data */

  ptd = (long)RDB[rea + REACTION_PTR_PHOTON_DIST];
  CheckPointer(FUNCTION_NAME, "(ptd)", DATA_ARRAY, ptd);

  /* Get size of form factor array */

  mcoh = (long)RDB[ptd + PHOTON_DIST_MCOH];
     
  /* This should be 55 (?) */

  if (mcoh != 55)
    Die(FUNCTION_NAME, "Error in array size");

  /* Get pointer to grids */

  loc0 = (long)RDB[ptd + PHOTON_DIST_PTR_WCO];
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  loc1 = (long)RDB[ptd + PHOTON_DIST_PTR_COH_FFINT];
  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

  /* Photon energy relative to neutron rest mass */

  alpha = E/E_RESTMASS;

  /* Calculate coefficient */

  t5 = 1698.8038*alpha*alpha;

  /* Avoid compiler warning */

  t7 = -1.0;

  /* Find interval from momentum transfer array */

  if ((i = SearchArray(&RDB[loc0], t5, mcoh)) < 0)
    {
      /* Compare to upper limit (lower is not accepted) */

      if (t5 > RDB[loc0 + mcoh - 1])
	t7 = RDB[loc1 + mcoh - 1];
      else
	Die(FUNCTION_NAME, "wtf?");
    }
  else
    {
      /* Check index */

      CheckValue(FUNCTION_NAME, "i", "", i, 0, mcoh - 2);

      /* Calculate interpolation factor */

      f = (t5 - RDB[loc0 + i])/(RDB[loc0 + i + 1] - RDB[loc0 + i]);
      CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);

      /* Interpolate */

      t7 = f*(RDB[loc1 + i + 1] - RDB[loc1 + i]) + RDB[loc1 + i];
    }

  /* Rejection loop */

  do
    {
      /* Sample factor */

      t3 = RandF(id)*t7;

      /* Search interval */

      i = SearchArray(&RDB[loc1], t3, mcoh);
      CheckValue(FUNCTION_NAME, "i", "", i, 0, mcoh - 2);

      /* Calculate ingerpolation factor (tää muutettiin 5.2.2012) */

      f = (t3 - RDB[loc1 + i + 1])/(RDB[loc1 + i] - RDB[loc1 + i + 1]);
      CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);
      
      /* Calculate cosine (ja tää) */
 
      mu = 1.0 
	- 2.0*(RDB[loc0 + i + 1] + f*(RDB[loc0 + i] - RDB[loc0 + i + 1]))/t5;
    }
  while (1.0 + mu*mu < 2.0*RandF(id));

  /* Check cosine */

  CheckValue(FUNCTION_NAME, "mu", "", mu, -1.0, 1.0);

  /* Rotate direction cosines */

  AziRot(mu, u, v, w, id);
}

/*****************************************************************************/
