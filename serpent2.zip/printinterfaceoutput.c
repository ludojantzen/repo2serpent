/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : printinterfaceoutput.c                         */
/*                                                                           */
/* Created:       2012/02/15 (JLe)                                           */
/* Last modified: 2013/04/03 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Prints output for multi-physics interface                    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PrintInterfaceOutput:"

/*****************************************************************************/

void PrintInterfaceOutput()
{
  long loc0, loc1, loc2, nz, nr, n, ptr, i, j, k, uni;
  double zmin, zmax, zl;
  char outfile[MAX_STR];
  FILE *fp;

  /* Check that interfaces are defined */

  if ((long)RDB[DATA_PTR_IFC0] < VALID_PTR)
    return;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check corrector step */

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) 
    return;

  /* Loop over interfaces and remove old output files */

  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Check if printed */
      
      if ((long)RDB[loc0 + IFC_CALC_OUTPUT] == YES)
	{
	  /* File name */
      	  
	  sprintf(outfile, "%s%ld", GetText(loc0 + IFC_PTR_OUTPUT_FNAME),
		  (long)RDB[DATA_BURN_STEP]);

	  /* Remove file */
	  
	  remove(outfile);
	}

      /* Next interface */

      loc0 = NextItem(loc0);
    }

  /* Check for matlab-mode */
 
  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Check if printed */
      
      if ((long)RDB[loc0 + IFC_CALC_OUTPUT] == YES)
	{
	  /* File name */

	  sprintf(outfile, "%s", GetText(loc0 + IFC_PTR_OUTPUT_FNAME));
	  
	  /* Check for ".m" at the end */
	  
	  if (strlen(outfile) > 2)
	    if ((outfile[strlen(outfile) - 1] == 'm') &&
		(outfile[strlen(outfile) - 2] == '.'))
	      {
		/* Open file for writing */
		
		if ((fp = fopen(outfile, "w")) == NULL)
		  Error(loc0, "Unable to open output file for writing");
		
		/* Print */
		
		fprintf(fp, "dat = [\n");
		
		/* Close file */
		
		fclose(fp);
	      }
	}

      /* Next interface */

      loc0 = NextItem(loc0);
    }

  /* Loop over interfaces */
  
  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Check flag */
      
      if ((long)RDB[loc0 + IFC_CALC_OUTPUT] == YES)
	{
	  /* File name */
	  
	  sprintf(outfile, "%s", GetText(loc0 + IFC_PTR_OUTPUT_FNAME));
	  
	  /* Open file for writing */
	  
	  if ((fp = fopen(outfile, "a")) == NULL)
	    Error(loc0, "Unable to open output file for writing");

	  /* Check type */

	  if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_FUEP)
	    {
	      /***************************************************************/

	      /***** Interface to fuel perfomance codes **********************/

	      /* Get pointer */
	      
	      loc1 = (long)RDB[loc0 + IFC_PTR_FUEP];
	      CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);
              
	      /* Loop over pins */

	      while (loc1 > VALID_PTR)
		{
		  /* Pointer to universe */
		  
		  uni = (long)RDB[loc1 + IFC_FUEP_PTR_UNI];
		  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

		  /* Pointer to statistics */
		  
		  ptr = (long)RDB[loc1 + IFC_FUEP_PTR_POWER];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		  /* Get dimensions */
 
		  nz = (long)RDB[loc1 + IFC_FUEP_OUT_NZ];
		  nr = (long)RDB[loc1 + IFC_FUEP_OUT_NR];
		  
		  /* Loop over axial and radial zones */

		  for (i = 0; i < nz; i++)
		    for (j = 0; j < nr; j++)
		      {
			/* Print universe name and indexes */

			fprintf(fp, "%6s %4ld %4ld ",
				GetText(uni + UNIVERSE_PTR_NAME), i + 1, 
				j + 1); 
			
			/* Print z-coordinates */

			ptr = (long)RDB[loc1 + IFC_FUEP_OUT_PTR_Z];
			CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			fprintf(fp, "%12.5E %12.5E ", RDB[ptr + i], 
				RDB[ptr + i + 1]);

			/* Print radii */

			ptr = (long)RDB[loc1 + IFC_FUEP_OUT_PTR_R2];
			CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			fprintf(fp, "%12.5E %12.5E ", sqrt(RDB[ptr + j]), 
				sqrt(RDB[ptr + j + 1]));

			/* Print result */

			ptr = (long)RDB[loc1 + IFC_FUEP_PTR_POWER];
			CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
			fprintf(fp, "%12.5E %7.5f\n", Mean(ptr, i, j), 
				RelErr(ptr, i, j));
		      }

		  /* Next pin */
		  
		  loc1 = NextItem(loc1);
		}

	      /***************************************************************/
	    }
	  else if ((long)RDB[loc0 + IFC_TYPE] == IFC_TYPE_CGNS)
	    {	      
	      /***** CGNS type ***********************************************/

	      /***************************************************************/

	      /* Get pointer to statistics */

	      ptr = (long)RDB[loc0 + IFC_PTR_STAT];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Loop over cells */

	      loc1 = (long)RDB[loc0 + IFC_PTR_CGNS];
	      while (loc1 > VALID_PTR)
		{
		  /* Check stat index */
		  
		  if ((i = (long)RDB[loc1 + IFC_CGNS_STAT_IDX]) > -1)
		    fprintf(fp, "%4ld %4ld %12.5E %7.5f\n",
			    (long)RDB[loc0 + IFC_IDX],
			    (long)RDB[loc1 + IFC_CGNS_IDX],  Mean(ptr, i), 
			    RelErr(ptr, i));
 
		  /* Next cell */

		  loc1 = NextItem(loc1);
		}

	      /***************************************************************/
	    }
	  else
	    {
	      /***************************************************************/

	      /***** Other types *********************************************/

	      /* Get pointer to statistics */

	      ptr = (long)RDB[loc0 + IFC_PTR_STAT];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* get parameters */
	      
	      nz = (long)RDB[loc0 + IFC_NZ];
	      zmin = RDB[loc0 + IFC_ZMIN];
	      zmax = RDB[loc0 + IFC_ZMAX];
	      nr = (long)RDB[loc0 + IFC_NR];
	  
	      /* Calculate length */
	      
	      zl = (zmax - zmin)/((double)nz);
	      
	      /* Loop over output regions */
	      
	      loc1 = (long)RDB[loc0 + IFC_PTR_OUT];
	      while (loc1 > VALID_PTR)
		{   
		  /* Pointer to statistics */

		  if ((loc2 = (long)RDB[loc1 + IFC_OUT_PTR_SCORE]) > VALID_PTR)
		    {
		      /* Get stat index */

		      i = (long)RDB[loc2 + IFC_SCORE_STAT_IDX];
		      CheckValue(FUNCTION_NAME, "i", "", i, 0, 
				 (long)RDB[loc0 + IFC_STAT_NREG]);
		      
		      /* Loop over axial and radial segments */
		      
		      for (n = 0; n < nz; n++)
			for (k = 0; k < nr; k++)
			  {
			    /* Print bottom coordinates */
			    
			    fprintf(fp, "%12.5E %12.5E %12.5E ", 
				    RDB[loc1 + IFC_OUT_X0],
				    RDB[loc1 + IFC_OUT_Y0], zmin + n*zl);
			    
			    /* Print top coordinates */
			    
			    fprintf(fp, "%12.5E %12.5E %12.5E ", 
				    RDB[loc1 + IFC_OUT_X0],
				    RDB[loc1 + IFC_OUT_Y0], zmin + (n + 1)*zl);
			    
			    /* Print radii */
			    
			    fprintf(fp, "%12.5E ", sqrt((double)k/((double)nr))*
				    RDB[loc1 + IFC_OUT_R]);
			    fprintf(fp, "%12.5E ", 
				    sqrt((double)(k + 1.0)/((double)nr))*
				    RDB[loc1 + IFC_OUT_R]);
			    
			    /* Print results */
			    
			    fprintf(fp, "%12.5E %7.5f ", Mean(ptr, i, n, k), 
				    RelErr(ptr, i, n, k));
		      
			    /* Newline */
			    
			    fprintf(fp, "\n");
			  }		  
		    }
		  
		  /* Next region */
		  
		  loc1 = NextItem(loc1);
		}

	      /***************************************************************/
	    }

	  /* Close file */
	  
	  fclose(fp);
	}

      /* Next interface */

      loc0 = NextItem(loc0);
    }

  /* Check for matlab-mode */
 
  loc0 = (long)RDB[DATA_PTR_IFC0];
  while (loc0 > VALID_PTR)
    {
      /* Check if printed */
      
      if ((long)RDB[loc0 + IFC_CALC_OUTPUT] == YES)
	{
	  /* File name */

	  sprintf(outfile, "%s", GetText(loc0 + IFC_PTR_OUTPUT_FNAME));
	  
	  /* Check for ".m" at the end */
	  
	  if (strlen(outfile) > 2)
	    if ((outfile[strlen(outfile) - 1] == 'm') &&
		(outfile[strlen(outfile) - 2] == '.'))
	      {
		/* Open file for reading */

		if ((fp = fopen(outfile, "r")) == NULL)
		  Error(loc0, "Unable to open output file for reading");

		/* Seek to the end */

		fseek(fp, -2, SEEK_END);
	
		/* Check last character */

		if (fgetc(fp) != ';')
		  {
		    /* Close file */

		    fclose(fp);
  
		    /* Open file for writing */
		
		    if ((fp = fopen(outfile, "a")) == NULL)
		      Error(loc0, "Unable to open output file for writing");
		    
		    /* Print */
		    
		    fprintf(fp, "];\n");
		  }
	       
		/* Close file */
		
		fclose(fp);
	      }
	}

      /* Next interface */

      loc0 = NextItem(loc0);
    }
}

/*****************************************************************************/
