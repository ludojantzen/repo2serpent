/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : burnmateriala.c                                */
/*                                                                           */
/* Created:       2011/05/22 (JLe)                                           */
/* Last modified: 2013/03/14 (JLe)                                           */
/* Version:       2.1.13                                                     */
/*                                                                           */
/* Description: Performs burnup calculation for materials                    */
/*                                                                           */
/* Comments: - OpenMP parallelization revised 4.6.2012 (2.1.6)               */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "BurnMaterials:"

/* Use local function to simplify OpenMP implementation */

void BurnMaterials0(long, long, long, long, long);

/* Väliaikainen funktio palamaluennon kuvien plottausta varten */

void Funktio2(long, double, double, struct ccsMatrix *, double *, long);

/*****************************************************************************/

void BurnMaterials(long dep, long step)
{
  long mat, nss, type, mode;

  /***************************************************************************/

  /***** Get parameters ******************************************************/

  /* Get the number of substeps. Constant extrapolation is forced to one */
  /* substep (no point using more) */ 
  
  if ( (long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP )
    {
      if ((long)RDB[DATA_BURN_FIT_TYPE] == PRED_TYPE_CONSTANT)
	nss = 1;
      else
	nss = (long)RDB[DATA_BURN_PRED_NSS];
    }

#ifdef STAB_BURN

  else  /* MODIFIED (AIs) */
    {
      if ((long)RDB[DATA_BURN_FIT_TYPE] == CORR_TYPE_CONSTANT)
	nss = 1;
      else
	nss = (long)RDB[DATA_BURN_CORR_NSS];
    }

#else

  else
    nss = (long)RDB[DATA_BURN_CORR_NSS];

#endif
    
  /* Get step type */
  
  type = (long)RDB[dep + DEP_HIS_STEP_TYPE];

  /* Set burnup mode (override if decay step ) */

  if ((type == DEP_STEP_DEC_STEP) || (type == DEP_STEP_DEC_TOT))
    mode = BUMODE_TTA;
  else
    mode = (long)RDB[DATA_BURN_BUMODE];

  /***************************************************************************/

  /***** Print output ********************************************************/

  fprintf(out, "Running burnup calculation:\n\n");

  fprintf(out, " - Step %ld / %ld ", (long)RDB[DATA_BURN_STEP] + 1, 
	  (long)RDB[DATA_BURN_TOT_STEPS] + 1);
	  
  if (((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE) ||
      (type == DEP_STEP_DEC_TOT) || (type == DEP_STEP_DEC_STEP))
    fprintf(out, "\n");
  else if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    fprintf(out, "(predictor)\n");
  else

#ifdef STAB_BURN

    fprintf(out, "(corrector %ld/%ld)\n", 
            (long)WDB[DATA_BURN_CI_I]+1, (long)WDB[DATA_BURN_CI_MAXI]);

#else

    fprintf(out, "(corrector)\n");

#endif

  if ((type != DEP_STEP_DEC_TOT) && (type != DEP_STEP_DEC_STEP))
    {
      fprintf(out, " - Algorithm: ");

      if ((long)RDB[DATA_BURN_PRED_TYPE] == PRED_TYPE_CONSTANT)
	fprintf(out, "CE");
      else
	fprintf(out, "LE");
      
      if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_CONSTANT)
	fprintf(out, "/CE\n");
      else if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_LINEAR)
	fprintf(out, "/LI\n");
      else if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_QUADRATIC)
	fprintf(out, "/QI\n");
      else
	fprintf(out, "\n");
    }

  fprintf(out, " - Time interval: %s\n", 
	  TimeIntervalStr(RDB[DATA_BURN_TIME_INTERVAL]));
  fprintf(out, " - Burnup interval: %1.2f MWd/kgU\n", 
	  RDB[DATA_BURN_BURNUP_INTERVAL]);

  fprintf(out, " - Cumulative burn time after step: %s\n", 
	  TimeIntervalStr((long)RDB[DATA_BURN_CUM_BURNTIME] +
			  (long)RDB[DATA_BURN_TIME_INTERVAL]));
  fprintf(out, " - Cumulative burnup after step: %1.2f MWd/kgU\n", 
	  RDB[DATA_BURN_CUM_BURNUP] + RDB[DATA_BURN_BURNUP_INTERVAL]);

  if (nss > 1)
    fprintf(out, " - Interval divided into %ld substeps\n", nss);

  if ((type == DEP_STEP_DEC_STEP) || (type == DEP_STEP_DEC_TOT))
    fprintf(out, 
	    " - Decay step, transmutation cross sections not calculated\n");
  else if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
    fprintf(out, " - Transmutation cross sections from spectrum\n");
  else
    fprintf(out, " - Transmutation cross sections from direct tallies\n");
  
  if (mode == BUMODE_TTA)
    fprintf(out, " - Bateman equations solved by linear chains method\n");
  else if (mode == BUMODE_CRAM)
    fprintf(out, " - Bateman equations solved by CRAM\n");

  /* Reduce private results */

  ReducePrivateRes();

  /***************************************************************************/

  /***** Main loop ***********************************************************/

  /* Reset thread numbers */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check thread number */
      
      WDB[mat + MATERIAL_OMP_ID] = -1.0;

      /* Next material */
      
      mat = NextItem(mat);
    }	  

  if ((long)RDB[DATA_N_BURN_MATERIALS] > 1)
    fprintf(out, "\nBurning %ld materials:\n\n", 
	    (long)RDB[DATA_N_BURN_MATERIALS]);
  else
    fprintf(out, "\nBurning material:\n\n");

  /* Print */

  PrintProgress(0, 0);

  /* Start parallel timer */

  StartTimer(TIMER_OMP_PARA);

#ifdef OPEN_MP
#pragma omp parallel private (mat)
#endif
  {
    /* Loop over materials */
    
    mat = (long)RDB[DATA_PTR_M0];
    while (mat > VALID_PTR)
      {
	/* Check burn flag and test parallel id's */

	if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	  if (MyParallelMat(mat, YES) == YES)
	    {
	      /* Burn */
	      
	      BurnMaterials0(mat, step, nss, type, mode);	
	      
	      /* Print */
	      
	      PrintProgress(mat, 2);
	    }
	
	/* Next material */
	
	mat = NextItem(mat);
      }
  }
  
  /* Stop parallel timer */

  StopTimer(TIMER_OMP_PARA);

  /* Copy compositions to parent materials */

  SumDivCompositions();

  /* Print */
  
  PrintProgress(0, 100);
   
  /***************************************************************************/
}

/*****************************************************************************/

/*****************************************************************************/

void BurnMaterials0(long mat, long step, long nss, long type, long mode)
{
  long iso, ptr, lst, i, sz, ss, id;
  double t, t1, t2, tot, *N, *N0; 
  struct ccsMatrix *A; 

  /* Check divisor type */

  if ((long)RDB[mat + MATERIAL_DIV_TYPE] == MAT_DIV_TYPE_PARENT)
    Die(FUNCTION_NAME, "Divided parent material");

  /* Avoid compiler warning */

  A = NULL; 
  N = NULL; 
  N0 = NULL;

  /* Get OpenMP id */

  id = OMP_THREAD_NUM;

  /* Get time step length */
      
  t = RDB[DATA_BURN_TIME_INTERVAL];
  CheckValue(FUNCTION_NAME, "t", "", t, ZERO, INFTY);

  /* Calculate transmutation cross sections */

  if ((type != DEP_STEP_DEC_STEP) && (type != DEP_STEP_DEC_TOT))
    CalculateTransmuXS(mat, id);

  /* Store the xs from above */
      
  StoreTransmuXS(mat, step, type, id);

  /* Size of composition vector */
  
  ptr = (long)RDB[mat + MATERIAL_PTR_COMP];
  sz = ListSize(ptr);
  
  /* Allocate memory for composition vectors */

  N0 = (double *)Mem(MEM_ALLOC, sz, sizeof(double));
  /*

  N0 = WorkArray(DATA_PTR_WORK_COMP1, PRIVA_ARRAY, sz, id);
  */
  /* Copy composition to N0. On predictor also store it for corrector */
  
  i = 0;
  lst = (long)RDB[mat + MATERIAL_PTR_COMP];
  
  if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    {
      /* Predictor step, copy composition to N0 and BOS for corrector */
      
      while ((iso = ListPtr(lst, i)) > VALID_PTR)
	{
	  WDB[iso + COMPOSITION_ADENS_BOS] = 
	    RDB[iso + COMPOSITION_ADENS];
	  N0[i++] = RDB[iso + COMPOSITION_ADENS_BOS];
	}
    }
  else
    {
      /* Correcor step, copy composition from BOS to N0 */
      
      while ((iso = ListPtr(lst, i)) > VALID_PTR)
	N0[i++] = RDB[iso + COMPOSITION_ADENS_BOS];
    }
  
  /* Check size */
  
  if (i != sz)
    Die(FUNCTION_NAME, "Mismatch in size");

  /***************************************************************************/

  /***** Loop over substeps **************************************************/

  for (ss = 0; ss < nss; ss++)
    {          
      /* substep beginning and end times */
      
      t1 = t*ss/nss;
      t2 = t*(ss + 1)/nss;

      /* calculate weighted xs and flux */

      AverageTransmuXS(mat, t1, t2, id);

      /* Create burnup matrix */
      
      A = MakeBurnMatrix(mat, id);

      /* Check size (sz == i tarkistettiin jo aikaisemmin) */
      
      if (sz != A->n)
	Die(FUNCTION_NAME, "Mismatch in size");
      
      /* Print depletion matrix */

      PrintDepMatrix(mat, A, t2 - t1, N0, N0, id);

      Funktio2(mat, t1, t2, A, N0, id);

      /* Calculate material-wise burnup */

      MaterialBurnup(mat, N0, t2 - t1, id);

      /* Start burnup equation timers */
      
      ResetTimer(TIMER_BATEMAN);
      StartTimer(TIMER_BATEMAN);
      StartTimer(TIMER_BATEMAN_TOTAL);

      /* Override burnup mode if flux is very low */

      if (RDB[mat + MATERIAL_BURN_FLUX_SSA] < 1E-6)
	mode = BUMODE_TTA;

      /* Solve depletion equations */

      if (mode == BUMODE_TTA)
	N = TTA(A, N0, t2 - t1);
      else if (mode == BUMODE_CRAM)
	N = MatrixExponential(A, N0, t2 - t1); 
      else
	Die(FUNCTION_NAME, "Invalid burnup mode");

      /* Stop timers */
      
      StopTimer(TIMER_BATEMAN);
      StopTimer(TIMER_BATEMAN_TOTAL);
      
      /* Print depletion matrix with final composition */
      
      PrintDepMatrix(mat, A, t2 - t1, N0, N, id); 

      /* Free burnup matrix and N0 (which is no longer needed)*/
      
      ccsMatrixFree(A);


      Mem(MEM_FREE, N0); 

      /* the final composition becomes initial for the next substep */
      
      N0 = N;
    } 
  
  /***************************************************************************/

  /***** Put final composition ***********************************************/
  
  /* Reset index and total atomic density */
      
  i = 0;
  tot = 0.0;
  
  /* Update composition */
  
  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > VALID_PTR)
    {
      /* Put atomic density */
      
      WDB[iso + COMPOSITION_ADENS] = N[i++];    
      
      /* Add to total */
      
      tot = tot + RDB[iso + COMPOSITION_ADENS]; 
      
      /* Next nuclide */
      
      iso = NextItem(iso);                       
    }
  
  /* Put total atomic density */
  
  WDB[mat + MATERIAL_ADENS] = tot;
  
  /* Free composition vectors (at this point N = N0) */
  
  /*
  Mem(MEM_FREE, N); 
  */
}

/*****************************************************************************/

void Funktio2(long mat, double t1, double t2, struct ccsMatrix *A, double *N, 
	     long id)
{
  long tgt, i, j, iso, nuc, idx;
  FILE *fp;
  char tmpstr[MAX_STR];

  return;

  sprintf(tmpstr, "%s_dataa2.m", GetText(DATA_PTR_INPUT_FNAME));

  if (strcmp(GetText(mat + MATERIAL_PTR_NAME), "UO2Gdp2r10"))
    return;

  fp = fopen(tmpstr, "a");

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP)
    {
      idx = 2;
      sprintf(tmpstr, "corr");
    }
  else
    {
      idx = 1;
      sprintf(tmpstr, "pred");
    }
  
  fprintf(fp, "idx%ld = idx%ld + 1;\n", idx, idx);

  t1 = t1 + RDB[DATA_BURN_CUM_BURNTIME];
  t2 = t2 + RDB[DATA_BURN_CUM_BURNTIME];



  fprintf(fp, "%s_prod(idx%ld) = 0.0;\n", tmpstr, idx);
  fprintf(fp, "%s_t1(idx%ld) = %E;\n", tmpstr, idx, t1);
  fprintf(fp, "%s_t2(idx%ld) = %E;\n", tmpstr, idx, t2);

  /* Loop over composition and print */

  i = -1;
  tgt = -1;

  iso = (long)RDB[mat + MATERIAL_PTR_COMP]; 
  while (iso > VALID_PTR)
    {
      /* Pointer to nuclide */

      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];

      /* Get nuclide index */
      
      tgt = TestValuePair(nuc + NUCLIDE_PTR_MATRIX_IDX, (double)mat, id);

      if ((long)RDB[nuc + NUCLIDE_ZAI] == 531310)
	break;

      /* Next isotope */

      iso = NextItem(iso);
    }

  fprintf(fp, "%s_N0(idx%ld) = %E;\n", tmpstr, idx, N[tgt]);

  for (i = 0; i < A->m; i++)
    for (j = A->colptr[i]; j < A->colptr[i + 1]; j++)
      if (A->rowind[j] == tgt)
	{
	  if (A->values[j].re < 0.0)
	    fprintf(fp, "%s_lambda(idx%ld) = %E;\n", tmpstr, idx, -A->values[j].re);
	  else
	    fprintf(fp, "%s_prod(idx%ld) = %s_prod(idx%ld) + %E;\n", tmpstr, idx,
		    tmpstr, idx, A->values[j].re*N[i]);
	}
  
  /* Close file */
	  
  fclose(fp);
}
